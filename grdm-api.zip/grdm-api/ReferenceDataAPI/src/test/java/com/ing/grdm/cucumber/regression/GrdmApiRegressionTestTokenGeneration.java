package com.ing.grdm.cucumber.regression;

import com.ing.grdm.cucumber.delegate.GrdmApiTestStepsDelegate;
import cucumber.api.java.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import java.io.IOException;
import java.net.URISyntaxException;

/**
 * Generates security token needed to execute GRDM APIs regression test steps
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 07-12-2017
 */
public class GrdmApiRegressionTestTokenGeneration {

	@Autowired
	@Qualifier("grdmApiTestStepsDelegate")
	private GrdmApiTestStepsDelegate delegate;

	@Before
	public void login() throws IOException, URISyntaxException {
		this.delegate.login();
	}
}
