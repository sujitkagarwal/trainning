package com.ing.grdm.api.response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.cache.AttributesDataCache;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.IOException;
import java.io.Writer;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;

/**
 * Unit tests for {@link CachedAttributesResponseService}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class CachedAttributeResponseServiceTest {

	@Mock
	private AttributesDataCache cache;

	@Mock
	private AttributesDataSerializer serializer;

	@Spy
	private ObjectMapper objectMapper;

	@InjectMocks
	private AttributesResponseService responseService = new CachedAttributesResponseService();

	@Before
	public void init() throws IOException {
		doReturn(TRUE).when(this.cache).containsTable("country");
		doReturn(FALSE).when(this.cache).containsTable("none");
		doReturn(TRUE).when(this.cache).containsColumns("country", Arrays.asList("code", "description"));
		doReturn(FALSE).when(this.cache).containsColumns("country", Arrays.asList("none", "exist"));
		doReturn("country_business_keys").when(this.cache).getBusinessKeysByDistributionName("country");
		doAnswer(invocation -> {
			final Map<String, Object> map = new HashMap<>();
			map.put("key", "value");
			return map;
		}).when(this.cache).getColumnsByDistributionNameAndBusinessKey("country", "nl");
		doReturn(null).when(this.cache).getColumnsByDistributionNameAndBusinessKey("country", "uk");
		doAnswer(invocation -> {
			final Writer writer = invocation.getArgument(0);
			writer.write("country_business_keys_with_columns");
			return null;
		}).when(this.serializer).serializeTableData(Mockito.any(), Mockito.anyMap(), Mockito.anyList());
	}

	@Test
	public void testRespondAttributesByTableName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"country", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(200));
		assertThat(response.getContentAsString(), is("country_business_keys"));
	}

	@Test
	public void testRespondAttributesByTableNameWithColumn() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"country", Arrays.asList("code", "description"), response);
		assertThat(response.getStatus(), is(200));
		assertThat(response.getContentAsString(), is("country_business_keys_with_columns"));
	}

	@Test
	public void testRespondAttributesByTableNameIllegalDistributionName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"country$", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid table name provided");
	}

	@Test
	public void testRespondAttributesByTableNameIllegalColumnNames() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"country", Arrays.asList("code$", "description"), response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid column name(s) provided");
	}

	@Test
	public void testRespondAttributesByTableNameNoTable() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"none", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(404));
		verifyErrorJson(response.getContentAsString(), 404, "No table found");
	}

	@Test
	public void testRespondAttributesByTableNameNoColumns() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableName(
				"country", Arrays.asList("none", "exist"), response);
		assertThat(response.getStatus(), is(404));
		verifyErrorJson(response.getContentAsString(), 404, "No columns found");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKey() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "nl", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(200));
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyWithColumns() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "nl", Arrays.asList("code", "description"), response);
		assertThat(response.getStatus(), is(200));
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyIllegalDistributionName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country$", "nl", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid table name provided");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyIllegalBusinessKey() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "nl$", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid business key provided");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyIllegalColumnNames() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "nl", Arrays.asList("code$", "description"), response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid column name(s) provided");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyNoBusinessKey() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "uk", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(404));
		verifyErrorJson(response.getContentAsString(), 404, "No record found");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyNoTable() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"none", "nl", Collections.emptyList(), response);
		assertThat(response.getStatus(), is(404));
		verifyErrorJson(response.getContentAsString(), 404, "No table found");
	}

	@Test
	public void testRespondAttributesByTableNameAndBusinessKeyNoColumns() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondAttributesByTableNameAndBusinessKey(
				"country", "nl", Arrays.asList("none", "exist"), response);
		assertThat(response.getStatus(), is(404));
		verifyErrorJson(response.getContentAsString(), 404, "No columns found");
	}

	@Test(expected = IOException.class)
	public void testRespondAttributesByTableNameIOException() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		doThrow(IOException.class).when(this.serializer)
				.serializeTableData(Mockito.any(), Mockito.anyMap(), Mockito.anyList());
		this.responseService.respondAttributesByTableName(
				"country", Arrays.asList("code", "description"), response);
	}

	private void verifyErrorJson(String content, int code, String messageContains) {
		new JsonPathExpectationsHelper("$.code").assertValue(content, code);
		new JsonPathExpectationsHelper("$.message")
				.assertValue(content, containsString(messageContains), String.class);
	}
}
