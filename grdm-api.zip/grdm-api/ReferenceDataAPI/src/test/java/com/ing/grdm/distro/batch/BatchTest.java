package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.database.GrdmDatabaseConfig;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.domain.DistributionImportStatus;
import com.ing.grdm.scheduling.GrdmJobScheduler;
import org.junit.After;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Bean;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.URISyntaxException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Unit tests for the batch job importing SDM distributions
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {BatchConfig.class, GrdmDatabaseConfig.class, GrdmJobScheduler.class})
@DataJpaTest
@Commit
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class BatchTest {

	public static class TestConfig {
		@Bean
		JobLauncherTestUtils jobLauncherTestUtils() {
			return new JobLauncherTestUtils();
		}
	}

	@Autowired
	private JobLauncherTestUtils jobLauncher;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@After
	public void after() {
		// The job tested commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to verify the data inserted in the database by the jobs/steps
		this.categoryDefinitionRepository.deleteAll();
		this.categoryDefinitionDistributionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	@Test
	@Ignore // Worksn't because JobLauncherTestUtils cannot invoke a individual step launched by a partitioner
	public void testDataStep() throws InterruptedException, URISyntaxException {
		final String uri = Thread.currentThread().getContextClassLoader().getResource("0002_COUNTRY_Attributes.xml").toURI().toString();
		final JobParameters parameters = new JobParametersBuilder()
				.addLong("categoryDefinitionId", 2L)
				.addLong("distributionSequenceNumber", 1L)
				.addString("zipFileUri", uri)
				.toJobParameters();
		final JobExecution jobExecution = this.jobLauncher.launchStep("xmlFileStep", parameters);

		int count = 0;
		do {
			TimeUnit.SECONDS.sleep(2L);
		} while (jobExecution.isRunning() && count++ < 10);

		Assert.assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());

		final List<ApiDataValue> rowData = this.dataValueRepository.getRowData(2L, 1, "NL");
		Assert.assertNotNull(rowData);
		Assert.assertFalse(rowData.isEmpty());
	}

	@Test
	public void testJob() throws Exception {
		final String uri = Thread.currentThread().getContextClassLoader().getResource("SDM_20170925_120000_1_xml.zip").toURI().toString();
		final JobParameters parameters = new JobParametersBuilder()
				.addString("zipFileUri", uri)
				.addLong("distributionSequenceNumber", 1L)
				.toJobParameters();
		final JobExecution jobExecution = this.jobLauncher.launchJob(parameters);

		int count = 0;
		do {
			TimeUnit.SECONDS.sleep(2L);
		} while (jobExecution.isRunning() && count++ < 10);

		Assert.assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		final ApiCategoryDefinition categoryDefinition = this.categoryDefinitionRepository.findByDistributionName("COUNTRY");
		Assert.assertNotNull(categoryDefinition);
		Assert.assertEquals(Integer.valueOf(1), categoryDefinition.getActiveDistributionSequenceNumber());

		final ApiCategoryDefinitionDistribution categoryDefinitionImport = this.categoryDefinitionDistributionRepository.findOne(
				new ApiCategoryDefinitionDistributionId(categoryDefinition.getTechnicalId(), 1));
		Assert.assertNotNull(categoryDefinitionImport);
		Assert.assertEquals(DistributionImportStatus.ACTIVE, categoryDefinitionImport.getStatus());

		final List<String> tableData = this.dataValueRepository.getTableData(categoryDefinition.getTechnicalId(), 1);
		Assert.assertFalse(tableData.isEmpty());

		final List<ApiDataValue> dataValues = this.dataValueRepository.getRowData(categoryDefinition.getTechnicalId(), 1, "NL");
		Assert.assertNotNull(dataValues);
		Assert.assertFalse(dataValues.isEmpty());

		final ApiDataValue dataValue = dataValues.stream()
				.filter(dv -> "DOMESTIC_MACRO_RATING".equals(dv.getColumnName()))
				.findFirst()
				.orElse(null);
		Assert.assertNotNull(dataValue);
		Assert.assertEquals("NL", dataValue.getBusinessKey());
		Assert.assertEquals(4, dataValue.getColumnOrderNumber());
		Assert.assertEquals(ColumnType.REFERENCE, dataValue.getColumnType());
		Assert.assertEquals("RISK_RATING", dataValue.getReferenceTable());
	}
}
