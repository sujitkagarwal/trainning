package com.ing.grdm.api.controller;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.cache.SearchCache;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit test for {@link GrdmApiReferenceDataController}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class)
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class GrdmApiReferenceDataControllerTest {

	@Autowired
	private GrdmApiReferenceDataController referenceDataController;
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private GrdmApiCategoryDefinitionRepository apiCategoryDefinitionRepository;
	@MockBean
	private GrdmApiDataValueRepository apiDataValueRepository;
	@MockBean
	private SearchCache searchCache;

	@Test
	public void controllerInitializedCorrectly() {
		assertThat(referenceDataController).isNotNull();
	}

	@Test
	public void testAttributesByTableName() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		List<String> businessKeys = Arrays.asList("NEAS", "AD");
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableData(Mockito.anyLong(), Mockito.anyInt())).thenReturn(businessKeys);
		mockMvc.perform(get("/attributes/country"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[1].business_key", is("AD")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getTableData(Mockito.anyLong(), Mockito.anyInt());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(createApiDataValue(1604, 134, "NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
						createApiDataValue(1604, 134, "NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2),
						createApiDataValue(1604, 134, "NEAS", "CRS_COMMITTED", "N", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR"),
						createApiDataValue(1604, 134, "NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26),
						createApiDataValue(1604, 134, "NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14),
						createApiDataValue(1604, 134, "NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20),
						createApiDataValue(1604, 134, "NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22),
						createApiDataValue(1604, 134, "AD", "CCRM_CODE", "AD", ColumnType.STRING, 1),
						createApiDataValue(1604, 134, "AD", "DESCRIPTION", "Andorra", ColumnType.STRING, 2),
						createApiDataValue(1604, 134, "AD", "CRS_COMMITTED", "Y", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR"));
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.any())).thenReturn(
				apiDataValues);
		mockMvc.perform(get("/attributes/country?column=CCRM_CODE&column=DESCRIPTION&column=CRS_COMMITTED&column=KMV_BUCKET_NUMBER&column=ASSETS_BIGGEST_BANK&column=REFERENCE_DATE&column=PERCENTAGE"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[0].ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$[0].description", is("Northeast Asia")))
				.andExpect(jsonPath("$[0].crs_committed.value", is("N")))
				.andExpect(jsonPath("$[0].crs_committed.table", is("yes_no_indicator")))
				.andExpect(jsonPath("$[0].kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$[0].assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$[0].reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$[0].percentage", is(30.00000000)))
				.andExpect(jsonPath("$[1].business_key", is("AD")))
				.andExpect(jsonPath("$[1].ccrm_code", is("AD")))
				.andExpect(jsonPath("$[1].description", is("Andorra")))
				.andExpect(jsonPath("$[1].crs_committed.value", is("Y")))
				.andExpect(jsonPath("$[0].crs_committed.table", is("yes_no_indicator")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getTableDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableName_DistributionNameNotFound() throws Exception {
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(null);
		mockMvc.perform(get("/attributes/country"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No table found with distribution name 'country'")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(0)).getTableData(Mockito.anyLong(), Mockito.anyInt());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableName_ColumnNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.any())).thenReturn(
				Collections.emptyList());
		mockMvc.perform(get("/attributes/country?column=description"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No columns found in table country with name(s) 'description'")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getTableDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableName_InvalidDistributionName() throws Exception {
		mockMvc.perform(get("/attributes/country$"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid table name provided")));
		verify(apiCategoryDefinitionRepository, never()).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableName_InvalidColumnNames() throws Exception {
		mockMvc.perform(get("/attributes/country?column=de$cription"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid column name(s) provided")));
		verify(apiCategoryDefinitionRepository, never()).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(createApiDataValue(1604, 134, "NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
						createApiDataValue(1604, 134, "NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2),
						createApiDataValue(1604, 134, "NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26),
						createApiDataValue(1604, 134, "NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14),
						createApiDataValue(1604, 134, "NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20),
						createApiDataValue(1604, 134, "NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22));

		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.description", is("Northeast Asia")))
				.andExpect(jsonPath("$.kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$.assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$.reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$.percentage", is(30.00000000)));

		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKeyWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(createApiDataValue(1604, 134, "NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
						createApiDataValue(1604, 134, "NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2));
		List<String> columns = Arrays.asList("CCRM_CODE", "DESCRIPTION");
		when(apiCategoryDefinitionRepository.findByDistributionName("COUNTRY")).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowDataByColumns(1604, 134, "NEAS", columns)).thenReturn(
				apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS?column=CCRM_CODE&column=DESCRIPTION"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.description", is("Northeast Asia")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getRowDataByColumns(1604, 134, "NEAS", columns);
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_DistributionNameNotFound() throws Exception {
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(null);
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No table found with distribution name 'country'")));

		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(0)).getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_BusinessKeyNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
				new ArrayList<>());
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No record found with business key 'NEAS' in table country")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_ColumnNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(1604L, "COUNTRY", "ATTRIBUTES", 134);
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString())).thenReturn(
				new ArrayList<>());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No record found with business key 'NEAS' or columns with name(s) 'description' in table country")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, times(1)).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_IllegalArgumentException() throws Exception {
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenThrow(new IllegalArgumentException());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Bad Request")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_RuntimeException() throws Exception {
		when(apiCategoryDefinitionRepository.findByDistributionName(Mockito.anyString())).thenThrow(new RuntimeException());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.code", is(500)))
				.andExpect(jsonPath("$.message", is("Internal Server Error")));
		verify(apiCategoryDefinitionRepository, times(1)).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidDistributionName() throws Exception {
		mockMvc.perform(get("/attributes/country$/NEAS"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid table name provided")));
		verify(apiCategoryDefinitionRepository, never()).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidBusinessKey() throws Exception {
		mockMvc.perform(get("/attributes/country/NEAS$"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid business key provided")));
		verify(apiCategoryDefinitionRepository, never()).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidColumnNames() throws Exception {
		mockMvc.perform(get("/attributes/country/NEAS?column=de$cription"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid column name(s) provided")));
		verify(apiCategoryDefinitionRepository, never()).findByDistributionName(Mockito.anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	private ApiCategoryDefinition createApiCategoryDefinition(Long categoryDefinitionId, String distributionName, String categoryType,
															  Integer activeDistributionSequenceNumber) {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(activeDistributionSequenceNumber);
		apiCategoryDefinition.setDistributionName(distributionName);
		apiCategoryDefinition.setCategoryType(categoryType);
		apiCategoryDefinition.setTechnicalId(categoryDefinitionId);
		return apiCategoryDefinition;
	}

	private ApiDataValue createApiDataValue(long categoryDefinitionId, int distributionSequenceNumber, String businessKey,
											String columnName, String storageString, ColumnType columnType,
											int columnOrderNumber) {
		return createApiDataValue(categoryDefinitionId, distributionSequenceNumber, businessKey, columnName,
				storageString, columnType, columnOrderNumber, null);
	}

	private ApiDataValue createApiDataValue(long categoryDefinitionId, int distributionSequenceNumber, String businessKey,
											String columnName, String storageString, ColumnType columnType,
											int columnOrderNumber, String referenceTable) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(distributionSequenceNumber);
		apiDataValue.setColumnType(columnType);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(columnOrderNumber);
		apiDataValue.setBusinessKey(businessKey);
		apiDataValue.setReferenceTable(referenceTable);
		return apiDataValue;
	}
}