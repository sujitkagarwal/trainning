package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link AttributesDataCache}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = { "grdm.cache.enabled=true",
		"grdm.cache.categories.exclude=gender" })
@RunWith(SpringRunner.class)
public class AttributesDataCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private AttributesDataCache cache;

	@Test
	public void testReloadAndCaseSensitivity() {

		// containsTable is case insensitive
		assertThat(this.cache.containsTable("COUNTRY"), is(false));
		assertThat(this.cache.containsTable("CoUnTry"), is(false));
		assertThat(this.cache.containsTable("country"), is(false));

		// containsBusinessKey is case insensitive, columns are case insensitive
		assertThat(this.cache.containsColumns("CoUnTry", Collections.singletonList("DESCRIPTION")), is(false));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("DeScRiPtIoN")), is(false));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("description")), is(false));

		// distributionName is case insensitive
		assertThat(this.cache.getColumnsByDistributionName("COUNTRY"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("CoUnTrY"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("country"), is(Collections.emptyMap()));

		// businessKey is case sensitive
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "NL"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "Nl"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "nl"), is(Collections.emptyMap()));

		// Signal cache to reload
		this.cache.init();

		// containsTable is case insensitive
		assertThat(this.cache.containsTable("COUNTRY"), is(true));
		assertThat(this.cache.containsTable("CoUnTry"), is(true));
		assertThat(this.cache.containsTable("country"), is(true));

		// containsBusinessKey is case insensitive, columns are case insensitive
		assertThat(this.cache.containsColumns("CoUnTry", Collections.singletonList("DESCRIPTION")), is(true));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("DeScRiPtIoN")), is(true));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("description")), is(true));

		// verify containsTable is case insensitive and table excluded in cache
		assertThat(this.cache.containsTable("GENDER"), is(false));
		assertThat(this.cache.containsTable("GenDer"), is(false));
		assertThat(this.cache.containsTable("gender"), is(false));

		// verify containsBusinessKey is case insensitive, columns are case insensitive and table excluded in cache
		assertThat(this.cache.containsColumns("GENDER", Collections.singletonList("DESCRIPTION")), is(false));
		assertThat(this.cache.containsColumns("GenDer", Collections.singletonList("DeScRiPtIoN")), is(false));
		assertThat(this.cache.containsColumns("gender", Collections.singletonList("description")), is(false));

		// verify distributionName is case insensitive and table excluded in cache
		assertThat(this.cache.getColumnsByDistributionName("GENDER"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("GenDer"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("gender"), is(Collections.emptyMap()));

		// verify businessKey is case sensitive and table excluded in cache
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("GENDER", "F"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("GENDER", "f"), is(Collections.emptyMap()));

		// getColumnsByDistributionName, distributionName is case insensitive
		final Map<String, Map<String, Object>> tableData = this.cache.getColumnsByDistributionName("CoUnTrY");

		// businessKey is case sensitive
		assertThat(tableData.containsKey("NL"), is(true));
		assertThat(tableData.containsKey("nl"), is(false));

		// returned columnName is uppercase, storage string is case sensitive
		assertThat(tableData.get("NL").containsKey("description"), is(true));
		assertThat(tableData.get("NL").containsKey("DESCRIPTION"), is(false));
		assertThat(tableData.get("NL").get("description"), is("Netherlands"));

		// getColumnsByDistributionNameAndBusinessKey, distributionName is case sensitive, businessKey is case sensitive
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("CoUnTrY", "Nl"), is(Collections.emptyMap()));

		final Map<String, Object> columnData = this.cache.getColumnsByDistributionNameAndBusinessKey("CoUnTrY", "NL");
		assertThat(columnData, is(notNullValue()));

		// returned columnNames are in uppercase
		assertThat(columnData.containsKey("description"), is(true));
		assertThat(columnData.containsKey("DESCRIPTION"), is(false));
		assertThat(columnData.get("description"), is("Netherlands"));
	}

	@Before
	public void loadApiCategoryDefinition() {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Netherlands", "NL");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("GENDER");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Female", "F");
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String storageString, String businessKey) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName("DESCRIPTION");
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}
