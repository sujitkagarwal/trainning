package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.google.common.collect.Table;
import com.google.common.collect.TreeBasedTable;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.ing.grdm.domain.ColumnType.NUMBER;
import static com.ing.grdm.domain.ColumnType.STRING;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link AttributesDataSerializer}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class AttributesDataSerializerTest {

	@Spy
	private JsonFactory jsonFactory = new JsonFactory(new ObjectMapper());

	@InjectMocks
	private AttributesDataSerializer serializer = new AttributesDataSerializer();

	@Test
	public void testSerializeBusinessKeys() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeBusinessKeys(writer, Arrays.asList("nl", "uk"));
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "nl");
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "uk");
		verify(this.jsonFactory, Mockito.times(1)).createGenerator(writer);
	}

	@Test
	public void testSerializeTableData() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeTableData(writer, createTableData(), Collections.emptyList());
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
	}

	@Test
	public void testSerializeTableDataWithColumns() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeTableData(writer, createTableData(), Arrays.asList("code", "people"));
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
	}

	@Test
	public void testSerializeRowData() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeRowData(writer, "NL", createTableData().get("NL"), Collections.emptyList());
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeRowDataWithColumns() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeRowData(writer, "NL", createTableData().get("NL"), Arrays.asList("code", "people"));
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").doesNotExist(content);
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeRowDataTableData() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeRowData(writer, createApiTableData(), true);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
	}

	@Test
	public void testSerializeRowDataRowData() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeRowData(writer, createApiRowData(), false);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test(expected = IOException.class)
	public void testSerializeTableDataIOException() throws IOException {
		final Writer writer = Mockito.mock(Writer.class);
		doThrow(IOException.class).when(writer).flush();
		this.serializer.serializeTableData(writer, createTableData(), Collections.emptyList());
	}

	private Map<String, Map<String, Object>> createTableData() {
		final Table<String, String, Object> table = TreeBasedTable.create();
		table.put("NL", "code", "NL");
		table.put("NL", "description", "Netherlands");
		table.put("NL", "people", 17);
		table.put("UK", "code", "UK");
		table.put("UK", "description", "United Kingdom");
		table.put("UK", "people", 65);
		return table.rowMap();
	}

	private List<ApiDataValue> createApiTableData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "code", STRING, "NL"),
				createApiDataValue("NL", "description", STRING, "Netherlands"),
				createApiDataValue("NL", "people", NUMBER, "17"),
				createApiDataValue("UK", "code", STRING, "UK"),
				createApiDataValue("UK", "description", STRING, "United Kingdom"),
				createApiDataValue("UK", "people", NUMBER, "65")
		);
	}

	private List<ApiDataValue> createApiRowData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "code", STRING, "NL"),
				createApiDataValue("NL", "description", STRING, "Netherlands"),
				createApiDataValue("NL", "people", NUMBER, "17")
		);
	}

	private ApiDataValue createApiDataValue(String businessKey, String columnName, ColumnType columnType, String storageString) {
		ApiDataValue dataValue = new ApiDataValue();
		dataValue.setBusinessKey(businessKey);
		dataValue.setColumnName(columnName);
		dataValue.setColumnType(columnType);
		dataValue.setStorageString(storageString);
		return dataValue;
	}
}
