package com.ing.grdm.cucumber.integration;

import com.ing.grdm.api.GrdmApiApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.grdm.event.OverstapDataChangedEvent;
import org.apache.http.client.HttpClient;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.SyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import javax.annotation.PostConstruct;
import java.net.URISyntaxException;
import java.util.Date;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Configuration for the integration test. The integration test starts a local server where the individual
 * tests are performed on.
 */
@ContextConfiguration(classes = GrdmApiIntegrationTestConfiguration.Config.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = GrdmApiApplication.class, properties = {"grdm.cache.overstap.enable=true"})
@Commit
@ActiveProfiles("test")
@SuppressWarnings("unused")
class GrdmApiIntegrationTestConfiguration {

	@LocalServerPort
	private int port;
	@Autowired
	private JobLauncher jobLauncher;
	@Autowired
	@Qualifier(value = "xmlFileJob")
	private Job xmlFileJob;
	@Autowired
	private URIBuilder uriBuilder;
	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;
	@Autowired
	private ApplicationEventPublisher publisher;

	@PostConstruct
	void postConstruct() {
		this.uriBuilder.setPort(this.port);
	}

	void setup() throws URISyntaxException, JobExecutionException {
		// Load some data in the in-memory database
		final String uri = Thread.currentThread().getContextClassLoader().getResource("SDM_20170925_120000_1_xml.zip").toURI().toString();
		final JobParameters parameters = new JobParametersBuilder()
				.addString("zipFileUri", uri)
				.addLong("distributionSequenceNumber", 3L)
				.addDate("date", new Date())
				.toJobParameters();
		this.jobLauncher.run(xmlFileJob, parameters);
		//this is required to load the data in cache.
		publisher.publishEvent(new AttributesDataChangedEvent());
		publisher.publishEvent(new OverstapDataChangedEvent());
	}

	void cleanUp() {
		// The job tested commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to verify the data inserted in the database by the jobs/steps
		this.categoryDefinitionRepository.deleteAll();
		this.categoryDefinitionDistributionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
		assertThat(this.categoryDefinitionRepository.count(), is(0L));
		assertThat(this.categoryDefinitionDistributionRepository.count(), is(0L));
		assertThat(this.dataValueRepository.count(), is(0L));
	}

	@Configuration
	@ComponentScan(basePackages = "com.ing.grdm.cucumber.delegate")
	static class Config {

		@Bean
		HttpClient httpClient() {
			return HttpClients.createDefault();
		}

		@Bean(name = "jobTaskExecutor")
		@Primary
		TaskExecutor jobTaskExecutor() {
			// Override the jobTaskExecutor to force job launcher running jobs synchronously
			// In this test we want the main thread loading the data
			return new SyncTaskExecutor();
		}

		@Bean
		URIBuilder uriBuilder() {
			return new URIBuilder().setScheme("http").setHost("localhost");
		}
	}
}
