package com.ing.grdm.database;

import com.ing.grdm.domain.ApiCategoryDefinition;
import org.hamcrest.CoreMatchers;
import org.hibernate.exception.ConstraintViolationException;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Unit test for {@link GrdmApiCategoryDefinitionRepository}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {GrdmDatabaseConfig.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class GrdmApiCategoryDefinitionRepositoryRWTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository repo;

	@Rule
	public ExpectedException expectedException = ExpectedException.none();

	@Test
	public void testInsert() {
		Assert.assertEquals(0, this.repo.count());
		insertApiCategoryDefinition("COUNTRY", "Attributes", null);

		final ApiCategoryDefinition foundCategoryDefinition = this.repo.findByDistributionName("COUNTRY");
		Assert.assertEquals("COUNTRY", foundCategoryDefinition.getDistributionName());
		Assert.assertNull(foundCategoryDefinition.getActiveDistributionSequenceNumber());
		Assert.assertEquals("Attributes", foundCategoryDefinition.getCategoryType());
	}

	@Test
	public void testUniqueConstraint() {
		Assert.assertEquals(0, this.repo.count());
		this.expectedException.expectCause(CoreMatchers.isA(ConstraintViolationException.class));
		insertApiCategoryDefinition("COUNTRY", "Attributes", null);
		insertApiCategoryDefinition("COUNTRY", "Attributes", null);

		// triggers the expected exception
		this.repo.findByDistributionName("COUNTRY");
	}

	@Test
	public void testGetActiveDistributionSequenceNumber() {
		insertApiCategoryDefinition("COUNTRY1", "Attributes", null);
		insertApiCategoryDefinition("COUNTRY2", "Attributes", 1);
		insertApiCategoryDefinition("COUNTRY3", "Attributes", 2);

		Assert.assertEquals(2, this.repo.getActiveDistributionSequenceNumber().intValue());
	}

	private void insertApiCategoryDefinition(String distributionName, String categoryType, Integer activeDistributionSequenceNumber) {
		final ApiCategoryDefinition categoryDefinition = new ApiCategoryDefinition();

		categoryDefinition.setDistributionName(distributionName);
		categoryDefinition.setCategoryType(categoryType);
		categoryDefinition.setActiveDistributionSequenceNumber(activeDistributionSequenceNumber);

		this.repo.save(categoryDefinition);
	}
}
