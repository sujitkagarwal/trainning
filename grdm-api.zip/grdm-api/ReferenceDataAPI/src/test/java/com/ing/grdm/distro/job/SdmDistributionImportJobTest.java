package com.ing.grdm.distro.job;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.distro.batch.ProcessDistributionException;
import com.ing.grdm.distro.batch.SdmDistributionFileHelper;
import com.ing.grdm.distro.batch.SdmDistributionFolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobRestartException;

import java.nio.file.Paths;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link SdmDistributionImportJob}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class SdmDistributionImportJobTest {

	@Mock
	private GrdmApiCategoryDefinitionDistributionRepository repository;

	@Mock
	private SdmDistributionFileHelper fileHelper;

	@Mock
	private JobLauncher jobLauncher;

	@InjectMocks
	private SdmDistributionImportJob job = new SdmDistributionImportJob();

	@Test
	public void testImportDistribution() throws Exception {
		doReturn(1).when(this.repository).getLastDistributionSequenceNumber();
		doReturn(new SdmDistributionFolder(Paths.get("SDM_20171031_103200_1"), "SHA-512"))
				.when(this.fileHelper).findFolderToProcess(any());
		doReturn(TRUE).when(this.fileHelper).verifyChecksum(any());
		this.job.importDistribution();
		verify(this.jobLauncher).run(any(), any());
	}

	@Test
	public void testImportDistributionChecksumFailed() throws Exception {
		doReturn(1).when(this.repository).getLastDistributionSequenceNumber();
		doReturn(new SdmDistributionFolder(Paths.get("SDM_20171031_103200_1"), "SHA-512"))
				.when(this.fileHelper).findFolderToProcess(any());
		doReturn(FALSE).when(this.fileHelper).verifyChecksum(any());
		this.job.importDistribution();
		verify(this.jobLauncher, never()).run(any(), any());
	}

	@Test
	public void testImportDistributionNoFolder() throws Exception {
		doReturn(1).when(this.repository).getLastDistributionSequenceNumber();
		this.job.importDistribution();
		verify(this.fileHelper, never()).verifyChecksum(any());
		verify(this.jobLauncher, never()).run(any(), any());
	}

	@Test
	public void testImportDistributionProcessDistributionException() throws Exception {
		doReturn(1).when(this.repository).getLastDistributionSequenceNumber();
		doThrow(new ProcessDistributionException("error")).when(this.fileHelper).findFolderToProcess(any());
		this.job.importDistribution();
		verify(this.fileHelper, never()).verifyChecksum(any());
		verify(this.jobLauncher, never()).run(any(), any());
	}

	@Test
	public void testImportDistributionJobExecutionException() throws Exception {
		doReturn(1).when(this.repository).getLastDistributionSequenceNumber();
		doReturn(new SdmDistributionFolder(Paths.get("SDM_20171031_103200_1"), "SHA-512"))
				.when(this.fileHelper).findFolderToProcess(any());
		doReturn(TRUE).when(this.fileHelper).verifyChecksum(any());
		doThrow(JobRestartException.class).when(this.jobLauncher).run(any(), any());
		this.job.importDistribution();
		verify(this.jobLauncher).run(any(), any());
	}
}
