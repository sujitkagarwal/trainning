package com.ing.grdm.database;

import com.google.common.collect.Lists;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ApiDataValueId;
import com.ing.grdm.domain.ColumnType;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.EntityManager;
import java.util.List;

/**
 * Unit test for {@link GrdmApiDataValueRepository}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {GrdmDatabaseConfig.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class GrdmApiDataValueRepositoryRWTest {

	@Autowired
	private EntityManager entityManager;

	@Autowired
	private GrdmApiDataValueRepository repo;

	@Test
	public void testApiDataValueId() {
		final Long categoryDefinitionId = 5L;
		final Integer distributionSequenceNumber = 6;
		final String businessKey = "businessKey";
		final Integer columnOrderNumber = 3;
		final ApiDataValueId id = new ApiDataValueId(categoryDefinitionId, distributionSequenceNumber, businessKey, columnOrderNumber);

		final int hashCode = new HashCodeBuilder()
				.append(categoryDefinitionId)
				.append(distributionSequenceNumber)
				.append(businessKey)
				.append(columnOrderNumber)
				.toHashCode();

		Assert.assertEquals(hashCode, id.hashCode());
		Assert.assertEquals(new ApiDataValueId(categoryDefinitionId, distributionSequenceNumber, businessKey, columnOrderNumber), id);
	}

	@Test
	public void testInsert() {
		final ApiDataValue dataValue = createDataValue(1001L, 1, "NL", 1, "CODE");

		this.repo.save(dataValue);
	}

	@Test
	public void testBulkInsert() {
		final List<ApiDataValue> list = Lists.newArrayList();

		for (int i = 0; i < 1000; i++) {
			list.add(createDataValue(1002L, 1, String.format("NL|%04d", i), 1, "CODE"));
		}

		this.repo.bulkInsert(list);
	}

	@Test
	public void testDeleteByDistributionSequenceNumber() {
		this.repo.save(createDataValue(1003L, 1, "NL11", 1, "CODE"));
		this.repo.save(createDataValue(1003L, 1, "NL12", 1, "CODE"));
		this.repo.save(createDataValue(1003L, 2, "NL11", 1, "CODE"));
		this.repo.save(createDataValue(1003L, 2, "NL12", 1, "CODE"));
		this.repo.save(createDataValue(1003L, 3, "NL11", 1, "CODE"));
		this.repo.save(createDataValue(1003L, 3, "NL12", 1, "CODE"));

		ApiDataValue def2 = this.repo.findOne(new ApiDataValueId(1003L, 2, "NL11", 1));
		Assert.assertNotNull(def2);

		this.repo.deleteCategoryDefinitionDistributionSequenceNumber(1003L, 2);

		final ApiDataValue def1 = this.repo.findOne(new ApiDataValueId(1003L, 1, "NL11", 1));
		Assert.assertNotNull(def1);
		def2 = this.repo.findOne(new ApiDataValueId(1003L, 2, "NL11", 1));
		Assert.assertNull(def2);
		final ApiDataValue def3 = this.repo.findOne(new ApiDataValueId(1003L, 3, "NL11", 1));
		Assert.assertNotNull(def3);
	}

	@Test
	public void testGetData() {
		this.repo.save(createDataValue(1004L, 1, "NL11", 1, "CODE1"));
		this.repo.save(createDataValue(1004L, 1, "NL11", 2, "CODE2"));
		this.repo.save(createDataValue(1004L, 1, "NL21", 1, "CODE1"));
		this.repo.save(createDataValue(1004L, 1, "NL21", 2, "CODE2"));
		this.repo.save(createDataValue(1004L, 1, "NL31", 1, "CODE1"));
		this.repo.save(createDataValue(1004L, 1, "NL31", 2, "CODE2"));

		final List<ApiDataValue> rowData = this.repo.getRowData(1004L, 1, "NL21");
		Assert.assertFalse(rowData.isEmpty());
		Assert.assertEquals(2, rowData.size());
	}

	private ApiDataValue createDataValue(long categoryDefinitionId, int distributionSequenceNumber, String businessKey, int columnOrderNumber, String columnName) {
		final ApiDataValue dataValue = new ApiDataValue();

		dataValue.setCategoryDefinitionId(categoryDefinitionId);
		dataValue.setDistributionSequenceNumber(distributionSequenceNumber);
		dataValue.setBusinessKey(businessKey);
		dataValue.setColumnOrderNumber(columnOrderNumber);
		dataValue.setColumnName(columnName);
		dataValue.setStorageString("NL");
		dataValue.setColumnType(ColumnType.STRING);

		return dataValue;
	}
}
