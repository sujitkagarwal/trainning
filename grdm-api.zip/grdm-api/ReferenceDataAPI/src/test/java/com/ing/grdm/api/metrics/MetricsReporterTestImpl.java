package com.ing.grdm.api.metrics;

import com.codahale.metrics.ConsoleReporter;
import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.concurrent.TimeUnit;

/**
 * Metrics reporter logging to the console. For development purposes only.
 */
@Component
public class MetricsReporterTestImpl implements MetricsReporter {

	@Value("${grdm.metrics.enabled}")
	private boolean metricsEnabled;

	@Autowired
	private MetricRegistry metricRegistry;

	private ConsoleReporter metricReporter;

	@PostConstruct
	public void init() {
		if (this.metricsEnabled) {
			this.metricReporter = ConsoleReporter.forRegistry(this.metricRegistry)
					.convertRatesTo(TimeUnit.MINUTES)
					.convertDurationsTo(TimeUnit.MILLISECONDS)
					.filter(MetricFilter.ALL)
					.build();
			this.metricReporter.start(1, TimeUnit.MINUTES);
		}
	}

	@PreDestroy
	public void destroy() {
		if (this.metricsEnabled) {
			this.metricReporter.stop();
		}
	}
}
