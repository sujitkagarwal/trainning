package com.ing.grdm.api.security;

import com.ing.grdm.api.GrdmApiTestApplication;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * /**
 * Created by QU04JL on 27-9-2017.
 */

@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.api.security=true")
@AutoConfigureMockMvc
public class GrdmSecurityMockTest extends ApiSecurityTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testValidAuthentication() throws Exception {
        this.mockMvc.perform(get("/api/config/get/85").header("Authorization", "Bearer " + CreateToken())).andDo(print()).andExpect(status().isNotFound());
    }

    @Test
    public void testInvalidValidAuthentication() throws Exception {
        this.mockMvc.perform(get("/api/config/get/85").header("Authorization", "Bearer 111" + CreateToken())).andDo(print()).andExpect(status().isUnauthorized())
                .andExpect(status().reason("Invalid Token"));

    }

    @Test
    public void testWithoutHeaderAuthentication() throws Exception {
        this.mockMvc.perform(get("/api/config/get/85")).andDo(print()).andExpect(status().isUnauthorized())
                .andExpect(status().reason("No JWT token found in request headers"));

    }
}
