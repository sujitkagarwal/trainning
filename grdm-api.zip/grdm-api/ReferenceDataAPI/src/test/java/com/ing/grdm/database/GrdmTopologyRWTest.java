package com.ing.grdm.database;

import com.ing.grdm.domain.TopologyServer;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.stream.StreamSupport;

/**
 * Unit tests for {@link GrdmTopologyRepository}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {GrdmDatabaseConfig.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class GrdmTopologyRWTest {

	@Autowired
	private GrdmTopologyRepository repo;

	@Test
	public void testFindById() {
		createTopologyRecord(1, "lrv17111", "DCR", "DGRDM1");
		final TopologyServer server = this.repo.findOne(1L);
		Assert.assertNotNull(server);
		Assert.assertEquals(1, server.getTechnicalId());
		Assert.assertEquals("lrv17111", server.getHostname());
		Assert.assertEquals("DCR", server.getDatacenter());
		Assert.assertEquals("DGRDM1", server.getDatabaseName());
		Assert.assertNull(this.repo.findOne(2L));
	}

	@Test
	public void testInsert() {
		final TopologyServer server = new TopologyServer(1);
		this.repo.save(server);

		Assert.assertNotNull(this.repo.findOne(1L));
	}

	@Test
	public void testGetActiveDatabase() {
		Assert.assertEquals("DGRDM2", this.repo.getActiveDatabase());
	}

	@Test
	public void testGetHostnamesByActiveDatabaseDatacenter() {
		createTopologyRecord(1, "lrv17111.europe.intranet", "DCR", null);
		createTopologyRecord(2, "lrv1714f.europe.intranet", "WPR", null);
		createTopologyRecord(3, "lrv17141.europe.intranet", "DCR", "DGRDM1");
		createTopologyRecord(4, "lrv1712x.europe.intranet", "WPR", "DGRDM2");

		final Iterable<TopologyServer> servers = this.repo.findAll();
		Assert.assertEquals(4, StreamSupport.stream(servers.spliterator(), false).count());
		Assert.assertFalse(this.repo.getHostnamesByActiveDatabaseDatacenter().isEmpty());
	}

	@Test
	public void testShouldJobRun() throws UnknownHostException {
		createTopologyRecord(1, "lrv17111", "DCR", null);
		createTopologyRecord(2, "lrv1714f", "WPR", null);
		createTopologyRecord(3, "lrv17141", "DCR", "DGRDM1");
		createTopologyRecord(4, "lrv1712x", "WPR", "DGRDM2");
		createTopologyRecord(5, Inet4Address.getLocalHost().getHostName(), "WPR", null);

		Assert.assertEquals(5, this.repo.count());
		Assert.assertTrue(this.repo.shouldJobRun());
	}

	private void createTopologyRecord(long id, String hostname, String datacenter, String databaseName) {
		TopologyServer server = new TopologyServer(id);
		server.setHostname(hostname);
		server.setDatacenter(datacenter);
		server.setDatabaseName(databaseName);
		this.repo.save(server);
	}
}
