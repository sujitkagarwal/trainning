package com.ing.grdm.cucumber.integration;

import com.ing.grdm.cucumber.delegate.OverstapApiTestStepsDelegate;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Test steps for the overstap integration test.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
public class OverstapApiIntegrationTestSteps extends GrdmApiIntegrationTestConfiguration {
	@Autowired
	private OverstapApiTestStepsDelegate delegate;

	@When("^the client requests forward accounts for ibans '(.*)'$")
	public void requestForwardAccountsByIbans(String ibans) throws Throwable {
		this.delegate.requestForwardAccounts(ibans);
	}

	@When("^the client requests forward accounts for filter date '(.*)' and ibans '(.+)'$")
	public void requestForwardAccountsByIbansAndFilterDate(String filterDate, String ibans) throws Throwable {
		this.delegate.requestForwardAccounts(ibans, filterDate);
	}

	@When("^the client makes an invalid request$")
	public void makeInvalidRequest() throws Throwable {
		this.delegate.placeInvalidRequest();
	}

	@Then("^the client receives status code as (\\d+)$")
	public void verifyStatus(int statusCode) {
		this.delegate.verifyStatus(statusCode);
	}

	@And("^the client receives forward accounts for ibans '(.+)'$")
	public void verifyForwardAccountsByIbans(String ibans) throws Throwable {
		this.delegate.verifyForwardAccountsByIbans(ibans);
	}

	@And("^the client receives empty array of forward accounts$")
	public void verifyForwardAccountsByIbans() throws Throwable {
		this.delegate.verifyForwardAccountsByIbans();
	}

	@And("^the client receives filter date as '(.*)'$")
	public void verifyFilterDate(String filterDate) throws Throwable {
		this.delegate.verifyFilterDate(filterDate);
	}

	@And("^the client receives status message as '(.*)'$")
	public void verifyStatus(String statusMessage) {
		this.delegate.verifyStatus(statusMessage);
	}
}
