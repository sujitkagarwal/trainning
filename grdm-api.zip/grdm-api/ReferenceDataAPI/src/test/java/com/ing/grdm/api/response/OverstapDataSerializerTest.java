package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import com.google.common.collect.TreeBasedTable;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Map;

import static org.mockito.Mockito.doThrow;

/**
 * Unit tests for {@link OverstapDataSerializer}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class OverstapDataSerializerTest {

	@Spy
	private JsonFactory jsonFactory = new JsonFactory(new ObjectMapper());

	@InjectMocks
	private OverstapDataSerializer serializer = new OverstapDataSerializer();

	@Test
	public void testSerializeOverstapData() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeOverstapData(writer, createOverstapData(), null);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.overstapAccounts").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$.overstapAccounts[0].accountId").assertValue(content, "NL03INGB0000461686");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].overstapAccountId").assertValue(content, "NL91SNSB0856282219");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].overstapAccountBIC").assertValue(content, "SNSBNL2A");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].startDate").assertValue(content, "2016-07-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].expirationDate").assertValue(content, "2017-08-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[0]").doesNotExist("ovt_sta");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].accountId").assertValue(content, "NL19INGB0000458973");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].overstapAccountId").assertValue(content, "NL80RABO0310612306");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].overstapAccountBIC").assertValue(content, "RABONL2U");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].startDate").assertValue(content, "2016-07-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].expirationDate").assertValue(content, "2017-08-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[1]").doesNotExist("ovt_sta");
		new JsonPathExpectationsHelper("$.filterDate").doesNotExist(content);
	}

	@Test
	public void testSerializeOverstapDataWithFilterDate() throws IOException {
		final String filterDate = "2016-02-03";
		final Writer writer = new StringWriter();
		this.serializer.serializeOverstapData(writer, createOverstapData(), filterDate);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.overstapAccounts").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$.overstapAccounts[0].accountId").assertValue(content, "NL03INGB0000461686");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].overstapAccountId").assertValue(content, "NL91SNSB0856282219");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].overstapAccountBIC").assertValue(content, "SNSBNL2A");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].startDate").assertValue(content, "2016-07-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[0].expirationDate").assertValue(content, "2017-08-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[0]").doesNotExist("ovt_sta");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].accountId").assertValue(content, "NL19INGB0000458973");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].overstapAccountId").assertValue(content, "NL80RABO0310612306");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].overstapAccountBIC").assertValue(content, "RABONL2U");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].startDate").assertValue(content, "2016-07-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[1].expirationDate").assertValue(content, "2017-08-21");
		new JsonPathExpectationsHelper("$.overstapAccounts[1]").doesNotExist("ovt_sta");
		new JsonPathExpectationsHelper("$.filterDate").assertValue(content,filterDate);
	}

	@Test
	public void testSerializeOverstapDataEmptyResponse() throws IOException {
		final Writer writer = new StringWriter();
		this.serializer.serializeOverstapData(writer, Maps.newHashMap(), null);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.overstapAccounts").assertValueIsEmpty(content);
		new JsonPathExpectationsHelper("$.filterDate").doesNotExist(content);
	}

	@Test
	public void testSerializeOverstapDataEmptyResponseWithFilterDate() throws IOException {
		final String filterDate = "2016-02-03";
		final Writer writer = new StringWriter();
		this.serializer.serializeOverstapData(writer, Maps.newHashMap(), filterDate);
		final String content = writer.toString();
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.overstapAccounts").assertValueIsEmpty(content);
		new JsonPathExpectationsHelper("$.filterDate").assertValue(content,filterDate);
	}

	@Test(expected = IOException.class)
	public void testSerializeOverstapDataIOException() throws IOException {
		final Writer writer = Mockito.mock(Writer.class);
		doThrow(IOException.class).when(writer).flush();
		this.serializer.serializeOverstapData(writer, createOverstapData(), null);
	}

	private Map<String, Map<String, Object>> createOverstapData() {
		final Table<String, String, Object> table = TreeBasedTable.create();
		table.put("NL19INGB0000458973", "accountId", "NL19INGB0000458973");
		table.put("NL19INGB0000458973", "overstapAccountId", "NL80RABO0310612306");
		table.put("NL19INGB0000458973", "overstapAccountBIC", "RABONL2U");
		table.put("NL19INGB0000458973", "startDate", "2016-07-21");
		table.put("NL19INGB0000458973", "expirationDate", "2017-08-21");
		table.put("NL19INGB0000458973", "ovt_sta", "06");
		table.put("NL03INGB0000461686", "accountId", "NL03INGB0000461686");
		table.put("NL03INGB0000461686", "overstapAccountId", "NL91SNSB0856282219");
		table.put("NL03INGB0000461686", "overstapAccountBIC", "SNSBNL2A");
		table.put("NL03INGB0000461686", "startDate", "2016-07-21");
		table.put("NL03INGB0000461686", "expirationDate", "2017-08-21");
		table.put("NL03INGB0000461686", "ovt_sta", "08");
		return table.rowMap();
	}
}
