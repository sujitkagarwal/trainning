package com.ing.grdm.cucumber.regression;

import com.ing.grdm.cucumber.delegate.ReferenceDataApiTestStepsDelegate;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

/**
 * Test steps for the Reference Data API regression test.
 */
@SuppressWarnings("unused")
public class ReferenceDataApiRegressionTestSteps extends GrdmApiRegressionTestConfiguration {

	@Autowired
	private ReferenceDataApiTestStepsDelegate delegate;

	@When("^setup$")
	public void setup() {
	}

	@When("^the client requests (\\w+) for table '(\\w+)'$")
	public void requestTable(String type, String table) throws IOException {
		this.delegate.requestTable(type, table);
	}

	@When("^the client requests (\\w+) for table '(\\w+)' and columns '(\\w+)'$")
	public void requestTableWithColumns(String type, String table, String columns) throws IOException {
		this.delegate.requestTableWithColumns(type, table, columns);
	}

	@Then("^the client receives status code of (\\d+)$")
	public void verifyStatus(int statusCode) {
		this.delegate.verifyStatus(statusCode);
	}

	@And("^the client receives all the businessKey for table (\\d+)$")
	public void verifyNumberOfBusinessKeys(int size) throws IOException {
		this.delegate.verifyNumberOfBusinessKeys(size);
	}

	@And("^the client receives value for business key '(.+)' and column '(.+)' is '(.+)'$")
	public void verifyColumnValue(String businessKey, String column, String description) {
		this.delegate.verifyColumnValue(businessKey, column, description);
	}

	@When("^the client requests (\\w+) for table '(\\w+)' and businessKey '(\\w+)'$")
	public void requestTableWithBusinessKey(String type, String table, String businessKey) throws IOException {
		this.delegate.requestTableWithBusinessKey(type, table, businessKey);
	}

	@When("^the client requests (\\w+) for table '(\\w+)' for businessKey '(\\w+)' and columns are '(.+)'$")
	public void requestTableWithBusinessKeyWithColumns(String type, String table, String businessKey, String columns) throws IOException {
		this.delegate.requestTableWithBusinessKeyWithColumns(type, table, businessKey, columns);
	}

	@And("^cleaning$")
	public void cleanup() {
	}
}