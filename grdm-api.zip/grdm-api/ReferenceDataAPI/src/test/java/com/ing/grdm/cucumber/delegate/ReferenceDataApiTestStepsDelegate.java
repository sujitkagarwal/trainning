package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual test steps for Reference Data API. Needs to be wired in the cucumber glue class.
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class ReferenceDataApiTestStepsDelegate extends GrdmApiTestStepsDelegate {

	private static final Log LOG = LogFactory.getLog(ReferenceDataApiTestStepsDelegate.class);

	// The deserialized json response of the request by table name
	private List<Map<String, Object>> byTableNameResponse;

	// The deserialized json response of the request by table name and business key
	private Map<String, Object> byTableNameAndBusinessKeyResponse;

	/**
	 * Perform a by table name request
	 *
	 * @param type  type of SDM table, e.g. Attributes
	 * @param table distribution name of the table
	 * @throws IOException communication error with the server
	 */
	public void requestTable(String type, String table) throws IOException {
		LOG.info(String.format("the client requests %s for table %s", type, table));

		performByTableNameRequest(String.format("/reference-data/%s/%s", type, table), Collections.emptyList());
	}

	/**
	 * @param type    type of SDM table, e.g. Attributes
	 * @param table   distribution name of the table
	 * @param columns any specific columns to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithColumns(String type, String table, String columns) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and columns %s", type, table, columns));

		final List<NameValuePair> nvps = Arrays.stream(StringUtils.split(columns, ','))
				.map(s -> new BasicNameValuePair("column", s))
				.collect(Collectors.toList());

		performByTableNameRequest(String.format("/reference-data/%s/%s", type, table), nvps);
	}

	/**
	 * @param type        type of SDM table, e.g. Attributes
	 * @param table       distribution name of the table
	 * @param businessKey any businessKey to retrieve
	 * @param columns     any specific columns to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithBusinessKeyWithColumns(String type, String table, String businessKey, String columns) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and businessKey %s and columns %s", type, table, businessKey, columns));
		final List<NameValuePair> nvps = Arrays.stream(StringUtils.split(columns, ','))
				.map(s -> new BasicNameValuePair("column", s))
				.collect(Collectors.toList());
		performByTableNameAndBusinessKeyRequest(String.format("/reference-data/%s/%s/%s", type, table, businessKey), nvps);
	}

	/**
	 * @param type        type of SDM table, e.g. Attributes
	 * @param table       distribution name of the table
	 * @param businessKey any businessKey to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithBusinessKey(String type, String table, String businessKey) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and businessKey %s ", type, table, businessKey));
		performByTableNameAndBusinessKeyRequest(String.format("/reference-data/%s/%s/%s", type, table, businessKey),
				Collections.emptyList());
	}

	/**
	 * Verify the returned status code
	 *
	 * @param statusCode the status code
	 */
	public void verifyStatus(int statusCode) {
		LOG.info(String.format("the client receives status code of %d", statusCode));

		assertThat(this.responseStatus, is(statusCode));
	}

	/**
	 * Verify the number of returned business keys
	 *
	 * @param size the size
	 */
	public void verifyNumberOfBusinessKeys(int size) {
		LOG.info(String.format("the client receives all the businessKey for table %d", size));

		assertThat(this.byTableNameResponse.size(), is(size));
	}

	/**
	 * Verify a particular column's value
	 *
	 * @param businessKey the business key of the row
	 * @param column      the column
	 * @param value       the value
	 */
	public void verifyColumnValue(String businessKey, String column, String value) {
		LOG.info(String.format("the client receives value for business key %s and column %s is %s", businessKey, column, value));

		final Map<String, Object> valueMap;

		if (this.byTableNameResponse != null) {
			valueMap = this.byTableNameResponse.parallelStream()
					.filter(map -> map.get("business_key").equals(businessKey))
					.findAny()
					.orElse(null);
		} else if (this.byTableNameAndBusinessKeyResponse != null) {
			valueMap = this.byTableNameAndBusinessKeyResponse;
		} else {
			return;
		}

		assertThat(valueMap, is(notNullValue()));
		assertThat(valueMap.get("business_key"), is(businessKey));
		assertThat(valueMap.containsKey(column), is(true));
		assertThat(valueMap.get(column), is(value));
	}

	private void performByTableNameRequest(String path, List<NameValuePair> nvps) throws IOException {
		final String content = performRequest(path, nvps);
		final TypeReference<List<Map<String, Object>>> typeReference = new TypeReference<List<Map<String, Object>>>() {
		};
		if (content != null) {
			this.byTableNameResponse = new ObjectMapper().readValue(content, typeReference);
		}
	}

	private void performByTableNameAndBusinessKeyRequest(String path, List<NameValuePair> nvps) throws IOException {
		final String content = performRequest(path, nvps);
		final TypeReference<Map<String, Object>> typeReference = new TypeReference<Map<String, Object>>() {
		};
		if (content != null) {
			this.byTableNameAndBusinessKeyResponse = new ObjectMapper().readValue(content, typeReference);
		}
	}
}
