package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.domain.ForwardAccount;
import com.ing.grdm.api.domain.ForwardAccountsResponseData;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual overstap test steps. Needs to be wired in the cucumber glue class.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class OverstapApiTestStepsDelegate extends GrdmApiTestStepsDelegate {

	private static final Log LOG = LogFactory.getLog(OverstapApiTestStepsDelegate.class);

	private static final String overstapApiPath = "/reference-data/forwarding-accounts";

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private JsonFactory jsonFactory;

	// The deserialized json response of the forward accounts request
	private ForwardAccountsResponseData forwardAccountsResponseData;

	// The serialized object for the overstap request
	private final Writer overstapRequestObject = new StringWriter();

	/**
	 * Perform overstap request for the list of old ibans
	 *
	 * @param ibans List of old ibans
	 * @throws IOException communication error with the server
	 */
	public void requestForwardAccounts(String ibans) throws IOException {
		LOG.info(String.format("the client requests forward accounts for ibans %s", ibans));
		final List<String> nvps = Arrays.stream(StringUtils.split(ibans, ',')).collect(Collectors.toList());
		performForwardAccountsRequest(overstapApiPath, nvps, null);
	}

	/**
	 * Perform overstap request for the list of old ibans and a valid filter date
	 *
	 * @param ibans      list of old ibans
	 * @param filterDate a valid filter date
	 * @throws IOException communication error with the server
	 */
	public void requestForwardAccounts(String ibans, String filterDate) throws IOException {
		LOG.info(String.format("the client requests forward accounts for ibans %s and filterdate %s", ibans, filterDate));
		final List<String> nvps = Arrays.stream(StringUtils.split(ibans, ',')).collect(Collectors.toList());
		performForwardAccountsRequest(overstapApiPath, nvps, filterDate);
	}

	/**
	 * Verify the response status message
	 *
	 * @param statusMessage the status message
	 */
	public void verifyStatus(String statusMessage) {
		LOG.info(String.format("the client receives status message as %s", statusMessage));

		assertThat(this.responseMessage, is(statusMessage));
	}

	/**
	 * Verify forward accounts received in response by passing list of old ibans
	 *
	 * @param oldIbans list of old ibans
	 */
	public void verifyForwardAccountsByIbans(String oldIbans) {
		LOG.info(String.format("the client receives forward accounts for ibans %s", oldIbans));
		final List<String> oldIbansList = Arrays.stream(StringUtils.split(oldIbans, ','))
				.collect(Collectors.toList());
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final List<ForwardAccount> forwardAccounts = this.forwardAccountsResponseData.getForwardAccounts();
		assertThat(forwardAccounts, is(notNullValue()));
		assertThat(forwardAccounts.size(), is(oldIbansList.size()));
		assertThat((forwardAccounts.get(0).getAccountId()), is(oldIbansList.get(0)));
		assertThat((forwardAccounts.get(1).getAccountId()), is(oldIbansList.get(1)));
	}

	/**
	 * Verify that forward accounts received in response is empty
	 */
	public void verifyForwardAccountsByIbans() {
		LOG.info("the client receives empty array of forward accounts");
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final List<ForwardAccount> forwardAccounts = this.forwardAccountsResponseData.getForwardAccounts();
		assertThat(forwardAccounts, is(notNullValue()));
		assertThat(forwardAccounts.isEmpty(), is(true));
	}

	/**
	 * Verify filter date received in response
	 */
	public void verifyFilterDate(String filterDate) {
		LOG.info(String.format("the client receives filter date as %s", filterDate));
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
		final LocalDate receivedFilterDate = this.forwardAccountsResponseData.getFilterDate();
		assertThat(receivedFilterDate, is(notNullValue()));
		assertThat(receivedFilterDate, is(LocalDate.parse(filterDate, formatter)));
	}

	/**
	 * Verify the returned status code
	 *
	 * @param statusCode the status code
	 */
	public void verifyStatus(int statusCode) {
		LOG.info(String.format("the client receives status code as %d", statusCode));

		assertThat(this.responseStatus, is(statusCode));
	}

	/**
	 * Making an invalid request to forward accounts API
	 */
	public void placeInvalidRequest() throws IOException {
		LOG.info("the client makes an invalid request");

		performPostRequest(overstapApiPath, "Some bogus request");
	}

	private void performForwardAccountsRequest(String path, List<String> nvps, String filterDate) throws IOException {
		final String content = performPostRequest(path, nvps, filterDate);
		if (content != null) {
			this.forwardAccountsResponseData = objectMapper.readValue(content, ForwardAccountsResponseData.class);
		}
	}

	private String performPostRequest(String path, List<String> oldIbans, String filterDate) throws IOException {
		return performPostRequest(path, createForwardAccountsRequestData(oldIbans, filterDate));
	}

	private String createForwardAccountsRequestData(List<String> oldIbans, String filterDate) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(this.overstapRequestObject)) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeFieldName("accountIds");
			jsonGenerator.writeStartArray();
			for (String accountId : oldIbans) {
				jsonGenerator.writeString(accountId);
			}
			jsonGenerator.writeEndArray();
			if (filterDate != null) {
				jsonGenerator.writeFieldName("filterDate");
				jsonGenerator.writeString(filterDate);
			}
			jsonGenerator.writeEndObject();
			jsonGenerator.flush();
		}
		return this.overstapRequestObject.toString();
	}
}
