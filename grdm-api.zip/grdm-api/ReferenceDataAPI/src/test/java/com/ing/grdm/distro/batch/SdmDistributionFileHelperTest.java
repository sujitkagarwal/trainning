package com.ing.grdm.distro.batch;

import com.google.common.collect.Maps;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

/**
 * Unit tests for {@link SdmDistributionFileHelper}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class SdmDistributionFileHelperTest {

	private static final String ALGORITHM = "SHA-512";

	@InjectMocks
	private SdmDistributionFileHelper helper;

	@Rule
	public TemporaryFolder distributionRootFolder = new TemporaryFolder();

	@Before
	public void init() throws IOException {
		ReflectionTestUtils.setField(helper, "distributionRootFolder", Paths.get(this.distributionRootFolder.getRoot().getAbsolutePath()));
		ReflectionTestUtils.setField(helper, "algorithm", ALGORITHM);
	}

	@Test
	public void testFindFolderToProcessWhenNoLast() throws ProcessDistributionException, IOException {
		distributionRootFolder.newFolder("GRD_20170911_110227_134");
		distributionRootFolder.newFolder("GRD_20170911_110227_135");
		final SdmDistributionFolder folder = helper.findFolderToProcess(null);

		Assert.assertNotNull(folder);
		Assert.assertEquals(135, folder.getDistributionSequenceNumber());
	}

	@Test
	public void testFindFolderToProcessWhenEmptyFolder() throws ProcessDistributionException {
		Assert.assertNull(helper.findFolderToProcess(1));
	}

	@Test(expected = ProcessDistributionException.class)
	public void testFindFolderToProcessWithError() throws ProcessDistributionException {
		ReflectionTestUtils.setField(helper, "distributionRootFolder", Paths.get("bla"));
		helper.findFolderToProcess(1);
	}

	@Test
	public void testFindFolderToProcess() throws ProcessDistributionException, IOException, ParseException {
		distributionRootFolder.newFolder("GRD_20170911_110227_134");
		distributionRootFolder.newFolder("GRD_20170912_110203_135");
		distributionRootFolder.newFolder("GRD_20170913_110203_136");
		distributionRootFolder.newFolder("GRD_20170914_110215_137");

		Assert.assertNotNull(helper.findFolderToProcess(1));
		Assert.assertNotNull(helper.findFolderToProcess(136));
		Assert.assertNull(helper.findFolderToProcess(137));

		final SdmDistributionFolder folder = helper.findFolderToProcess(135);
		Assert.assertEquals("GRD", folder.getSystemCode());
		Assert.assertEquals(new SimpleDateFormat("yyyyMMdd_HHmmss").parse("20170914_110215"), folder.getDistributionDate());
		Assert.assertEquals(137, folder.getDistributionSequenceNumber());
		Assert.assertEquals("GRD_20170914_110215_137", folder.getFolderName());
		Assert.assertEquals("GRD_20170914_110215_137_xml.zip", folder.getXmlZipFile().getFileName().toString());
		Assert.assertEquals("GRD_20170914_110215_137_xml.sha512", folder.getXmlChecksumFile().getFileName().toString());
	}

	@Test
	public void testGetAttributeFiles() throws ProcessDistributionException, IOException, URISyntaxException {
		final Path distributionFolderPath = Paths.get(this.distributionRootFolder.getRoot().getAbsolutePath(), "GRD_20170914_110215_137");
		final SdmDistributionFolder distributionFolder = new SdmDistributionFolder(distributionFolderPath, ALGORITHM);
		createZipAndChecksumFiles(distributionFolder, "0002_COUNTRY_Attributes.xml");
		Assert.assertTrue(this.helper.verifyChecksum(distributionFolder));

		try (FileSystem zipFileSystem = FileSystems.newFileSystem(createZipFileUri(distributionFolder.getXmlZipFile()), Maps.newHashMap())) {
			final List<URI> filesToImport = helper.getAttributeFilesToImport(distributionFolder.getXmlZipFile().toUri().toString());

			Assert.assertNotNull(filesToImport);
			Assert.assertFalse(filesToImport.isEmpty());
			Assert.assertEquals(1, filesToImport.size());
			Assert.assertTrue(Files.exists(Paths.get(filesToImport.get(0))));
		}
	}

	@Test
	public void testGetAttributeFilesChecksumError() throws IOException, URISyntaxException, ProcessDistributionException {
		final Path distributionFolderPath = Paths.get(this.distributionRootFolder.getRoot().getAbsolutePath(), "GRD_20170914_110215_137");
		final SdmDistributionFolder distributionFolder = new SdmDistributionFolder(distributionFolderPath, ALGORITHM);
		createZipAndChecksumFiles(distributionFolder, "0002_COUNTRY_Attributes.xml");
		createChecksumFile(distributionFolder, "bla");

		Assert.assertFalse(this.helper.verifyChecksum(distributionFolder));
	}

	private void createZipAndChecksumFiles(SdmDistributionFolder distributionFolder, String fileName) throws IOException, URISyntaxException {
		// Prepare directories and file paths
		this.distributionRootFolder.newFolder(distributionFolder.getFolderName(), "xml");
		final Path zipFile = distributionFolder.getXmlZipFile();

		// Create zip file containing one xml file
		final Map<String, String> params = Maps.newHashMap();
		params.put("create", "true");
		try (FileSystem zipFileSystem = FileSystems.newFileSystem(createZipFileUri(zipFile), params)) {
			final URI fileUriToAdd = Thread.currentThread().getContextClassLoader().getResource(fileName).toURI();
			Files.copy(Paths.get(fileUriToAdd), zipFileSystem.getPath(fileName));
		}

		// Generate the checksum and create the file
		try (InputStream fileInput = Files.newInputStream(zipFile)) {
			final byte[] digest = DigestUtils.getDigest(ALGORITHM).digest(IOUtils.toByteArray(fileInput));
			final String checksum = String.format("%x", new BigInteger(1, digest));
			createChecksumFile(distributionFolder, checksum);
		}
	}

	private void createChecksumFile(SdmDistributionFolder distributionFolder, String checksum) throws IOException {
		// Create the checksum file
		final Path checksumFile = distributionFolder.getXmlChecksumFile();
		try (OutputStream fileOutput = Files.newOutputStream(checksumFile)) {
			IOUtils.copy(new StringReader(checksum), fileOutput);
		}
	}

	private URI createZipFileUri(Path zipFilePath) {
		return URI.create("jar:" + zipFilePath.toUri().toString());
	}
}
