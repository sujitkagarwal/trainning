package com.ing.grdm.cucumber.regression;

import com.ing.grdm.cucumber.delegate.OverstapApiTestStepsDelegate;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;

/**
 * Test steps for the Overstap API regression tests
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 07-12-2017
 */
@SuppressWarnings("unused")
public class OverstapApiRegressionTestSteps extends GrdmApiRegressionTestConfiguration {

	@Autowired
	private OverstapApiTestStepsDelegate delegate;

	@When("^the client requests forward accounts for ibans '(.*)'$")
	public void requestForwardAccountsByIbans(String ibans) throws IOException {
		this.delegate.requestForwardAccounts(ibans);
	}

	@When("^the client requests forward accounts for filter date '(.*)' and ibans '(.+)'$")
	public void requestForwardAccountsByIbansAndFilterDate(String filterDate, String ibans) throws IOException {
		this.delegate.requestForwardAccounts(ibans, filterDate);
	}

	@When("^the client makes an invalid request$")
	public void makeInvalidRequest() throws IOException {
		this.delegate.placeInvalidRequest();
	}

	@And("^the client receives forward accounts for ibans '(.+)'$")
	public void verifyForwardAccountsByIbans(String ibans) throws IOException {
		this.delegate.verifyForwardAccountsByIbans(ibans);
	}

	@And("^the client receives empty array of forward accounts$")
	public void verifyForwardAccountsByIbans() throws IOException {
		this.delegate.verifyForwardAccountsByIbans();
	}

	@And("^the client receives filter date as '(.*)'$")
	public void verifyFilterDate(String filterDate) throws IOException {
		this.delegate.verifyFilterDate(filterDate);
	}

	@And("^the client receives status message as '(.*)'$")
	public void verifyStatus(String statusMessage) {
		this.delegate.verifyStatus(statusMessage);
	}

	@Then("^the client receives status code as (\\d+)$")
	public void verifyOverstapApiRequestStatus(int statusCode) {
		this.delegate.verifyStatus(statusCode);
	}

}