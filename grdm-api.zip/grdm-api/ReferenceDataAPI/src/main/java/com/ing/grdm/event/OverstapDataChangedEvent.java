package com.ing.grdm.event;

/**
 * Application event notifying listeners that overstap data has changed
 */

public class OverstapDataChangedEvent {
	public OverstapDataChangedEvent() {
	}
}
