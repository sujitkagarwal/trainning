package com.ing.grdm.database;

import com.ing.grdm.database.custom.GrdmApiDataValueBatchRepository;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ApiDataValueId;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Repository definition for the GRDM_API_DATA_VALUE table
 */
public interface GrdmApiDataValueRepository extends CrudRepository<ApiDataValue, ApiDataValueId>, GrdmApiDataValueBatchRepository {

	/**
	 * Deletes all data values with a given category definition id and distribution sequence number
	 *
	 * @param categoryDefinitionId       the id of the category definition
	 * @param distributionSequenceNumber the distribution sequence number
	 */
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query("delete ApiDataValue where categoryDefinitionId = ?1 and distributionSequenceNumber = ?2")
	void deleteCategoryDefinitionDistributionSequenceNumber(long categoryDefinitionId, int distributionSequenceNumber);

	/**
	 * Returns data values for all rows in table with given category definition and distribution sequence number
	 *
	 * @param categoryDefinitionId       the category definition id
	 * @param distributionSequenceNumber the distribution sequence number
	 * @return the list of data values
	 */
	@Query("from ApiDataValue adv where adv.categoryDefinitionId = ?1 and adv.distributionSequenceNumber = ?2 order by columnName")
	List<ApiDataValue> getAllRowData(long categoryDefinitionId, int distributionSequenceNumber);

	/**
	 * Returns the data values for a row with given category definition, distribution sequence number and business key
	 *
	 * @param categoryDefinitionId       the category definition id
	 * @param distributionSequenceNumber the distribution sequence number
	 * @param businessKey                the business key
	 * @return the list of data values
	 */
	@Query("from ApiDataValue adv where adv.categoryDefinitionId = ?1 and adv.distributionSequenceNumber = ?2 and adv.businessKey = ?3 order by columnName")
	List<ApiDataValue> getRowData(long categoryDefinitionId, int distributionSequenceNumber, String businessKey);

	/**
	 * Returns the data values (only given list of columns )for a row with given category definition, distribution sequence number and business key
	 *
	 * @param categoryDefinitionId       the category definition id
	 * @param distributionSequenceNumber the distribution sequence number
	 * @param businessKey                the business key
	 * @return the list of data values (only given list of columns)
	 */
	@Query("from ApiDataValue adv where adv.categoryDefinitionId = ?1 and adv.distributionSequenceNumber = ?2 and adv.businessKey = ?3 and adv.columnName in (?4) order by columnName")
	List<ApiDataValue> getRowDataByColumns(long categoryDefinitionId, int distributionSequenceNumber, String businessKey, List<String> columns);

	/**
	 * Returns the business keys for all rows in given category definition and distribution sequence number.
	 * For standard and non-standard tables
	 *
	 * @param categoryDefinitionId       the technical id of the category definition
	 * @param distributionSequenceNumber the distribution sequence number
	 * @return the list of business keys for the given categoryDefinitionId ( uniquely identifies standard/non-standard tables)and sequenceNumber
	 */
	@Query("select adv.businessKey from ApiDataValue adv where adv.categoryDefinitionId = ?1 and adv.distributionSequenceNumber = ?2 and adv.columnOrderNumber = 1 order by adv.businessKey")
	List<String> getTableData(long categoryDefinitionId, int distributionSequenceNumber);

	/**
	 * Returns the business keys and columns for all rows in the given category definition and distribution sequence number.
	 * For standard and non-standard tables
	 *
	 * @param categoryDefinitionId       the technical id of the category definition
	 * @param distributionSequenceNumber the distribution sequence number
	 * @return the list of business keys and given set of columns for the given categoryDefinitionId and sequenceNumber
	 */
	@Query("from ApiDataValue adv where adv.categoryDefinitionId = ?1 and adv.distributionSequenceNumber = ?2 and adv.columnName in (?3) order by businessKey,columnName")
	List<ApiDataValue> getTableDataByColumns(long categoryDefinitionId, int distributionSequenceNumber, List<String> columns);
}
