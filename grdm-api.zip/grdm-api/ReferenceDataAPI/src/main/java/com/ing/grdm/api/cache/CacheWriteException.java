package com.ing.grdm.api.cache;

/**
 * Indicates IOExceptions while writing the cache
 */
public class CacheWriteException extends RuntimeException {
	public CacheWriteException(Throwable cause) {
		super(cause);
	}
}
