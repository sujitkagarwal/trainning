package com.ing.grdm.api.security.handler;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * This class is used to handle authentication failures
 * {@link AuthenticationFailureHandler}
 * @author  Sujit Kumar Agarwal
 * @version 1.0
 * @since   18-09-2017
 */
@Component
public class GrdmAuthenticationFailureHandler implements AuthenticationFailureHandler {

    /**
     *This is invoked when user tries to access a secured REST resource without supplying any token or invalid token.
     * @param request  This is the http request object
     * @param response  This is the http response object
     * @param authException this is exception thrown during
     * @throws IOException on input/output error
     * @throws ServletException on server exception
     * @see IOException
     * @see ServletException
     */
    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException authException) throws IOException, ServletException {
        // This is invoked when user tries to access a secured REST resource without supplying any token
        // We should just send a 401 Unauthorized response because there is no 'login page' to redirect to
        //  response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, authException.getMessage());

    }
}
