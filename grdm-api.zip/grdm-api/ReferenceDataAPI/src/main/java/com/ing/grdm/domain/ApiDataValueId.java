package com.ing.grdm.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;

/**
 * Represents the primary key of GRDM_API_DATA_VALUE table.
 */
public class ApiDataValueId implements Serializable {

	private Long categoryDefinitionId;
	private Integer distributionSequenceNumber;
	private String businessKey;
	private Integer columnOrderNumber;

	public ApiDataValueId() {
	}

	public ApiDataValueId(Long categoryDefinitionId, Integer distributionSequenceNumber, String businessKey, Integer columnOrderNumber) {
		this.categoryDefinitionId = categoryDefinitionId;
		this.distributionSequenceNumber = distributionSequenceNumber;
		this.businessKey = businessKey;
		this.columnOrderNumber = columnOrderNumber;
	}

	public long getCategoryDefinitionId() {
		return categoryDefinitionId;
	}

	public int getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public Integer getColumnOrderNumber() {
		return columnOrderNumber;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
