package com.ing.grdm.database;

import com.ing.grdm.domain.GrdmConfig;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository for configuration table
 */
@Repository
public interface GrdmConfigRepository extends JpaRepository<GrdmConfig, Long> {

	GrdmConfig findByTechnicalId(Long technicalId);
}
