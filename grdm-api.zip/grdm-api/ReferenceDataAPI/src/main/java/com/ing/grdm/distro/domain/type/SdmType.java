package com.ing.grdm.distro.domain.type;

/**
 * Interface for different column definition types in the SDM distribution
 */
public interface SdmType {
}
