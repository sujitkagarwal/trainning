package com.ing.grdm.api.security.authentication.exception;

import org.springframework.security.core.AuthenticationException;

/**
 * This  is GrdmAuthenticationException exception  which  extends  AuthenticationException
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class GrdmAuthenticationException extends AuthenticationException {
    public GrdmAuthenticationException(String msg) {
        super(msg);
    }
}
