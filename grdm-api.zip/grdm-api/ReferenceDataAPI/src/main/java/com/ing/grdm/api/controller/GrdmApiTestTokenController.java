package com.ing.grdm.api.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


/**
 * Test Controller
 */
@ConditionalOnProperty("com.ing.grdm.api.token.enable")
@RestController
@RequestMapping("/api")
public class GrdmApiTestTokenController {

	private static final TypeReference<List<Map<String, Object>>> JSON_TYPE_REFERENCE = new TypeReference<List<Map<String, Object>>>() {
	};

	@Value("${grdm.api-trust-tokens.url}")
	private String tokenServerUrl;

	@Autowired
	private ResourceLoader resourceLoader;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private JsonFactory jsonFactory;

	private ObjectMapper objectMapper;

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		this.objectMapper = new ObjectMapper(this.jsonFactory);
	}

	@RequestMapping(value = "/token", method = RequestMethod.GET)
	@ResponseBody
	@SuppressWarnings("unchecked")
	public ResponseEntity<String> getToken() throws IOException {
		final long time = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
		List<Map<String, Object>> jsonList;
		try (InputStream inputStream = this.resourceLoader.getResource("classpath:/token.json").getInputStream()) {
			jsonList = objectMapper.readValue(inputStream, JSON_TYPE_REFERENCE);
		}

		final Map<String, Object> map = (Map<String, Object>) jsonList.get(0).get("access_token");
		map.put("not_before", time);

		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		final HttpEntity<String> entity = new HttpEntity<>(objectMapper.writeValueAsString(jsonList), headers);
		final ResponseEntity<String> httpResponse =
				restTemplate.exchange(tokenServerUrl, HttpMethod.POST, entity, String.class);
		final String response = httpResponse.getBody();

		final List<Map<String, Object>> responseList =
				objectMapper.readValue(response.substring(response.indexOf('[')), JSON_TYPE_REFERENCE);
		final String token = "Bearer " + responseList.get(0).get("unencrypted_access_token");
		return new ResponseEntity<>(token, HttpStatus.OK);
	}

}
