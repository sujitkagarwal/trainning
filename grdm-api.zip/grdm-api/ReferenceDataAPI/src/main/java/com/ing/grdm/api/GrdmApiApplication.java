package com.ing.grdm.api;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

/**
 * GRDM's API Spring Boot application
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.ing.grdm.database", "com.ing.grdm.api", "com.ing.grdm.distro.batch", "com.ing.grdm.scheduling"})
@PropertySource(value = "classpath:/grdm.properties", ignoreResourceNotFound = true)
@PropertySource(value = "file:${PROPERTIES_DIR}/grdm.properties", ignoreResourceNotFound = true)
public class GrdmApiApplication extends SpringBootServletInitializer {

}
