package com.ing.grdm.api.cache;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetQuery;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.springframework.stereotype.Component;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The business key cache
 */
@Component
public class BusinessKeyCache extends AbstractCache {
	@Override
	protected List<String> getFacets() {
		return Arrays.asList(TABLE_DISTRO_NAME, BUSINESS_KEY);
	}

	public void addDocument(String businessKey, String distributionName) {
		final Document document = new Document();

		document.add(new StringField(BUSINESS_KEY, businessKey, Field.Store.YES));
		document.add(new StoredField(TABLE_DISTRO_NAME, distributionName));
		document.add(new FacetField(BUSINESS_KEY, businessKey.split("|")));
		document.add(new FacetField(TABLE_DISTRO_NAME, distributionName));

		addDocument(document);
	}

	public List<Map<String, Object>> search(String searchString, String distributionName) {
		final BooleanQuery.Builder builder = new BooleanQuery.Builder()
				.add(new FuzzyQuery(new Term(BUSINESS_KEY, searchString)), BooleanClause.Occur.MUST);

		if (distributionName != null) {
			builder.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName.toLowerCase()), BooleanClause.Occur.MUST);
		}

		return search(builder.build());
	}

	@Override
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.singletonList(Stream.of(
				new SimpleEntry<String, Object>("rel", "self"),
				new SimpleEntry<String, Object>("href", new StringJoiner("/", "/", "")
						.add("attributes")
						.add(document.get(TABLE_DISTRO_NAME))
						.add(document.get(BUSINESS_KEY)).toString())
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
	}
}
