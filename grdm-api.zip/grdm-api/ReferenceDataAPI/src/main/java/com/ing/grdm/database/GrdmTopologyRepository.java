package com.ing.grdm.database;

import com.ing.grdm.database.custom.GrdmTopologyCustomRepository;
import com.ing.grdm.domain.TopologyServer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Repository for GRDM_TOPOLOGY table.
 */
public interface GrdmTopologyRepository extends CrudRepository<TopologyServer, Long>, GrdmTopologyCustomRepository {

	/**
	 * Returns the hostnames part of the datacenter of the active database
	 *
	 * @return the list of hostnames
	 */
	@Query(value =
			"select hostname from grdm_topology where datacenter = ( " +
					"select t.datacenter from grdm_topology t where t.database_name = ( select sys_context('USERENV', 'INSTANCE_NAME') from dual))",
			nativeQuery = true)
	List<String> getHostnamesByActiveDatabaseDatacenter();

	/**
	 * @return the name of the active database
	 */
	@Query(value = "select sys_context('USERENV', 'INSTANCE_NAME') from dual", nativeQuery = true)
	String getActiveDatabase();
}
