package com.ing.grdm.api.security.matcher;

import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class is used to skip following endpoints provided by swagger UI:
 * /v2/api-docs", "/configuration/ui", "/swagger-resources/**", "/configuration/**", "/swagger-ui.html", "/webjars/**
 * This is achieved with GrdmSkipPathRequestMatcher implementation of RequestMatcher.
 * {@link RequestMatcher}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class GrdmSkipPathRequestMatcher implements RequestMatcher {
    private final OrRequestMatcher matcher;

    /**
     * This constructor is used create GrdmSkipPathRequestMatcher object
     *
     * @param pathsToSkip This is the lists of path to skip
     */

    public GrdmSkipPathRequestMatcher(List<String> pathsToSkip) {
        List<RequestMatcher> m = pathsToSkip.stream().map(AntPathRequestMatcher::new).collect(Collectors.toList());
        matcher = new OrRequestMatcher(m);
    }

    @Override
    public boolean matches(HttpServletRequest request) {
        return !matcher.matches(request);
    }
}