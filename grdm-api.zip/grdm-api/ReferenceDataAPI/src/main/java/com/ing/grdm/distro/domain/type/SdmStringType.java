package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represents a string type column definition in the SDM distribution
 */
public class SdmStringType implements SdmType {

	@XStreamAsAttribute
	private Integer size;

	public Integer getSize() {
		return size;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
