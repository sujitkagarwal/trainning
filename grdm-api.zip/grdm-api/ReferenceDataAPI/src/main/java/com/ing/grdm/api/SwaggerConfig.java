package com.ing.grdm.api;

import com.google.common.collect.Lists;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.PathProvider;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.paths.RelativePathProvider;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.ApiKeyVehicle;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.servlet.ServletContext;
import java.util.List;

/**
 * Swagger configuration
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    /**
     * This is used set the docket for the swagger.
     * @param pathProvider It is default method to provide the path
     * @return Return the Docket object with all the configuration.
     */
    @Bean
    public Docket api(PathProvider pathProvider) {
        return new Docket(DocumentationType.SWAGGER_2)
                .pathProvider(pathProvider)
                .securitySchemes(Lists.newArrayList(apiKey()))
                .securityContexts(Lists.newArrayList(securityContext()))
                .enable(true)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.ing.grdm.api.controller"))
                .paths(PathSelectors.any())
                .build();
    }
    /**
     * This is used set the path of api .
     * @param servletContext getting the context of the application.
     * @return Return the application path.
     *
     */
    @Bean
    public PathProvider getPathProvider(ServletContext servletContext) {
        return new RelativePathProvider(servletContext) {
            @Override
            public String getApplicationBasePath() {
                return "/api";
            }
        };
    }

    /**
     * This is used to enable the text box for the header in  swagger ui.
     */
    private ApiKey apiKey() {
        return new ApiKey("Authorization", "Authorization", "HEADER");
    }

    /**
     * This is used to enable the authentication in swagger ui.
     */
    @Bean
    SecurityConfiguration security() {
        return new SecurityConfiguration(
                null,
                null,
                null, // realm Needed for authenticate button to work
                "GRDM", // appName Needed for authenticate button to work
                "",// apiKeyValue
                ApiKeyVehicle.HEADER,
                "Authorization", //apiKeyName
                null);
    }
    /**
     * This method is used to configure the security context.
     */
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(jwtAuth())
                .forPaths(PathSelectors.regex("/anyPath.*"))
                .build();
    }
    /**
     * This method is used to get the token from ui and set in authorization header.
     */

    private List<SecurityReference> jwtAuth() {
        AuthorizationScope authorizationScope
                = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return Lists.newArrayList(
                new SecurityReference("Authorization", authorizationScopes));
    }
}
