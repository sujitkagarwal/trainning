package com.ing.grdm.scheduling;

import com.ing.grdm.database.GrdmTopologyRepository;
import com.ing.grdm.distro.job.SdmDistributionCleanupJob;
import com.ing.grdm.distro.job.SdmDistributionImportJob;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import javax.annotation.PostConstruct;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * The GRDM job scheduler. Responsible for starting the distribution import and cleanup jobs.
 */
@ConditionalOnProperty(value = "grdm.scheduling.enabled")
@Configuration
@EnableScheduling
public class GrdmJobScheduler {
	private static final Log LOG = LogFactory.getLog(GrdmJobScheduler.class);

	@Autowired
	private GrdmTopologyRepository topologyRepository;

	@Autowired
	private SdmDistributionImportJob importJob;

	@Autowired
	private SdmDistributionCleanupJob cleanupJob;

	@PostConstruct
	public void init() throws UnknownHostException {
		if (!this.topologyRepository.shouldJobRun()) {
			LOG.info(String.format("Not starting jobs on this host %s", InetAddress.getLocalHost().getHostName()));
		}
	}

	@Scheduled(cron = "${grdm.scheduling.import.cron}")
	public void runBatch() throws UnknownHostException {
		if (this.topologyRepository.shouldJobRun()) {
			this.importJob.importDistribution();
		} else {
			LOG.debug(String.format("Not starting jobs on this host %s", InetAddress.getLocalHost().getHostName()));
		}
	}

	@Scheduled(cron = "${grdm.scheduling.cleanup.cron}")
	public void runCleanupJob() throws UnknownHostException {
		if (this.topologyRepository.shouldJobRun()) {
			this.cleanupJob.cleanupDistributions();
		} else {
			LOG.debug(String.format("Not starting jobs on this host %s", InetAddress.getLocalHost().getHostName()));
		}
	}
}