package com.ing.grdm.api.response;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of {@link AttributesResponseService} using database
 */
@Component
@ConditionalOnProperty(value = "grdm.cache.enabled", havingValue = "false", matchIfMissing = true)
public class RepositoryAttributesResponseService extends AbstractResponseService implements AttributesResponseService {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private AttributesDataSerializer dataSerializer;

	@Override
	public void respondAttributesByTableName(String distributionName, List<String> columns, HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, null, columns, response)) {
			final ApiCategoryDefinition categoryDefinition =
					this.categoryDefinitionRepository.findByDistributionName(distributionName.toUpperCase());
			if (categoryDefinition == null) {
				generateTableNotFoundResponse(distributionName, response);
				return;
			}

			if (columns == null || columns.isEmpty()) {
				final List<String> businessKeys = this.dataValueRepository.getTableData(categoryDefinition.getTechnicalId(),
						categoryDefinition.getActiveDistributionSequenceNumber());
				prepareResponse(response, null);
				this.dataSerializer.serializeBusinessKeys(response.getWriter(), businessKeys);
			} else {
				final List<String> parmColumns =
						columns.parallelStream().map(String::toUpperCase).collect(Collectors.toList());
				final List<ApiDataValue> tableData = this.dataValueRepository.getTableDataByColumns(
						categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber(),
						parmColumns);
				if (tableData.isEmpty()) {
					generateColumnsNotFoundResponse(distributionName, columns, response);
					return;
				}
				prepareResponse(response, null);
				this.dataSerializer.serializeRowData(response.getWriter(), tableData, true);
			}
		}
	}

	@Override
	public void respondAttributesByTableNameAndBusinessKey(
			String distributionName, String businessKey, List<String> columns, HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, businessKey, columns, response)) {
			final ApiCategoryDefinition categoryDefinition =
					this.categoryDefinitionRepository.findByDistributionName(distributionName.toUpperCase());
			if (categoryDefinition == null) {
				generateTableNotFoundResponse(distributionName, response);
				return;
			}
			final List<ApiDataValue> rowData;
			if (columns == null || columns.isEmpty()) {
				rowData = this.dataValueRepository.getRowData(categoryDefinition.getTechnicalId(),
						categoryDefinition.getActiveDistributionSequenceNumber(), businessKey.toUpperCase());
				if (rowData.isEmpty()) {
					generateNotFoundResponse(
							String.format("No record found with business key '%s' in table %s",
									businessKey, distributionName), response);
					return;
				}
			} else {
				final List<String> parmColumns =
						columns.parallelStream().map(String::toUpperCase).collect(Collectors.toList());
				rowData = this.dataValueRepository.getRowDataByColumns(categoryDefinition.getTechnicalId(),
						categoryDefinition.getActiveDistributionSequenceNumber(), businessKey.toUpperCase(), parmColumns);
				if (rowData.isEmpty()) {
					generateNotFoundResponse(
							String.format("No record found with business key '%s' or columns with name(s) '%s' in table %s",
									businessKey, StringUtils.join(columns, ','), distributionName),
							response);
					return;
				}
			}
			prepareResponse(response, null);
			this.dataSerializer.serializeRowData(response.getWriter(), rowData, false);
		}
	}
}
