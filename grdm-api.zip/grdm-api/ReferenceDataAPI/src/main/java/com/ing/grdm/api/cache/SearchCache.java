package com.ing.grdm.api.cache;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * The search cache
 */
@Component
@SuppressWarnings("unused")
public class SearchCache {

	private static final Log LOG = LogFactory.getLog(SearchCache.class);

	@Value("${grdm.cache.categories.include:}")
	private String[] includedCategories;

	@Value("${grdm.cache.categories.exclude:}")
	private String[] excludedCategories;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private TableNameCache tableNameCache;
	@Autowired
	private ColumnNameCache columnNameCache;
	@Autowired
	private BusinessKeyCache businessKeyCache;
	@Autowired
	private ValueCache valueCache;

	private List<AbstractCache> registeredCaches = new ArrayList<>();

	@PostConstruct
	void init() throws IOException {
		LOG.info("Included categories in cache " + Stream.of(this.includedCategories).collect(Collectors.joining(",")));
		LOG.info("Excluded categories in cache " + Stream.of(this.excludedCategories).collect(Collectors.joining(",")));
		this.registeredCaches.add(this.tableNameCache);
		this.registeredCaches.add(this.columnNameCache);
		this.registeredCaches.add(this.businessKeyCache);
		this.registeredCaches.add(this.valueCache);

		reload();
	}

	@PreDestroy
	private void closeCaches() {
		this.registeredCaches.forEach(AbstractCache::close);
	}

	public List<Map<String, Object>> searchDistributionName(String searchString) {
		return this.tableNameCache.search(searchString);
	}

	public List<Map<String, Object>> searchBusinessKey(String searchString, String distributionName) {
		return this.businessKeyCache.search(searchString, distributionName);
	}

	public List<Map<String, Object>> searchColumnName(String searchString, String distributionName) {
		return this.columnNameCache.search(searchString, distributionName);
	}

	public List<Map<String, Object>> searchValue(String searchString, String distributionName,
												 String columnName, String businessKey) {
		return this.valueCache.search(searchString, distributionName, columnName, businessKey);
	}

	private void reload() {
		resetCaches();

		try {
			this.registeredCaches.forEach(AbstractCache::openForWriting);

			indexDocs();
		} catch (CacheWriteException cle) {
			LOG.error("Failed to load cache", cle);
		} finally {
			this.registeredCaches.forEach(AbstractCache::finishedWriting);
		}

		try {
			this.registeredCaches.forEach(AbstractCache::openForReading);
		} catch (CacheReadException cre) {
			LOG.info("Could not open directory reader", cre);
		}
	}

	private void indexDocs() {
		final Integer distributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();
		if (distributionSequenceNumber == null) {
			LOG.info("No categories to index because active distribution sequence number is unknown");
		}

		StreamSupport.stream(this.categoryDefinitionRepository.findAll().spliterator(), true)
				.filter(cd -> Arrays.stream(this.excludedCategories)
						.noneMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
				.filter(cd -> this.includedCategories.length == 0 || Arrays.stream(this.includedCategories)
						.anyMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
				.forEach(cd -> indexCategoryDefinition(cd, distributionSequenceNumber));
	}

	private void indexCategoryDefinition(
			ApiCategoryDefinition categoryDefinition, Integer distributionSequenceNumber) {
		LOG.info("Adding category " + categoryDefinition.getDistributionName());
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(categoryDefinition.getTechnicalId(),
				distributionSequenceNumber);
		final String distributionName = categoryDefinition.getDistributionName().toLowerCase();

		this.tableNameCache.addDocument(distributionName);

		rowData.parallelStream()
				.forEach(dv -> this.valueCache.addDocument(
						dv,
						distributionName));

		rowData.parallelStream()
				.collect(Collectors.groupingBy(ApiDataValue::getColumnName))
				.keySet()
				.forEach(columnName -> this.columnNameCache.addDocument(columnName.toLowerCase(), distributionName));

		rowData.parallelStream()
				.collect(Collectors.groupingBy(ApiDataValue::getBusinessKey))
				.keySet()
				.forEach(businessKey -> this.businessKeyCache.addDocument(businessKey, distributionName));
	}

	private void indexDataValue(ApiDataValue dataValue, String distributionName, String businessKey) {
		this.valueCache.addDocument(dataValue, distributionName);
	}

	private void resetCaches() {
		this.registeredCaches.forEach(AbstractCache::reset);
	}
}
