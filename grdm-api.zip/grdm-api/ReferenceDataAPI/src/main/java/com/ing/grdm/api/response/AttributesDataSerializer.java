package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.ing.grdm.domain.ApiDataValue;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;

/**
 * Class responsible for serializing attributes data
 */
@Component
public class AttributesDataSerializer {

	private static final String BUSINESS_KEY = "business_key";

	@Autowired
	private JsonFactory jsonFactory;

	/**
	 * Generates a response containing all business keys
	 *
	 * @param writer       the writer object
	 * @param businessKeys the list of business keys
	 * @throws IOException when failed to write to the writer
	 */
	public void serializeBusinessKeys(Writer writer, List<String> businessKeys) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(writer)) {
			jsonGenerator.writeStartArray();
			for (String businessKey : businessKeys) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField(BUSINESS_KEY, businessKey);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing table data for given columns
	 *
	 * @param writer    the writer object
	 * @param tableData the table data
	 * @param columns   the optional list of columns
	 * @throws IOException when failed to write to the writer
	 */
	public void serializeTableData(Writer writer, Map<String, Map<String, Object>> tableData, List<String> columns)
			throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(writer)) {
			jsonGenerator.writeStartArray();
			for (Map.Entry<String, Map<String, Object>> entry : tableData.entrySet()) {
				serializeRowData(jsonGenerator, entry.getKey(), entry.getValue(), columns);
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing row data for given business key and columns
	 *
	 * @param writer      the writer object
	 * @param businessKey the list of business keys
	 * @param rowData     the row data
	 * @param columns     the optional list of columns
	 * @throws IOException when failed to write to the writer
	 */
	public void serializeRowData(Writer writer, String businessKey, Map<String, Object> rowData, List<String> columns)
			throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(writer)) {
			serializeRowData(jsonGenerator, businessKey, rowData, columns);
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing row/table data for given business key and columns
	 *
	 * @param writer      the writer object
	 * @param tableData   all values
	 * @param isTableData indicates if the table data contains multiple rows
	 * @throws IOException when failed to write to the writer
	 */
	public void serializeRowData(Writer writer, List<ApiDataValue> tableData, boolean isTableData)
			throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(writer)) {
			if (isTableData) {
				jsonGenerator.writeStartArray();
				String currentBusinessKey = null;
				for (ApiDataValue apiDataValue : tableData) {
					if (!StringUtils.equals(currentBusinessKey, apiDataValue.getBusinessKey())) {
						if (currentBusinessKey != null) {
							jsonGenerator.writeEndObject();
						}
						jsonGenerator.writeStartObject();
						jsonGenerator.writeStringField(BUSINESS_KEY, apiDataValue.getBusinessKey());
						currentBusinessKey = apiDataValue.getBusinessKey();
					}
					jsonGenerator.writeFieldName(apiDataValue.getColumnName().toLowerCase());
					jsonGenerator.writeObject(getColumnNameWithAppropriateDataType(apiDataValue));
				}
				jsonGenerator.writeEndObject();
				jsonGenerator.writeEndArray();
			} else {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField(BUSINESS_KEY, tableData.get(0).getBusinessKey());
				for (ApiDataValue apiDataValue : tableData) {
					jsonGenerator.writeFieldName(apiDataValue.getColumnName().toLowerCase());
					jsonGenerator.writeObject(getColumnNameWithAppropriateDataType(apiDataValue));
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.flush();
		}
	}

	/**
	 * Creates an object of the appropriate type for given data value
	 *
	 * @param apiDataValue the data value
	 * @return the object
	 */
	public static Object getColumnNameWithAppropriateDataType(ApiDataValue apiDataValue) {
		switch (apiDataValue.getColumnType()) {
			case NUMBER:
			case PERCENTAGE:
				return Double.valueOf(apiDataValue.getStorageString());
			case REFERENCE:
			case MODEL_REFERENCE:
				return new ReferenceVo(apiDataValue.getStorageString(), apiDataValue.getReferenceTable().toLowerCase());
			case DATE:
				// For date column type the storage string is already according yyyy-MM-dd
			default:
				return apiDataValue.getStorageString();
		}
	}

	private void serializeRowData(JsonGenerator jsonGenerator, String businessKey, Map<String, Object> rowData, List<String> columns)
			throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeStringField(BUSINESS_KEY, businessKey.toUpperCase());
		for (Map.Entry<String, Object> dataValue : rowData.entrySet()) {
			if (columns == null || columns.isEmpty() || columns.parallelStream().anyMatch(s -> s.equalsIgnoreCase(dataValue.getKey()))) {
				jsonGenerator.writeObjectField(dataValue.getKey(), dataValue.getValue());
			}
		}
		jsonGenerator.writeEndObject();
	}

}
