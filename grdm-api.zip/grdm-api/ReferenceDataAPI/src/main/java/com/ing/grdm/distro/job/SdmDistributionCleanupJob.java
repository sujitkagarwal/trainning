package com.ing.grdm.distro.job;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.DistributionImportStatus;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Job responsible for cleaning up 'old' distributions.
 * The number of 'old' or inactive distributions can be configured by setting the property grdm.distro.minimum_inactive_distros.
 * By default 1 inactive distribution will be saved.
 */
@Component
public class SdmDistributionCleanupJob {

	private static final Log LOG = LogFactory.getLog(SdmDistributionCleanupJob.class);

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionImportRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Value("${grdm.distro.minimum_inactive_distros:1}")
	private long minimumInactiveDistributions;

	public void cleanupDistributions() {
		LOG.info("Starting cleanup distributions");

		// Find any category definitions with inactive data to delete
		this.categoryDefinitionImportRepository
				.getCategoryDefinitionsWithInactivesToDelete(minimumInactiveDistributions)
				.forEach(this::cleanupCategoryDefinition);

		LOG.info("Cleanup distributions done");
	}

	private void cleanupCategoryDefinition(Long categoryDefinitionId) {
		LOG.info(String.format("Cleanup category definition with id %d", categoryDefinitionId));
		final long start = System.currentTimeMillis();

		// Retrieve the category definition's distribution sequence numbers to delete
		this.categoryDefinitionImportRepository
				.getCategoryDefinitionDistributionsToDelete(categoryDefinitionId)
				.forEach(this::deleteCategoryDefinitionDistribution);

		LOG.info(String.format("Cleanup category definition with id %d completed, took %dms.",
				categoryDefinitionId, (System.currentTimeMillis() - start)));
	}

	private void deleteCategoryDefinitionDistribution(ApiCategoryDefinitionDistribution distributionToDelete) {
		this.dataValueRepository.deleteCategoryDefinitionDistributionSequenceNumber(
				distributionToDelete.getCategoryDefinitionId(), distributionToDelete.getDistributionSequenceNumber());

		// Update the record with new status DELETED
		distributionToDelete.setStatus(DistributionImportStatus.DELETED);
		distributionToDelete.setLastUpdateDate(new Date());
		this.categoryDefinitionImportRepository.save(distributionToDelete);
	}
}
