package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.List;

/**
 * Represents the structure tag in the SDM distribution
 */
@XStreamAlias("structure")
public class SdmStructure {

	@XStreamImplicit(itemFieldName = "columndefinition")
	private List<SdmColumnDefinition> columnDefinitions;

	public List<SdmColumnDefinition> getColumnDefinitions() {
		return columnDefinitions;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
