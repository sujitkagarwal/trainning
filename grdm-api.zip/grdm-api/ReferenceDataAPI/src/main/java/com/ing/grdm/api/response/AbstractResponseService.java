package com.ing.grdm.api.response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.domain.GrdmApiExceptionResponse;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static javax.servlet.http.HttpServletResponse.SC_NOT_FOUND;

/**
 * Base class for all response services.
 */
public abstract class AbstractResponseService {

	private static final Pattern SAFE_DISTRIBUTION_NAME_PATTERN = Pattern.compile("([A-Za-z0-9_]{1,25})");
	private static final Pattern SAFE_BUSINESS_KEY_PATTERN = Pattern.compile("([A-Za-z0-9_|]{1,255})");
	private static final Pattern SAFE_COLUMN_NAME_PATTERN = Pattern.compile("([A-Za-z0-9_]{1,28})");


	@Autowired
	private ObjectMapper objectMapper;

	/**
	 * Generates a default response when the table with given distribution name is not found
	 *
	 * @param distributionName the distribution name of the table
	 * @param response         the response object
	 * @throws IOException when failed to write to the response
	 */
	protected void generateTableNotFoundResponse(String distributionName, HttpServletResponse response) throws IOException {
		generateNotFoundResponse(
				String.format("No table found with distribution name '%s'", safeDistributionName(distributionName)),
				response);
	}

	/**
	 * Generates a default response when no columns are found for table with given distribution name
	 *
	 * @param distributionName the distribution name of the table
	 * @param columns          the columns provided in the request
	 * @param response         the response object
	 * @throws IOException when failed to write to the response
	 */
	protected void generateColumnsNotFoundResponse(String distributionName, List<String> columns, HttpServletResponse response) throws IOException {
		generateNotFoundResponse(
				String.format("No columns found in table %s with name(s) '%s'",
						safeDistributionName(distributionName), safeColumnNames(columns)),
				response);
	}

	/**
	 * Generates a bad request response when an illegal distribution name is provided
	 *
	 * @param message  the message
	 * @param response the response object
	 * @throws IOException when failed to write to the response
	 */
	protected void generateBadRequestResponse(String message, HttpServletResponse response) throws IOException {
		generateExceptionResponse(SC_BAD_REQUEST, message, response);
	}

	/**
	 * This method generates the exception response for all business exceptions
	 * and writes it directly to the response
	 *
	 * @param message  the message to put in the response
	 * @param response Generated serialized exception response will be written to this response
	 * @throws IOException when failing to obtain the writer
	 */
	protected void generateNotFoundResponse(String message, HttpServletResponse response) throws IOException {
		generateExceptionResponse(SC_NOT_FOUND, message, response);
	}

	private void generateExceptionResponse(int code, String message, HttpServletResponse response) throws IOException {
		final GrdmApiExceptionResponse exceptionResponse = new GrdmApiExceptionResponse(code, message);
		prepareResponse(response, exceptionResponse.getCode());
		this.objectMapper.writeValue(response.getWriter(), exceptionResponse);
	}

	/**
	 * Prepares the response by setting the content type, character encoding and status code.
	 *
	 * @param response the response object
	 * @param status   the status code, 200 if not specified
	 */
	protected void prepareResponse(HttpServletResponse response, Integer status) {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.setStatus(status == null ? HttpServletResponse.SC_OK : status);
	}

	/**
	 * Validates the given distribution name, business key and column names for illegal characters and length.
	 * This method also generates a proper exception response.
	 *
	 * @param distributionName the distribution name
	 * @param businessKey      the business key, optional
	 * @param columnNames      the column names, optional
	 * @return valid or not
	 */
	protected boolean validateInput(String distributionName, String businessKey, List<String> columnNames,
									HttpServletResponse response) throws IOException {
		boolean result = false;
		if (!SAFE_DISTRIBUTION_NAME_PATTERN.matcher(distributionName).matches()) {
			generateBadRequestResponse("Invalid table name provided", response);
		} else if (businessKey != null && !SAFE_BUSINESS_KEY_PATTERN.matcher(businessKey).matches()) {
			generateBadRequestResponse("Invalid business key provided", response);
		} else if (columnNames != null
				&& !columnNames.parallelStream().allMatch(s -> SAFE_COLUMN_NAME_PATTERN.matcher(s).matches())) {
			generateBadRequestResponse("Invalid column name(s) provided", response);
		} else {
			result = true;
		}
		return result;
	}

	private String safeDistributionName(String distributionName) {
		return SAFE_DISTRIBUTION_NAME_PATTERN.matcher(distributionName).replaceFirst("$1");
	}

	private String safeBusinessKey(String businessKey) {
		return SAFE_BUSINESS_KEY_PATTERN.matcher(businessKey).replaceFirst("$1");
	}

	private String safeColumnNames(List<String> columnNames) {
		return columnNames.stream()
				.map(column -> SAFE_COLUMN_NAME_PATTERN.matcher(column).replaceFirst("$1"))
				.collect(Collectors.joining(","));
	}

}
