/*
 * Copyright (c) 2017 ING Group. All rights reserved.
 * 
 * This software is the confidential and proprietary information of ING Group ("Confidential Information").
 */
package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.util.List;

/**
 * Represents a row in the SDM distribution.
 */
@XStreamAlias("row")
public class SdmRow {

	@XStreamAsAttribute
	private Integer level;
	
	@XStreamAsAttribute
	private String status;
	
	@XStreamImplicit(itemFieldName = "column")
	private List<SdmColumn> columns;

	public List<SdmColumn> getColumns() {
		return columns;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}
