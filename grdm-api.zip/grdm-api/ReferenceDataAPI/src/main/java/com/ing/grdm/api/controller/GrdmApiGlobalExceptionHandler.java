package com.ing.grdm.api.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.domain.GrdmApiExceptionResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Exception Handler to handle any exceptions that arise during execution of GRDM APIs
 */
@ControllerAdvice
public class GrdmApiGlobalExceptionHandler extends ResponseEntityExceptionHandler {
	private static final Logger LOG = LoggerFactory.getLogger(GrdmApiGlobalExceptionHandler.class);

	@Autowired
	private JsonFactory jsonFactory;

	/**
	 * Handle IllegalArgumentException as a bad request
	 *
	 * @param iae      the IllegalArgumentException
	 * @param response the response object
	 */
	@ExceptionHandler(IllegalArgumentException.class)
	public void handleIllegalArgumentException(IllegalArgumentException iae, HttpServletResponse response) {
		LOG.error(iae.getMessage());
		final GrdmApiExceptionResponse exceptionResponse =
				new GrdmApiExceptionResponse(HttpServletResponse.SC_BAD_REQUEST, "Bad Request");
		generateExceptionResponse(exceptionResponse, response);
	}

	/**
	 * Handle any uncaught exceptions
	 *
	 * @param re       the RuntimeException
	 * @param response the response object
	 */
	@ExceptionHandler(RuntimeException.class)
	public void handleRuntimeException(RuntimeException re, HttpServletResponse response) {
		LOG.error(re.getMessage(), re);
		final GrdmApiExceptionResponse exceptionResponse =
				new GrdmApiExceptionResponse(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Internal Server Error");
		generateExceptionResponse(exceptionResponse, response);
	}

	/**
	 * Unable to obtain the writer from the response or failed to write serialized data to it
	 *
	 * @param ioe      the IOException
	 * @param response the response object
	 */
	@ExceptionHandler(IOException.class)
	public void handleIOException(IOException ioe, HttpServletResponse response) {
		LOG.error(ioe.getMessage(), ioe);
		response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	}

	private void generateExceptionResponse(GrdmApiExceptionResponse exceptionResponse, HttpServletResponse response) {
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		response.setStatus(exceptionResponse.getCode());
		try {
			new ObjectMapper(this.jsonFactory).writeValue(response.getWriter(), exceptionResponse);
		} catch (IOException ioe) {
			// The buck stops here
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			LOG.error(ioe.getMessage(), ioe);
		}
	}


	/**
	 * Handle MethodArgumentNotValidException. Triggered when an object fails @Valid validation.
	 *
	 * @param ex      the MethodArgumentNotValidException that is thrown when @Valid validation fails
	 * @param headers HttpHeaders
	 * @param status  HttpStatus
	 * @param request WebRequest
	 * @return the ResponseEntity object of GrdmApiExceptionResponse.
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex,
			HttpHeaders headers,
			HttpStatus status,
			WebRequest request) {
		String errorMsg = ex.getBindingResult().getFieldErrors().stream()
				.map(DefaultMessageSourceResolvable::getDefaultMessage)
				.findFirst()
				.orElse(ex.getMessage());
		GrdmApiExceptionResponse grdmApiExceptionResponse = new GrdmApiExceptionResponse(HttpStatus.BAD_REQUEST.value(), errorMsg);
		return new ResponseEntity<>(grdmApiExceptionResponse, HttpStatus.BAD_REQUEST);

	}
}
