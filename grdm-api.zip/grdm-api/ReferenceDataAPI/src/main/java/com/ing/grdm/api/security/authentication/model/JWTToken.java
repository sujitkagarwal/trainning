package com.ing.grdm.api.security.authentication.model;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;


/**
 * This  is JWTToken token class which  extends  AbstractAuthenticationToken to pass in the
 * authentication provider by setting the token in  {@link AbstractAuthenticationProcessingFilter}.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class JWTToken extends AbstractAuthenticationToken implements UserDetails {

    private final String token;

    public JWTToken(String token) {
        super(null);
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getPrincipal() {
        return null;
    }


    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}
