package com.ing.grdm.api.cache;

import com.ing.grdm.api.domain.ForwardAccount;
import com.ing.grdm.api.response.AttributesDataSerializer;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.event.OverstapDataChangedEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * This is class is used for caching the overstap table based on time cron job.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 28-11-2017
 */
@Component
@ConditionalOnProperty(value = "grdm.cache.overstap.enable", matchIfMissing = true)
public class OverstapCache {
	private static final Log LOG = LogFactory.getLog(OverstapCache.class);

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	private String[] excludedColumns = {"BBAN_OLD", "BBAN_NEW"};

	private String[] includedStatus = {"06", "08"};

	// The cached data
	private OverstapCache.Data cachedData;

	@PostConstruct
	void init() {
		LOG.info("Loading over Overstap Cache  on startup");
		reload();
	}

	@Scheduled(cron = "${grdm.cache.attributes.refresh_cron}")
	void monitorAttributesDataChanges() {
		final Integer activeDistributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();
		if (activeDistributionSequenceNumber != null && !activeDistributionSequenceNumber.equals(this.cachedData.distributionSequenceNumber)) {
			LOG.info(String.format("Reloading overstap  data cache after loading distribution with sequence number %d",
					activeDistributionSequenceNumber));
			reload();
		}
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleOverstapDataChangedEvent(OverstapDataChangedEvent event) {
		LOG.info("Reloading overstap data cache after receiving event ");
		reload();
	}


	private void reload() {
		LOG.info("Excluded column in OverstapCache cache " + Stream.of(this.excludedColumns).collect(Collectors.joining(",")));
		final ApiCategoryDefinition categoryDefinition = this.categoryDefinitionRepository.findByDistributionName("OVERSTAP_TABLE");

		Integer distributionSequenceNr = null;
		Map<String, ForwardAccount> forwardAccountByOldIban = Collections.emptyMap();
		if (categoryDefinition != null) {
			// Load the row data
			forwardAccountByOldIban = this.cacheRowDataByCategoryDefinitionId(categoryDefinition);
			// Find current distribution sequence number
			distributionSequenceNr = categoryDefinition.getActiveDistributionSequenceNumber();
			}
		// swap in
		this.cachedData = new OverstapCache.Data(distributionSequenceNr, forwardAccountByOldIban);
	}

	/**
	 * This method return the matching forward account with the list of input oldIban and optional filterDate.
	 *
	 * @param oldIbans   list of Ibans for which which forward accounts will be returned
	 * @param filterDate the date for which forward account is to be filter between start and expiry date
	 * @return list of ForwardAccounts.
	 */
	public List<ForwardAccount> getForwardAccountsByIbansAndDate(List<String> oldIbans, final LocalDate filterDate) {
		return oldIbans.stream()
				.distinct() //remove duplicates
				.parallel() //parallel: get from cache (if not found: null)
				.map(iban -> iban.trim().toUpperCase())
				.map(cachedData.forwardAccountByOldIban::get)
				.filter(Objects::nonNull) //remove the null values (not found in cache)
				.filter(forwardAccount -> compareDate(forwardAccount, filterDate))
				.collect(Collectors.toList());
	}


	/**
	 * Checks if start date is after the given request date
	 *
	 * @param forwardAccount the forward account of the check against filter date
	 * @param filterDate     the date for which forward account is checked
	 * @return true if any match, false otherwise
	 */
	private boolean compareDate(final ForwardAccount forwardAccount, final LocalDate filterDate) {
		//if date is null, no filter is applied, so included in output
		if (filterDate == null) {
			return true;
		}
		// filter date is Not null, SO, Apply filter:// check start date <= filter date <= end date
		return !(filterDate.isBefore(forwardAccount.getStartDate()) || filterDate.isAfter(forwardAccount.getExpirationDate()));
	}


	private Map<String, ForwardAccount> cacheRowDataByCategoryDefinitionId(ApiCategoryDefinition categoryDefinition) {
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
				categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

		// Map of row data by business key
		Map<String, Map<String, Object>> rawData = rowData.stream()
				.filter(cd -> Arrays.stream(this.excludedColumns)
						.noneMatch(s -> s.equalsIgnoreCase(cd.getColumnName())))
				.collect(
						Collectors.groupingBy(
								// the key in the resulting map is the business key (always uppercase)
								ApiDataValue::getBusinessKey,
								Collectors.toMap(
										// the key in the value map is the column name (always lowercase)
										dv -> dv.getColumnName(),
										// the value is the object with the correct type, e.g. String, Double
										AttributesDataSerializer::getColumnNameWithAppropriateDataType)));

		return cacheForwardAccountbyOldIbanNumber(rawData);
	}


	/**
	 * This method is used to filter the ovt_sta from imput parameter and create new map having key as old_ban and forward account object.
	 *
	 * @param rowByBusinesskey map of busnesskey and map object of column and value.
	 * @return this method return the key as old iban and forward account object.
	 */
	private Map<String, ForwardAccount> cacheForwardAccountbyOldIbanNumber(Map<String, Map<String, Object>> rowByBusinesskey) {
		return rowByBusinesskey.entrySet().parallelStream()
				.filter(cd -> Arrays.stream(includedStatus)
						.anyMatch(s -> s.equalsIgnoreCase(cd.getValue().get("OVT_STA").toString())))
				.collect(
						Collectors.toMap(
								d -> d.getValue().get("IBAN_OLD").toString(),
								d -> createForwardAccount(d.getValue())
						));

	}

	private ForwardAccount createForwardAccount(Map<String, Object> forwardingAccountMap) {
		return new ForwardAccount(forwardingAccountMap.get("IBAN_OLD").toString(),
				LocalDate.parse(forwardingAccountMap.get("STRT_DT_EFF").toString(), DateTimeFormatter.ISO_LOCAL_DATE),
				forwardingAccountMap.get("IBAN_NEW").toString(),
				forwardingAccountMap.get("BIC_NEW").toString(),
				LocalDate.parse(forwardingAccountMap.get("EXP_DT").toString(), DateTimeFormatter.ISO_LOCAL_DATE)

		);

	}

	/**
	 * Represents the cached data itself, containing:
	 * <ul>
	 * <li>The current distribution sequence number</li>
	 * <li>Map containing all the forward account with key as old iban number</li>
	 * </ul>
	 * By using a Data object we can swap in the refreshed data atomically.
	 */
	private static final class Data {
		private Integer distributionSequenceNumber;
		private Map<String, ForwardAccount> forwardAccountByOldIban;

		private Data(Integer distributionSequenceNumber, Map<String, ForwardAccount> forwardAccountByOldIban) {
			this.distributionSequenceNumber = distributionSequenceNumber;
			this.forwardAccountByOldIban = Collections.unmodifiableMap(forwardAccountByOldIban);
		}
	}


}