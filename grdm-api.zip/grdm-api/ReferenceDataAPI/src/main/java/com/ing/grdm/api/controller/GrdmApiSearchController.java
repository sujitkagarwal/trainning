package com.ing.grdm.api.controller;

import com.ing.grdm.api.cache.SearchCache;
import io.swagger.annotations.SwaggerDefinition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * The Search API controller
 */
@RestController
@RequestMapping("/attributes")
@SuppressWarnings("unused")
public class GrdmApiSearchController {

	@Autowired
	private SearchCache searchCache;

	@RequestMapping(value = "/search/table/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchDistributionName(@PathVariable(name = "searchString") String searchString) {
		return this.searchCache.searchDistributionName(searchString);
	}

	@RequestMapping(value = "/search/businesskey/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchBusinessKey(@PathVariable(name = "searchString") String searchString) {
		return this.searchCache.searchBusinessKey(searchString, null);
	}

	@RequestMapping(value = "/search/businesskey/{tableName}/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchBusinessKeyInTable(@PathVariable(name = "tableName") String distributionName,
															  @PathVariable(name = "searchString") String searchString) {
		return this.searchCache.searchBusinessKey(searchString, distributionName);
	}

	@RequestMapping(value = "/search/column/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchColumnName(@PathVariable(name = "searchString") String searchString) {
		return this.searchCache.searchColumnName(searchString, null);
	}

	@RequestMapping(value = "/search/column/{tableName}/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchColumnName(@PathVariable(name = "tableName") String distributionName,
													  @PathVariable(name = "searchString") String searchString) {
		return this.searchCache.searchColumnName(searchString, distributionName);
	}

	@RequestMapping(value = "/search/value/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchValue(@PathVariable(name = "searchString") String searchString,
												 @RequestParam(name = "tableName", required = false) String distributionName,
												 @RequestParam(name = "column", required = false) String columnName,
												 @RequestParam(name = "businessKey", required = false) String businessKey) {
		return this.searchCache.searchValue(searchString, distributionName, columnName, businessKey);
	}

}
