package com.ing.grdm.api.security.filter;


import com.ing.grdm.api.security.authentication.exception.GrdmAuthenticationException;
import com.ing.grdm.api.security.authentication.model.JWTToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * This filter is applied to each API (/api/**) to authorized the request.
 * This filter has the following responsibilities:
 * <ol>
 * <li>Check for access token in Authorization header. If Access token is found in the header, delegate authentication to {link GrdmAuthenticationProvider} otherwise throw authentication exception</li>
 * <li>Invokes success or failure strategies based on the outcome of authentication process performed by GrdmAuthenticationProvider</li>
 * </ol>
 * {@link AbstractAuthenticationProcessingFilter}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class GrdmAuthenticationTokenFilter extends AbstractAuthenticationProcessingFilter {
    private final AuthenticationFailureHandler failureHandler;

    @Autowired
    public GrdmAuthenticationTokenFilter(AuthenticationFailureHandler failureHandler, RequestMatcher matcher) {
        super(matcher);
        this.failureHandler = failureHandler;
    }

    /**
     * This is invoked when request  to access a secured REST resource .
     *
     * @param httpServletRequest  This is the http request object
     * @param httpServletResponse This is the http response object
     * @throws IOException             on input/output error
     * @throws ServletException        on server exception
     * @throws AuthenticationException invalid token or empty throw GrdmAuthenticationException
     * @see IOException
     * @see ServletException
     * @see GrdmAuthenticationException
     */
    @Override
    public Authentication attemptAuthentication(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
            throws AuthenticationException, IOException, ServletException {
        String header = httpServletRequest.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            throw new GrdmAuthenticationException("No JWT token found in request headers");
        }
        String authToken = header.substring(7);
        return getAuthenticationManager().authenticate(new JWTToken(authToken));
    }

    /**
     * This is invoked when token is valid to access the secured REST resource and also set the authentication security context  .
     *
     * @param httpServletRequest  This is the http request object
     * @param httpServletResponse This is the http response object
     * @param authResult          this is valid authentication
     * @throws IOException      on input/output error
     * @throws ServletException on server exception
     * @see IOException
     * @see ServletException
     */
    @Override
    protected void successfulAuthentication(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain chain,
                                            Authentication authResult) throws IOException, ServletException {
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authResult);
        SecurityContextHolder.setContext(context);
        chain.doFilter(httpServletRequest, httpServletResponse);
    }

    /**
     * This is invoked when token is invalid to access the secured REST resource and also invoke the AuthenticationFailureHandler.   .
     *
     * @param request  This is the http request object
     * @param response This is the http response object
     * @param failed   this is exception thrown when token is null or invalid
     * @throws IOException             on input/output error
     * @throws ServletException        on server exception
     * @throws AuthenticationException invalid token or empty throw GrdmAuthenticationException
     * @see IOException
     * @see ServletException
     */
    @Override
    protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response,
                                              AuthenticationException failed) throws IOException, ServletException {
        SecurityContextHolder.clearContext();
        failureHandler.onAuthenticationFailure(request, response, failed);
    }


}
