package com.ing.grdm.api;

import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * GRMD's API web application configuration
 */
@Configuration
@EnableWebMvc
@EnableAspectJAutoProxy
@EnableScheduling
public class GrdmApiConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry
				.addResourceHandler("swagger-ui.html")
				.addResourceLocations("classpath:/META-INF/resources/");
		registry
				.addResourceHandler("/webjars/**")
				.addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	@Bean
	MetricRegistry metricRegistry() {
		return new MetricRegistry();
	}

	@Bean
	JsonFactory jsonFactory() {
		final JsonFactory jsonFactory = new JsonFactory();
		jsonFactory.disable(JsonGenerator.Feature.AUTO_CLOSE_TARGET);
		jsonFactory.setCodec(new ObjectMapper());
		return jsonFactory;
	}

	@Bean
	ObjectMapper objectMapper(JsonFactory jsonFactory) {
		return new ObjectMapper(jsonFactory);
	}
}
