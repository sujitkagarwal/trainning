package com.ing.grdm.domain;

/**
 * Possible status values for distribution imports.
 */
public enum DistributionImportStatus {
	/**
	 * This file is being imported
	 */
	IMPORTING,
	/**
	 * This file is successfully imported
	 */
	IMPORTED,
	/**
	 * The job failed to import this file
	 */
	FAILED,
	/**
	 * This distribution is the active one
	 */
	ACTIVE,
	/**
	 * This distribution is no longer active
	 */
	INACTIVE,
	/**
	 * This distribution's data has been deleted
	 */
	DELETED
}
