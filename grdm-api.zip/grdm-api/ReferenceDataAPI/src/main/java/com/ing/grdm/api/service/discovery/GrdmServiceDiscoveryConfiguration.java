package com.ing.grdm.api.service.discovery;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.DelegatingPhoenixResolver;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.Instance;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.PhoenixClient;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.PhoenixPulse;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.PhoenixResolver;
import com.ing.apisdk.toolkit.connectivity.discovery.phoenix.ServiceInformation;
import com.ing.apisdk.toolkit.connectivity.transport.core.finagle.tls.TlsUtil;
import com.twitter.finagle.stats.NullStatsReceiver;
import com.twitter.finagle.util.DefaultTimer;
import com.twitter.util.Duration;
import com.twitter.util.FuturePools;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

/**
 * This is GrdmServiceDiscoveryConfiguration which used to Discover the Grdm API in service discovery.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 16-10-2017
 */
@ConditionalOnProperty("grdm.service.discovery.enabled")
@Configuration
public class GrdmServiceDiscoveryConfiguration {

	private static final Log LOG = LogFactory.getLog(GrdmServiceDiscoveryConfiguration.class);

	@Autowired
	private ObjectMapper objectMapper;

	@Value("#{'${grdm.service.discovery.connection}'.split(',')}")
	private List<String> serviceDiscoveryConnection;
	@Value("${grdm.keyStore.location}")
	private String keyStoreFileName;
	@Value("${grdm.trustStore.location}")
	private String trustStoreFileName;
	@Value("${grdm.app.version}")
	private String version;
	@Value("${grdm.keyStorePassword}")
	private String keyStorePassword;
	@Value("${grdm.keyPassword}")
	private String keyPassword;
	@Value("${grdm.trustStorePassword}")
	private String trustStorePassword;
	@Value("${grdm.application.port}")
	private int applicationPort;
	@Value("${grdm.app.name}")
	private String applicationName;
	@Value("${grdm.application.datacenter}")
	private String applicationDataCenter;

	@Autowired
	private PhoenixResolver phoenixResolver;
	@Autowired(required = false)
	private PhoenixPulse phoenixPulse;

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		DelegatingPhoenixResolver.setPhoenixResolver(phoenixResolver);
		if (phoenixPulse != null) {
			LOG.info("phoenixPulse  started");
			phoenixPulse.start();
		}
	}

	@PreDestroy
	@SuppressWarnings("unused")
	void shutdown() {
		if (phoenixPulse != null) {
			phoenixPulse.stop();
		}
	}

	/**
	 * The PhoenixResolver is required for both resolving Phoenix’ own instances and resolving other APIs.
	 * The PhoenixResolver basically needs two configuration options and some dependencies. The configuration options are:
	 * <ol>
	 * <li> Polling interval - Indicates how often the service discovery is queried for the current set of instances for a particular endpoint, e.g. 5 seconds.</li>
	 * <li> Seed­nodes - The seed­nodes of the Phoenix cluster which will be used to discover the whole Phoenix cluster </li>
	 * </ol>
	 *
	 * @param phoenixClient {@link PhoenixClient}
	 * @return this method return the PhoenixResolver object.
	 */
	@Bean
	public PhoenixResolver phoenixResolver(final PhoenixClient phoenixClient) {
		LOG.info("resolving  phoenixResolver");
		return new PhoenixResolver(NullStatsReceiver.get(), Optional.of(Duration.fromMilliseconds(5000L)),
				FuturePools.unboundedPool(), serviceDiscoveryConnection, phoenixClient, DefaultTimer.twitter());
	}

	/**
	 * Phoenix is IN­G’s implementation of service discovery. It is used for discovering other APIs within
	 * ING and making your API available to other consumers
	 *
	 * @return this method return the PhoenixClient object.
	 * @throws IOException this will throw IOException if any configuration issue
	 */
	@Bean
	public PhoenixClient phoenixClient() throws IOException {
		LOG.info("initializing PhoenixClient client");
		try (FileInputStream keyStore = new FileInputStream(keyStoreFileName);
			 FileInputStream trustStore = new FileInputStream(trustStoreFileName)) {
			final SSLContext sslContext = TlsUtil.createMutualTlsContext(
					keyStore,
					keyStorePassword,
					keyPassword,
					trustStore,
					trustStorePassword);
			LOG.info("initializing ssl context");
			return new PhoenixClient(sslContext);
		}
	}

	/**
	 * The PhoenixPulse will send heart­beats to the Phoenix cluster at a con­figured in­ter­val and will register the API if needed.
	 *
	 * @param phoenixClient {@link PhoenixClient}
	 * @return this method return the PhoenixPulse object.
	 * @throws IOException this will throw IOException if any configuration issue
	 */
	@Bean
	public PhoenixPulse phoenixPulse(final PhoenixClient phoenixClient) throws IOException, URISyntaxException {
		LOG.info("initializing phoenixPulse");
		final Duration pollInterval = Duration.fromMilliseconds(5000L);
		String manifest = new String(Files.readAllBytes(Paths.get(getClass().getClassLoader().getResource("ReferenceDataAPI.txt").toURI())));
		final ServiceInformation serviceInformation = ServiceInformation.apply(applicationName, "1.0.0", manifest);
		final Instance instanceInformation = Instance.apply(InetAddress.getLocalHost().getHostName(), applicationPort, applicationDataCenter);
		return PhoenixPulse.apply(phoenixClient, serviceInformation, instanceInformation, pollInterval,
				DefaultTimer.twitter());

	}
}
