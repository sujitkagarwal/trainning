package com.ing.grdm.database;

import com.ing.grdm.domain.ApiCategoryDefinition;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Repository definition for the GRDM_API_CATEGORY_DEFINITION table
 */
public interface GrdmApiCategoryDefinitionRepository extends CrudRepository<ApiCategoryDefinition, Long> {

	/**
	 * @param distributionName the distribution name of the category definition
	 * @return Returns the category definition for given distribution name
	 */
	ApiCategoryDefinition findByDistributionName(String distributionName);

	/**
	 * Determines the active distribution sequence number by getting the max from the database.
	 * The active distribution number is atomically updated when distribution job completes.
	 *
	 * @return the active distribution sequence number
	 */
	@Query("select max(activeDistributionSequenceNumber) from ApiCategoryDefinition")
	Integer getActiveDistributionSequenceNumber();
}
