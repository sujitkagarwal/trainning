package com.ing.grdm.api.cache;

import com.ing.grdm.domain.ApiDataValue;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.DoublePoint;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetQuery;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * The value cache
 */
@Component
public class ValueCache extends AbstractCache {
	@Override
	protected List<String> getFacets() {
		return Arrays.asList(TABLE_DISTRO_NAME, BUSINESS_KEY, COLUMN_DISTRO_NAME);
	}

	public void addDocument(ApiDataValue dataValue, String distributionName) {
		final Document document = new Document();
		final IndexableField field;

		switch (dataValue.getColumnType()) {
			case NUMBER:
			case PERCENTAGE:
				field = new DoublePoint("value", Double.parseDouble(dataValue.getStorageString()));
				break;
			default:
				field = new StringField("value", dataValue.getStorageString(), Field.Store.YES);
		}

		document.add(field);
		document.add(new StoredField(TABLE_DISTRO_NAME, distributionName));
		document.add(new StoredField(BUSINESS_KEY, dataValue.getBusinessKey()));
		document.add(new StoredField(COLUMN_DISTRO_NAME, dataValue.getColumnName().toLowerCase()));

		document.add(new FacetField(TABLE_DISTRO_NAME, distributionName));
		document.add(new FacetField(BUSINESS_KEY, dataValue.getBusinessKey().toLowerCase().split("|")));
		document.add(new FacetField(COLUMN_DISTRO_NAME, dataValue.getColumnName().toLowerCase()));

		addDocument(document);
	}

	public List<Map<String, Object>> search(String searchString, String distributionName, String columnName, String businessKey) {

		final FuzzyQuery query = new FuzzyQuery(new Term("value", searchString));

		final BooleanQuery.Builder builder = new BooleanQuery.Builder()
				.add(query, Occur.MUST);

		if (distributionName != null) {
			builder.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName.toLowerCase()), Occur.MUST);
		}
		if (columnName != null) {
			builder.add(new FacetQuery(COLUMN_DISTRO_NAME, columnName.toLowerCase()), Occur.MUST);
		}
		if (businessKey != null) {
			builder.add(new FacetQuery(BUSINESS_KEY, businessKey.toLowerCase().split("|")), Occur.MUST);
		}

		return search(builder.build());
	}
}
