package com.ing.grdm.api.cache;

import com.ing.grdm.api.response.AttributesDataSerializer;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * Cache containing the required attributes data
 */
@Component
@ConditionalOnProperty("grdm.cache.enabled")
public class AttributesDataCache {

	private static final Log LOG = LogFactory.getLog(AttributesDataCache.class);

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private AttributesDataSerializer attributesDataSerializer;

	@Value("${grdm.cache.categories.exclude:}")
	private String[] excludedCategories;

	// The cached data
	private Data cachedData;

	/**
	 * Represents the cached data itself, containing:
	 * <ul>
	 * <li>The current distribution sequence number</li>
	 * <li>Map with business keys per table distribution name, already serialized!</li>
	 * <li>Map containing all row data of active tables</li>
	 * <li>Map containing all column names per table distribution name, used for verifying column names provided in request</li>
	 * </ul>
	 * By using a Data object we can swap in the refreshed data atomically.
	 */
	private static final class Data {
		private int distributionSequenceNumber;

		private Map<String, Set<String>> columnNamesByDistributionName;

		private Map<String, String> businessKeysByDistributionName;

		private Map<String, Map<String, Map<String, Object>>> columnsByDistributionName;

		private Data(int distributionSequenceNumber,
					 Map<String, String> businessKeysByDistributionName,
					 Map<String, Map<String, Map<String, Object>>> columnsByDistributionName) {
			this.distributionSequenceNumber = distributionSequenceNumber;
			this.columnNamesByDistributionName = cacheColumnNamesByDistributionName(columnsByDistributionName);
			this.businessKeysByDistributionName = Collections.unmodifiableMap(businessKeysByDistributionName);
			this.columnsByDistributionName = Collections.unmodifiableMap(columnsByDistributionName);
		}
	}

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		LOG.info("Loading attributes data cache on startup");
		reload();
	}

	@Scheduled(cron = "${grdm.cache.attributes.refresh_cron}")
	@SuppressWarnings("unused")
	void monitorAttributesDataChanges() {
		final Integer activeDistributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();
		if (activeDistributionSequenceNumber != this.cachedData.distributionSequenceNumber) {
			LOG.info(String.format("Reloading attributes data cache after loading distribution with sequence number %d",
					activeDistributionSequenceNumber));
			reload();
		}
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleAttributesDataChangedEvent(AttributesDataChangedEvent event) {
		LOG.info("Reloading attributes data cache after receiving event");
		reload();
	}

	private void reload() {
		// Find all distributions
		LOG.info("Excluded categories in attribute cache " + Stream.of(this.excludedCategories).collect(Collectors.joining(",")));

		final Iterable<ApiCategoryDefinition> categoryDefinitions = this.categoryDefinitionRepository.findAll();

		// Load the business keys by distribution name
		final Map<String, String> businessKeysByDistributionName =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(cd -> cd.getActiveDistributionSequenceNumber() != null)
						.filter(cd -> Arrays.stream(this.excludedCategories)
								.noneMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								this::cacheBusinessKeysByCategoryDefinitionId));

		// Load the row data
		final Map<String, Map<String, Map<String, Object>>> columnsByDistributionName =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(cd -> cd.getActiveDistributionSequenceNumber() != null)
						.filter(cd -> Arrays.stream(this.excludedCategories)
								.noneMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								this::cacheRowDataByCategoryDefinitionId));

		// Find current distribution sequence number
		final int distributionSequenceNr = StreamSupport.stream(categoryDefinitions.spliterator(), true)
				.filter(cd -> cd.getActiveDistributionSequenceNumber() != null)
				.filter(cd -> Arrays.stream(this.excludedCategories)
						.noneMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
				.mapToInt(ApiCategoryDefinition::getActiveDistributionSequenceNumber)
				.findAny().orElse(-1);

		// swap in
		this.cachedData = new Data(distributionSequenceNr, businessKeysByDistributionName, columnsByDistributionName);
	}

	private String cacheBusinessKeysByCategoryDefinitionId(ApiCategoryDefinition categoryDefinition) {
		final List<String> tableData = this.dataValueRepository.getTableData(categoryDefinition.getTechnicalId(),
				categoryDefinition.getActiveDistributionSequenceNumber());
		final StringWriter writer = new StringWriter();
		try {
			// pre-serialize the list of business keys
			attributesDataSerializer.serializeBusinessKeys(writer, tableData);
			return writer.toString();
		} catch (IOException ioe) {
			// won't happen
			return "[]";
		} finally {
			LOG.info(String.format(
					"Loaded business keys by distribution name %s with distribution sequence number %d into cache",
					categoryDefinition.getDistributionName(), categoryDefinition.getActiveDistributionSequenceNumber()));
		}
	}

	private Map<String, Map<String, Object>> cacheRowDataByCategoryDefinitionId(ApiCategoryDefinition categoryDefinition) {
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
				categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

		// Map of row data by business key
		return rowData.stream().collect(
				Collectors.groupingBy(
						// the key in the resulting map is the business key (always uppercase)
						ApiDataValue::getBusinessKey,
						Collectors.toMap(
								// the key in the value map is the column name (always lowercase)
								dv -> dv.getColumnName().toLowerCase(),
								// the value is the object with the correct type, e.g. String, Double
								AttributesDataSerializer::getColumnNameWithAppropriateDataType)));
	}

	private static Map<String, Set<String>> cacheColumnNamesByDistributionName(Map<String, Map<String, Map<String, Object>>> columnsByDistributionName) {
		// Sets of column names by distribution name
		return columnsByDistributionName.entrySet().stream().collect(
				Collectors.toMap(
						// the key in the resulting map is the distribution name
						Map.Entry::getKey,
						// the entry are the unique column names
						d -> d.getValue().values().parallelStream().flatMap(
								v -> v.keySet().stream()).collect(Collectors.toSet())
				));
	}

	/**
	 * Check for existing table distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return true if found, false otherwise
	 */
	public boolean containsTable(String distributionName) {
		return this.cachedData.businessKeysByDistributionName.containsKey(distributionName.toUpperCase());
	}

	/**
	 * Checks if any given column name exists in given table distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @param columns          the columns from the request, case insensitive
	 * @return true if any match, false otherwise
	 */
	public boolean containsColumns(String distributionName, List<String> columns) {
		return this.cachedData.columnNamesByDistributionName
				.getOrDefault(distributionName.toUpperCase(), Collections.emptySet())
				.stream().anyMatch(s -> columns.stream().anyMatch(s::equalsIgnoreCase));
	}

	/**
	 * Returns all the business keys of the table with given distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return the pre-serialized string containing all business keys
	 */
	public String getBusinessKeysByDistributionName(String distributionName) {
		return this.cachedData.businessKeysByDistributionName.get(distributionName.toUpperCase());
	}

	/**
	 * Returns all row data from the table with given distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return the row data in a Map, an empty Map if not found
	 */
	public Map<String, Map<String, Object>> getColumnsByDistributionName(String distributionName) {
		return this.cachedData.columnsByDistributionName
				.getOrDefault(distributionName.toUpperCase(), Collections.emptyMap());
	}

	/**
	 * Returns the row data from the table with given distribution name for given business key
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @param businessKey      the business key of the row, case sensitive
	 * @return the row data in a Map, an empty Map if not found
	 */
	public Map<String, Object> getColumnsByDistributionNameAndBusinessKey(String distributionName, String businessKey) {
		return getColumnsByDistributionName(distributionName.toUpperCase())
				.getOrDefault(businessKey, Collections.emptyMap());
	}
}
