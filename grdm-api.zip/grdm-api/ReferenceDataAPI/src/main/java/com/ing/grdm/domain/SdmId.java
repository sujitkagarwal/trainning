/*
 * Copyright (c) 2017 ING Group. All rights reserved.
 * 
 * This software is the confidential and proprietary information of ING Group ("Confidential Information").
 */
package com.ing.grdm.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Compound key
 */
@Embeddable
public class SdmId implements Serializable {

	@Column(name = "BUSINESS_KEY")
	private String businessKey;

	@Column(name = "VERSION")
	private Long version;

	public SdmId() {
		// Required by JPA
	}

	public SdmId(String businessKey, Long version) {
		this.businessKey = businessKey;
		this.version = version;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public Long getVersion() {
		return version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

}
