package com.ing.grdm.domain;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import java.io.Serializable;

/**
 * Represents the primary key in the GRDM_API_CAT_DEF_SEQ table
 */
public class ApiCategoryDefinitionDistributionId implements Serializable {

	private Long categoryDefinitionId;
	private Integer distributionSequenceNumber;

	public ApiCategoryDefinitionDistributionId() {
	}

	public ApiCategoryDefinitionDistributionId(Long categoryDefinitionId, Integer distributionSequenceNumber) {
		this.categoryDefinitionId = categoryDefinitionId;
		this.distributionSequenceNumber = distributionSequenceNumber;
	}

	public Long getCategoryDefinitionId() {
		return categoryDefinitionId;
	}

	public Integer getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	@Override
	public int hashCode() {
		return HashCodeBuilder.reflectionHashCode(this);
	}

	@Override
	public boolean equals(Object obj) {
		return EqualsBuilder.reflectionEquals(this, obj);
	}
}
