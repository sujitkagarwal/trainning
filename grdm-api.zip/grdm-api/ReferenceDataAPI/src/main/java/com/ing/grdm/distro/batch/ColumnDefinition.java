package com.ing.grdm.distro.batch;

import com.ing.grdm.domain.ColumnType;

import java.io.Serializable;

/**
 * Column definitions for use in the batch, needs to be {@link Serializable} so it fits in the step/job execution context
 */
public class ColumnDefinition implements Serializable {

	private String distributionName;
	private boolean primaryKey;
	private ColumnType columnType;
	private int orderNumber;
	private String referenceTable;

	public String getDistributionName() {
		return distributionName;
	}

	public void setDistributionName(String distributionName) {
		this.distributionName = distributionName;
	}

	public boolean isPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(boolean primaryKey) {
		this.primaryKey = primaryKey;
	}

	public ColumnType getColumnType() {
		return columnType;
	}

	public void setColumnType(ColumnType columnType) {
		this.columnType = columnType;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getReferenceTable() {
		return referenceTable;
	}

	public void setReferenceTable(String referenceTable) {
		this.referenceTable = referenceTable;
	}
}
