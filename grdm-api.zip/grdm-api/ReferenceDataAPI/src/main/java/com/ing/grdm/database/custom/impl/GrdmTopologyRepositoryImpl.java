package com.ing.grdm.database.custom.impl;

import com.ing.grdm.database.GrdmTopologyRepository;
import com.ing.grdm.database.custom.GrdmTopologyCustomRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Custom operations on GRDM_TOPOLOGY table.
 */
public class GrdmTopologyRepositoryImpl implements GrdmTopologyCustomRepository {
	private static final Log LOG = LogFactory.getLog(GrdmTopologyRepositoryImpl.class);

	@Autowired
	private GrdmTopologyRepository repo;

	@Override
	public boolean shouldJobRun() {
		try {
			final String hostname = InetAddress.getLocalHost().getHostName();
			return this.repo.getHostnamesByActiveDatabaseDatacenter().contains(hostname);
		} catch (UnknownHostException e) {
			// should not happen
			LOG.warn("Could not resolve this server's hostname: " + e.getMessage());
			return false;
		}
	}
}
