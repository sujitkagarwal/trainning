package com.ing.grdm.api.metrics;

import com.codahale.metrics.MetricFilter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.ScheduledReporter;
import com.codahale.metrics.graphite.Graphite;
import com.codahale.metrics.graphite.GraphiteReporter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.InetSocketAddress;
import java.util.concurrent.TimeUnit;

/**
 * Metrics reporter posting results to Graphite every minute.
 */
@Component
@Profile("default")
public class MetricsReporterImpl implements MetricsReporter {

	private static final Log LOG = LogFactory.getLog(MetricsReporterImpl.class);

	@Value("${grdm.metrics.enabled:false}")
	private boolean metricsEnabled;

	@Value("${grdm.metrics.graphite.host:}")
	private String graphiteHost;

	@Value("${grdm.metrics.graphite.port:0}")
	private int graphitePort;

	@Value("${grdm.metrics.graphite.prefix:}")
	private String prefix;

	@Autowired
	private MetricRegistry metricRegistry;

	private ScheduledReporter metricsReporter;

	@PostConstruct
	public void init() {
		if (this.metricsEnabled) {
			LOG.info("initializing graphite reporter");
			final Graphite graphite = new Graphite(new InetSocketAddress(graphiteHost, graphitePort));
			this.metricsReporter = GraphiteReporter.forRegistry(this.metricRegistry)
					.prefixedWith(prefix)
					.convertRatesTo(TimeUnit.MINUTES)
					.convertDurationsTo(TimeUnit.MILLISECONDS)
					.filter(MetricFilter.ALL)
					.build(graphite);

			LOG.info(String.format("graphite reporter initialized, host=%s:%d, prefix=%s", graphiteHost, graphitePort, prefix));

			// Schedule the reporter
			this.metricsReporter.start(1, TimeUnit.MINUTES);
			LOG.info("graphite reporting started");
		} else {
			LOG.info("graphite reporting disabled");
		}
	}

	@PreDestroy
	public void destroy() {
		if (this.metricsEnabled) {
			this.metricsReporter.stop();
			LOG.info("graphite reporting stopped");
		}
	}
}
