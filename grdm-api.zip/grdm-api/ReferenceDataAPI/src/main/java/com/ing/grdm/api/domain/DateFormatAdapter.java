/*
 * DateFormatAdapter.java
 *
 * Copyright © 2017 ING Group. All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * ING Group ("Confidential Information").
*/
package com.ing.grdm.api.domain;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * LocalDate adapter for date conversion in/to xml
 */
class DateFormatAdapter extends XmlAdapter<String, LocalDate> {

	@Override
	public LocalDate unmarshal(String v) throws Exception {
		return LocalDate.parse(v, DateTimeFormatter.ISO_LOCAL_DATE);
	}

	@Override
	public String marshal(LocalDate v) throws Exception {
		return DateTimeFormatter.ISO_LOCAL_DATE.format(v);
	}
}
