package com.ing.grdm.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity bean representing row in configuration table
 */
@Entity
@Table(name = "GRDM_CONFIG" )
public class GrdmConfig {

	@Id
	@Column(name = "TECHNICAL_ID")
	private Long technicalId;

	@Column(name = "TECHNICAL_VERSION")
	private Integer technicalVersion;

	@Column(name = "NAME")
	private String name;

	@Column(name = "VALUE")
	private String value;

	@Column(name = "DESCRIPTION")
	private String description;

	public Long getTechnicalId() {
		return technicalId;
	}

	public void setTechnicalId(Long technicalId) {
		this.technicalId = technicalId;
	}

	public Integer getTechnicalVersion() {
		return technicalVersion;
	}

	public void setTechnicalVersion(Integer technicalVersion) {
		this.technicalVersion = technicalVersion;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
