package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;

/**
 * Represents a multi reference table type column definition in the SDM distribution
 */
public class SdmMultiReferenceTableType implements SdmType {

	@XStreamImplicit(itemFieldName = "referenceabletable")
	private List<String> values;

	public List<String> getValues() {
		return values;
	}
}

