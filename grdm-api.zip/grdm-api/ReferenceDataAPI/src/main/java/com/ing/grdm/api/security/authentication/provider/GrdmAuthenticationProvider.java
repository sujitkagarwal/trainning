package com.ing.grdm.api.security.authentication.provider;

import com.ing.api.security.trust.InvalidTokenException;
import com.ing.api.security.trust.properties.StandardTrustProperties;
import com.ing.api.security.trust.token.access.AccessTokenParser;
import com.ing.grdm.api.security.authentication.exception.GrdmAuthenticationException;
import com.ing.grdm.api.security.authentication.model.JWTToken;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;


/**
 * This  is AuthenticationProvider which used to validate the token.
 * This AuthenticationProvider has the following responsibilities:
 * <ol>
 * <li> Verify the access token's signature.</li>
 * <li> Using the  trust token api to parse the token.</li>
 * <li> If Access token is unable to parse then invalid token is thrown</li>
 * </ol>
 * {@link com.ing.grdm.api.security.config.GrdmWebSecurityConfig}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
@ConditionalOnProperty(value = "grdm.api.security", matchIfMissing = true)
@Component
public class GrdmAuthenticationProvider implements AuthenticationProvider {

	private final AccessTokenParser accessTokenParser;

	/**
	 * This is default constructor to set the access token parser to parse the token .
	 */
	public GrdmAuthenticationProvider(@Value("${grdm.api-trust-tokens.properties.location}") String location) {
		accessTokenParser = new AccessTokenParser(new StandardTrustProperties(location));
	}

	/**
	 * This is invoked from GrdmAuthenticationTokenFilter  to valid the token .
	 *
	 * @param authentication This is the http response object
	 * @throws AuthenticationException on invalid token
	 * @throws AuthenticationException invalid token or empty throw GrdmAuthenticationException
	 * @see AuthenticationException
	 * @see GrdmAuthenticationException
	 */
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		JWTToken jwtToken = (JWTToken) authentication;
		try {
			accessTokenParser.parseAccessToken(jwtToken.getToken());
		} catch (InvalidTokenException exceptionMessage) {
			throw new GrdmAuthenticationException("Invalid Token");
		}
		authentication.setAuthenticated(true);
		return authentication;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return JWTToken.class.isAssignableFrom(authentication);
	}
}
