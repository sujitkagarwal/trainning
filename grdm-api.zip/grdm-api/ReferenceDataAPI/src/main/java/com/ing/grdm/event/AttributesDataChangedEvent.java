package com.ing.grdm.event;

/**
 * Application event notifying listeners that attributes data has changed
 */

public class AttributesDataChangedEvent {
	public AttributesDataChangedEvent() {

	}
}
