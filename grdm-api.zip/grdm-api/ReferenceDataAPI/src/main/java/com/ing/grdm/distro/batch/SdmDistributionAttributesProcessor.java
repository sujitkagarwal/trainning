package com.ing.grdm.distro.batch;

import com.ing.grdm.distro.domain.SdmColumn;
import com.ing.grdm.distro.domain.SdmRow;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.itrf.sdm.common.beans.data.DataRow;
import org.apache.commons.lang.StringUtils;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * {@link ItemProcessor} implementation responsible for converting SDM distribution rows into a list of data values.
 */
@Component
@StepScope
public class SdmDistributionAttributesProcessor implements ItemProcessor<SdmRow, List<ApiDataValue>> {

	@Value("#{stepExecutionContext['categoryDefinitionId']}")
	private long categoryDefinitionId;

	@Value("#{jobParameters['distributionSequenceNumber']}")
	private Long distributionSequenceNumber;

	@Value("#{stepExecutionContext['columnDefinitions']}")
	private Map<String, ColumnDefinition> columnDefinitions;

	@Override
	public List<ApiDataValue> process(SdmRow input) throws Exception {
		if (this.columnDefinitions.isEmpty()) {
			// For some reason reading the table structure failed in the step execution listener, fail here
			throw new ProcessDistributionException(String.format("No column definitions found for category definition %d", this.categoryDefinitionId));
		}
		if (DataRow.DATA_ROW_STATUS_ACTIVE_DESCRIPTION.equals(input.getStatus())) {
			return input.getColumns().stream()
					.filter(column -> StringUtils.isNotBlank(column.getValue()))
					.map(column -> transformColumn(column, input.getColumns()))
					.collect(Collectors.toList());
		}

		return Collections.emptyList();
	}

	private ApiDataValue transformColumn(SdmColumn currentColumn, List<SdmColumn> columns) {
		final ApiDataValue dataValue = new ApiDataValue();
		final ColumnDefinition columnDefinition = this.columnDefinitions.get(currentColumn.getName());
		dataValue.setCategoryDefinitionId(this.categoryDefinitionId);
		dataValue.setDistributionSequenceNumber(this.distributionSequenceNumber.intValue());
		dataValue.setBusinessKey(createBusinessKey(columns));
		dataValue.setColumnOrderNumber(columnDefinition.getOrderNumber());
		dataValue.setColumnName(currentColumn.getName());
		dataValue.setStorageString(currentColumn.getValue());
		dataValue.setColumnType(columnDefinition.getColumnType());
		dataValue.setReferenceTable(columnDefinition.getReferenceTable());
		return dataValue;
	}

	private String createBusinessKey(List<SdmColumn> columns) {
		return columns.stream()
				.filter(column -> this.columnDefinitions.get(column.getName()).isPrimaryKey())
				.map(SdmColumn::getValue)
				.collect(Collectors.joining("|"));
	}
}
