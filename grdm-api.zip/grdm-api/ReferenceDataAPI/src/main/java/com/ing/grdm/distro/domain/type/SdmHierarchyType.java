package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents a hierarchy type column definition in the SDM distribution
 */
public class SdmHierarchyType implements SdmType {

	@XStreamAsAttribute
	@XStreamAlias("maxlevel")
	private int maxLevel;

	public int getMaxLevel() {
		return maxLevel;
	}
}
