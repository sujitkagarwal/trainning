package com.ing.grdm.api.cache;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.facet.FacetsConfig;
import org.apache.lucene.facet.taxonomy.TaxonomyWriter;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.RAMDirectory;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Super class for cache implementations
 */
public abstract class AbstractCache implements Closeable {

	private static final Log LOG = LogFactory.getLog(AbstractCache.class);

	protected static final String TABLE_DISTRO_NAME = "table";
	protected static final String COLUMN_DISTRO_NAME = "column";
	protected static final String BUSINESS_KEY = "business_key";

	private RAMDirectory directory;
	private RAMDirectory taxonomyDirectory;
	private FacetsConfig facetsConfig = new FacetsConfig();
	private IndexWriter indexWriter;
	private TaxonomyWriter taxonomyWriter;
	private IndexReader indexReader;
	private IndexSearcher indexSearcher;
	private AtomicInteger count = new AtomicInteger();

	protected void openForWriting() {
		try {
			this.indexWriter = new IndexWriter(this.directory,
					new IndexWriterConfig().setOpenMode(OpenMode.CREATE));
			this.taxonomyWriter = new DirectoryTaxonomyWriter(this.taxonomyDirectory, OpenMode.CREATE);
		} catch (IOException ioe) {
			throw new CacheWriteException(ioe);
		}
	}

	protected void finishedWriting() {
		IOUtils.closeQuietly(this.indexWriter);
		IOUtils.closeQuietly(this.taxonomyWriter);

		LOG.info(String.format("Reloading search cache completed, added %d documents", this.count.get()));
	}

	protected void openForReading() {
		try {
			this.indexReader = DirectoryReader.open(this.directory);
		} catch (IOException ioe) {
			throw new CacheReadException(ioe);
		}
		this.indexSearcher = new IndexSearcher(this.indexReader);
	}

	@PreDestroy
	void breakdown() {
		close();
		IOUtils.closeQuietly(this.directory);
		IOUtils.closeQuietly(this.taxonomyDirectory);
	}

	@Override
	public void close() {
		IOUtils.closeQuietly(this.indexWriter);
		IOUtils.closeQuietly(this.indexReader);

		this.indexReader = null;
		this.indexSearcher = null;
		this.count.set(0);
	}

	@PostConstruct
	public void init() {
		getFacets().forEach(category -> this.facetsConfig.setHierarchical(category, true));
	}

	protected abstract List<String> getFacets();

	public void reset() {
		close();

		this.directory = new RAMDirectory();
		this.taxonomyDirectory = new RAMDirectory();
	}

	protected void addDocument(Document document) {
		try {
			this.indexWriter.addDocument(this.facetsConfig.build(this.taxonomyWriter, document));
			this.count.incrementAndGet();
		} catch (IOException ioe) {
			throw new CacheWriteException(ioe);
		}
	}

	protected List<Map<String, Object>> search(Query query) {
		final Analyzer analyzer = new StandardAnalyzer();

		try {
			final TopDocs hits = this.indexSearcher.search(query, 10);

			return Arrays.stream(hits.scoreDocs).map(this::scoreDocToString).collect(Collectors.toList());
		} catch (IOException | RuntimeException e) {
			LOG.warn("Could not execute query", e);
			return Collections.emptyList();
		}
	}

	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.emptyList();
	}

	private Map<String, Object> scoreDocToString(ScoreDoc scoreDoc) {
		try {
			final Document doc = this.indexSearcher.doc(scoreDoc.doc);
			final Map<String, Object> result = new LinkedHashMap<>(doc.getFields()
					.stream()
					.collect(Collectors.toMap(IndexableField::name, IndexableField::stringValue)));
			result.put("score", scoreDoc.score);
			final List<Map<String, Object>> links = addLinks(doc);
			if (!links.isEmpty()) {
				result.put("links", links);
			}
			return result;
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}
