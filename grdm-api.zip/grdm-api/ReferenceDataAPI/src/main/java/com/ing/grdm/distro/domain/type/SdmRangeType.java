package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents a range type column definition in the SDM distribution
 */
public class SdmRangeType implements SdmType {

	@XStreamAsAttribute
	@XStreamAlias("rangevalue")
	private Double rangeValue;

	public Double getRangeValue() {
		return rangeValue;
	}
}
