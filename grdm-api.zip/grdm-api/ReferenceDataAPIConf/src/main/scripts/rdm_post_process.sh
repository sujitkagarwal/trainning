#!/bin/bash

cd /appl/grdm/sdm2rdm

# Untar and remove the delivered tar file
tarfile=rdm_distro.tar.gz

if [ -f $tarfile ]; then
        tar -xzf $tarfile
        rm $tarfile
else
        echo "$tarfile not found"
fi

# Keep only latest 3 distributions
distros=(RDM_*)
keep=3
length=$((${#distros[@]}-$keep))

for f in ${distros[@]:0:$length}; do
        echo "`date`: Removing distribution $f" >> /appl/grdm/scripts/rdm_post_process.log
        rm -fr $f
done
