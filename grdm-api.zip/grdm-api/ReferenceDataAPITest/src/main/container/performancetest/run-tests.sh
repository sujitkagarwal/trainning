#!/bin/bash

echo "application=$APPLICATION"
echo "version=$VERSION"
echo "environment=$ENVIRONMENT"
echo "password=$PASSWORD"
echo "vUser=$VUSER"
echo "rampUpTime=$RAMPUPTIME"
echo "duration=$DURATION"

/apache-jmeter/bin/jmeter.sh -n -t /testscripts/grdm.jmx  -l /testresults/referenceDataAPI.csv  -e -o /output -Jfile=/config/$ENVIRONMENT/reference-data-api-test.csv -JvUser=$VUSER -JrampUpTime=$RAMPUPTIME -Jduration=$DURATION

tar -C /output -cvf referenceDataAPI.tar .

curl -X PUT -T 'referenceDataAPI.tar' "http://itested.europe.intranet:8888/put/performancetest/testresults/stdout/tar/$APPLICATION/$VERSION/$ENVIRONMENT/1/1/0/0?overwrite=true"