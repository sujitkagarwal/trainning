package com.ing.grdm.cucumber.report;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import net.masterthought.cucumber.Reportable;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Generates a nice report using the generated json results file.
 */
public class Main {

	public static void main(String[] args) throws IOException {
		final String projectName = args[0];
		final String buildNumber = args[1];
		final String releaseNumber = args[2];
		final String environment = args[3];

		final File reportOutputDirectory = new File("output");
		final List<String> jsonFiles = new ArrayList<>();
		jsonFiles.add(args[4]);

		final Configuration configuration = new Configuration(reportOutputDirectory, projectName);
		configuration.setParallelTesting(false);
		configuration.setRunWithJenkins(false);
		configuration.setBuildNumber(buildNumber);
		configuration.addClassifications("Branch", "master/" + releaseNumber);
		configuration.addClassifications("Environment", environment);

		final ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		final Reportable result = reportBuilder.generateReports();

		try (final FileWriter fileWriter = new FileWriter("output/results.txt")) {
			fileWriter.append(String.format("total=%d%n", result.getScenarios()))
					.append(String.format("passed=%d%n", result.getPassedScenarios()))
					.append(String.format("failed=%d%n", result.getFailedFeatures()))
					.append("exceptions=0").flush();
		}
	}

}
