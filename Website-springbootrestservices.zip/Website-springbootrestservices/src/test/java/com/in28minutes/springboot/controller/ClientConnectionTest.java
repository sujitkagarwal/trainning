package com.in28minutes.springboot.controller;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;

import java.io.IOException;


public class ClientConnectionTest {
    static {
        System.setProperty("javax.net.ssl.trustStore", "C:\\sujit\\workspace\\Website-springbootrestservices\\config_certificate\\client.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "password");
        System.setProperty("javax.net.ssl.keyStore", "C:\\sujit\\workspace\\Website-springbootrestservices\\config_certificate\\client.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "password");
    }

    /**
     * @param args
     * @throws IOException
     * @throws HttpException
     */
    public static void main(String[] args) throws HttpException, IOException {
        HttpClient client = new HttpClient();
        GetMethod method = new GetMethod();
        method.setURI(new URI("https://localhost:8443/students/Student1/courses", false));
        client.executeMethod(method);

        System.out.println(method.getResponseBodyAsString());
    }
}