package com.in28minutes.springboot.controller;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;

import java.io.IOException;

/**
 * Created by qu04jl on 11-9-2017.
 */
public class APItesting {
    static {
        System.setProperty("javax.net.ssl.trustStore", "C:\\sujit\\workspace\\Website-springbootrestservices\\config_certificate\\api\\client-truststore.jks");
        System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
        System.setProperty("javax.net.ssl.keyStore", "C:\\sujit\\workspace\\Website-springbootrestservices\\config_certificate\\api\\client-keystore.tst.jks");
        System.setProperty("javax.net.ssl.keyStorePassword", "mypass");
    }

    /**
     * @param args
     * @throws IOException
     * @throws HttpException
     */
    public static void main(String[] args) throws HttpException, IOException {
        HttpClient client = new HttpClient();
        PostMethod method = new PostMethod();
        method.setRequestEntity(new StringRequestEntity("{\n" +
                "        \"means\": \"nl-username-passwords\",\n" +
                "        \"authenticationContext\": {\n" +
                "          \"identifyeeType\": \"customer\",\n" +
                "          \"clientId\": \"00000000-0000-0000-0000-000000000001\",\n" +
                "          \"requiredLevelOfAssurance\": 2,\n" +
                "          \"scopes\": [\"personal_data\"]\n" +
                "        },\n" +
                "        \"authenticationResult\": {\n" +
                "          \"agreementKey\": {\n" +
                "          \"id\":\"26b19f9d-7e37-4586-80c0-26fdb787514e\",\n" +
                "          \"type\":\"UUID\"\n" +
                "          }\n" +
                "        }\n" +
                "      }","application/json",null));


        method.setURI(new URI("https://lrv1620q.europe.intranet:8084/authenticate", false));
        client.executeMethod(method);

        System.out.println(method.getResponseBodyAsString());
    }
}
