## Setup

1. Create docker registry secret

```text
    kubectl create secret docker-registry regsecret --docker-server=open.docker.ing.net --docker-username=<username> --docker-password=<password>
```

2. Copy secret-artifactory.yml.template as secret-artifactory.yml (not versioned, on .gitignore) and add base64 encoded Artifactory token in secret-artifactory.yml

```text
    echo "the secret" | base64
```

3. Create kubernetes secret

```text
    kubectl apply -f secret-artifactory.yml
```

4. [Optional] Run ./delete.sh to remove old services

```text
    ./delete.sh
```

5. Run ./deploy.sh to deploy non-TPA services to your local dev environments

```text
    ./deploy.sh
```