#!/bin/bash
for files in dependencies/*
do
    echo -e "\n*** Deleting resources in ${files} ***\n"
    kubectl delete -f "${files}"
done

sleep 3

for files in deployments/*
do
    echo -e "\n*** Deleting resources in ${files} ***\n"
    kubectl delete -f "${files}"
done