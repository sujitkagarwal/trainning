#!/bin/bash
for files in dependencies/*
do
    echo -e "\n*** Deploying resources in ${files} ***\n"
    kubectl apply -f "${files}"
done

sleep 3

echo -e "\n*** Deploying Vault ***\n"

kubectl apply -f deployments/vault.yml

sleep 30

declare -a DEPENDENT_SVC=(
"apigateway"
"authenticationorchestration")

for microservice in "${DEPENDENT_SVC[@]}"; do
    echo -e "\n*** Restarting microservice with dependency: $microservice ***\n"
    kubectl delete pod -l app="$microservice"
done


for files in deployments/*
do
    echo -e "\n*** Deploying resources in ${files} ***\n"
    kubectl apply -f "${files}"
done
