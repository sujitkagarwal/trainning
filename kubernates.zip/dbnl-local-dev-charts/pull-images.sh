#!/bin/bash
for files in deployments/*
do
    str="$(grep --no-filename 'image: ' "${files}")"
    read -ra IMAGES <<< "$str"
    for docker in "${IMAGES[@]}"; do
        if  [[ $docker == open.docker.ing.net* ]] ;
        then
            docker pull "$docker"
        fi
    done
done