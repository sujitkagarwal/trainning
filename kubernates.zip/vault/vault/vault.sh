echo "Initializing vault."
sleep 30
vault operator init > keys.txt

echo "Unsealing vault."
vault operator unseal $(grep 'Key 1:' keys.txt | awk '{print $NF}')
vault operator unseal $(grep 'Key 2:' keys.txt | awk '{print $NF}')
vault operator unseal $(grep 'Key 3:' keys.txt | awk '{print $NF}')

echo "Authenticating to vault."
vault login $(grep 'Initial Root Token:' keys.txt | awk '{print substr($NF, 1, length($NF))}')

vault secrets enable kv

# default secrets
vault write kv/jksSecrets jks.json="`cat certs/default/jks.json`"
vault write kv/vault ca.crt="`cat certs/default/ca.crt`" ca.key="`cat certs/default/ca.key`"
vault write kv/vaultTls vault-tls.jks="`base64 certs/default/vault-tls.jks`" vault-https.properties="`cat certs/default/vault-https.properties`"
vault write kv/vault-ssl https_truststore="`jq -r .httpstruststore certs/default/secrets.json`" https_keystore="`jq -r .httpskeystore certs/default/secrets.json`" https_keypassword="`jq -r .httpskeypassword certs/default/secrets.json`"
vault write kv/peerTokensJks api-trust-peer-tokens.jks="`base64 certs/default/api-trust-peer-tokens.jks`"
vault write kv/accessTokensJks api-trust-access-tokens.jks="`base64 certs/default/api-trust-access-tokens.jks`"
vault write kv/tokensProperties api-trust-tokens.properties="`cat certs/default/api-trust-tokens.properties`"

# database secrets
vault write kv/database username="`jq -r .sqlusername certs/database/dbsecrets.json`" password="`jq -r .sqlpassword certs/database/dbsecrets.json`"

# insurancebeproductapi secrets
vault write kv/insuranceBeProductJks api-trust.jks="`base64 certs/insurance-be-product/api-trust.jks`" manifest.jks="`base64 certs/insurance-be-product/manifest.jks`" qis-keystore.jks="`base64 certs/insurance-be-product/qis-keystore.jks`"
vault write kv/insuranceBeProductConfigs api-trust.properties="`cat certs/insurance-be-product/api-trust.properties`" insurance-be-product.properties="`cat certs/insurance-be-product/insurance-be-product.properties`" mode="`cat certs/insurance-be-product/mode`"

# insuranceorchestrationapi secrets
vault write kv/insuranceOrchestrationJks api-trust.jks="`base64 certs/insurance-orchestration/api-trust.jks`" manifest.jks="`base64 certs/insurance-orchestration/manifest.jks`"
vault write kv/insuranceOrchestrationConfigs api-trust.properties="`cat certs/insurance-orchestration/api-trust.properties`" customer.json="`cat certs/insurance-orchestration/customer.json`" insurance-orchestration.properties="`cat certs/insurance-orchestration/insurance-orchestration.properties`" mode="`cat certs/insurance-orchestration/mode`"

# TPA secrets
vault write kv/meansPin IngKeystore.jks="`base64 certs/means-pin/IngKeystore.jks`"
vault write kv/apigateway api.tiab.ing.net.crt="`cat certs/apigateway/api.tiab.ing.net.crt`" api.tiab.ing.net.key="`cat certs/apigateway/api.tiab.ing.net.key`" priv.pem="`cat certs/apigateway/priv.pem`" store.keys="`cat certs/apigateway/store.keys`"
vault write kv/authenticationOrchestration api-trust-tokens.jks="`base64 certs/authentication-orchestration/api-trust-tokens.jks`"
vault write kv/bootstrap app_keystore.p12="`base64 certs/bootstrap/app_keystore.p12`"
vault write kv/tokenApi api-trust-tokens.jks="`base64 certs/token-api/api-trust-tokens.jks`" token-signature.jks="`base64 certs/token-api/token-signature.jks`"

vault policy write default default_access.hcl
vault policy write database database_access.hcl
vault policy write insurancebeproduct insurancebeproduct_access.hcl
vault policy write insuranceorchestration insuranceorchestration_access.hcl
vault policy write meanspin meanspin_access.hcl
vault policy write apigateway apigateway_access.hcl
vault policy write authenticationorchestration authenticationorchestration_access.hcl
vault policy write bootstrap bootstrap_access.hcl
vault policy write tokenapi tokenapi_access.hcl

echo "Enabling Kubernetes Auth Backend."
vault auth enable kubernetes

echo "Writing Kubernetes Auth Backend configuration."
vault write auth/kubernetes/config \
    kubernetes_host=$HOSTNAME \
    token_reviewer_jwt=@/var/run/secrets/kubernetes.io/serviceaccount/token \
    kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt \
    policies='*'

vault write auth/kubernetes/role/default \
    bound_service_account_names='default-sa' \
    bound_service_account_namespaces='*' \
    policies='default'

vault write auth/kubernetes/role/defaultdb \
    bound_service_account_names='defaultdb-sa' \
    bound_service_account_namespaces='*' \
    policies='default,database'

vault write auth/kubernetes/role/insurancebeproduct \
    bound_service_account_names='beproduct-sa' \
    bound_service_account_namespaces='*' \
    policies='default,insurancebeproduct'

vault write auth/kubernetes/role/insuranceorchestration \
    bound_service_account_names='orchestration-sa' \
    bound_service_account_namespaces='*' \
    policies='default,insuranceorchestration'

vault write auth/kubernetes/role/meanspin \
    bound_service_account_names='meanspin-sa' \
    bound_service_account_namespaces='*' \
    policies='default,database,meanspin'

vault write auth/kubernetes/role/apigateway \
    bound_service_account_names='apigateway-sa' \
    bound_service_account_namespaces='*' \
    policies='default,apigateway'

vault write auth/kubernetes/role/authenticationorchestration \
    bound_service_account_names='authenticationorchestration-sa' \
    bound_service_account_namespaces='*' \
    policies='default,authenticationorchestration'

vault write auth/kubernetes/role/bootstrap \
    bound_service_account_names='bootstrap-sa' \
    bound_service_account_namespaces='*' \
    policies='default,bootstrap'

vault write auth/kubernetes/role/tokenapi \
    bound_service_account_names='tokenapi-sa' \
    bound_service_account_namespaces='*' \
    policies='default,tokenapi'

vault audit enable file file_path=/var/log/vault_audit.log

rm -rf certs.*