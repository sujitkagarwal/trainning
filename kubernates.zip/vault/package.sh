DATE=`date +"%m%d%Y"`

cd secrets

curl -H 'X-JFrog-Art-Api:$1' -O "https://artifactory.ing.net/artifactory/releases_mvn_insurance/secrets/$2"

tar xvf $2

cp -R uploads/* certs

tar czvf certs-DEV.DBNL.$DATE.tar.gz certs