### Integration samples

You have a new Local Means API and want to test it before integrating to TPA.

Note: Use an existing means-id. The purpose of using one is to test out the ability of the newly created means to request an access token. After it is tested to work with the AOA, the standard procedure is to request or register the new means to be added on MeansAdministrationAPI and SecurityPolicyAPI before going to acceptance or production.(https://touchpoint.ing.net/forge/#/product/27645/documentation/latest/getting-started/create-an-authentication-means/registering-your-means.html).

1: Create a Docker image out of the application
`docker build -t stormtroopers.docker.ing.net/capability/mysamplemeans:version1 .`

Please see below for the Dockerfile
```
###For verbosity only this whole dockerfile snippet will be used to create a docker container out of an java application 
FROM centos:7
MAINTAINER <mainteners@ing.com>

####### base code | start -> to be pushed to a base container image in the future #####################
ENV TINI_VERSION v0.16.1

ADD https://github.com/krallin/tini/releases/download/${TINI_VERSION}/tini /tini
RUN chmod +x /tini
####### base code | end #####################

### Install dependencies, in our case we use the openjdk
RUN yum update -y && yum install -y java-1.8.0-openjdk
RUN chmod +x /tini
RUN yum update -y && yum upgrade -y

#####  Externalised Config | start -> only add the snippet below if you have externalised your configuration or certificates #####
####local copy of configurations to be copied on the containers / (root) ####
COPY conf/ /conf
#### the path /certs is defined in the kubernetes.yml as the mounting volume for the certificates that was provisioned by the vault.####
ENV LOADER_PATH=/certs,/conf
##### Externalised Config | end #####

### define to add the jar
ADD <MyLocalMeans>-1.0.0.0.jar app.jar

CMD java -jar /app.jar
```
2: Create a kubernetes.yaml definition
```
### Service definition of a kubernetes.yml | start ####
apiVersion: v1
kind: Service
metadata:
  name: mysamplemeans
spec:
  ports:
  - port: 8080
    targetPort: 8080
    name: http
  - port: 8081
    targetPort: 8081
    name: http-management
  - port: 8443
    targetPort: 8443
    name: https
  - port: 8444
    targetPort: 8444
    name: https-management
  selector:
    app: mysamplemeans
### Service definition of a kubernetes.yml | end ####
---
### Deployment definition of a kubernetes.yml | start ###
apiVersion: apps/v1beta2
kind: Deployment
metadata:
  name: mysamplemeans
spec:
  replicas: 1
  revisionHistoryLimit: 1
  selector:
    matchLabels:
      app: mysamplemeans
      version: v1
      country: asia
  template:
    metadata:
      labels:
        app: mysamplemeans
        version: v1
        country: asia
    spec:
      serviceAccountName: vault-auth
      containers:
      - name: mysamplemeans
        image: stormtroopers.docker.ing.net/capability/mysamplemeans:version1
        imagePullPolicy: IfNotPresent
        ### volume mounting point for the certificate provisioned by the vault
        volumeMounts:
        - name: certs-dir
          mountPath: /certs
        resources:
          requests:
            cpu: "25m"
            memory: "384Mi"
          limits:
            cpu: "2"
            memory: "768Mi"
        ### Externalized environment variables
        env:
        - name: server.ssl.enabled
          value: "true"
        - name: ACCESS_CONTROL_ALLOW_ORIGIN
          value:  "*"
        - name: server.port
          value: "8080"
        ### certificate path and password is also externalized
        - name: TLS_KEYSTORE_FILE
        ### this jks file is the same name as the value defined on the CN name below, please see environment definitions under the initContainers
          value: "file:/certs/mysamplemeans.jks"
        - name: TLS_KEYSTORE_PASSWORD
          value: "password"
        ports:
        - containerPort: 8080
        - containerPort: 8443
        - containerPort: 8444
        - containerPort: 8081
      volumes:
      - name: certs-dir
        emptyDir: {}
      ### Important: used with the current file_fetcher_image image that was used in the TIAB as this contains a csr that generates a certificate, will be signed by the vault CA and will be provisioned and mounted via this init container
      initContainers:
      - name: certs-container
        image: {{file_fetcher_image}}
        imagePullPolicy: IfNotPresent
        command: ["/bin/bash","-c","python3 app.py && ./convert-cert.sh"]
        env:
        - name: VAULT_URL
          value: "https://vault:8200"
        - name: CN
          ### change this value as whatever you like, the value defined will reflect on the CN of the certificate provisioned by the vault for this service
          value: "mysamplemeans"
        - name: OU
          ### change this value as whatever you like, the value defined will reflect on the OU of the certificate provisioned by the vault for this service. We will need this value if you integrate a local means and is intended to communicate directly to AOA. 
          ### the value defined in here would be added on the application.conf to add a local means on the tls.clients of AOA
          ### use the current CN value that is also registered or defined on the current appplication.conf of AOA current list is MeansPin, LdapOtpMeansAPI, GateKeeper, SecureRemotePassword, KnowledgeBasedQuestions, Bootstrap
          value: "MeansPin"
        volumeMounts:
        - name: certs-dir
          mountPath: /certs
          ### important to define an img_pull_secret, so in an instance that you push the image on a repository, in order for the kubernetes to pull the docker image on a repository you need to define an image pull secret.
      imagePullSecrets:
      - name: {{ img_pull_secret }}
### Deployment definition of a kubernetes.yml | end ###
``` 

##### Optional | start
Modify vault instance:
1) access the vault via `kubectl exec -it <vault_pod_name> -- bash`
2) modify the application.conf in the vault via `vi /certs/application.conf`
3) add the newly created local means on tls.client block
4)
```
tls.clients: [
  {
    application-name: "MeansPin"
    endpoints = ${groups.all}
  },
  {
    application-name: "LdapOtpMeansAPI"
    endpoints = ${groups.all}
  },
  {
    application-name: "GateKeeper"
    endpoints = ${groups.all}
  },
  {
    application-name: "SecureRemotePassword"
    endpoints = ${groups.all}
  },
  {
    application-name: "KnowledgeBasedQuestions"
    endpoints = ${groups.all}
  },
  {
    application-name: "Bootstrap"
    endpoints = ${groups.all}
  },
  {
    application-name: "MySampleMeans"
    endpoints = ${groups.all}
  }
]
  ```
  
5) on the root context of the container `cd /`
6) invoke the command to save the changes to the vault datasource ` vault write kv/aoa application="`cat certs/application.conf`" `
7) exit on the bash session of the vault container `exit`
8) get the pods `kubectl get pods` and restart the AuthenticationOrchestrationAPI via `kubectl delete pods <aoa_pod_name>` Note: Restarting the AOA is necessary, when the pod restarts the init container will provision the modified application.conf of the AOA which contains the newly added tls.client for the local means.



3: Deploy the application via its kubernetes.yml definition via the command
`kubectl create -f kubernetes.yml`
4: check if the application is running
`kubectl get pods`
5: check if apigateway is running locally. Access into the bash of the apigateway to modify the route.
`kubectl exec -it <api_gateway_pod_name> -- bash`
6: Edit the nginx.conf to add the route of the locally created means
`vi /etc/nginx/nginx.conf`
sample route
```
    #local means
    location /api/mysamplemeans {
        proxy_pass http://mysamplemeans:8080/mysamplemeans/helloworld;
    }
```
7: After adding the route save the file and restart the nginx service
`/usr/sbin/nginx -s reload`
8: Test the means via postman or curl
```
curl  \
  http://localhost:8080/api/mysamplemeans \
  -H 'accept: application/json' \
  -H 'content-type: application/json' 
```

#### Integrate a capability API that will consumes an access token
1: Create a Docker image out of the application
`docker build -t stormtroopers.docker.ing.net/capability/mycapabilityAPI:version1 .`

Please see below for the Dockerfile
```
### For verbosity only this whole dockerfile snippet will be used to create a docker container out of an java application 
FROM centos:7
MAINTAINER <mainteners@ing.com>

####### base code | start -> to be pushed to a base container image in the future #####################
ENV TINI_VERSION v0.16.1

ADD https://github.com/krallin/tini/releases/download/${TINI_VERSION}/tini /tini
RUN chmod +x /tini
####### base code | end #####################

### Install dependencies, in our case we use the openjdk
RUN yum update -y && yum install -y java-1.8.0-openjdk
RUN chmod +x /tini
RUN yum update -y && yum upgrade -y

#####  Externalised Config | start -> only add the snippet below if you have externalised your configuration or certificates #####
####local copy of configurations to be copied on the containers / (root) ####
COPY conf/ /conf
#### the path /certs is defined in the kubernetes.yml as the mounting volume for the certificates that was provisioned by the vault.####
ENV LOADER_PATH=/certs,/conf
##### Externalised Config | end #####

### define to add the jar
ADD <MyCapabilityAPI>-1.0.0.0.jar app.jar

CMD java -jar /app.jar
```
2: Create a kubernetes.yaml definition
```
### Service definition of a kubernetes.yml | start ####
apiVersion: v1
kind: Service
metadata:
  name: mycapabilityAPI
spec:
  ports:
  - port: 8080
    targetPort: 8080
    name: http
  - port: 8081
    targetPort: 8081
    name: http-management
  - port: 8443
    targetPort: 8443
    name: https
  - port: 8444
    targetPort: 8444
    name: https-management
  selector:
    app: mycapabilityAPI
### Service definition of a kubernetes.yml | end ####
---
### Deployment definition of a kubernetes.yml | start ###
apiVersion: apps/v1beta2
kind: Deployment
metadata:
  name: mycapabilityAPI
spec:
  replicas: 1
  revisionHistoryLimit: 1
  selector:
    matchLabels:
      app: mycapabilityAPI
      version: v1
      country: asia
  template:
    metadata:
      labels:
        app: mycapabilityAPI
        version: v1
        country: asia
    spec:
      serviceAccountName: vault-auth
      containers:
      - name: mycapabilityAPI
        image: stormtroopers.docker.ing.net/capability/mycapabilityAPI:version1
        imagePullPolicy: IfNotPresent
        ### volume mounting point for the certificate provisioned by the vault
        volumeMounts:
        - name: certs-dir
          mountPath: /certs
        resources:
          requests:
            cpu: "25m"
            memory: "384Mi"
          limits:
            cpu: "2"
            memory: "768Mi"
        ### Externalized environment variables
        env:
        - name: server.ssl.enabled
          value: "true"
        - name: ACCESS_CONTROL_ALLOW_ORIGIN
          value:  "*"
        - name: server.port
          value: "8080"
        ### certificate path and password is also externalized
        - name: TLS_KEYSTORE_FILE
        ### this jks file is the same name as the value defined on the CN name below, please see environment definitions under the initContainers
          value: "file:/certs/mycapabilityAPI.jks"
        - name: TLS_KEYSTORE_PASSWORD
          value: "password"
        ports:
        - containerPort: 8080
        - containerPort: 8443
        - containerPort: 8444
        - containerPort: 8081
      volumes:
      - name: certs-dir
        emptyDir: {}
      ### Important: used the current file_fetcher_image image that was used in the TIAB as this contains a certicate that generates a certificate, will be signed by the vault CA and would be provisioned and mounted via this init container
      initContainers:
      - name: certs-container
        image: {{file_fetcher_image}}
        imagePullPolicy: IfNotPresent
        command: ["/bin/bash","-c","python3 app.py && ./convert-cert.sh"]
        env:
        - name: VAULT_URL
          value: "https://vault:8200"
        - name: CN
          ### change this value as whatever you like, the value defined will reflect on the CN of the certificate provisioned by the vault for this service
          value: "mycapabilityAPI"
        - name: OU
          ### change this value as whatever you like, the value defined will reflect on the OU of the certificate provisioned by the vault for this service. We will need this value if you integrate a local means and is intended to communicate directly to AOA. 
          ### the value defined in here would be added on the application.conf to add a local means on the tls.clients of AOA
          value: "MyCapabilityAPI"
        volumeMounts:
        - name: certs-dir
          mountPath: /certs
          ### important to define an img_pull_secret, so in an instance that you push the image on a repository, in order for the kubernetes to pull the docker image on a repository you need to define an image pull secret. If the image is existing locally, theres no need to define this pull secrets
      imagePullSecrets:
      - name: {{ img_pull_secret }}
### Deployment definition of a kubernetes.yml | end ###
```
3: Deploy the application via its kubernetes.yml definition via the command
`kubectl create -f kubernetes.yml`
4: check if the application is running
`kubectl get pods`
5: check if apigateway is running locally. Access into the bash of the apigateway to modify the route.
`kubectl exec -it <api_gateway_pod_name> -- bash`
6: Edit the nginx.conf to add the route of the locally created means
`vi /etc/nginx/nginx.conf`
sample route
```
    #local capability api
    location /api/mycapabilityapi {
        ### define auth_token directive this is important so that it will protect an api to ensure only valid access token w/c was provisioned by the api gateway would be able to make a request and will decrypt the access token
        auth_token on;
        proxy_pass http://mycapabilityAPI:8080/mycapabilityAPI/retrieveOnePamProfile;
    }
```
7: After adding the route save the file and restart the nginx service
`/usr/sbin/nginx -s reload`
8: Test the means via postman or curl
```
curl  \
  http://localhost:8080/api/mycapabilityapi \
  -H 'accept: application/json' \
  -H 'content-type: application/json' \
  -H 'authorization: Bearer eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoidHN0LTRjOGI1Mzk3LTFhYjgtNDFhOC1hNTViLWE3MTk5MTJiODNkMiIsImN0eSI6IkpXVCJ9..qtu9trsr0R_Tpy0ShCtT0Q.N1geZRF3ZKsSStND-e0AokzmqK79ymRAKGSTZz1RaQo0YMRT9FI-bGnpgK8fj0oZk8syvP6VboGIEfBf3XsVkGCkTTElf0HSyHVNnWZ8riXcg6KfeT7WL7M4Y1nALNlk5jXAB9PhQ-Xmf5epEDXRf9DBQ0LNmc16g_kQfHmnzf80Mf5aA1yRtSbOslgVEZ9V4vE8E4M8cRdRwbkqnIlHCAETPlYgLIKDsxst4AqntUa5Ijmo4vfDSHQxfxX2Z_NQOvsXrtxg9X51hjzp12rqqaO3-dwISsAwFpRKJoYvLUH2_X9Fzwrf2fWRtSvrsKGYVQBnCCEGQczH1mxLFxnopaIyTPNjgWBB-a4HiLrkytSODaNQKkv9pSCQM3H_LtUcPQvOVJo6-V-jqcaL_uyjmLsLy_l9VAfiDx9K2fXZNlWVfRfAiGvVUMrPkXwgPJUSpKf__3-skAz1iEDvTqHUwVSSEwbsPJWUWuuPPi17513xpviXu65FbU28Uxthvo1rHU8j55t6BXVZrIIBotl4HZIVQWiGsyvIHMyVtNWCKHWXTLkGlI6lOwo4vvTokpacb1ZMEHsxK2FbPYqqqL6B6qAuWzszjVUsFZYJ4-wCu5RbIPjTWmp5qFfcZYcBWPpbUVMZLR9cno-5io7CZE5BVtYAjP6PE09dFy5BAExqyLkHZXhLqbBmssajbcMHPu3bvBPR-Y1ra7e_a-um4xKYHMSmc13FM2LNnpL7xjyQu9_JMY2aWVctZGW6r4KgZN-iG7gZ4_JtyA9xqxPA0xy751q-xAg-ZvZgcV8dtpBwDAUfGXcI7uyz7YrJe6XBy7TSFLkVqnE68wP7t9NPd0L-fA5xKyQQ8OKfUw2pp4JYVxqNoU3GVD7jEHCikz9Cx03Qho1OfK39RrLD4cLm-XGD2FHjDt-UP2LKkpWHtGXbR1zDmKPbONKkxgpEr9aDSicZrJG8gDKIRNxQfDCt-GZ78eJlWSLd-Cn29G4nROEgYsbwq2rMTyXhoiDkXmu0uZuKSBC23sqnKL_UwxJ4ecs6K6AFyxtejvqz5iWuPCnWOzQxN7-B6JL1E_r1h1JxAJzyaRhL1DJbcjF5xZaXJ71TycXPh9oSV07ADML_x0-shCjpYllq0EvFQzP7zKf-EBtgiMjo8frSYzyWeyHo8dCQRu9yiw7kOtpKWYdqYyRLQj7pyOF_KOvd_ucr8okEaqaxuu6HJt-ALerZzeHBX89EN77t_4EfGWdGh__2xftogAc85_yn6w_Ob-iPDXqyqAcbdSe_mJQrzNnCFcAJrBNOkeHK20uapJUQNZ5zgACpO-ar4p26PZdXsJA7z8ymTxGdwRsnxSgKO3zF5fzNW1UWwD7ETBYwvD_nC8bNxeh7NQ3Ofm26rvGVqs4Cjd5z0lsDBJCRnrnYSgbw3m8ipab9udojM_ty3EX-Mr-nvMSwHHjPmDjrAc4XFjewTuRb9UQ7L426blNpqZK7WzHHlUBXI6OZ54QRNlw9EVZyC3hqLhSVE6vGsNp3uvAsRnZ6ylLf.bFcMMjCM592UlrimYQXkCA5utMLGBKCySCD1By6TzbA'
```
