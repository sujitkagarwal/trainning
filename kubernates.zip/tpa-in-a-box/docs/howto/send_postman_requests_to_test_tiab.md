# Sending postman requests to test TIAB's endpoints

If all pods are running you should be able to use [Postman](https://go.pstmn.io/apps) to send requests to the box. Download the [postman collection](https://gitlab.ing.net/stormtroopers/tpa-in-a-box/raw/master/test/tiab.postman_collection.json?inline=false) and import it into Postman via `File -> Import -> Select file`
This collection holds a couple of requests that you can send to TIAB as an example. With the initially loaded TP components you should be able to fire the bootstrap request and get a bootstrap token as a result.

Note: For the MeansLdapOTP to work you need to turn on extra TP components, please check [this readme](docs/howto/enabling_other_tp_services.md) on how that works.


