# E-mails use case
NOTE: Credits to Engagement suite team for creating [this documentation](https://gitlab.ing.net/CCNA/ccna-in-a-box).

### Starting the CCNA pods

1. Copy the following part into the services variable in <ansilbe/group_vars/all.yml> to configure the CCN components:

```
services:
# - authentication-orchestration
# - bootstrap
# - consent-orchestration
# - means-administration
# - secure-remote-password
# - security-policy
# - token-api
# - graphite-metrics
  - estestconsole
  - engagementsuite
  - broker
  - zookeeper
  - cp_schema_registry
  - mailhog
```
This will turn off all services except CCN components

2. Restart TIAB with `/playbook reset`

### Sending emails

1. [Create your custom template for e-mails](#1-create-your-custom-template-for-e-mails)
2. [Send an e-mail with the console](#2-send-an-e-mail-with-the-console)
3. [Send an e-mail with your own implementation](#3-send-an-e-mail-with-your-own-implementation)

#### 1. Create your custom template for e-mails

E-mail templates are made of two parts, the subject and the body. In the body you can use the regular HTML that you use for e-mails. Keep in mind that each e-mail client might have different support for HTMl and the e-mail visualization might differ.

You need to define at least this two parts in their own and then the template itself. The template will reference the parts.

Remember to escape all quotes inside the template with a backslash.

##### Example
```json
[
  {
    "reference": "my_awesome_template",
    "parts": [
      "my_awesome_template_subject",
      "my_awesome_template_body"
    ]
  },
  {
    "reference": "my_awesome_template_subject",
    "content": "Check my awesome template!"
  },
  {
    "reference": "my_awesome_template_body",
    "content": "<html><body><h1>[[${title}]]</h1><p id=\"some_id\">Hello [[${customer}]]!</p></body></html>"
  }
]
```

You can use parameters in your template using thymeleaf format. These tags will be replaced with the values of the template params in the notification event.

Create your own template file and add it to the container as explained in [Using a docker volume (Static templates)](README.md#using-a-docker-volume-static-templates)

#### 2. Send an e-mail with the console

With CCNA in a box you can send emails and receive them in a Fake Inbox.

Once the containers are running and ready, open the ESTestConsole.

You can access the ESTestConsole with a browser (not IE). By default it will be available in <http://console.tiab.ing.net:31881>.

Select Notification Events

![](docs/images/notifications.png "Notification mode button")

Go to the receive events tab.

![](docs/images/receive.png "Receive events tab")

Configure the tracking and communication topics if you changed the default topics included in the docker-compose.yml.

![](docs/images/rtopics.png "Receive topics")

Click in the 'play' button to start listening to events.

![](docs/images/play.png "Play button")

Go to the send events tab.

![](docs/images/send.png "Send events tab")

Configure the notification topic if you changed the default topic included in the configurations.

![](docs/images/notificationtopic.png "Notification topic")

Select e-mail channel.

![](docs/images/email.png "Email")

Select `first STMP example` from the examples drop down.

![](docs/images/example.png "Example")

Change the template_reference to match the template you created (my_awesome_template if you copied the example) and add all the channel params required by you template. For the example we need title and customer.

You could additionally change the address where the email is being sent. In this case is not really necessary since we are using a fake inbox and we will see all e-mails.

If you follow the examples your event should look something similar to this:
```json
{
    "header": {
        "id": "22839626799",
        "type": "notification",
        "created": 1485245627563,
        "source": {
            "hostname": "loadtest-producer_hostname",
            "instanceId": "loadtest-producer_instanceId"
        },
        "metadata": null,
        "traceId": "3eb1fdf4-2143-4d6c-a6d7-eea4f1293df8"
    },
    "body": {
        "customerId": "123",
        "channel": "email-smtp",
        "language": "en-US",
        "address": "email.adress@ing.com",
        "communication": "communication_campaign",
        "templateReference": "my_awesome_template",
        "templateParams": {
            "title": "My awesome title",
            "customer": "Engament Suite user"
        }
    }
}
```

Click on the send button.


![](docs/images/sendbutton.png "Send button")

If you go back to the receive event tab you should find all the tracking and communications events published by Engagement Suite related to the Notification event you just send. If there is a communication event with status SUCCESS everything worked.

![](docs/images/events.png "Trackings and communication events")

Now open Mailhog in the browser (by default <http://console.tiab.ing.net:31180>) to check how your e-mail looks like. There should be a new entry like this one:
![](docs/images/mailhog_entry.png "Mailhog entry")

Click on it to check how you e-mail looks like.

![](docs/images/emailmailhog.png "Email in Mailhog")

#### 3. Send an e-mail with your own implementation

If you want to learn how to produce your own Notification Events you can do it in [The Forge](https://theforge.ing.net/product/27581/documentation/latest/how_to/how_to_publish_notification_events)

If you already have a building block capable of sending notification events all you need is to configure Engagement Suite and your building block to use the same broker and schema registry.

You could configure both to use the broker and schema registry included in the docker-compose or to use an external one.

Check the [Configure images](https://gitlab.ing.net/CCNA/ccna-in-a-box/tree/master/docs/engagement/README.md#configure-images) section to learn how to set the broker, schema registry and topics you need.
