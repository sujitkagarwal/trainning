# Integrate with TIAB using TLS Router

As you should have already known by now, TIAB runs on local Openshift/Kubernetes. And to imitate production setup, the communication from each TPA service to another was made secure using TLS certificates signed by 
TIAB's own CA Certificates generated upon every startup. So, the Capability API or Local Means you are running from outside TIAB cannot simply communicate to the TPA services inside.

Worry not! To fill that gap, we added a [TLS Router](tls_router.md)! So, you would not have to manually configure a lot things before you can test!
This router serves as the bridge of the TPA services to any services outside TIAB and vice versa.

Voila! Testing your own Capability API or Local Means from your host machine is now really easy by following the steps below:

*The following steps needs to be done inside TIAB, refer to [login command line](../../readme.md#login-command-line)*
1. Run `oc get pods` and ensure that *TLS router* is included and the TPA service that you want to integrate with.
2. Navigate to the project directory `/root/tpa-in-a-box`
3. Execute `./playbook.sh create-cert -n <service_name> -hn <host_name> -sn <service_name>` this will generate TLS certificates for the given service. For a more information refer to [Generate TLS certificates](create_tls_certs_for_your_own_service.md)

*The following steps needs to be done on host machine*

4. Copy the generated certificates by using an SCP client, `scp -P 30022 root@localhost:/root/tpa-in-a-box/ansible/.client-certs/<service_name>/<service_name>.crt <path_destination_at_host_os>`
5. Run your service using the TLS certificates you just copied
6. Follow the [configuration](tls_router.md#configuration) part of the TLS Router to properly setup everything on host machine
7. Execute your test case locally
