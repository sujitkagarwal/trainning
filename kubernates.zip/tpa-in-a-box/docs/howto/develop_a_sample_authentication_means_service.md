# Develop a sample authentication means service

* [Overview](#overview)
* [Prerequisites](#prerequisites)
* [Generate TLS certificate for your sample authentication means](#generate-tls-certificate-for-your-sample-authentication-means)
* [Configure the authentication endpoints in the API Gateway configuration](#configure-the-authentication-endpoints-in-the-api-gateway-configuration)
* [Add sample authentication means to Authentication Orchestration API client whitelist](#add-sample-authentication-means-to-authentication-orchestration-api-client-whitelist)
* [Modify test data of simulated Identity API](#modify-test-data-of-simulated-identity-api)
* [Simulate sample authentication means via Postman](#simulate-sample-authentication-means-via-postman)
* [Build and run sample authentication means](#build-and-run-sample-authentication-means)
* [Test sample authentication means](#test-sample-authentication-means)

## Overview
A means is a plugin to the Authentication Platform that facilitates a particular way of logging in, typically for the ING customers from a specific country.
This document guides you through the process of testing a sample authentication means using TIAB.

## Prerequisites
* [Create an Authentication Means](https://touchpoint.ing.net/forge/product/27645/documentation/latest/getting-started/create-an-authentication-means/index), make sure it identifies as sample-means because this has been preregistered in the means administration and security policies services
* Add `authenticationorchestration.tiab.ing.net` as alias for `127.0.0.1` in the hosts file of your workstation
* Steps in [Integrating with TIAB](test_your_own_service_against_tpa_in_a_box_from_outside.md)
* Import [postman collection](../../test/tiab.postman_collection.json) and set `Postman -> Preferences -> General -> Request -> SSL certificate verification` to off

## Generate TLS certificate for your sample authentication means
Mutual TLS is required for communications between any components of TIAB, hence you need to provision a client certificate for your sample authentication means.
SSH into TIAB virtual machine and go to project root `/root/tpa-in-a-box/` and execute the command below, kindly follow font case stated at the example.

ssh into the VM:
```
    #Password is `password`
    ssh -p 30022 root@tiab.ing.net
```

create certificate and JKS:
```
    ./playbook.sh create-cert -n <name> -hn <hostname> -sn <ServiceName>
```
example:
```
    ./playbook.sh create-cert -n samplemeans -hn samplemeans -sn SampleMeans
```

The client certificate and Java KeyStore will be generated and stored at `tpa-in-a-box/ansible/.client-certs/samplemeans/`, the password of the JKS is `password`.
Copy the certificates using the command below executed from your host operating system.

```
    #Copy sample means certificate
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/.client-certs/samplemeans/samplemeans.crt <path_destination_at_hostos>
    
    #Copy sample means JKS
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/.client-certs/samplemeans/samplemeans.jks <path_destination_at_hostos>   
```

Store is already pre-generated and located at `tpa-in-a-box/ansible/ca/`, the password of the trustStore is `password`.

```
    #Copy truststore certificate
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/ca/ca.crt <hostos_path_destination>
    
    #Copy truststore JKS
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/ca/ca.jks <hostos_path_destination>    
```

## Configure the authentication endpoints in the API Gateway configuration
In order for your sample authentication means endpoints to be exposed as a route of TIAB, you need to configure API Gateway's Nginx configuration.
SSH into TIAB virtual machine and go to `tpa-in-a-box/configs/apigateway/` and edit desired server configuration in `nginx.conf`. 
There are two server configuration one has cookie pinning which is intended for web clients(listens at port 8080) and the other one uses SRP pinning for mobile clients (listens at port 8088). 

ssh into the VM:
```
    #Password is `password`
    ssh -p 30022 root@tiab.ing.net
```

route template:
```
    location /route/endpoint {
       proxy_pass https://ext.tiab.ing.net:<sample_authentication_means_port>;
    }
```

example:
```
    location /api/merak/reference/authenticate {
       proxy_pass https://ext.tiab.ing.net:8085/api/merak/reference/authenticate; 
    }
```

When the configuration file is changed, delete the current configmap and create a new one and after that delete the pod to have it restarted using the new configuration.

```
    #Delete API Gateway configmap 
    oc delete configmap apigateway-cm
    
    #Create API Gateway configmap after adding route
    oc create configmap apigateway-cm --from-file=/root/tpa-in-a-box/configs/apigateway/nginx.conf
    
    #Delete API Gateway pods
    oc delete pod -l app=apigateway
```

## Add sample authentication means to Authentication Orchestration API client whitelist
Add sample authentication means to the trusted peers whitelist of the authentication orchestration service. SSH into TIAB virtual machine and go to `tpa-in-a-box/configs/authenticationorchestration/` and edit `application.conf`. 
Add SampleMeans as one of the `tls.clients` as shown below:


ssh into the VM:
```
    #Password is `password`
    ssh -p 30022 root@tiab.ing.net
```

TLS clients whitelisting:
```
    tls.clients: [
        {
            application-name: "SampleMeans"
            endpoints = ${groups.all}
        }
    ]
```

When the configuration file is changed, delete the current configmap and create a new one and after that delete the pod to have it restarted using the new configuration.

```
    #Delete Authentication Orchestration API configmap 
    oc delete configmap aoa-cm
    
    #Create Authentication Orchestration API configmap after adding tls client
    oc create configmap aoa-cm --from-file=/root/tpa-in-a-box/configs/authentication-orchestration/application.conf
    
    #Delete Authentication Orchestration API pods
    oc delete pod -l app=authenticationorchestration
```

## Modify test data of simulated Identity API
The Authentication Orchestration service calls the Identity service to find access profiles based on the means agreement.  If you want to modify the response for this call, go to `tpa-in-a-box/configs/integration-stubber/` and edit `agreement_type-uuid.json`.

When the test data is changed, delete the current configmap and create a new one and after that delete the pod to have it restarted using the new configuration.

```
    #Delete Integration Stubber configmap 
    oc delete configmap integrationstubber-cm
    
    #Create Integration Stubber configmap after modifying test data
    oc create configmap integrationstubber-cm --from-file=/root/tpa-in-a-box/configs/integration-stubber 
    
    #Delete Integration Stubber pods
    oc delete pod -l app=integrationstubber
```

## Simulate sample authentication means via Postman
#### Flow
1. Post the credentials by calling the TLS Router using `https://authenticationorchestration.tiab.ing.net:30000/security-means/authenticate`
2. The API will forward the call to `https://authenticationorchestration:8443/security-means/authenticate`
3. The means calls the Authentication Orchestration service via the TLS router
4. The TLS router routes (on the IP layer) the request to `authenticationorchestration.touchpoint-in-a-box.svc.cluster.local`
5. The Authentication Orchestration service calls the Security Policy service
6. The Authentication Orchestration service calls the Means Administration service
7. The Authentication Orchestration service calls the Identity service
8. The Authentication Orchestration service calls the Risk Assessment service
9. When the result of all previous calls were successful, the Authentication Orchestration service calls the Token API service to create the access and refresh token pair and returns the result to the Authentication Means service which in turn returns the result to requester (curl) including a set-cookie to set the pinning cookie

#### Note: Since Mutual TLS is required for the communication between TPA components, you will need to use the generated [TLS certificates](create_tls_certs_for_your_own_service.md) as client certificates in the test case below:
![](../postmanclientcertificate.jpeg)

Check suitable means to make sure that `sample-means` is registered at Means Administration and Security Policy, use clientId `00000000-0000-0000-0000-000000000001`, set identifyeeType as customer and requiredLevelOfAssurance to zero. <br /><br />
Request: `GET` `https://authenticationorchestration.tiab.ing.net:30000/suitable-means?identifyeeType=customer&requiredLevelOfAssurance=0&clientId=00000000-0000-0000-0000-000000000001` <br />
Response:

```
[
    {
        "name": "SecureRemotePassword-mpin",
        "status": "active",
        "metadata": {}
    },
    {
        "name": "KnowledgeBasedQuestions",
        "status": "active",
        "metadata": {}
    },
    {
        "name": "sample-means",
        "status": "active",
        "metadata": {}
    },
    {
     "name": "SecureRemotePassword-fingerprint",
     "status": "active",
     "metadata": {}
    }
    ...
}
```

Test authentication endpoint, the flow starting at step 3 can be simulated using this request: <br /><br />
Request: `POST` `https://authenticationorchestrationservice.tiab.ing.net:30000/authenticate` <br />
Body: raw → `JSON(application/json)`

```
{
    "means": "sample-means",
    "authenticationContext": {
        "identifyeeType": "customer",
        "clientId": "00000000-0000-0000-0000-000000000001",
        "requiredLevelOfAssurance": 2,
        "scopes": ["personal_data"]
    },
    "authenticationResult": {
        "agreementKey": {
            "id": "00000000-0000-0000-0000-000000000003",
            "type": "UUID"
        }
    }
}
```

Response:

```
{
    "person": {
        "id": "00000000-0000-0000-0000-000000000001"
    },
    "accessTokens": [
        {
            "accessToken": <access token>,
            "accessTokenExpirationDate": <date>,
            "accessTokenTimeToLive": 240,
            "refreshToken": <refresh token,
            "refreshTokenExpirationDate": <date>,
            "refreshTokenTimeToLive": 7200,
            "profileId": "00000000-0000-0000-0000-000000000002",
            "profileName": "Primary",
            "default": true,
            "jwtId": <jwt id>,
            "setId": <set id>,
            "executorLevelOfAssurance": 2
        }
    ],
    "authentication": {
        "status": "complete"
    }
}
```

## Build and run sample authentication means
We developed a sample authentication means based from Merak reference API which includes the configurations and secrets that are needed to integrate with TIAB.

Clone sample authentication means:

```
    git clone --branch tiab https://gitlab.ing.net/stormtroopers/apisdk.git
```

At the root of the project execute [publishing in local repository](https://gitlab.ing.net/stormtroopers/apisdk#publishing-in-local-maven-repository) command. <br />

Go to [project directory](https://gitlab.ing.net/stormtroopers/apisdk/tree/tiab/examples/MerakReferenceAPI/reference-sample-means-springmvc-web), build and run the application.

```
    #Build 
    mvn clean install -Plocal
    
    #Run
    mvn spring-boot:run -Plocal
```

By default this component runs on port 8085.

## Test sample authentication means
#### Flow
1. Post the credentials by calling the API Gateway using `https://tiab.ing.net:30088/api/merak/reference/authenticate`
2. The API will forward the call to `https://ext.tiab.ing.net:8085/api/merak/reference/authenticate`
3. The means calls the Authentication Orchestration service via the TLS router
4. The TLS router routes (on the IP layer) the request to `authenticationorchestration.touchpoint-in-a-box.svc.cluster.local`
5. The Authentication Orchestration service calls the Security Policy service
6. The Authentication Orchestration service calls the Means Administration service
7. The Authentication Orchestration service calls the Identity service
8. The Authentication Orchestration service calls the Risk Assessment service
9. When the result of all previous calls were successful, the Authentication Orchestration service calls the Token API service to create the access and refresh token pair and returns the result to the Authentication Means service which in turn returns the result to requester (curl) including a set-cookie to set the pinning cookie

Navigate to Postman collection `TouchPoint in A Box > SampleMeans > authenticate`, take a look at `Body`.


```
{
    "username": "root",
    "password": "password"
}
```

We set the the correct credentials by default. Send the request, response should look like:

```
{
    "person": {
        "id": "00000000-0000-0000-0000-000000000001"
    },
    "accessTokens": [
        {
            "accessToken": "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiZGV2LWEyZDE4MGQ4LTAxZDctNDNiZi04M2IzLTZiZjJkMGYzMWUyMiIsImN0eSI6IkpXVCJ9..5_GkE1yBdm32ibBor6FVUw.HHD4h3atOXx0cOMExu7bXYNidgjJVBXphQ_vk3tTVNGku1dyIiCapgC1FNaBLf7YvF72h-d0xAXj3CSE3WSQ0-mgqfC_K05GkS_AoWG85FMxpuhcU5hD1JHMeneE3mFbOR13zUfEm6RZ_-UnL_wR2rq6yBFalxHBWjZBAkNT3lzIYN_mSt3oDIw1F4KjULEVlDUfDsisMcOdftsXt8AKbvc7ymF3yhCWdLnDzA9NBfg71lgKAgkzkTT2oj63wo-wR4jpBEnJgiMMgdEeYqNSYvs_mll6K73tkgqL_h2MlShiTxQHRUQmM5TC2V_pNvBpnD9_3M-cy1-3P5I0nMpuX9AbPoMk7mJWpKhUjnCbwxsavAAAQt3lqvf4S4iMLEMfzmK-g01I2EfR883E3DaiMXi6tHN-ptBZALyAARKoyaX_ayGgmB7zaWysKw2ArdQ8LyEDdQi_Nh3jJdH85a6AZ0-Eo-tG13osdfp8OwCklFz0yPsxkho-uLhusIoYhspJTdEuhFpWYfj4JDwdknitGo9ddpZ0slCESTKHUnZAX4b6uC4sECXdFqqSbfpxN7Y2qkXOBqip0Aka7iHQrvFvBAFp6En4nbq2T0s5l5R80H-LLxGgDF2xvrGLWy0q5e7sDOJe6QGMaKsYMvotWIvp1V0_e10wZEgpuELU3_tWZmJRqTorsZp9NsJinmxKKiWJFJch4_EJ0hrPUMzWNspBxAR0qwtaAorPfImTcWfePyOmsVtFSvtrlQUJf4WBtYeyWXhSyy4C5oQotermpGchj3hjUyIpkFhnx_t7QryBPMWoiSEmBNajrxwLAGF036t7wdhvNw10JdT7pPfQBNn1DZiR1jKCoC7u51L7wKCG_9oqGShD-NsJb5Hjlr_dxpzwTC5s0DL-wsYQwyVtyEgzHBBBnnwWEQ0tcwC955ejpttUPS1qw_-WoLINNPPPtdBoPnhKivOQ5EeavPG1WdjINRQmZuwgaL7AKNcKlJuryZQoT8XpcdulO_fjH1d0YQtcT7aa6WowkZg9jnED-wDo3MMDnzt4909YqIqISWLHlOgvnJtOf5s3gpjBIB8Y9ha9oaT-itMHAajfxdpI8OAPII8J-vMamM9cBtlxaHlHF_UeO6c8bumqDSknM3JKMPCc1yUexmgxFIQ4380_ayZPV3RutbmnOzIjHWP2laaBeqrsjU73N2KVf3hFI6fyFOaRfK0Bbyx-VaOp8NMYxKDNFB1EkqlqVBwV2cAfMpXVfW821QIthzvIIfZgGPiJnkycFxGS3s402HQi3lkM0o6FlTyoVN7cCIlyxrWUgckP2ivalF83VZDKrn68Tx67IrvdqvYp4cScGm93nGsds4K2ollXRiALW7R3AIB5gLO7Kblt0vSJUb-WuZQ4w5iXsKwv7wmfHdKygqvUZQzTYfrpqus4FkMoFJ3TI1_4bzTTKCA2y8Piy77ZrP8dgt-rYiJILJ6TLMYiGXFfnmTelPjjX7ej8qIoDMAwi_XK8dNjvP2I1J_qmawiu3OdND7_QRmNFcRikb-QY8bxjL2d-eH_catj2i6Jfu7R4WfxmXnEin3u3PI2xi30Du2pou9tIYdd_SvwiFqCQWIQJzlhuh775P1NoIgw9fFgUKbDu5g0gB4.DTOyyiL4B7WVX2AWXnf23_UZdvbj0-ulpEZz0gpAEEo",
            "accessTokenExpirationDate": "2019-06-11T00:06:36.642",
            "accessTokenTimeToLive": 245,
            "refreshToken": "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiZGV2LWE5OWRlYmUyLTc0YjEtNDYxYy1hNjVhLWZlNTZhZTg0M2FlNiJ9..wSPlDQi2QCtntvZGqmqGsw.q_6-5_f4Wwj-mBGjbMmMAMJwVxJrxZLiD4wZfIY6gEXRJiGaRvQg-qGWYdmGMaxgUMfq-RCSZm4BfCSBEuc0ynN7bpBGkr87gZ_fL9ISkhlgSAGgFhp8gazCmev3DxMFG72GJ8vo_nmGez87MSZbWAWWOATXFzzdSAvnRNfF9KciNQD9MN0E29tTmvTtzxWnEAQ3k6XTGpElue4L-8yiFkmoBN-TcDSE-gZWXGJTcyrWOPGmR9-H1oMI-Vv26IQFSvtJUauuU9t3Q40z8-G6SMXq_0swnPemPTzVLTALoaGpxpLrvILq9uWntyE-1FIQBA8yTbwP3fizobzBZdRB9Tila1wo7QW3V7bz6Ud86aU-6cyLsQUBjf68XCLeXOeSIhjjEPGWvvRYaw0CEYgcM0giaLIG-BZdJ9_RhRfvNnbewQuyNj8zqlmHn4_DlLxwD86bZsArhJKX0v4jY5kVYMNhPMjm1d9DRhHL8O21Y89FhHgs26A1T7ewDW_zSFJ9OTPa26aw8Nu5QLeJExu0iUJmDoZ-am9xE3Mnfaui57KoRe2_0UTFaCzerTe2jVSVrItJUxVd6rcIUCjeK9eqgAcZE8CYkinAn3kJKRJoZ2BELSNtMqgmNIgSm-s-vLjWdGOYkICbxNv3zn4fmdLCezBIMRMmIYxJS-zW4BCwrUaAR3HQ2Um4llgMLTnbnMZTn7jwuNKPLgzmiWvaP8Orwn5LsUdyvjv5CYGq4T0G5J6x9J95Kqv2c0eVD87A1xnOZadQUjzIcw5QXQGOyUngQyg6GSwS9aIW64HmAX6LaR2JBnlDC2jMlFH4FU7bvOmHYnGNu7sxhr3MUl73YXXiEil_jUGJEs5vj9oJ7Kcco_RUsvVwtALgLk57vuJDk-40.kHmkRhyonxW-NSiKqtysK5h36wrxwXsgiVFHh7Acrn8",
            "refreshTokenExpirationDate": "2019-06-11T02:02:31.642",
            "refreshTokenTimeToLive": 7200,
            "profileId": "00000000-0000-0000-0000-000000000002",
            "profileName": "Primary",
            "profileType": "PRIM",
            "default": true,
            "jwtId": "ee4fff04-e7af-4636-a304-1a09bd32f85c",
            "setId": "92b53d10-37fc-4ece-9fd9-f4d323c571cb",
            "executorLevelOfAssurance": 2
        }
    ],
    "authentication": {
        "status": "complete"
    }
}
```

Test negative scenario by updating wrong credentials, and response should be empty with http status 401.

***
*Contact Us: <ml-stormtroopers@ing.com> / [Mattermost](https://mattermost.ing.net/stormtroopers/channels/town-square)*