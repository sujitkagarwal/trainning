# Enabling other TouchPoint services
TIAB comes configured with multiple services, but after you initially startup TIAB we only run a set of services that are needed to run the [Bootstrap token request](docs/howto/send_postman_requests_to_test_tiab.md). In a couple of simple steps you will be able to toggle the other TouchPoint services on or off.

1. Login to the box
2. Open the all.yml file `vi /root/tpa-in-a-box/ansible/group_vars/all.yml`
3. Under the `services`, remove the `#` on the lines of the services you want to enable. 

```yaml
######################################
### Configure the pods to run      ###
### comment/uncomment to configure ###
######################################
services:
  - api-gateway
  - authentication-orchestration
  - bootstrap
  - cassandra
# - consent-orchestration
  - means-administration
# - secure-remote-password
  - security-policy
  - token-api
  - tls-router
# - ok-button-means
# - graphite-metrics
# - estestconsole
# - engagementsuite
# - broker
# - zookeeper
# - cp_schema_registry
# - mailhog
```

Make sure to check if a service has a dependency on another and enable that service as well. You can find the list [here](docs/design/busy_box.md).

4. Reset the playbook `./playbook reset`
5. Check the status of the pods with `oc get pods`
