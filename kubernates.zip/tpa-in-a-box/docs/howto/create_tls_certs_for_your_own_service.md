# TLS Certificates

## Overview
Communication with TPA services is vital to a capability/means that is being developed. For this to be possible, there needs to be mutual trust between the services. And for TPA Services, this is done using TLS.

## How to generate user specified TLS certificate
*The following steps need to be done inside TIAB, refer to [login command line](../../readme.md#login-command-line)*.

As explained in [injecting configurations](../design/injecting_configurations.md), after running `./playbook.sh` the script automatically generates the TLS certificates.
To do the same for your service, simply execute `./playbook.sh create-cert` with the following required arguments:
```
-n: Name of the service that the certificate is for
-hn: hostname
-sn: ServiceName
```

Example: `./playbook.sh create-cert -n authenticationorchestration -hn authenticationorchestration -sn AuthenticationOrchestration`

Ths script will create a folder `/root/tpa-in-a-box/ansible/.client-certs/<service_name>/` containing the following files:
```
<service_name>.crt
<service_name>.key
<service_name>.jks
```

The truststore is already pre-generated and located at `/root/tpa-in-a-box/ansible/ca/ca.jks`.

The password for both JKS is `password`

To copy files which are inside TIAB, use the command below which needs to be executed from your host machine.
```
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/.client-certs/<service_name>/<file> <path_destination_at_hostos>
```

Samples for the naming convention for each option used for TIAB can be found in `all.yml` under `service_certificates.services`.
