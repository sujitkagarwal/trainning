# Updating Dnsmasq Configuration
In order for your localhost to be resolved by TIAB you need to update the dnsmasq address-ip mapping.
In most cases if your host OS is Window you don't need to do this step.

1. Login to the box
2. Open the all.yml file `vi /etc/dnsmasq.d/tiab.conf`
```
address=/local.tiab.ing.net/ext.tiab.ing.net/<localhost_ip>
address=/tiab.ing.net/svc.tiab.ing.net/10.0.2.15
```
3. Restart dsnmasq
```
systemctl restart dnsmasq
```
