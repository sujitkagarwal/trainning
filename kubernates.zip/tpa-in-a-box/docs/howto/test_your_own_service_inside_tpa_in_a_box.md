# How to test your Capability API or Local Means against TIAB inside TIAB

Running the Capability API or Local Means that you are developing inside TIAB means you need to run it on the same cluster where TIAB is running on your local Openshift/Kubernetes. To do this, you need to follow the steps below:

1. Dockerize your application, meaning you have to create an image of your application
2. To imitate production setup, communication to a TPA service from another is made secure by TLS certificates signed by TIAB's own CA Certificates. These generate on every startup. So, in order for your own service to communicate to the TPA services you need to [create TLS certificates](create_tls_certs_for_your_own_service.md) for your service.
3. Make sure you are on the same cluster and namespace as where the TIAB is running on your local Openshift/Kubernetes 
4. If your application's configuration is not baked inside the image, create an Openshift/Kubernetes Config Map for it using the command: `oc create cm <name_of_this_config_map> --from-file=<file_path_of_config_file>`. If there are multiple configurations, create only one Config Map for it by just adding another `--from-file` option to the command.
5. If your application's secrets is not baked inside the image (such as the TLS certificates you created a while ago), create an Openshift/Kubernetes Secrets for it using the command:  `oc create secrets <name_of_this_config_map> --from-file=<file_path_of_config_file>`. If there are multiple secrets, create only one Secrets for it by just adding another `--from-file` option to the command.
6. Create a yaml template for creating an Openshift/Kubernetes service and an Openshift/Kubernetes deployment for your service. Refer to the templates we created for the TPA services for TIAB in `kubernetes/templates`. Please do not forget to incorporate any Config Maps or Secrets you created on this template.
7. Execute the command: `oc apply -f <path_of_the_template_file_you_created>`
8. Expose your services' endpoints through API Gateway
9. Run your APIs 

Note: For Steps 4 and 5, kindly refer to the [Injecting Configurations README](../design/injecting_configurations.md)