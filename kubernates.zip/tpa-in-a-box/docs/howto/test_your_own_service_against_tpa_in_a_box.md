# Testing your Capability API or Local Means against TIAB

Primarily, there are 2 ways to test your Capability API or Local Means against TIAB: run it [inside the box](test_your_own_service_inside_tpa_in_a_box.md) or [outside](test_your_own_service_against_tpa_in_a_box_from_outside.md).

Running it inside means running it on the local Openshift/Kubernetes together with the TPA services. In this option, you will have to worry about creating Openshift/Kubernetes service, deployment, config maps, secrets, etc plus exposing your service's endpoints through the API Gateway. If you are not familiar with Openshift/Kubernetes and/or Nginx, you might need to spend a lot of time learning the basics first before you could actually test. Nevertheless, these technologies are quite interesting and having an overview of how things actually work in container orchestration will be advantageous.

On the other hand, running it outside means your service will communicate with the TPA services from outside the local Openshift/Kubernetes (or outside the VM if you are running the VM). Using this method, you will only have to worry about: running the box, running your service, and generating the TLS certificates. The communication from the outside to inside of the box is made possible by the [TLS Router](tls_router.md).

Whichever option you prefer, please do note that communication from one TPA service to another was made secure by TLS certificates signed by TIAB's own CA Certificates. These are generated upon every startup so as to imitate a production setup. So in order for your Capability API or Local Means to be able to communicate to any TPA service, it needs to be authorized by TLS certificates created & signed by the same CA used in the box as described [here](create_tls_certs_for_your_own_service.md).

