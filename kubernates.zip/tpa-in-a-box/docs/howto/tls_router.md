# TLS Router

## Overview
The TLS Router at its core is an Nginx which acts as a [layer 4](https://www.nginx.com/resources/glossary/layer-4-load-balancing/#layers) load balancer and based on the [SNI Header](https://en.wikipedia.org/wiki/Server_Name_Indication) 
set during the TLS handshake routes the request to the service based on the rule set for mapping the `SNI Header` to the service inside the cluster. This is while still maintaining mutual TLS between the caller outside the cluster 
and the service within the cluster.

For example, given the request to `https://tokenapi.tiab.ing.net/security-tokens/access-token` <br />
ssl_preread_server_name/SNI_Header = tokenapi.tiab.ing.net  <br />
SNI Header mapping

```
map $ssl_preread_server_name $pod {
    ~^(?<service>[^\.]+)       $service.touchpoint-in-a-box.svc.cluster.local;
}
```

The regex basically matches everything that is not a `.`.  <br />
It will match and proxy the call to `tokenapi.touchpoint-in-a-box.svc.cluster.local`.  <br />
Refer to [tls-router config](../configs/tls-router/nginx.conf) for the whole configuration.

## <a name="configuration"></a>Configuration
The only configuration needed for the application is to properly set the above rule in the url of the API. For example, they want to communicate with `authenticationorchestration` inside the cluster and the service is named `authenticationorchestration`, the URL should be `https://authenticationorchestration.tiab.ing.net`.

The setup will be more on the host machine, since TIAB is hosted locally we normally make a call to localhost but if we want to use the `TLS Router` we need to keep the URL format as above so the solution is to add an alias in the host machine domain names.

For NixOS:
Edit `/etc/hosts` and add the domain name to be alias for localhost. For the examples above.
```
127.0.0.1   authenticationorchestration.tiab.ing.net tokenapi.tiab.ing.net
```

***
<em>Contact Us: <ml-stormtroopers@ing.com> / [mattermost](https://mattermost.ing.net/signup_user_complete/?id=ktub38h4cpb8tbu5tffyaad8nr)</em>