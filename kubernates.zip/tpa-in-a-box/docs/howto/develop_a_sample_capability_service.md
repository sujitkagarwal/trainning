# Develop a sample capability service

* [Overview](#overview)
* [Prerequisites](#prerequisites)
* [Generate TLS certificate for your sample capability](#generate-tls-certificate-for-your-sample-capability)
* [Configure the capability endpoints in the API Gateway configuration](#configure-the-capability-endpoints-in-the-api-gateway-configuration)
* [Build and run sample capability](#build-and-run-sample-capability)
* [Test sample capability](#test-sample-capability)

## Overview
A capability service is any application that implements business logic.
This document guides you through the process of testing a sample capability using TIAB.

## Prerequisites
* Run sample authentication means by following the [develop_a_sample_authentication_means_service](./develop_a_sample_authentication_means_service.md) guide
* Import [postman collection](../../test/tiab.postman_collection.json) and set `Postman -> Preferences -> General -> Request -> SSL certificate verification` to off

## Generate TLS certificate for your sample capability
Mutual TLS is required for communications between any components of TIAB, hence you need to provision a client certificate for your sample capability.
SSH into TIAB virtual machine and go to project root `/root/tpa-in-a-box/` and execute the command below, kindly follow font case stated at the example.

ssh into the VM:
```
    #Password is `password`
    ssh -p 30022 root@tiab.ing.net
```

create certificate and JKS:
```
    ./playbook.sh create-cert -n <name> -hn <hostname> -sn <ServiceName>
```
example:
```
    ./playbook.sh create-cert -n samplecapability -hn samplecapability -sn SampleCapability
```

The client certificate and Java KeyStore will be generated and stored at `tpa-in-a-box/ansible/.client-certs/samplecapability/`, the password of the JKS is `password`.
Copy the certificates using the command below executed from your host operating system.

```
    #Copy sample capability certificate
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/.client-certs/samplecapability/samplecapability.crt <path_destination_at_hostos>
    
    #Copy sample capability JKS
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/.client-certs/samplecapability/samplecapability.jks <path_destination_at_hostos>   
```

Store is already pre-generated and located at `tpa-in-a-box/ansible/ca/`, the password of the trustStore is `password`.

```
    #Copy truststore certificate
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/ca/ca.crt <hostos_path_destination>
    
    #Copy truststore JKS
    scp -P 30022 root@tiab.ing.net:/root/tpa-in-a-box/ansible/ca/ca.jks <hostos_path_destination>    
```

## Configure the capability endpoints in the API Gateway configuration
In order for your sample capability endpoints to be exposed as a route of TIAB, you need to configure API Gateway's Nginx configuration.
SSH into TIAB virtual machine and go to `tpa-in-a-box/configs/apigateway/` and edit desired server configuration in `nginx.conf`. 
There are two server configuration one has cookie pinning which is intended for web clients(listens at port 8080) and the other one uses SRP pinning for mobile clients (listens at port 8088). 

ssh into the VM:
```
    #Password is `password`
    ssh -p 30022 root@tiab.ing.net
```

route template:
```
    location /route/endpoint {
       proxy_pass https://ext.tiab.ing.net:<sample_capability_port>;
    }
```

example:
``` 
    location /api/merak/reference {
       auth_token on;
       proxy_pass https://ext.tiab.ing.net:8086/api/merak/reference;
    }
```

When the configuration file is changed, delete the current configmap and create a new one and after that delete the pod to have it restarted using the new configuration.

```
    #Delete API Gateway configmap 
    oc delete configmap apigateway-cm
    
    #Create API Gateway configmap after adding route
    oc create configmap apigateway-cm --from-file=/root/tpa-in-a-box/configs/apigateway/nginx.conf
    
    #Delete API Gateway pods
    oc delete pod -l app=apigateway
```

## Build and run sample capability
We developed a sample capability based from Merak reference API which includes the configurations and secrets that are needed to integrate with TIAB.

Clone sample capability:

```
    git clone --branch tiab https://gitlab.ing.net/stormtroopers/apisdk.git
```

At the root of the project execute [publishing in local repository](https://gitlab.ing.net/stormtroopers/apisdk#publishing-in-local-maven-repository) command. <br />

Go to [project directory](https://gitlab.ing.net/stormtroopers/apisdk/tree/tiab/examples/MerakReferenceAPI/reference-sample-capability-springmvc-web), build and run the application.

```
    #Build 
    mvn clean install -Plocal
    
    #Run
    mvn spring-boot:run -Plocal
```

By default this component runs on port 8086.

## Test sample capability
#### Flow
1. Obtain Access token by sending POST request `https://tiab.ing.net:38080/api/merak/reference/authenticate` to API Gateway
2. GET request `https://tiab.ing.net:38080/api/merak/reference/greeting/secure` to API Gateway
3. The API will forward the call to `https://ext.tiab.ing.net:8085/api/merak/reference/greeting/secure`

Go to Postman collection `TouchPoint in A Box > SampleMeans > authenticate`, send and obtain access token.  <br />
Then navigate to `TouchPoint in A Box > SampleCapability > greeting/secure` and trigger it. <br /><br />
Response should look like:

```
{
    "message": "Hi",
    "ipAndHost": "172.16.40.127/ABM3LC02VJ4WNHTD7:8086",
    "tokenId": "91eacdd6-6866-4637-9201-7e3a9d5eddf4",
    "protocol": "HTTP/1.1"
}
```

Test negative scenario by removing access token, and response should be empty with http status 401.

***
*Contact Us: <ml-stormtroopers@ing.com> / [Mattermost](https://mattermost.ing.net/stormtroopers/channels/town-square)*
