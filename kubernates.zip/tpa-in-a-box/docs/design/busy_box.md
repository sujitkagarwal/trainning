# BusyBox
## Service start up dependency

Some services are dependent on the connection to its data source upon start up.

For TIAB this data source is Cassandra. Without Cassandra running on TIAB or for some cases if it is still starting up, the services could enter the CrashLoopBackOff state as OpenShift tries to restart the pod over and over again while it encounters the error regarding Cassandra connection.

As a solution to this, we added a BusyBox initContainer to those services. This initContainer checks for 10 times if Cassandra is already up and running (via netcat or nc) before it runs the services' application container.

```yaml
command: ['sh', '-c', 'counter=0; until nc -zv cassandra 9042; do if [ "$counter" -eq 10 ]; then echo counter reached.. exit1; exit 1; fi; echo waiting for cassandra, $counter; sleep 2; let counter++; done;']
```

In addition, we also did the same for Bootstrap with regards to Authentication Orchestration API (AOA). Since Bootstrap is an authentiation means, it needs AOA to perform its function.

The following are the data source or service with the services that are dependent on them on TIAB:

1. Cassandra
* Consent Orchestration API
* Secure Remote Password
* Token API

2. Authentication Orchestration API
* Bootstrap

Be aware that if you configure a service, be sure to check if it has a dependency and make sure you configure to run its dependency as well. Or else that service will be stuck on initContainer and it will never start up.