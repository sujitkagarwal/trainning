# CORS Enabled

Usually, a front end application is being served from a domain separate from the back end. In this case, AJAX calls will use the origin of the front end. And because of same-origin policy, scripts from the front end domain would not be allowed to access data from the back end domain.

Thus, TIAB has its CORS filter activated via the Nginx configuration of API Gateway.

```
    cors_enabled on;
    cors_autoprefix_enabled on;
```