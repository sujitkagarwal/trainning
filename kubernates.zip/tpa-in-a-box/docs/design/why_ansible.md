# Why Ansible

Ansible was chosen mainly for its templating capabilities. Since this is a collaborative project and we are dependent on the releases of the different TPA Teams, the images and different configurations could change with every release. It would be cumbersome to have to directly modify each Deployment/Service yaml file and change the image manually. The process would be error prone and would take too much time, so we looked into tools which can help with templating and we came upon Ansible.
