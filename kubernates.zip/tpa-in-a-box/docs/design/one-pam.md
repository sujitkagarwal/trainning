# OnePAM
The current OnePAM is dependent on MDM, which is an IBM Product. Duplicating/cloning OnePAM means creating new instances of MDM directly translates to additional licensing costs and significantly heavier setup overhead. 

To workaround this coupling, Asia created OnePAM Edge which basically mimics the API contracts and database model. Instead of using MDM, they used MySQL, making it possible to containerize and spawn some OnePAM API Contracts on demand without impact on licensing cost. This implementation is called OnePAM Edge and is maintained by Project Wright. The approach also ensures that its compatible with the 
Touchpoint services in TIAB.

For TIAB, since the focus is local development, it is only vital to have a OnePAM which would be able to cater to the request of the different Touchpoint services so we decided to use [PACT files](pact.md).

If there are calls which are lacking from the current PACT files or if needs improvements, feel free to reach out to us via the channels provided in the main [readme.md](../archive/readme.md#contact-us).
