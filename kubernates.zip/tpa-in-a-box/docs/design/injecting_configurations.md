- [Injecting Configurations](#injecting-configurations)
  * [How it works](#how-it-works)
  * [How ConfigMap and Secret are generated](#how-configmap-and-secret-are-generated)
  * [Rolling updates when ConfigMap changes](#rolling-updates-when-configmap-changes)
  * [How TLS certs are generated](#how-tls-certs-are-generated)
  * [How its configured](#how-its-configured)

# Injecting Configurations

## How it works
For people coming from Docker, mounting volumes is a popular approach to injecting configurations inside your container. And TIAB (which uses Kubernetes/Openshift) uses that too but with a different representation.
In Kubernetes/Openshift land, they have two ways of providing configurations: 

1.[ConfigMap](https://kubernetes.io/docs/tasks/configure-pod-container/configure-pod-configmap/) representing any files/variables used for configuration, such as your application.conf/application.properties/application.yml. (Non-confidential)

2.[Secret](https://kubernetes.io/docs/concepts/configuration/secret/) representing the credentials, jks, private-public key pair. Being obfuscated with a Base64 encoding. (Confidential)
These `ConfigMap` and `Secret` are both represented as objects inside Kubernetes/Openshift and these objects are being mounted to the containers. 

Example integration with `Secret` and `ConfigMap`
```yaml
apiVersion: apps/v1beta2
kind: Deployment
metadata:
  name: integrationstubber
spec:
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      app: integrationstubber
      version: v1
  template:
    metadata:
      annotations:
        configHash: 8f59ae2df86ddd4cbb10fd14bd3ed216091c9dde
  template:
    metadata:
      annotations:
        configHash: 8f59ae2df86ddd4cbb10fd14bd3ed216091c9dde
      labels:
        app: integrationstubber
        version: v1
    spec:
      containers:
      - name: integrationstubber
        image: stormtroopers.docker.ing.net/dev/integration-stubber:2.19.0-e555f941-alpine
        imagePullPolicy: IfNotPresent
        resources:
          requests:
            cpu: "25m"
            memory: "384Mi"
          limits:
            cpu: "2"
            memory: "768Mi"
        readinessProbe:
          failureThreshold: 5
          periodSeconds: 3
          successThreshold: 1
          tcpSocket:
            port: 8443
          timeoutSeconds: 1
        ports:
        - containerPort: 8080
        - containerPort: 8443
        - containerPort: 5556
        volumeMounts:
        - name: ca-jks
          mountPath: /certs/ca.jks
          subPath: ca.jks
        - name: tls-jks
          mountPath: /certs/integrationstubber.jks
          subPath: integrationstubber.jks
        - name: mappings-dir
          mountPath: /mappings
      volumes:
      - name: tls-jks
        secret:
          secretName: integrationstubber-jks
      - name: ca-jks
        secret:
          secretName: ca-jks
      - configMap:
          name: integrationstubber-cm
        name: mappings-dir
      imagePullSecrets:
      - name: regsecret
```

`ConfigMap` and `Secret` is named/specified in `volume` and its usage on which folder/file these objects will be mapped to is set using `volumeMounts`

## How ConfigMap and Secret are generated
Running `./playbook.sh` will generate the `ConfigMap` and `Secret` yaml file and store them inside `../ansible/.kubernetes/cm` and `../ansible/.kubernetes/secrets` and also apply these objects such that the Deployment objects can refer to these `ConfigMap` and `Secret`. 
See [config-maps.yml](../ansible/tasks/config-maps.yml) and [secrets.yml](../ansible/tasks/secrets.yml) for the command used to generate the yaml definitions.

## Rolling updates when ConfigMap changes
Natively, Kubernetes/Openshift doesn't do any updating of pods when the `ConfigMap` object changes. To work around this problem, we rely on the Kubernetes/Openshift version control functionality and insert a hash in the Deployment.
```yaml
apiVersion: apps/v1beta2
kind: Deployment
metadata:
  name: apigateway
spec:
  replicas: 1
  selector:
    matchLabels:
      app: apigateway
      version: v1
  template:
    metadata:
      annotations:
        configHash: 684832c41bb6328b42b476d7ecb8151661c65b61
      labels:
        serviceType: tpa
        app: apigateway
        version: v1
```
configHash is added in the `spec.template.metadata.annotations.configHash`. When something changes in any of the configurations in `configs/`, the ansible-playbook will create a `ConfigMap` yaml and then compute the hash and insert the hash in the deployment yaml. When these objects are applied, Kubernetes/Openshift will see the changes in deployment object and redeploy a new pod.

See the list of configurations which generates `ConfigMap` refer to `service_configs` in `../ansible/group_vars/all.yml`

## How TLS certs are generated
When `./playbook.sh` is executed, it creates the CA certificate and then uses the `service_certificates.services` variable defined in `../ansible/group_vars/all.yml` for the list of services that needs to have their TLS certificate generated and signed by the CA. These  certificates will be stored in `ansible/ca` and `ansible/.client-certs`

`../ansible/group_vars/all.yml`
```yaml
service_certificates:
  default:
    environment: DEV
    issuer     : Kubernetes
  services:
    - { name: bootstrap, hostname: bootstrap, svc_name: Bootstrap }
```

The script will create xx.key, xx.crt, xx.pkcs12 and xx.jks where `xx` is the hostname defined in the `service_certificates.services`. All these files are stored inside the `../ansible/.client-certs` inside their respective services. The CA certs are stored in `ansible/ca`

## How its configured
tpa-in-a-box stores all configurations needed by the different TPA services in `configs/` folder. When `./playbook.sh` is executed the contents of the `configs/` folder is converted to `ConfigMap` and linked to their respective services. The same is being done with `secrets/` folder but aside from that, there are `Secret` being generated when `./playbook.sh` is executed. These generated secrets are the different [tls certs]() needed by the TPA services to do mutual TLS.

