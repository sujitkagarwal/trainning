# Pact

TIAB also has the capability to consume pact files and spin up a server which responds to the definitions in those pact files. Thanks to the [api-simulation](https://gitlab.ing.net/GlobalApiSdk/api-simulation)

If you have pact files and you want to test your services against those pact files, you can easily use it with TIAB. Simple place those pact files in `configs/apisimulation/pact` and simply rerun the `./playbook.sh`. 
