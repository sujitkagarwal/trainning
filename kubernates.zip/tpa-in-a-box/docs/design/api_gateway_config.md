# API-Gateway Configuration

TIAB runs the API Gateway in a container but we are not experts in the configuration of Nginx. What we have in TIAB are some of the things that worked with our use cases. If you think there are things that needs to be added to improve 
the overall product, feel free to reach out to us via the channels provided in the main [readme.md](../archive/readme.md#contact-us).
