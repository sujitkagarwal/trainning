# Use other OnePAM Data other than what is provided by the integration-stubber

Since TIAB uses [stubs](stubbing.md) for its OnePAM, data it provides are just what is defined for each endpoint in JSON files in `configs/integration-stubber`.

If you wish to use other response data for a OnePAM endpoint, just look for the specific JSON file and update its `response`. Moreover, if there is a OnePAM endpoint that you would like to call but is not yet stubbed in TIAB, just create a new stub (a new JSON file) in `configs/integration-stubber` for it.

As an example, below is the stub we created for the endpoint `/identities/individual-internal-identifiers/lookup`:

```json
{
    "request": {
        "method": "POST",
        "bodyPatterns": [
            {
                "ignoreExtraElements": true,
                "matchesJsonPath": {
                    "expression": "$.involvedPartyInternalIdentifier.involvedPartyInternalIdentifierType",
                    "matches": "UUID"
                }
            }
        ],
        "urlPath": "/identities/individual-internal-identifiers/lookup",
        "headers": {
            "Content-Type": {
                "contains": "application/json"
            }
        }
    },
    "response": {
        "status": 200,
        "jsonBody": {
            "individual": {
                "involvedPartyIdentifier": "00000000-0000-0004-0000-000000000004"
            },
            "accessProfiles": [
                {
                    "accessProfileIdentifier": "00000000-0000-0004-0000-000000000004",
                    "accessProfileType": "ING_CORP_KEY",
                    "accessProfileName": "Family"
                },
                {
                    "accessProfileIdentifier": "00000000-0000-0000-0000-000000000029",
                    "accessProfileType": "ING_CORP_KEY",
                    "accessProfileName": "Family"
                }
            ],
            "meansAgreement": {
                "defaultAccessProfileIdentifier": "00000000-0000-0004-0000-000000000004"
            }
        }
    }
}
```

Lastly, do not forget to run `./playbook.sh reset`, this will delete the existing configmap for the `integration-stubber` and will create a new one with the JSON files you updated or added.

## Remark

If you are new to OnePAM and you would like to make sense of its data, below are some references you can read on:

##### Identity:

https://theforge.ing.net/product/25904/documentation/latest/IdentityAPI

##### Access Profile:

https://theforge.ing.net/product/25904/documentation/latest/AccessProfileAPI

https://confluence.europe.intranet/display/CHD/Usefull+documentation?preview=%2F726462213%2F729133490%2FAccess+Profile+principle+V1.3+.pptx

##### Involved Party, Individual:

https://theforge.ing.net/product/32037/documentation/latest/introduction

##### Agreements:

https://theforge.ing.net/product/13419/documentation/latest/introduction

