## Setup VirtualBOX image manually
This is a manual on how to setup the VirtualBox image manually, this also includes the setup of SSH to make it easier to work with the virtual machine, and the option to mount drives to make transferring files easier.


#### install and configure Virtualbox
1. Download the Centos image http://isoredirect.centos.org/centos/7/isos/x86_64/CentOS-7-x86_64-Minimal-1810.iso
2. Create a new box >> type - Linux >> Version - Red hat (64 bit) >> Memory - 10G >> File size - 40Gig
3. Start box >> choose Centos image you downloaded
4. Start installation of Centos >> hit Network & Hostname >> check the Ethernet enp0s from off to on >> hit done
5. Hit installation destination >> hit done
6. Hit begin installation
7. Configure a password and start the installation

#### Configuring virtual box
1. Settings >> network >> advanced >> port forwarding >> add >> Hostport 30022, Guestport 22 
2. Settings >> network >> advanced >> port forwarding >> add >> Hostport 30080, Guestport 30080, ip 10.0.2.15, name ApiGatewayWeb
2. Settings >> network >> advanced >> port forwarding >> add >> Hostport 30088, Guestport 30088, ip 10.0.2.15, name ApiGatewayMobile
2. Settings >> network >> advanced >> port forwarding >> add >> Hostport 30000, Guestport 30000, ip 10.0.2.15, name TLSRouter
3. Settings >> System >> processor >> change to 4 Processors

#### Install git and setup the box
1. Start the server and login with root
2. yum install -y git epel-release && yum install -y ansible
3. git -c http.sslVerify=false clone https://gitlab.ing.net/stormtroopers/tpa-in-a-box.git
4. Run the Ansible script, navigate to the folder ansible and run ansible-playbook centosvm-install.yml
5. **Configure secret**, in order for docker to pull the images it needs to know your credentials to the artifactory, this secret can be configured as follows:
`kubectl create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>`
6. **Run the Ansible script**, navigate to the folder `ansible` and run `ansible-playbook Touchpoint-in-a-box-start.yml`

#### SSH for the box
It might help to enable ssh to virtualbox if you want to make changes to the machine, after running the ansible playbook this should already be configured so you can ssh with: `ssh -p 3022 root@localhost` the password is the root password of your machine

#### mount your disk
1. After starting the image go to the menu bar >> Hit devices >> insert guest additions CD
2. In virtualbox Settings >> shared folders >> add >> Choose folder where you cloned the project, check Auto-mount, check Make Permanent

