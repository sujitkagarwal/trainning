# Installing docker
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo && yum install -y docker-ce-18.06.1.ce
systemctl start docker && systemctl enable docker
echo '{
    "insecure-registries" : [ "stormtroopers.docker.ing.net" ]
}' >> /etc/docker/daemon.json
systemctl daemon-reload && systemctl restart docker

# Installing Kubernetes
curl -LO https://storage.googleapis.com/kubernetes-release/release/$(curl -s https://storage.googleapis.com/kubernetes-release/release/stable.txt)/bin/linux/amd64/kubectl && chmod +x kubectl && mv kubectl /usr/bin/
curl -Lo minikube https://storage.googleapis.com/minikube/releases/v0.30.0/minikube-linux-amd64 && chmod +x minikube && mv minikube /usr/bin/
iptables -P FORWARD ACCEPT
systemctl stop firewalld && systemctl disable firewalld
setenforce 0

# Enabling SSH
echo 'PermitRootLogin yes' >> /etc/ssh/ssh_config
systemctl enable sshd && systemctl start sshd

# Adding certificates for root minikube
minikube start --vm-driver=none
minikube stop
curl -k https://pki.ing.net/base64_certificates/intg3_b64.cer >> /root/.minikube/intg3_b64.cer
curl -k https://pki.ing.net/base64_certificates/insg3_b64.cer >> /root/.minikube/insg3_b64.cer
curl -k https://pki.ing.net/base64_certificates/rootca_b64.cer >> /root/.minikube/rootca_b64.cer
curl -k https://pki.ing.net/base64_certificates/rootg3_b64.cer >> /root/.minikube/rootg3_b64.cer
curl -k https://pki.ing.net/base64_certificates/tecca_b64.cer >> /root/.minikube/tecca_b64.cer