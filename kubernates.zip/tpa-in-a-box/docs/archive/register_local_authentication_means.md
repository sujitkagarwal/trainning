# Register a local authentication means service during development

AuthenticationOrchestrationAPI is the interface and orchestrator to the gate components. As such, all new local authentication means will need to pass through the AuthenticationOrchestrationAPI service. 

A new local authentication means should be trusted or whitelisted and accessible to AuthenticationOrchestrationAPI using the steps below.

## Create a local authentication means
Create your sample means and run in on a specific port. Ensure that it identifies as a pre-registered means in `meansadministration` & `securitypolicy`. For this case, `sample-means` can be used. 

## Whitelist the authentication means in the authentication orchestration configuration file
Edit the `configs/authentication-orchestration/application.conf` to add your means as a trusted peer. 
```conf
tls.clients [
    {
        application-name: "SampleMeans"
        endpoints = ${groups.all}
    }
]
```
Delete the current configmap `oc delete cm aoa-cm` and replace it with the new configuration `oc create cm aoa-cm --from-file=configs/authentication-orchestration/application.conf`.
Then delete your authenticationorchestration pod `oc delete po -l app=authenticationorchestration` for it to restart using the new configuration.

## Create an entry in the nginx configuration for your new endpoint
Edit the `configs/apigateway/nginx.conf` to add your endpoint
```conf
location /security-means/sample-means/authenticate {
   proxy_ssl_name samplemeans.tiab.ing.net;
   proxy_pass https://<host-ip>:<port>;
}
```

Delete the current configmap `oc delete cm apigateway-cm` and replace it with the new configuration `oc create cm apigateway-cm --from-file=configs/apigateway/nginx.conf`.
Then delete your apigateway pod `oc delete po -l app=apigateway` for it to restart using the new configuration.

