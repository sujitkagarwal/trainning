# Stubbing

## How it works
Stubbing is done with the use of `integration-stubber`, which is one of the deployments used in TIAB.
Under the hood, this image uses [wiremock standalone](http://wiremock.org/docs/running-standalone/). This Java application consumes JSON files describing the request to match and then the corresponding response.
```json
{
  "request": {
    "method": "GET",
    "urlPathPattern": "/applications/.*"
  },
  "response": {
    "status": 200,
    "jsonBody": [
      {
        "id":"{{request.path.[1]}}"
      }
    ],
    "headers": {
      "Content-Type": "application/json"
    },
    "transformers": ["response-template"]
  }
}
```

The list of configured stubs can be found in `configs/integration-stubber`.

## Need more stubs
For cases wherein we lack stubs (which happens), have a look at [wiremock stubbing](http://wiremock.org/docs/stubbing) for creating your own stubs and after creating one just place it in the `configs/integration-stubber`. Then, simply run `./playbook.sh reset`, this automatically creates a configmap containing the JSON files inside the `configs/integration-stubber` and associates the configmap with the integration-stubber deployment which will then load all the JSON files as stubs.

Do not forget to contribute back by doing a merge request if you think that other teams can benefit from the stubs that you have created. Reach out to us via the channels provided in the main [readme.md](../archive/readme.md#contact-us).
