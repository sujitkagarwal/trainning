- [TPA in a box](#tpa-in-a-box)
  * [Design decisions](#design-decisions)
  * [Setup Mac](#setup-mac)
  * [Setup Windows using VirtualBox Image](#setup-windows-using-virtualbox-image)
  * [Setup Linux](#setup-linux)
  * [Test the Box!](#test-the-box)
  * [Configuring the Box](#configuring-the-box)
  * [Use cases](#use-cases)
  * [Contact Us](#contact-us)
  * [Terms and Conditions](#terms-and-conditions)
  * [Roadmap](#roadmap)

# TIAB Touchpoint in a box

TIAB is a simple way to run the TouchPoint platform in a box, think of it as a black box running locally on your machine which you can use test your local means API, web or Mobile app that uses TPA. You don't need to worry about the complexity behind TPA, everything runs in the box.

**NOTE**: This is strictly a local development tool only, and not appropriate for production use. 

This project is developed by and for ING developers and maintained by the Stormtroopers. We are always looking for suggestions and contributors, feel free to make a pull request or a suggestion if you need anything in the project.

For any help or questions, please feel free to [Contact Us](#contact-us)
Feedback and/or suggestions are welcome. Good Luck and Enjoy!

## Design decisions
* [Why ansible?](../design/why_ansible.md)
* [OnePAM](../design/one-pam.md)
* [Configurations and secrets](../design/injecting_configurations.md)
* [Used Api-gateway configuration](../design/api_gateway_config.md)
* [integration-stubber](stubbing.md)

## Setup Mac
### Pre-requisite Requirements

Make sure you have the following installed/configured:
* Docker edge - https://docs.docker.com/install/ **(available in self service)**
* Postman - https://go.pstmn.io/apps **(available in self service)**
* Ansible - https://hvops.com/articles/ansible-mac-osx/
* Java8 - `brew cask install java8`
* Openssl - `brew install openssl` and `export PATH="/usr/local/opt/openssl/bin:$PATH"`

**NOTE**:
* One of the images being used the `integration-stubber` doesn't have support for java keystore type `PKCS12` which is the default starting with Java9
* Mac ships with a default installation of openssl which is outdated and doing a brew install over it won't override the default installation. To fix this do the export part.

### Set up your Box
1. **Configure the memory of Docker** by default Docker limits itself to 4G of memory, for this project this is often too little, you can increase it to 8G by going to **Docker >> Preferences >> Advanced >> change the Memory**
2. **Enable Kubernetes** In Docker go to the preferences and to the tab **Kubernetes** and check `Enable Kubernetes` This will install and start Kubernetes, make sure you are not on the ING network when Kubernetes is starting. Click on the Docker icon to view the status of Kubernets, when it successfully started you can switch back to the ING network
3. **Clone the repository** `git clone https://gitlab.ing.net/stormtroopers/tpa-in-a-box.git`
4. **Configure secret**, in order for docker to pull the images it needs to know your credentials to the artifactory, this secret can be configured as follows:
`kubectl create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>`
5. **Run the Ansible script**, navigate to the home directory and run `./playbook.sh`

**NOTE**:
* You can SSH from your Local Machine - `ssh -p 30022 root@localhost`
* if you already had kuberneters/openshift installed and are already connected to an environment make sure to switch back to your local environment before you run the Ansible script `kubectl config use-context docker-for-desktop (or docker-desktop)`
* The first time running the script might take a while since it has to pull all the images (>2G)

## Setup Windows using VirtualBox Image
Since kubernetes is not supported on windows 7, which is most commonly used in ING, we made a release in VirtualBox. Literally TPA ... in a box! 

We deliver two options for this: one wherein the VirtualBox image is setup for immediate use, and another where you setup the VM up manually; see the readme [here](docs/virtualbox_setup_kubernetes.md). This VM is set up using CentOS 7.

### Pre-implementation Requirements
Make sure you have the following installed/configured
* VirtualBox: https://www.virtualbox.org/wiki/Downloads
* Postman: https://go.pstmn.io/apps

### Setup your box (Kubernetes)
1. **Download the image** [here](https://artifactory.ing.net/artifactory/releases_mvn_stormtroopers/vm/tpa-in-a-box-CentOSv1.0.1.ova)
2. **Load the image** in VirtualBox >> File >> Import Appliance.. >> select the downloaded file >> start the box, username `root` password `Welcome123`
3. **Update the repo** go to the tpa-in-a-box folder and run `git pull` then insert your GitLab credentials
4. **Switch to a non corporate network and start the cached minikube cluster** `minikube start`
5. **Wait for the kube-system pods status to be running** `watch kubectl get po -n kube-system`
6. **Configure secret**, in order for docker to pull the images it needs to know your credentials to the artifactory, this secret can be configured as follows:
`kubectl create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>`
7. **On the corporate network, run the Ansible script**, navigate to the home directory and run `./playbook.sh`

**Call mobile and web ports from your host machine via localhost:30088 and localhost:30080 respectively**
* You can SSH from your Local Machine - `ssh -p 3022 root@localhost`

### Setup your box (Openshift OKD)
1. **Download the image** [here](https://artifactory.ing.net/artifactory/releases_mvn_stormtroopers/vm/TIAB+OKD+CentOS7.ova)
2. **Load the image** in VirtualBox >> File >> Import Appliance.. >> select the downloaded file >> start the box, username `root` password `password`
3. **Log in to Openshift** `oc login https://console.tiab.ing.net:38443` with username `root` password `password`
4. **Wait for the pre-loaded TPA in a Box pods status to be running** `watch kubectl get po -n touchpoint-in-a-box`

**Configure secret** In case of an update or an ErrImagePull, in order for docker to pull any new images it needs to know your credentials to the artifactory. This secret can be configured as follows:
`kubectl create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>`
**Call mobile and web ports from your host machine via localhost:30088 and localhost:30080 respectively**

* You can SSH from your Local Machine - `ssh -p 30022 root@localhost`
* The Openshift Console can be accessible from your local machine's browser. First set an alias to map localhost to console.tiab.ing.net & tiab.ing.net by editing the host file of your machine [/etc/hosts for Macs][C:\Windows\System32\Drivers\etc\hosts for Windows] and going to the link https://console.tiab.ing.net:38443 

Hosts File:
127.0.0.1       console.tiab.ing.net tiab.ing.net

## Setup Linux

### Pre-implementation Requirements
Make sure you have the following installed/configured
* Postman: https://go.pstmn.io/apps
* Ansible: Based on Linux distro, yum install ansible -y or apt-get

### Set up your Box

1. **Clone the repository** `git clone https://gitlab.ing.net/stormtroopers/tpa-in-a-box.git`
2. **Run the Ansible script**, navigate to the folder `ansible` and run `./create-dev-env-tpa-box-linux.yml -t minikube`
3. **Increase the memory and cpu**, `virsh edit minikube` [This will open an xml in your default linux editor], change the following values (in the future, this will be improved with templates)
```
i. <memory unit='KiB'>2000000</memory> change to <memory unit='KiB'>10000000</memory>
ii. <currentMemory unit='KiB'>2000000</currentMemory> change to <currentMemory unit='KiB'>10000000</currentMemory>
iii. <vcpu placement='static'>2</vcpu> change to <vcpu placement='static'>5</vcpu>
```
4. **Run the Ansible script** `./create-dev-env-tpa-box-linux.yml -t ing-certs --private-key=/root/.minikube/machines/minikube/id_rsa`
5. **Run this command to set the environment to access minikube** `eval $(minikube docker-env)`
6. **Configure secret**, in order for docker to pull the images it needs to know your credentials to the artifactory, this secret can be configured as follows:
`kubectl create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>`
7. **On the corporate network, run the Ansible script**, navigate to the home directory and run `./playbook.sh`


## Test the Box

First check if all the containers are up and running using `kubectl get pods`. All pods should have the **running** status and **1/1**, if a pod does not successfully start it will give an error here.

### Using the Box
If all pods are running you should be able to request access tokens from the running pods. This can easily be done by sending requests to the pods via postman. Load the following configuration in postman: 
`https://gitlab.ing.net/stormtroopers/tpa-in-a-box/test/postman_collection.json` Navigate to postman, import the configuration and choose one of the requests for bootstrap or meansldapotp.

**NOTE**:
* not all requests work as of the moment. We are still working on fixing the other requests.

If you successfully receive a token that means that the box is working properly, Congratulations! you now have a working TPA instance running on your local machine. How cool is that!


## Configuring the Box
### TPA Pods
It is now possible to configure which pods will be spawned. Before Running `./playbook.sh` edit `services` in [all.yml](../../ansible/group_vars/all.yml), comment or uncomment services
### Changing TPA Pods configuration
A number of TPA Pods can be configured check `configs` folder. After editing the configurations rerun `./playbook.sh` and kubernetes will automatically respawn the pods where changes was done.
### [Generate TLS Certs for local integration](../howto/create_tls_certs_for_your_own_service.md)
### [Making API Calls from local run to inside TIAB](../howto/tls_router.md)
### [Use own OnePam data response](use_own_onepam_test_data.md)
### [Register API endpoints in the API Gateway](../howto/register_api_endpoints_in_the_api_gateway.md)
### Other Configuration Request
We would love to hear your feedback, please let us know what you ran into while running this project.
### Using the Ansible Script `./playbook.sh`
Running the Ansible Script `./playbook.sh` will deploy the TPA in a Box resources to your local kubernetes/openshift.

Say, you reconfigured something and you want to redeploy the resources with a clean slate, just add the argument `reset` when running the script, i.e., run `./playbook.sh reset`. This will delete all exisiting TPA in a Box related resources on your local kubernetes/openshift before redeploying them.

## Use cases
Depending on what you want to do, TPA in a Box can support you in the following usecases:

* Develop a Local Means API to the TPA landscape
* Develop a Capability API that will consume an access token (uses the API SDK to digest an access token)
* Integration testing with TPA components done on local machine
* Integrate with web components that calls TPA APIs ( e.g. web components which call consent orchestration )
* Integrate with mobile components that calls TPA APIs
* Simulate or recreate issues, incidents and concerns (DEBUG).
* Prototyping and Proof of Concepts

#### Integration samples
Please see the integration samples [here](../integration_samples.md)

## Contact Us
* email: <ml-stormtroopers@ing.com>
* mattermost: [stormtroopers](https://mattermost.ing.net/signup_user_complete/?id=ktub38h4cpb8tbu5tffyaad8nr)
If you're really eager feel free to visit us in Manila :D

### We need you
![](../weneedyou.jpeg)

We've given you tpa in a box, now we ask you to use it and tell us what you think and what your use cases are such that we can improve our product :)

## Terms and Conditions

This is a first MVP and should be considered as such. It’s functionality is limited, there may be bugs and it is not suitable for sharing with external parties. 
If you have feedback (we love and welcome it!), or have feature requests, please use the links provided via [Contact us](#contact-us). 
Issues and bugs can be reported using the link on the left menu “Issues” 
If you fork, change code or implement it differently from the instructions, we will not be able to support you. 

We rather encourage you to contribute to the product, so if you like to participate in evolving and enriching the box, let us know!

## Roadmap
* Add more containerized TPA components to the project
* Provide a limited TPA in a Box which can be used by external parties
* Have example capability APIs to test on the box ( https://gitlab.ing.net/stormtroopers/Means   / ssh://git@gitlab.ing.net:2222/stormtroopers/Means.git )
