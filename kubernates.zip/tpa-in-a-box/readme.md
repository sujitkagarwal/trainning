# Touchpoint in a Box (TIAB)

* [Overview](#overview)
* [Prerequisites](#prerequisites)
* [Setup](#setup)
* [Login](#login)
* [How to check if TIAB is working](#check-tiab-status)
* [Pulling images within TIAB](#pull-image-within-tiab)
* [Use Cases](#use-cases)

## Overview

The Touchpoint-in-a-Box (TIAB) is a local machine sandbox for the Touchpoint Platform.
It runs Touchpoint components as containers on Openshift and packaged as a virtual machine.

Let us know if you are using TIAB by sending us a [message](mailto:ml-stormtroopers@ing.com?Subject=I%20am%20using%20TIAB&Body=greetings).
This will help us track users and reach out to them when there are updates.

We are always looking for suggestions and contributors, feel free to make a pull request or a suggestion if you need anything in the project.

## Prerequisites

Make sure you have the following installed/configured:

* [VirtualBox 6](https://www.virtualbox.org/wiki/Downloads)
* [Postman](https://go.pstmn.io/apps)
* SSH client, [PuTTY](https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html) for Windows
* SCP client

## Setup

### Import TIAB Image

1. Download the [virtual box image](https://artifactory.ing.net/artifactory/releases_mvn_stormtroopers/vm/tiab_okd_centos7_20190724_1_1_4.ova)
2. Import the image in VirtualBox by opening the virtual box image or by going to
   `VirtualBox -> File -> Import Appliance.. -> Select the downloaded file`
3. Run the Virtual Machine

We have already set up the necessary port forwarding rules to make TIAB easy to use and also set up SSH and SCP. Also, we have pre-loaded TIAB with docker images for some of the TPA components.

### <a name="alias-tiab-host"></a>Create Alias on Host Machine to easily refer to TIAB

**NOTE**: Editing the host file requires admin access.
Referring to `localhost` when sending requests to TIAB works but later on when we want to access the Openshift Web Console creating an alias will make it more convenient.

1. Locate the host file for your OS

   * Linux/Mac - `/etc/hosts`
   * Windows - `C:\Windows\System32\drivers\etc\hosts`

2. Set an alias to TIAB

   ``` text
       127.0.0.1       console.tiab.ing.net tiab.ing.net
   ```

3. To test if it works, try to ping the domain `ping console.tiab.ing.net`. It should give good responses.

## <a name="login"></a>Login to Openshift Cluster

### <a name="login-command-line"></a>Command line

There are two ways to go inside TIAB:

* Using the VirtualBox VM application
* Using SSH client, `ssh -p 30022 root@localhost`

Whichever option you choose to get inside TIAB

1. the username is `root` and the password: `password`
2. login to Openshift with `oc login https://console.tiab.ing.net:38443`,
   using the username: `root` and password: `password`
3. then switch project using `oc project touchpoint-in-a-box`

### <a name="login-web-console">Web Console

This part assumes setup of [host alias](#alias-tiab-host) was done

1. Go to [Openshift WebConsole](https://console.tiab.ing.net:38443) using your browser
2. Trust the certificate
3. Login using username: `root` with password: `password`

## <a name="check-tiab-status"></a>How to check if TIAB is working

### Command line

1. Execute `oc get pods`
2. This will show the currently running pods in TIAB along with its status. The Status should be *Running* and Ready should be N/N.

### Openshift Web Console

1. Follow the steps in [logging in to web console](#login-web-console) which takes you to the Openshift web console
2. After logging in, there will be two panes. The right pane, *My Projects*, shows the projects inside TIAB. Expand the selection by clicking on *View All* under the *Create Project*.
3. Then choose the `touchpoint-in-a-box` project. This will take you to the Overview page showing the currently available resources.
4. On the left pane, choose `Application -> Pods`. This will show the currently running pods in TIAB along with its status. The Status should be *Running* and Ready should be *N/N*.

## <a name="pull-image-within-tiab"></a>How to allow the cluster to pull images from Artifactory

This part assumes that you already did the [login](#login-command-line) steps for command line
In order for Openshift to pull any new docker images from our docker registry, it needs to know your credentials to the artifactory. Configure your secret using the command:

```text
    oc create secret docker-registry regsecret --docker-server=stormtroopers.docker.ing.net --docker-username=<CORPORATE KEY> --docker-password=<PASSWORD> --docker-email=<YOUR_EMAIL>
```

## Integrating with TIAB

* [Run service on host machine](docs/howto/test_your_own_service_against_tpa_in_a_box_from_outside.md)
* [Resolving host machine](docs/howto/updating_dnsmasq_configuration.md)

## Use Cases

After you have logged in and was able to access Openshift, you can do any of the use cases below:

* [Develop a sample authentication means service](docs/howto/develop_a_sample_authentication_means_service.md)
* [Develop a sample capability service](docs/howto/develop_a_sample_capability_service.md)
* Develop stubs or simulations
* Local testing of TPA components
* Education/Play around

## Other how to's

* [Use postman to test TIAB endpoints](docs/howto/send_postman_requests_to_test_tiab.md)
* [Toggle other TP services on/off](docs/howto/enabling_other_tp_services.md)
* [Use CCN in a box for local development](docs/howto/test_ccn_in_tiab.md)

## Terms of Usage

TIAB is designed to be a developer tool and not for production use.
TIAB runs on an OKD cluster. Running the script and TIAB on different versions of Openshift/Kubernetes is not within the scope of this project.

***
*Contact Us: <ml-stormtroopers@ing.com> / [Mattermost](https://mattermost.ing.net/stormtroopers/channels/town-square)*
