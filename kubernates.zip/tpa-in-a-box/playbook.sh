#!/usr/bin/env bash

ACTION="$(echo "$1" | tr [:upper:] [:lower:])"

CREATE_CERT_VALID_OPTIONS=("-n" "-hn" "-sn")

validate_create_cert_options() {
    if [[ !(($# -eq 1 && "$1" = "--help") || ($# -eq 6 && $(echo ${CREATE_CERT_VALID_OPTIONS[@]} | grep -e "$(echo $1)" -c) -eq 1 && $(echo ${CREATE_CERT_VALID_OPTIONS[@]} | grep -e "$(echo $3)" -c) -eq 1 && $(echo ${CREATE_CERT_VALID_OPTIONS[@]} | grep -e "$(echo $5)" -c) -eq 1)) ]];
        then
            echo "Invalid options! To see the full list of options supported, run './playbook.sh create-cert --help'"
            exit
    fi
}

process_create_cert_options() {

    validate_create_cert_options $@

    while [ -n "$1" ]; do
        case "$1" in
            -n)
                NAME="$2"
                echo "name: $NAME"
                ;;
            -hn)
                HOSTNAME="$2"
                echo "hostname: $HOSTNAME"
                ;;
            -sn)
                SERVICE_NAME="$2"
                echo "service name: $SERVICE_NAME"
                ;;
            --help)
                echo "Create TLS certificates for your Capability API or Means that you would like to test against Touchpoint-in-a-Box"
                echo ""
                echo "Usage: ./playbook.sh create-cert -n nameofyourservice -hn hostname -sn ServiceName"
                echo ""
                echo "Options:"
                echo "   -n: name of your service"
                echo "  -hn: host name for certificate names, the certificate subject, and certificate alias"
                echo "  -sn: service name for the certificate subject"
                echo "NOTE: All the options above are required"
                exit
                ;;
            *)
                echo "Invalid options! To see the full list of options supported for 'create-cert', run './playbook.sh create-cert --help'"
                exit
                ;;
        esac
        shift 2
    done
}

case $ACTION in
    create-ca)
        ansible-playbook --inventory localhost, --connection=local ansible/Touchpoint-in-a-box-create-ca.yml
        ;;
    create-cert)
        shift 1
        process_create_cert_options $@
        ansible-playbook --inventory localhost, --connection=local ansible/Touchpoint-in-a-box-create-client-certs-external-service.yml -e NAME=$NAME -e HOSTNAME=$HOSTNAME -e SERVICE_NAME=$SERVICE_NAME
        ;;
    start)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-build.yml
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-apply.yml
        ;;
    build)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-build.yml
        ;;
    run)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-apply.yml
        ;;
    stop)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-svc-stop.yml
        ;;
    restart)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-svc-start.yml
        ;;
    reset)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-clear.yml
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-build.yml
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-apply.yml
        ;;
    clean)
        shift 1
        ansible-playbook --inventory localhost, --connection=local $@ ansible/Touchpoint-in-a-box-clear.yml
        ;;
    *)
        echo "Usage: ./playbook.sh [COMMAND]"
        echo "Automation script to manage Touchpoint-in-a-Box."
        echo "Example: ./playbook.sh start"
        echo ""
        echo "[COMMAND]s for general operation:"
        echo "    start            performs the build command, and then the run command."
        echo "    build            generates Kubernetes/OpenShift YAMLs from templates."
        echo "    run              applies the configurations, secrets and generated YAML"
        echo "                     files to your local Kubernetes/OpenShift."
        echo "    stop             stops all services on your local Kubernetes/OpenShift."
        echo "    restart          restarts the default services of Touchpoint-in-a-Box" 
        echo "                     on your local Kubernetes/Openshift."
        echo "    reset            performs the clean, build, and then the run command."
        echo "    clean            removes the configurations, secrets and other"
        echo "                     TPA components from your local Kubernetes/OpenShift."
        echo ""
        echo "[COMMANDS]s related to certificates:"
        echo "    create-ca        creates new CA certificates for Touchpoint-in-a-Box."
        echo "    create-cert      creates client certificates for services originally" 
        echo "                     not in Touchpoint-in-a-Box."
        echo "                     run ./playbook.sh create-cert --help for more info."
        echo ""
        echo "Note that you can also pass any parameter that can be used by the Ansible "
        echo "script as options or parameter. Configure which services to run by default"
        echo "when using the restart command here: ansible/group_vars/servicelist.yml"
        echo ""
        echo "Report bugs to: ml-stormtroopers@ing.com"
        echo "Touchpoint home page: <https://touchpoint.ing.net>"
esac
