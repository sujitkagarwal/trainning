if [ "$SOURCE" = "azure" ]
then
    export AZURE_STORAGE_ACCOUNT=$AZURE_STORAGE_ACCOUNT
    export AZURE_STORAGE_KEY=$AZURE_STORAGE_KEY

    /azure-cli/bin/python -m azure.cli storage blob download -c $AZURE_CONTAINER -n $AZURE_FILENAME -f $AZURE_FILENAME
    tar -xvf $AZURE_FILENAME
fi

if [ "$SOURCE" = "artifactory" ]
then
    export ARTIFACTORY_TOKEN=$ARTIFACTORY_TOKEN

    curl -k -H "X-JFrog-Art-Api:$ARTIFACTORY_TOKEN" -O "https://artifactory.ing.net/artifactory/$ARTIFACTORY_PATH/$ARTIFACTORY_FILENAME"
    tar -xvf $ARTIFACTORY_FILENAME
fi

if [ "$SOURCE" = "artifactory_personal" ]
then
    export USERNAME=$USERNAME
    export ARTIFACTORY_TOKEN=$ARTIFACTORY_TOKEN

    curl -k "-u$USERNAME:$ARTIFACTORY_TOKEN" -O "https://artifactory.ing.net/artifactory/$ARTIFACTORY_PATH/$ARTIFACTORY_FILENAME"
    tar -xvf $ARTIFACTORY_FILENAME
fi