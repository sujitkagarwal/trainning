#!/bin/bash
FINGERPRINT=`keytool -v -list -keystore $1 -storepass $3 2>&1  | grep SHA1 | awk '{ print $2 }'`
sed -i'.bak' -e"s/FINGERPRINT/${FINGERPRINT}/g" $2