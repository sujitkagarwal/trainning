import hvac
import sys
from os import getenv, system

def get_vault_client(vault_url):
    return hvac.Client(url=vault_url, verify='vault-tls.crt')

def authenticate_vault(vault_client):
    params = {}

    role = getenv('VAULT_ROLE')

    if role is None:
        role = 'default'

    with open('/var/run/secrets/kubernetes.io/serviceaccount/token', 'r') as f:
        jwt = f.read()
        params = {
            'jwt': jwt,
            'role': role
        }

        vault_client.login('/v1/auth/kubernetes/login', json=params)

def create_file(filepath, file, content):
    binary = False
    binary_extensions = ['.jks', '.p12', '.cer']
    temppath = filepath + '/temp'
    fullpath = filepath + '/' + file

    for extension in binary_extensions:
        if extension in file:
            with open('/%s/%s' % (filepath, 'temp'), "w") as f:
                f.write('%s' % content)
                
            system('base64 -d ' + temppath + ' > ' + fullpath)
            binary = True
            break
    
    if not binary:
        with open("/%s/%s" % (filepath, file), "w") as f:
            f.write("%s" % content)

def get_kv(vault_client, path):
    return vault_client.read("%s" % path)


if __name__ == '__main__':
    vault_url = getenv('VAULT_URL')
    vault_client = get_vault_client(vault_url)
    authenticate_vault(vault_client)

    with open('default') as file:
        endpoints = file.readlines()
        
    default = [endpoint.strip() for endpoint in endpoints if endpoint.strip()]
    secrets = sys.argv[1:] + default

    filepath = getenv('FILEPATH')
    if filepath is None:
        filepath = '/certs'

    for secret in secrets:
        kv = get_kv(vault_client, 'kv/'+secret)

        for file in kv['data']:
            content = kv['data'][file]
            create_file(filepath, file, content)