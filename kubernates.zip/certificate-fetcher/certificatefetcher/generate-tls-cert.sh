#/bin/bash
if [ -z "$FILEPATH" ]
then
      FILEPATH='/certs'
fi

SVCJKSPASS="`jq -r .servicejkspassword $FILEPATH/jks.json`"

# generate key
openssl genrsa -out $FILEPATH/$CN.key 4096
# create csr
openssl req -new -key $FILEPATH/$CN.key -out $FILEPATH/$CN.csr -subj "/O=ING/OU=Services/OU=Kubernetes/OU=DEV/OU=$OU/CN=$CN*"
# sign CSR using Vault CA
openssl x509 -req -extfile /v3.ext -in $FILEPATH/$CN.csr -CA $FILEPATH/ca.crt -CAkey $FILEPATH/ca.key -CAcreateserial -out $FILEPATH/$CN.pem -days 1001 -sha256
# convert pem to p12
openssl pkcs12 -export -inkey $FILEPATH/$CN.key -in $FILEPATH/$CN.pem -out $FILEPATH/tls_certificate.p12 -passout pass:$SVCJKSPASS
# create jks
keytool -importkeystore -srckeystore $FILEPATH/tls_certificate.p12 -srcstoretype PKCS12 -deststoretype JKS -destkeystore $FILEPATH/$CN.jks  -deststorepass $SVCJKSPASS -srcstorepass $SVCJKSPASS
# change alias to service name
keytool -changealias -keystore $FILEPATH/$CN.jks -alias 1 -destalias $CN -storepass $SVCJKSPASS -noprompt
# convert ca to der
openssl x509 -in $FILEPATH/ca.crt -out $FILEPATH/ca.der -outform der
# create ca.jks
keytool -importcert -keystore $FILEPATH/ca.jks -alias ca -file $FILEPATH/ca.der -storepass $SVCJKSPASS -noprompt