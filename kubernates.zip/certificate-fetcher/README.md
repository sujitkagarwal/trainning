# Build certificate-fetcher image
Use the command below to build certificate-fetcher for local testing. 

Build arguments:
* image_name - target image name for your local build (e.g. open.docker.ing.net/dbnl/demo/certificate-fetcher:local)
* artifactory_token - NPA token used to fetch the certificate needed by certificate-fetcher to connect to vault
* artifactory_path - repository path in artifactory where the required certificate is located (e.g. releases_mvn_insurance/secrets/certs.tar.gz)

```text
    docker build -t <image_name> --build-arg artifactory_token=<artifactory_token> --build-arg artifactory_path=<artifactory_path> .
```