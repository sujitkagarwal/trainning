#!/bin/bash

parse_input()
{
    for RGB in $@; do
        if [[ ! $RGB =~ ^[0-9]+$ ]]; then
            echo "WARN: can't process '$RGB'. please enter numbers only"
        else
            RGBs+=($RGB)
        fi
    done

    if [[ ${#RGBs[@]} -lt 1 ]]; then
        echo
        echo "No RGB to process. Exiting"
        exit 0
    fi

    echo
    echo "Will use the following RGB(s): "
    for i in "${RGBs[@]}"; do echo "$i"; done
    echo
}

build_arrangementbyuuid_csv()
{
    filename_1_lines=("uuid,recordtype,roletypecode,rolestarted,keytypecode,rolepartyid,category,categorycode,currency,currencycode,currencyisocode,ended,executes,ingentity,keyid,keytype,keyupdateddate,logicaldatadomain,name,nickname,productsource,producttype,producttypecode,recordupdated,roleended,rolepartytype,rolepartytypecode,roletype,roleupdateddate,status,statuscode,updateddate")

    for RGB_NL in "${RGBs[@]}"; do
        filename_1_lines+=("b58e-$RGB_NL,1,0,1969-12-31 23:00:00.000+0000,0,0,Betalen,1,Euro,7,EUR,,2012-03-17 23:00:00.000+0000,,,,,,Hr J Jansen,Jan,ps,Betaalrekening,21,,,,,,,Lopend,1,")
        filename_1_lines+=("b58e-$RGB_NL,2,11,2014-11-05 23:00:00.000+0000,0,$RGB_NL,,,,,,,,,,,,,,,,,,,,Individual,1,Houder,2014-12-04 08:28:38.000+0000,,,")
        filename_1_lines+=("b58e-$RGB_NL,3,0,2016-03-17 23:00:00.000+0000,4,0,,,,,,,,,NL$RGB_NL,IBAN,2016-02-04 08:28:38.000+0000,,,,,,,,,,,,,,,")
    done

    rm -f $filename_1
    for i in "${filename_1_lines[@]}"; do echo $i >> $filename_1; done
}

build_arrangementuuidbypartyid_csv()
{
    filename_2_lines=("partyid,uuid,partyidtypecode")

    for RGB_NL in "${RGBs[@]}"; do
        filename_2_lines+=("$RGB_NL,b58e-$RGB_NL,")
    done

    rm -f $filename_2
    for i in "${filename_2_lines[@]}"; do echo $i >> $filename_2; done
}

main ()
{
    if [[ $# -lt 1 ]]; then
        RGB_NL="123456789"
        parse_input $RGB_NL
    elif [[ ! $1 =~ ^[0-9]+ ]]; then
        echo "please enter numbers only"
        exit 2
    else
        parse_input $@
    fi


    CASSANDRA_POD=`kubectl get pods -l app=cassandra | awk 'NR>1{print $1}'`

    filename_1=".arrangementbyuuid.csv"
    build_arrangementbyuuid_csv RGBs

    filename_2=".arrangementuuidbypartyid.csv"
    build_arrangementuuidbypartyid_csv RGBs

    cql_command="COPY party.arrangementbyuuid FROM '/$filename_1' with header=true; \
    COPY party.arrangementuuidbypartyid FROM '/$filename_2' with header=true;"

    kube_commands=''
    kube_commands+=("kubectl cp $filename_1 $CASSANDRA_POD:/")
    kube_commands+=("kubectl cp $filename_2 $CASSANDRA_POD:/")
    kube_commands+=("kubectl exec $CASSANDRA_POD -- cqlsh -e \"$cql_command\"")
    kube_commands+=("kubectl exec $CASSANDRA_POD rm $filename_1")
    kube_commands+=("kubectl exec $CASSANDRA_POD rm $filename_2")
    kube_commands+=("rm $filename_1")
    kube_commands+=("rm $filename_2")

    for i in "${kube_commands[@]}"; do eval $i; done
}

main $@
