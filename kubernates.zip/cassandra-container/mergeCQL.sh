#!/usr/bin/env bash
cat ./CQL/*.cql >> merged.cql