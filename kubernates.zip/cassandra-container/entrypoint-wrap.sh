#!/bin/bash
until cqlsh -e 'use party;' ; do
  echo "cqlsh: Cassandra is unavailable - retrying after 5 seconds"
  sleep 5
  if cqlsh -e 'describe keyspaces'; then
    cqlsh -f /merged.cql
    touch /tmp/startup_done
  fi
done &

exec /docker-entrypoint.sh "$@"