This container builds up on TIAB image of cassandra and adds a new keyspace and test data

How to use shell script to insert data:
1. Execute script with RGB numbers as arguments e.g.
	./insert_rgb_to_cassandra.sh <RGB_1> <RGB_2> ... <RGB_n>

Note: Script only allows numbers for RGB numbers. It will not process the input with other characters. Just change the condition in the script to allow other characters
