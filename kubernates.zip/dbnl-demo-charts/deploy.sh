for files in dependencies/*
do
    echo -e "\n*** Deploying resources in ${files} ***\n"
    kubectl apply -f "${files}"
done

echo -e "\n*** Restarting microservices with dependencies ***\n"
kubectl delete pod -l app=authenticationorchestration
kubectl delete pod -l app=apigateway

sleep 3

for files in deployments/*
do
    echo -e "\n*** Deploying resources in ${files} ***\n"
    kubectl apply -f "${files}"
done
