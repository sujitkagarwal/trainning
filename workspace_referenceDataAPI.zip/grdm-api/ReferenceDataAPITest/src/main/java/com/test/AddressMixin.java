package com.test;

/**
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 12-1-2018
 */

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
public abstract class AddressMixin {
    @JsonCreator
    public AddressMixin(
            @JsonProperty("city") String city,
            @JsonProperty("state") String state) {
        System.out.println("Wont be called");
    }
}