package com.test;

/**
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 12-1-2018
 */
public class Address {
    private String city;
    private String state;
    public Address(String city, String state) {
        this.city = city;
        this.state = state;;
    }
    @Override
    public String toString() {
        return "Address [city=" + city + ", state=" + state +  "]";
    }
}