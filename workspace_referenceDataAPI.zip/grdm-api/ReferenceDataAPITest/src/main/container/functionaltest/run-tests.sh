#!/bin/bash

echo "application=$APPLICATION"
echo "version=$VERSION"
echo "environment=$ENVIRONMENT"
echo "password=$PASSWORD"
echo "buildnumber=$BUILDNUMBER"

sleep 60

java -Dtest.environment=$ENVIRONMENT -jar reference-data-api-web-test-jar-with-dependencies.jar -g com.ing.grdm.cucumber.regression -g com.ing.grdm.cucumber.steps -p json:output/cucumber-result.json classpath:features

java -jar reference-data-api-test-test-jar-with-dependencies.jar $APPLICATION $BUILDNUMBER $VERSION $ENVIRONMENT output/cucumber-result.json

tar -C output/cucumber-html-reports -cvf reference-data-api-test-report.tar .

. ./output/results.txt

echo "total=$total"
echo "passed=$passed"
echo "failed=$failed"

curl -X PUT -T 'reference-data-api-test-report.tar' "http://itested.europe.intranet:8888/put/functionaltest/testresults/stdout/tar/$APPLICATION/$VERSION/$ENVIRONMENT/$total/$passed/$failed/0?overwrite=true"