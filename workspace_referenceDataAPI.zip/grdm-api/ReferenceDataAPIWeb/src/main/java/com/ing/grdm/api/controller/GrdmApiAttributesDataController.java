package com.ing.grdm.api.controller;

import com.ing.grdm.api.response.AttributesResponseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Reference data controller for Attributes
 */
@RestController
public class GrdmApiAttributesDataController {

	@Autowired
	private AttributesResponseService responseService;

	/**
	 * This method retrieves table data for the given table name with only business keys or chosen input columns along with business key
	 *
	 * @param distributionName This is the table distribution name for which reference data is fetched
	 * @param columns          The list of optional column distribution names
	 * @param response         This is used to provide HTTP-specific functionality while sending a response
	 * @throws IOException when failing to obtain the writer or write serialized data to it
	 */
	@RequestMapping(value = "/attributes/{tableName}", method = RequestMethod.GET)
	public void attributesByTableName(@PathVariable("tableName") String distributionName,
									  @RequestParam(value = "column", required = false) final List<String> columns,
									  HttpServletResponse response) throws IOException {
		this.responseService.respondAttributesByTableName(distributionName, columns, response);
	}

	/**
	 * This method retrieves tha table row corresponding to the given businessKey with either given input columns or all columns
	 *
	 * @param distributionName This is the table distribution name for which reference data is fetched
	 * @param businessKey      This is the businessKey of the table
	 * @param columns          The list of optional column distribution names
	 * @param response         This is used to provide HTTP-specific functionality while sending a response
	 * @throws IOException when failing to obtain the writer or write serialized data to it
	 */
	@RequestMapping(value = "/attributes/{tableName}/{businessKey}", method = RequestMethod.GET)
	public void attributesByTableNameAndBusinessKey(@PathVariable("tableName") String distributionName,
													@PathVariable("businessKey") String businessKey,
													@RequestParam(value = "column", required = false) final List<String> columns,
													HttpServletResponse response) throws IOException {
		this.responseService.respondAttributesByTableNameAndBusinessKey(distributionName, businessKey, columns, response);
	}
}