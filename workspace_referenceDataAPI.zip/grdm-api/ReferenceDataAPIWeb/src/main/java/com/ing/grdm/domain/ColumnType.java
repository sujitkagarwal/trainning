package com.ing.grdm.domain;

import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_CDS_USER;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_DATE;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_DOMAIN;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_HIERARCHY;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_MODEL_PARAMETER;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_MODEL_REFERENCE;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_MULTI_REFERENCE_ROW;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_MULTI_REFERENCE_TABLE;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_NUMBER;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_PARAMETER;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_PERCENTAGE;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_PORTAL_USER;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_RANGE_MAX;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_RANGE_MIN;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_REFERENCE;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_STATUS;
import static com.ing.itrf.sdm.common.beans.structure.ColumnDefinition.COLUMN_DEFINITION_TYPE_STRING;

/**
 * Column types as defined in SDM.
 */
public enum ColumnType {

	STRING(COLUMN_DEFINITION_TYPE_STRING, "string"),
	NUMBER(COLUMN_DEFINITION_TYPE_NUMBER, "number"),
	DATE(COLUMN_DEFINITION_TYPE_DATE, "date"),
	REFERENCE(COLUMN_DEFINITION_TYPE_REFERENCE, "reference"),
	DOMAIN(COLUMN_DEFINITION_TYPE_DOMAIN, "domain"),
	HIERARCHY(COLUMN_DEFINITION_TYPE_HIERARCHY, "hierarchy"),
	MULTI_REFERENCE_TABLE(COLUMN_DEFINITION_TYPE_MULTI_REFERENCE_TABLE, "multireferencetable"),
	MULTI_REFERENCE_ROW(COLUMN_DEFINITION_TYPE_MULTI_REFERENCE_ROW, "multireferencerow"),
	STATUS(COLUMN_DEFINITION_TYPE_STATUS, "status"),
	PERCENTAGE(COLUMN_DEFINITION_TYPE_PERCENTAGE, "percentage"),
	PARAMETER(COLUMN_DEFINITION_TYPE_PARAMETER, "parameter"),
	MODEL_REFERENCE(COLUMN_DEFINITION_TYPE_MODEL_REFERENCE, "modelreference"),
	MODEL_PARAMETER(COLUMN_DEFINITION_TYPE_MODEL_PARAMETER, "modelparameter"),
	RANGE_MIN(COLUMN_DEFINITION_TYPE_RANGE_MIN, "rangefrom"),
	RANGE_MAX(COLUMN_DEFINITION_TYPE_RANGE_MAX, "rangeuntil"),
	CDS_USER(COLUMN_DEFINITION_TYPE_CDS_USER, "cdsuser"),
	PORTAL_USER(COLUMN_DEFINITION_TYPE_PORTAL_USER, "uamuser");

	private int columnTypeId;
	private String xmlColumnType;

	ColumnType(int columnTypeId, String xmlColumnType) {
		this.columnTypeId = columnTypeId;
		this.xmlColumnType = xmlColumnType;
	}

	public int getColumnTypeId() {
		return columnTypeId;
	}

	public String getXmlColumnType() {
		return xmlColumnType;
	}

	/**
	 * Return the enum constant by column type id.
	 *
	 * @param id the id of the column definition as known in SDM
	 * @return the column type with given id
	 * @throws IllegalArgumentException if there is no such column type
	 */
	public static ColumnType byId(int id) {
		for (ColumnType value : ColumnType.values()) {
			if (value.columnTypeId == id) {
				return value;
			}
		}
		throw new IllegalArgumentException("No enum constant found for id " + id);
	}

	/**
	 * Return the enum constant by XML column name
	 *
	 * @param name the name of the column as known in an SDM xml distribution file
	 * @return the column type with given name
	 * @throws IllegalArgumentException if there is no such column type
	 */
	public static ColumnType byXmlName(String name) {
		for (ColumnType value : ColumnType.values()) {
			if (value.xmlColumnType.equals(name)) {
				return value;
			}
		}
		throw new IllegalArgumentException("No enum constant found for name " + name);
	}
}

