package com.ing.grdm.database.custom.impl;

import com.ing.grdm.database.GrdmJobRepository;
import com.ing.grdm.database.custom.GrdmJobCustomRepository;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Custom operations on GRDM_Job table.
 */
public class GrdmJobRepositoryImpl implements GrdmJobCustomRepository {

	@Autowired
	private GrdmJobRepository repository;

	@Override
	public boolean shouldJobRun(Class<?> jobType, String hostname, int failOverTimeout) {
		return this.repository.updateJob(jobType.getName(), hostname, failOverTimeout) > 0;
	}
}
