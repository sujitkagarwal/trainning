package com.ing.grdm.api.metrics;

import com.codahale.metrics.Gauge;
import com.codahale.metrics.MetricRegistry;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Profile;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.management.JMException;
import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.openmbean.CompositeDataSupport;
import java.lang.management.ManagementFactory;
import java.nio.file.Paths;
import java.util.Arrays;

/**
 * This class initializes ThreadPool and Memory metrics from this server to be sent to Graphite
 */
@Component
@ConditionalOnProperty("grdm.metrics.enabled")
@Profile("default")
public class GrdmApiMonitor {

	private static final Log LOG = LogFactory.getLog(GrdmApiMonitor.class);

	@Autowired
	private MetricRegistry metricRegistry;

	@Value("${grdm.metrics.graphite.prefix.hosts}")
	private String prefix;

	@Value("${grdm.metrics.threadpool.attributes}")
	private String[] threadPoolAttributes;

	@Value("${grdm.metrics.memory.attributes}")
	private String[] memoryAttributes;

	@Value("${grdm.metrics.memory.composite_attributes}")
	private String[] compositeMemoryAttributes;

	@Value("${grdm.metrics.operatingsystem.attributes}")
	private String[] operatingSystemAttributes;

	private MBeanServer beanServer;

	@EventListener
	@SuppressWarnings("unused")
	void init(ApplicationReadyEvent event) throws JMException {
		this.beanServer = ManagementFactory.getPlatformMBeanServer();
		final ObjectName engine =
				this.beanServer.queryNames(new ObjectName("*:type=Engine"), null).iterator().next();
		final String instanceName =
				Paths.get(this.beanServer.getAttribute(engine, "baseDir").toString()).getFileName().toString();
		final String engineName = this.beanServer.getAttribute(engine, "name").toString();

		// Initialize ThreadPool metrics
		final ObjectName threadPool =
				this.beanServer.queryNames(new ObjectName(engineName + ":type=ThreadPool,name=*"), null).iterator().next();
		Arrays.stream(this.threadPoolAttributes)
				.forEach(attribute -> registerThreadPoolMetric(threadPool, instanceName, attribute));

		// Initialize Memory metrics
		final ObjectName memory =
				this.beanServer.queryNames(new ObjectName("java.lang:type=Memory"), null).iterator().next();
		Arrays.stream(this.memoryAttributes)
				.forEach(attribute -> registerMemoryMetrics(memory, instanceName, attribute));

		// Initialize OperatingSystem metrics
		final ObjectName operatingSystem =
				this.beanServer.queryNames(new ObjectName("java.lang:type=OperatingSystem"), null).iterator().next();
		Arrays.stream(this.operatingSystemAttributes)
				.forEach(attribute -> registerOperatingSystemMetrics(operatingSystem, instanceName, attribute));
	}

	private void registerThreadPoolMetric(ObjectName threadPool, String instanceName, String attribute) {
		this.metricRegistry.register(MetricRegistry.name(this.prefix, instanceName, "ThreadPool", attribute),
				(Gauge<Integer>) () -> {
					try {
						return (Integer) this.beanServer.getAttribute(threadPool, attribute);
					} catch (JMException jme) {
						LOG.warn(String.format("Failed to retrieve ThreadPool attribute %s", attribute));
						throw new RuntimeException(jme);
					}
				});
	}

	private void registerMemoryMetrics(ObjectName memory, String instanceName, String attribute) {
		Arrays.stream(this.compositeMemoryAttributes)
				.forEach(compositeAttribute -> registerMemoryMetric(memory, instanceName, attribute, compositeAttribute));
	}

	private void registerMemoryMetric(ObjectName memory, String instanceName, String attribute, String compositeAttribute) {
		this.metricRegistry.register(
				MetricRegistry.name(this.prefix, instanceName, "Memory", attribute, compositeAttribute),
				(Gauge<Long>) () -> {
					try {
						final CompositeDataSupport memoryUsage =
								(CompositeDataSupport) this.beanServer.getAttribute(memory, attribute);
						return (Long) memoryUsage.get(compositeAttribute);
					} catch (JMException jme) {
						LOG.warn(String.format("Failed to retrieve Memory attribute %s.%s", attribute, compositeAttribute));
						throw new RuntimeException(jme);
					}
				});
	}

	private void registerOperatingSystemMetrics(ObjectName operatingSystem, String instanceName, String attribute) {
		this.metricRegistry.register(MetricRegistry.name(this.prefix, instanceName, "OperatingSystem", attribute),
				(Gauge<Number>) () -> {
					try {
						return (Number) this.beanServer.getAttribute(operatingSystem, attribute);
					} catch (JMException jme) {
						LOG.warn(String.format("Failed to retrieve OperatingSystem attribute %s", attribute));
						throw new RuntimeException(jme);
					}
				});
	}

}
