package com.ing.grdm.database.custom.impl;

import com.ing.grdm.database.custom.GrdmApiDataValueBatchRepository;
import com.ing.grdm.domain.ApiDataValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Implementation of {@link GrdmApiDataValueBatchRepository}
 */
public class GrdmApiDataValueRepositoryImpl implements GrdmApiDataValueBatchRepository {

	@Autowired
	private EntityManager entityManager;

	@Value("${spring.jpa.properties.hibernate.jdbc.batch_size}")
	private int batchSize;

	@Override
	public Collection<ApiDataValue> bulkInsert(Collection<ApiDataValue> dataValues) {
		final List<ApiDataValue> savedEntities = new ArrayList<>(dataValues.size());
		int count = 0;
		for (ApiDataValue dataValue : dataValues) {
			this.entityManager.persist(dataValue);
			savedEntities.add(dataValue);

			if (++count % batchSize == 0) {
				this.entityManager.flush();
				this.entityManager.clear();
			}
		}
		return savedEntities;
	}

}
