package com.ing.grdm.api.cache.search;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * Spring configuration for Search Cache
 */
@Configuration
@ComponentScan(basePackages = "com.ing.grdm.api.cache.search")
public class SearchCacheConfig {

	@Bean(name = "cacheDirectory")
	@Scope(BeanDefinition.SCOPE_PROTOTYPE)
	Directory tableCacheDirectory() {
		return new RAMDirectory();
	}

	@Bean(name = "taxonomyDirectory")
	@Scope(BeanDefinition.SCOPE_PROTOTYPE)
	Directory tableTaxonomyDirectory() {
		return new RAMDirectory();
	}

}
