/*
 * Copyright (c) 2017 ING Group. All rights reserved.
 * 
 * This software is the confidential and proprietary information of ING Group ("Confidential Information").
 */
package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represents the column tag in the SDM distribution
 */
@XStreamAlias("column")
@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "value" })
public class SdmColumn {

	@XStreamAlias("name")
	@XStreamAsAttribute
	private String name;

	private String value;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
