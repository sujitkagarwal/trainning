package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

/**
 * Serializer class for mappings data response
 */
@Component
public class MappingsDataSerializer {

	@Autowired
	private JsonFactory jsonFactory;

	void serializeGlobalCode(Writer writer, String distributionName, String globalCode) throws IOException {
		try (JsonGenerator generator = this.jsonFactory.createGenerator(writer)) {
			generator.writeStartObject();
			generator.writeStringField("code", globalCode);
			generator.writeFieldName("links");
			generator.writeStartArray();
			generator.writeStartObject();
			generator.writeStringField("rel", "attributes");
			generator.writeStringField("href",
					new StringJoiner("/", "/", "")
							.add("attributes")
							.add(distributionName.toLowerCase())
							.add(globalCode).toString());
			generator.writeEndObject();
			generator.writeEndArray();
			generator.writeEndObject();
			generator.flush();
		}
	}

	void serializeGlobalMappings(Writer writer, Map<String, String> mappings) throws IOException {
		try (JsonGenerator generator = this.jsonFactory.createGenerator(writer)) {
			generator.writeStartObject();
			generator.writeFieldName("data");
			generator.writeStartArray();
			for (Map.Entry<String, String> entry : mappings.entrySet()) {
				generator.writeStartObject();
				generator.writeStringField("local", entry.getKey());
				generator.writeStringField("global", entry.getValue());
				generator.writeEndObject();
			}
			generator.writeEndArray();
			generator.writeEndObject();
			generator.flush();
		}
	}

	void serializeLocalCodes(Writer writer, List<String> localCodes) throws IOException {
		try (JsonGenerator generator = this.jsonFactory.createGenerator(writer)) {
			generator.writeStartObject();
			generator.writeFieldName("data");
			serializeLocalCodeArray(generator, localCodes);
			generator.writeEndObject();
			generator.flush();
		}
	}

	void serializeLocalMappings(Writer writer, Map<String, List<String>> mappings) throws IOException {
		try (JsonGenerator generator = this.jsonFactory.createGenerator(writer)) {
			generator.writeStartObject();
			generator.writeFieldName("data");
			generator.writeStartArray();
			for (Map.Entry<String, List<String>> entry : mappings.entrySet()) {
				generator.writeStartObject();
				generator.writeStringField("global", entry.getKey());
				generator.writeFieldName("local");
				serializeLocalCodeArray(generator, entry.getValue());
				generator.writeEndObject();
			}
			generator.writeEndArray();
			generator.writeEndObject();
			generator.flush();
		}
	}

	private void serializeLocalCodeArray(JsonGenerator generator, List<String> localCodes) throws IOException {
		generator.writeStartArray();
		for (String code : localCodes) {
			generator.writeString(code);
		}
		generator.writeEndArray();

	}
}
