package com.ing.grdm.api.security.authentication.provider;

import com.ing.api.security.trust.TrustException;
import com.ing.api.security.trust.token.peer.PeerToken;
import com.ing.api.security.trust.token.peer.PeerTokenParser;
import com.ing.grdm.api.cache.WhiteListCache;
import com.ing.grdm.api.constant.GrdmConstants;
import com.ing.grdm.api.security.authentication.exception.GrdmAuthenticationException;
import com.ing.grdm.api.security.authentication.model.JWTToken;
import com.ing.grdm.api.security.config.GrdmPeerTokenWebSecurityConfig;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * This is GrdmPeerTokenAuthenticationProvider which used to validate the peer token.
 * This AuthenticationProvider has the following responsibilities:
 * <ol>
 * <li> if peer token is not null then Verify the Peer token's signature  with below listed points otherwise check for whitelisting and return result</li>
 * <li> Using the  trust token api to parse the peer token.</li>
 * <li> If Peer token is unable to parse then invalid Peer token is thrown</li>
 * <li> It also checks the endpoint is authorized for access </li>
 * <li> It also checks the endpoint is authorized for access </li>
 * </ol>
 * {@link GrdmPeerTokenWebSecurityConfig}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
@ConditionalOnExpression("${grdm.api.security.enabled:true}")
@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
@Component
public class GrdmPeerTokenAuthenticationProvider implements AuthenticationProvider {
	private static final Log LOG = LogFactory.getLog(GrdmPeerTokenAuthenticationProvider.class);
	private final Pattern subjectDnPattern = Pattern.compile("CN=(.*?)(?:,|$)", Pattern.CASE_INSENSITIVE);

	@Autowired
	private PeerTokenParser peerTokenParser;

	@Autowired
	private WhiteListCache whiteListCache;

	/**
	 * This is invoked from GrdmAuthenticationTokenFilter  to valid the token .
	 *
	 * @param authentication This is the http response object
	 * @throws AuthenticationException on invalid token
	 * @throws AuthenticationException invalid token or empty throw GrdmAuthenticationException
	 * @see AuthenticationException
	 * @see GrdmAuthenticationException
	 */
	@Override
	public Authentication authenticate(Authentication authentication)
			throws AuthenticationException {
		final JWTToken jwtToken = (JWTToken) authentication;
		if (jwtToken.getCertificate() != null) {
			//if peer token is null then go for whitelisting approach
			if (jwtToken.getToken() != null) {
				try {
					PeerToken peerToken = this.peerTokenParser.parsePeerToken(jwtToken.getToken(), jwtToken.getCertificate());
					JWTToken jwtToken1 = new JWTToken(jwtToken.getToken(), jwtToken.getCertificate(), peerToken.getClaimsSet().getEndpoints());
					jwtToken1.setAuthenticated(true);
					return jwtToken1;
				} catch (TrustException exceptionMessage) {
					throw new GrdmAuthenticationException("Invalid Peer Token");
				}
			} else {
				//this is custom code to check whitelist due to business requirement
				checkWhiteList(jwtToken);
				authentication.setAuthenticated(true);
				return authentication;
			}
		} else {
			throw new GrdmAuthenticationException(GrdmConstants.UNAUTHORIZED);
		}
	}

	private void checkWhiteList(JWTToken jwtToken) throws GrdmAuthenticationException {
		String subjectDN = jwtToken.getCertificate().getSubjectDN().getName();
		Matcher matcher = this.subjectDnPattern.matcher(subjectDN);
		if (matcher.find() && matcher.groupCount() == 1) {
			String username = matcher.group(1);
			if (LOG.isDebugEnabled()) {
				LOG.debug(String.format("Extracted Principal name is '%s'", username));
			}
			if (!whiteListCache.contains(username)) {
				throw new GrdmAuthenticationException(GrdmConstants.UNAUTHORIZED);
			}
		} else {
			throw new GrdmAuthenticationException(GrdmConstants.UNAUTHORIZED);
		}
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return (JWTToken.class.isAssignableFrom(authentication));
	}
}
