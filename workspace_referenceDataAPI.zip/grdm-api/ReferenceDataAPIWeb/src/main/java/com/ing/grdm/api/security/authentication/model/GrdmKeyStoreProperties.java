package com.ing.grdm.api.security.authentication.model;

import com.ing.api.security.trust.token.access.AccessTokenProperties;
import com.ing.api.security.trust.token.peer.PeerTokenProperties;
import com.ing.api.security.trust.util.KeyStoreType;

import javax.annotation.Nullable;

/**
 * GRDM's implementation of access and peer token properties. The implemenation provided by api-trust only supports
 * providing a location to a particular properties file containing a absolute path to the location of the key store.
 * This absolute path cannot contain the placeholder PROPERTIES_DIR or any other placeholder.
 */
public class GrdmKeyStoreProperties implements AccessTokenProperties, PeerTokenProperties {

	private String keyStoreLocation;
	private String keyStorePassword;
	private String signatureKeyCertificateFingerprint;
	private String signatureKeyPassword;

	@Override
	public String getKeyStoreType() {
		return KeyStoreType.JKS.asString();
	}

	@Override
	public String getKeyStoreLocation() {
		return this.keyStoreLocation;
	}

	@Override
	public String getKeyStorePassword() {
		return this.keyStorePassword;
	}

	@Override
	public String getSignatureKeyCertificateFingerprint() {
		return this.signatureKeyCertificateFingerprint;
	}

	@Override
	public String getSignatureKeyPassword() {
		return this.signatureKeyPassword;
	}

	@Nullable
	@Override
	public String getSecurityProvider() {
		return null;
	}

	public void setKeyStoreLocation(String keyStoreLocation) {
		this.keyStoreLocation = keyStoreLocation;
	}

	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}

	public void setSignatureKeyCertificateFingerprint(String signatureKeyCertificateFingerprint) {
		this.signatureKeyCertificateFingerprint = signatureKeyCertificateFingerprint;
	}

	public void setSignatureKeyPassword(String signatureKeyPassword) {
		this.signatureKeyPassword = signatureKeyPassword;
	}
}
