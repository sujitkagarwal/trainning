package com.ing.grdm.api.cache.search;

import com.ing.grdm.domain.ApiDataValue;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetQuery;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.BoostQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.TermQuery;
import org.springframework.stereotype.Component;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The value cache
 */
@Component
public class ValueCache extends AbstractCache {
	@Override
	protected List<String> getFacets() {
		return Arrays.asList(TABLE_DISTRO_NAME, BUSINESS_KEY, COLUMN_DISTRO_NAME);
	}

	public void addDocument(ApiDataValue dataValue, String distributionName) {
		final Document document = new Document();

		switch (dataValue.getColumnType()) {
			case NUMBER:
			case PERCENTAGE:
				document.add(new StoredField("value", Double.parseDouble(dataValue.getStorageString())));
				document.add(new TextField("_value", dataValue.getStorageString(), Field.Store.NO));
				break;
			default:
				document.add(new StringField("value", dataValue.getStorageString(), Field.Store.YES));
				document.add(new TextField("_value", dataValue.getStorageString(), Field.Store.NO));
		}

		document.add(new StoredField(TABLE_DISTRO_NAME, distributionName));
		document.add(new StoredField(BUSINESS_KEY, dataValue.getBusinessKey()));
		document.add(new StoredField(COLUMN_DISTRO_NAME, dataValue.getColumnName().toLowerCase()));

		document.add(new FacetField(TABLE_DISTRO_NAME, distributionName));
		document.add(new FacetField(BUSINESS_KEY, dataValue.getBusinessKey().toLowerCase().split("\\|")));
		document.add(new FacetField(COLUMN_DISTRO_NAME, dataValue.getColumnName().toLowerCase()));

		addDocument(document);
	}

	public void deleteDocument(String tableName, String columnName, String businessKey) {
		final BooleanQuery query = new BooleanQuery.Builder()
				.add(new FacetQuery(TABLE_DISTRO_NAME, tableName.toLowerCase()), Occur.MUST)
				.add(new FacetQuery(COLUMN_DISTRO_NAME, columnName.toLowerCase()), Occur.MUST)
				.add(new FacetQuery(BUSINESS_KEY, businessKey.toLowerCase().split("\\|")), Occur.MUST)
				.build();

		deleteDocument(query);
	}

	public List<Map<String, Object>> search(String searchString, String distributionName, String columnName, String businessKey) {

		final FuzzyQuery fuzzyQuery = new FuzzyQuery(new Term("_value", searchString.toLowerCase()));
		final TermQuery termQuery = new TermQuery(new Term("value", searchString));

		final BooleanQuery inner = new BooleanQuery.Builder()
				.add(new BoostQuery(termQuery, 2.0f), Occur.SHOULD)
				.add(fuzzyQuery, Occur.SHOULD)
				.build();

		if (distributionName == null && columnName == null && businessKey == null) {
			return search(inner);
		}

		final BooleanQuery.Builder builder = new BooleanQuery.Builder();
		builder.add(inner, Occur.MUST);

		if (distributionName != null) {
			builder.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName.toLowerCase()), Occur.MUST);
		}
		if (columnName != null) {
			builder.add(new FacetQuery(COLUMN_DISTRO_NAME, columnName.toLowerCase()), Occur.MUST);
		}
		if (businessKey != null) {
			builder.add(new FacetQuery(BUSINESS_KEY, businessKey.toLowerCase().split("\\|")), Occur.MUST);
		}

		return search(builder.build());
	}

	@Override
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.singletonList(Stream.of(
				new SimpleEntry<String, Object>("rel", "self"),
				new SimpleEntry<String, Object>("href", new StringJoiner("/", "/", "")
						.add("attributes")
						.add(document.get(TABLE_DISTRO_NAME))
						.add(document.get(BUSINESS_KEY)).toString())
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
	}
}
