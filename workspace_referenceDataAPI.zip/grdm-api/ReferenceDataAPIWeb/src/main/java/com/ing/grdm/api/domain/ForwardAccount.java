package com.ing.grdm.api.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.io.Serializable;
import java.time.LocalDate;

import static com.ing.grdm.api.constant.GrdmConstants.DATE_FORMAT;


/**
 * ForwardAccount POJO class.
 */

@XmlRootElement
@XmlType(propOrder = {"accountId", "forwardAccountId", "forwardAccountBIC", "startDate",
		"expirationDate"})
@XmlAccessorType(XmlAccessType.FIELD)
public class ForwardAccount implements Serializable {

	private static final long serialVersionUID = 258490342076647508L;

	private String accountId = null;

	private String forwardAccountId = null;

	private String forwardAccountBIC = null;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT)
	@XmlElement(name = "startDate")
	@XmlJavaTypeAdapter(value = DateFormatAdapter.class)
	private LocalDate startDate = null;

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT)
	@XmlElement(name = "expirationDate")
	@XmlJavaTypeAdapter(value = DateFormatAdapter.class)
	private LocalDate expirationDate = null;

	public ForwardAccount() {
	}

	public ForwardAccount(String accountId, LocalDate startDate, String forwardAccountId,
						  String forwardAccountBIC, LocalDate expirationDate) {
		this.accountId = accountId;
		this.startDate = startDate;
		this.forwardAccountId = forwardAccountId;
		this.forwardAccountBIC = forwardAccountBIC;
		this.expirationDate = expirationDate;

	}

	public String getAccountId() {
		return accountId;
	}

	public String getForwardAccountId() {
		return forwardAccountId;
	}

	public String getForwardAccountBIC() {
		return forwardAccountBIC;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public LocalDate getExpirationDate() {
		return expirationDate;
	}
}

