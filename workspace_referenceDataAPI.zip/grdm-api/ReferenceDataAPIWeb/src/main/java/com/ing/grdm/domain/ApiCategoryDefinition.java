package com.ing.grdm.domain;

import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * Represents a record in the GRDM_API_CATEGORY_DEFINITION table
 */
@Entity
@Table(name = "GRDM_API_CATEGORY_DEFINITION",
		uniqueConstraints = @UniqueConstraint(name = "GRDM_API_CAT_DEF_U1", columnNames = {"DISTRIBUTION_NAME", "CATEGORY_TYPE"}))
public class ApiCategoryDefinition {

	@Id
	@Column(name = "TECHNICAL_ID")
	@GeneratedValue(generator = "apiCategoryDefinitionSequence", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName = "GRDM_API_CAT_DEF_SEQ", allocationSize = 1, name = "apiCategoryDefinitionSequence")
	private Long technicalId;

	@Column(name = "DISTRIBUTION_NAME")
	private String distributionName;

	@Column(name = "CATEGORY_TYPE")
	private String categoryType;

	@Column(name = "ACTIVE_DISTRIBUTION_SEQ_NR")
	private Integer activeDistributionSequenceNumber;

	@Column(name = "HAS_VERSIONING")
	@Type(type = "org.hibernate.type.YesNoType")
	private boolean hasVersioning;

	public Long getTechnicalId() {
		return technicalId;
	}

	public void setTechnicalId(Long technicalId) {
		this.technicalId = technicalId;
	}

	public String getDistributionName() {
		return distributionName;
	}

	public void setDistributionName(String distributionName) {
		this.distributionName = distributionName;
	}

	public String getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(String categoryType) {
		this.categoryType = categoryType;
	}

	public Integer getActiveDistributionSequenceNumber() {
		return activeDistributionSequenceNumber;
	}

	public void setActiveDistributionSequenceNumber(Integer activeDistributionSequenceNumber) {
		this.activeDistributionSequenceNumber = activeDistributionSequenceNumber;
	}

	public boolean isHasVersioning() {
		return hasVersioning;
	}

	public void setHasVersioning(boolean hasVersioning) {
		this.hasVersioning = hasVersioning;
	}
}
