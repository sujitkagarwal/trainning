package com.ing.grdm.api.cache.search;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetQuery;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.TermQuery;
import org.springframework.stereotype.Component;

import java.util.AbstractMap.SimpleEntry;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The column name cache
 */
@Component
public class ColumnNameCache extends AbstractCache {
	@Override
	protected List<String> getFacets() {
		return Collections.singletonList(TABLE_DISTRO_NAME);
	}


	public void addDocument(String columnName, String distributionName) {
		final Document document = new Document();

		document.add(new StringField(COLUMN_DISTRO_NAME, columnName, Field.Store.YES));
		document.add(new StoredField(TABLE_DISTRO_NAME, distributionName));
		document.add(new FacetField(TABLE_DISTRO_NAME, distributionName));

		addDocument(document);
	}

	public void deleteDocument(String columnName, String distributionName) {
		final BooleanQuery query = new BooleanQuery.Builder()
				.add(new TermQuery(new Term(COLUMN_DISTRO_NAME, columnName)), BooleanClause.Occur.MUST)
				.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName), BooleanClause.Occur.MUST)
				.build();

		deleteDocument(query);
	}

	public List<Map<String, Object>> search(String searchString, String distributionName) {

		final FuzzyQuery query = new FuzzyQuery(new Term(COLUMN_DISTRO_NAME, searchString.toLowerCase()));
		final BooleanQuery.Builder builder = new BooleanQuery.Builder()
				.add(query, BooleanClause.Occur.MUST);

		if (distributionName != null) {
			builder.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName.toLowerCase()), BooleanClause.Occur.MUST);
		}

		return search(builder.build());
	}

	@Override
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.singletonList(Stream.of(
				new SimpleEntry<String, Object>("rel", "self"),
				new SimpleEntry<String, Object>("href", new StringBuilder("/attributes/")
						.append(document.get(TABLE_DISTRO_NAME))
						.append("?column=")
						.append(document.get(COLUMN_DISTRO_NAME)).toString())
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
	}
}
