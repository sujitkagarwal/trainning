package com.ing.grdm.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Represents a record in the GRDM_JOB table.
 */
@Entity
@Table(name = "GRDM_JOB")
@SuppressWarnings("unused")
public class GrdmJob {

	@Id
	@Column(name = "TECHNICAL_ID")
	private long technicalId;

	@Column(name = "JOB_TYPE")
	private String jobType;

	@Column(name = "HOSTNAME")
	private String hostName;

	@Column(name = "LAST_RUN_TIMESTAMP")
	private Date lastRunDate;

	GrdmJob() {
		// Jobs should not be created by application
	}

}
