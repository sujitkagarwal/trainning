package com.ing.grdm.api.metrics;

/**
 * Marker interface for metrics reporter.
 */
public interface MetricsReporter {
}
