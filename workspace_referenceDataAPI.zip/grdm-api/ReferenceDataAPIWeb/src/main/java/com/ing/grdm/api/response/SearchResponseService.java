package com.ing.grdm.api.response;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Response service interface for Search API.
 */
public interface SearchResponseService {

	/**
	 * @param searchString
	 * @param response
	 * @return
	 * @throws IOException
	 */
	List<Map<String, Object>> respondSearchTableName(String searchString,
													 HttpServletResponse response) throws IOException;

	/**
	 * @param searchString
	 * @param tableName
	 * @param columnName
	 * @param businessKey
	 * @param response
	 * @return
	 * @throws IOException
	 */
	List<Map<String, Object>> respondSearchValue(String searchString,
												 String tableName,
												 String columnName,
												 String businessKey,
												 HttpServletResponse response) throws IOException;

	/**
	 * @param searchString
	 * @param tableName
	 * @param response
	 * @return
	 * @throws IOException
	 */
	List<Map<String, Object>> respondSearchColumnName(String searchString,
													  String tableName,
													  HttpServletResponse response) throws IOException;

	/**
	 * @param searchString
	 * @param tableName
	 * @param response
	 * @return
	 * @throws IOException
	 */
	List<Map<String, Object>> respondSearchBusinessKey(String searchString,
													   String tableName,
													   HttpServletResponse response) throws IOException;
}
