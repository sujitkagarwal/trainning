package com.ing.grdm.api.cache.search;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.TermQuery;
import org.springframework.stereotype.Component;

import java.util.AbstractMap.SimpleEntry;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The table name cache
 */
@Component
public class TableNameCache extends AbstractCache {

	@Override
	protected List<String> getFacets() {
		return Collections.emptyList();
	}


	public void addDocument(String distributionName) {
		final Document document = new Document();

		document.add(new StringField(TABLE_DISTRO_NAME, distributionName, Field.Store.YES));

		addDocument(document);
	}

	public void deleteDocument(String distributionName) {
		deleteDocument(new TermQuery(new Term(TABLE_DISTRO_NAME, distributionName)));
	}

	public List<Map<String, Object>> search(String searchString) {
		final FuzzyQuery query = new FuzzyQuery(new Term(TABLE_DISTRO_NAME, searchString.toLowerCase()));

		return search(query);
	}

	@Override
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.singletonList(Stream.of(
				new SimpleEntry<String, Object>("rel", "self"),
				new SimpleEntry<String, Object>("href", "/attributes/" + document.get(TABLE_DISTRO_NAME))
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
	}
}
