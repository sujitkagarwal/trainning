package com.ing.grdm.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.time.LocalDate;

/**
 * Represents a record in the GRDM_API_DATA_VALUE table.
 */
@Entity
@Table(name = "GRDM_API_DATA_VALUE")
@IdClass(ApiDataValueId.class)
public class ApiDataValue {

	@Id
	@Column(name = "CATEGORY_DEFINITION_ID")
	private long categoryDefinitionId;

	@Id
	@Column(name = "DISTRIBUTION_SEQ_NR")
	private int distributionSequenceNumber;

	@Id
	@Column(name = "BUSINESS_KEY")
	private String businessKey;

	@Id
	@Column(name = "COLUMN_ORDER_NUMBER")
	private int columnOrderNumber;

	@Id
	@Column(name = "TECHNICAL_VERSION")
	private int technicalVersion;

	@Column(name = "EFFECTIVE_DATE")
	private LocalDate effectiveDate;

	@Column(name = "END_DATE")
	private LocalDate endDate;

	@Column(name = "COLUMN_NAME")
	private String columnName;

	@Column(name = "STORAGE_STRING")
	private String storageString;

	@Column(name = "COLUMN_TYPE")
	private int columnType;

	@Column(name = "REFERENCE_TABLE")
	private String referenceTable;

	public long getCategoryDefinitionId() {
		return categoryDefinitionId;
	}

	public void setCategoryDefinitionId(long categoryDefinitionId) {
		this.categoryDefinitionId = categoryDefinitionId;
	}

	public int getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	public void setDistributionSequenceNumber(int distributionSequenceNumber) {
		this.distributionSequenceNumber = distributionSequenceNumber;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public int getColumnOrderNumber() {
		return columnOrderNumber;
	}

	public void setColumnOrderNumber(int columnOrderNumber) {
		this.columnOrderNumber = columnOrderNumber;
	}

	public int getTechnicalVersion() {
		return technicalVersion;
	}

	public void setTechnicalVersion(int technicalVersion) {
		this.technicalVersion = technicalVersion;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public String getColumnName() {
		return columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public String getStorageString() {
		return storageString;
	}

	public void setStorageString(String storageString) {
		this.storageString = storageString;
	}

	public ColumnType getColumnType() {
		return ColumnType.byId(this.columnType);
	}

	public void setColumnType(ColumnType columnType) {
		this.columnType = columnType.getColumnTypeId();
	}

	public String getReferenceTable() {
		return referenceTable;
	}

	public void setReferenceTable(String referenceTable) {
		this.referenceTable = referenceTable;
	}

	public Version getVersion() {
		return Version.fromDates(this.effectiveDate, this.endDate);
	}
}
