package com.ing.grdm.api.cache;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * This is class is used for caching the Whitelist  table based on time cron job.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 28-11-2017
 */
@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
@Component
public class WhiteListCache {
	private static final Log LOG = LogFactory.getLog(WhiteListCache.class);

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Value("${grdm.environment}")
	private String environment;

	// The cached data
	private WhiteListCache.Data cachedData;

	@PostConstruct
	void init() {
		LOG.info("Loading Whitelist data cache on startup");
		reload();
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleAttributesDataChangedEvent(AttributesDataChangedEvent event) {
		if (event.getDistributionSequenceNumber() == null) {
			LOG.info("Reloading whitelist data cache after receiving event");
			reload();
		} else if (!event.getDistributionSequenceNumber().equals(this.cachedData.distributionSequenceNumber)) {
			LOG.info(String.format("Reloading whitelist data cache after receiving event, new distribution sequence number %d",
					event.getDistributionSequenceNumber()));
			reload();
		}
	}

	private void reload() {
		final ApiCategoryDefinition categoryDefinition =
				this.categoryDefinitionRepository.findAttributesCategoryByDistributionName("GRDM_API_WL");
		Integer distributionSequenceNr = null;
		Set<String> authorizedHosts = Collections.emptySet();
		if (categoryDefinition != null) {
			// Find current distribution sequence number
			distributionSequenceNr = categoryDefinition.getActiveDistributionSequenceNumber();
			// Load the row data
			authorizedHosts = cacheRowDataByEnvironment(categoryDefinition);
		}
		// swap in
		this.cachedData = new WhiteListCache.Data(distributionSequenceNr, authorizedHosts);

		LOG.info(String.format("Whitelist data cache loaded with distribution sequence number %d", distributionSequenceNr));
	}

	private Set<String> cacheRowDataByEnvironment(ApiCategoryDefinition categoryDefinition) {
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
				categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

		final Map<String, Map<String, String>> rawData = rowData.stream()
				.collect(
						Collectors.groupingBy(
								// the key in the resulting map is the business key (always uppercase)
								ApiDataValue::getBusinessKey,
								Collectors.toMap(
										// the key in the value map is the column name (always lowercase)
										ApiDataValue::getColumnName,
										// the value is the object with the correct type, e.g. String, Double
										ApiDataValue::getStorageString)));

		return rawData.entrySet().parallelStream()
				//filter the data row based on the environment
				.filter(cd -> cd.getValue().get("ENV").equals(environment))
				//return the host name of the environment.
				.map(cd -> cd.getValue().get("HOSTNAME")).collect(Collectors.toSet());
	}

	/**
	 * Check for existing hostname name
	 *
	 * @param hostName the subjectPrincipal name of the requester certificate
	 * @return true if found, false otherwise
	 */
	public boolean contains(String hostName) {
		return this.cachedData.authorizedHosts.contains(hostName);
	}

	/**
	 * Represents the cached data itself, containing:
	 * <ul>
	 * <li>The current distribution sequence number</li>
	 * <li>List containing all authorized host</li>
	 * </ul>
	 * By using a Data object we can swap in the refreshed data atomically.
	 */
	private static final class Data {

		private final Integer distributionSequenceNumber;
		private final Set<String> authorizedHosts;

		private Data(final Integer distributionSequenceNumber, final Set<String> authorizedHosts) {
			this.distributionSequenceNumber = distributionSequenceNumber;
			this.authorizedHosts = authorizedHosts;
		}
	}
}
