package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Represents the table tag in the SDM distribution
 */
@XStreamAlias("table")
public class SdmTable {

	// Attributes
	@XStreamAsAttribute
	private String name;

	@XStreamAsAttribute
	@XStreamAlias("distributionsequencenumber")
	private int distributionSequenceNumber;

	private String description;
	private SdmCategory category;

	public String getName() {
		return name;
	}

	public int getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	public String getDescription() {
		return description;
	}

	public SdmCategory getCategory() {
		return category;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
