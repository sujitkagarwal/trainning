package com.ing.grdm.api.response;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * Interface for the attributes response service
 */
public interface AttributesResponseService {

	/**
	 * Responds the request for attributes by table distribution name
	 *
	 * @param distributionName the distribution name of the table
	 * @param columns          optional list of names of the columns to return additionally
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondAttributesByTableName(String distributionName,
									  List<String> columns,
									  HttpServletResponse response) throws IOException;

	/**
	 * Responds the request for attributes by table distribution name and business key
	 *
	 * @param distributionName the distribution name of the table
	 * @param businessKey      the business key of the row
	 * @param columns          optional list of names of the columns to return additionally
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondAttributesByTableNameAndBusinessKey(String distributionName,
													String businessKey,
													List<String> columns,
													HttpServletResponse response) throws IOException;
}
