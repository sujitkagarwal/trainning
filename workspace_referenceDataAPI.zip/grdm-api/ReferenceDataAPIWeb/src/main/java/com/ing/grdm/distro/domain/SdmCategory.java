package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.util.List;

/**
 * Represents the category tag in the SDM distribution
 */
@XStreamAlias("category")
public class SdmCategory {

	@XStreamAsAttribute
	private String type;

	private SdmStructure structure;

	@XStreamImplicit(itemFieldName = "row")
	private List<SdmRow> rows;

	public String getType() {
		return type;
	}

	public SdmStructure getStructure() {
		return structure;
	}

	public List<SdmRow> getRows() {
		return rows;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
