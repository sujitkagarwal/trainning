package com.ing.grdm.api.cache.search;

/**
 * Indicates IOExceptions while writing the cache
 */
public class CacheWriteException extends RuntimeException {
	public CacheWriteException(Throwable cause) {
		super(cause);
	}
}
