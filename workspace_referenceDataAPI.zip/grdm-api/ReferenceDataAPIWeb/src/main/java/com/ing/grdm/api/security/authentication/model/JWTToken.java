package com.ing.grdm.api.security.authentication.model;

import com.ing.api.security.trust.token.peer.Endpoint;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import java.security.cert.X509Certificate;
import java.util.List;


/**
 * This  is JWTToken token class which  extends  AbstractAuthenticationToken to pass in the
 * authentication provider by setting the token in  {@link AbstractAuthenticationProcessingFilter}.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class JWTToken extends AbstractAuthenticationToken implements UserDetails {

	private final String token;
	private final X509Certificate certificate;
	private final List<Endpoint> endpoints;

	public JWTToken(String token) {
		this(token, null);
	}

	public JWTToken(String token, X509Certificate certificate) {
		this(token, certificate, null);
	}

	public  JWTToken(String token, X509Certificate certificate, List<Endpoint>  endpoints) {
		super(null);
		this.token = token;
		this.certificate = certificate;
		this.endpoints = endpoints;
	}

	public String getToken() {
		return token;
	}

	@Override
	public Object getCredentials() {
		return null;
	}

	@Override
	public Object getPrincipal() {
		return null;
	}


	@Override
	public String getPassword() {
		return null;
	}

	@Override
	public String getUsername() {
		return null;
	}

	@Override
	public boolean isAccountNonExpired() {
		return false;
	}

	@Override
	public boolean isAccountNonLocked() {
		return false;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return false;
	}

	@Override
	public boolean isEnabled() {
		return false;
	}


	public X509Certificate getCertificate() {
		return certificate;
	}

	public List<Endpoint>  getEndpoints() {
		return endpoints;
	}


}
