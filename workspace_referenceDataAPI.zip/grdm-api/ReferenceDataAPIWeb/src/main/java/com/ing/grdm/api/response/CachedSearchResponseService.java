package com.ing.grdm.api.response;

import com.ing.grdm.api.cache.SearchCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Implementation of {@link SearchResponseService} using a cache
 */
@Component
public class CachedSearchResponseService extends AbstractResponseService implements SearchResponseService {

	private static final String INVALID_TABLE_NAME = "Invalid table name provided";
	private static final String INVALID_SEARCH_STRING = "Invalid search string provided";

	@Autowired
	private SearchCache searchCache;

	@Override
	public List<Map<String, Object>> respondSearchTableName(String searchString,
															HttpServletResponse response) throws IOException {
		if (isValidTableName(searchString)) {
			return this.searchCache.searchDistributionName(searchString);
		} else {
			generateBadRequestResponse(INVALID_SEARCH_STRING, response);
			return null;
		}
	}

	@Override
	public List<Map<String, Object>> respondSearchValue(String searchString,
														String tableName,
														String columnName,
														String businessKey,
														HttpServletResponse response) throws IOException {
		if (!validateInput(tableName, businessKey, Collections.singletonList(columnName), response)) {
			return null;
		} else if (searchString != null && isValidValue(searchString)) {
			return this.searchCache.searchValue(searchString, tableName, columnName, businessKey);
		} else {
			generateBadRequestResponse(INVALID_SEARCH_STRING, response);
			return null;
		}
	}

	@Override
	public List<Map<String, Object>> respondSearchColumnName(String searchString,
															 String tableName,
															 HttpServletResponse response) throws IOException {
		if (tableName != null && !isValidTableName(tableName)) {
			generateBadRequestResponse(INVALID_TABLE_NAME, response);
			return null;
		} else if (searchString != null && isValidColumnName(searchString)) {
			return this.searchCache.searchColumnName(searchString, tableName);
		} else {
			generateBadRequestResponse(INVALID_SEARCH_STRING, response);
			return null;
		}
	}

	@Override
	public List<Map<String, Object>> respondSearchBusinessKey(String searchString,
															  String tableName,
															  HttpServletResponse response) throws IOException {
		if (tableName != null && !isValidTableName(tableName)) {
			generateBadRequestResponse(INVALID_TABLE_NAME, response);
			return null;
		} else if (searchString != null && isValidBusinessKey(searchString)) {
			return this.searchCache.searchBusinessKey(searchString, tableName);
		} else {
			generateBadRequestResponse(INVALID_SEARCH_STRING, response);
			return null;
		}
	}
}
