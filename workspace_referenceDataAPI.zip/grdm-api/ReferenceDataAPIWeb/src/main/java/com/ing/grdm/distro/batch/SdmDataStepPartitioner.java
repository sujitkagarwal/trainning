package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.ing.grdm.domain.DistributionImportStatus.IMPORTING;

/**
 * Creates a partition strategy for processing Attributes files in parallel.
 * Puts the absolute file uri and category definition id in the step execution context.
 * Creates also a category definition in the database if required.
 */
@Component
@JobScope
public class SdmDataStepPartitioner implements Partitioner {

	private static final Log LOG = LogFactory.getLog(SdmDataStepPartitioner.class);

	@Value("#{jobParameters['zipFileUri']}")
	private String zipFileUri;

	@Value("#{jobParameters['distributionSequenceNumber']}")
	private int distributionSequenceNumber;

	@Autowired
	private SdmDistributionFileHelper distributionFileHelper;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	private static final Pattern IMPORT_FILE_PATTERN = Pattern.compile(SdmDistributionFileHelper.IMPORT_FILE_PATTERN);

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {
		LOG.info(String.format("Partitioning steps for zip file %s", Paths.get(URI.create(this.zipFileUri)).getFileName()));
		try {
			// Get all attribute files from the zip and create execution contexts
			final List<URI> filesToImport = this.distributionFileHelper.getAttributeFilesToImport(this.zipFileUri);
			final AtomicInteger count = new AtomicInteger(0);

			LOG.info(String.format("Found %d Attributes files in zip", filesToImport.size()));
			return filesToImport.stream().collect(Collectors.toMap(uri -> "partition" + count.getAndIncrement(), this::createExecutionContext));
		} catch (ProcessDistributionException e) {
			LOG.error("Could not partition zip file, returning empty map of execution contexts for now");
		}

		return Collections.emptyMap();
	}

	private ExecutionContext createExecutionContext(URI uri) {
		final ExecutionContext context = new ExecutionContext();
		context.put("fileUri", uri.toString());
		context.put("categoryDefinitionId", getCategoryDefinitionId(uri));
		return context;
	}

	private Long getCategoryDefinitionId(URI uri) {
		final String distributionFileName = Paths.get(uri).getFileName().toString();
		final Matcher matcher = IMPORT_FILE_PATTERN.matcher(distributionFileName);

		if (matcher.matches()) {
			// Determine distribution name from file
			final String distributionName = matcher.group(1);
			final String categoryType = matcher.group(2);

			// Create or update the category definition
			ApiCategoryDefinition categoryDefinition =
					this.categoryDefinitionRepository.findByDistributionNameAndCategoryType(distributionName, categoryType);
			if (categoryDefinition == null) {
				categoryDefinition = new ApiCategoryDefinition();
			}
			categoryDefinition.setDistributionName(distributionName);
			categoryDefinition.setCategoryType(categoryType);
			categoryDefinition = this.categoryDefinitionRepository.save(categoryDefinition);

			// Create a distribution record
			final ApiCategoryDefinitionDistribution categoryDefinitionDistribution = new ApiCategoryDefinitionDistribution();
			final Date importDate = new Date();
			categoryDefinitionDistribution.setCategoryDefinitionId(categoryDefinition.getTechnicalId());
			categoryDefinitionDistribution.setDistributionSequenceNumber(distributionSequenceNumber);
			categoryDefinitionDistribution.setFileName(distributionFileName);
			categoryDefinitionDistribution.setStatus(IMPORTING);
			categoryDefinitionDistribution.setImportDate(importDate);
			categoryDefinitionDistribution.setLastUpdateDate(importDate);
			this.categoryDefinitionDistributionRepository.save(categoryDefinitionDistribution);

			return categoryDefinition.getTechnicalId();
		}

		return null;
	}
}
