package com.ing.grdm.api.cache.search;

/**
 * Indicates IOExceptions while reading the cache
 */
public class CacheReadException extends RuntimeException {
	public CacheReadException(Throwable cause) {
		super(cause);
	}
}
