package com.ing.grdm.scheduling;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmJobRepository;
import com.ing.grdm.distro.job.SdmDistributionCleanupJob;
import com.ing.grdm.distro.job.SdmDistributionImportJob;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.grdm.event.OverstapDataChangedEvent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

/**
 * The GRDM job scheduler. Responsible for starting the distribution import and cleanup jobs.
 */
@ConditionalOnProperty(value = "grdm.scheduling.enabled")
@Configuration
@EnableScheduling
public class GrdmJobScheduler {
	private static final Log LOG = LogFactory.getLog(GrdmJobScheduler.class);

	@Value("${hostname.fully.qualified}")
	private String hostname;

	@Value("${grdm.scheduling.import.failover_timeout}")
	private int importFailOverTimeout;

	@Value("${grdm.scheduling.cleanup.failover_timeout}")
	private int cleanupFailOverTimeout;

	@Autowired
	private GrdmJobRepository jobRepository;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private SdmDistributionImportJob importJob;

	@Autowired
	private SdmDistributionCleanupJob cleanupJob;

	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Scheduled(cron = "${grdm.scheduling.import.cron}")
	void runBatch() {
		if (this.jobRepository.shouldJobRun(SdmDistributionImportJob.class, this.hostname, this.importFailOverTimeout)) {
			this.importJob.importDistribution();
		} else {
			LOG.debug(String.format("Not starting jobs on this host %s", this.hostname));
		}
	}

	@Scheduled(cron = "${grdm.scheduling.cleanup.cron}")
	void runCleanupJob() {
		if (this.jobRepository.shouldJobRun(SdmDistributionCleanupJob.class, this.hostname, this.cleanupFailOverTimeout)) {
			this.cleanupJob.cleanupDistributions();
		} else {
			LOG.debug(String.format("Not starting jobs on this host %s", this.hostname));
		}
	}

	@Scheduled(cron = "${grdm.cache.attributes.refresh_cron}")
	void monitorAttributesDataChanges() {
		// The active distribution sequence number, updated by the import process
		final Integer activeDistributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();

		if (activeDistributionSequenceNumber != null) {
			// Fire the events to reload caches
			this.eventPublisher.publishEvent(new AttributesDataChangedEvent(activeDistributionSequenceNumber, true));
			this.eventPublisher.publishEvent(new OverstapDataChangedEvent(activeDistributionSequenceNumber));
		}
	}
}