package com.ing.grdm.api.cache.search;

import org.apache.lucene.facet.taxonomy.TaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;

import java.io.IOException;

/**
 * Created by BC90DX on 20-12-2017.
 */
public interface IndexFactory {

	/**
	 * Creates an {@link IndexWriter} instance for create or update of the index.
	 *
	 * @param recreate <code>true</code> will for recreation of the index
	 * @return a new instance of {@link IndexWriter}
	 * @throws IOException if an error occurs
	 */
	IndexWriter createIndexWriter(boolean recreate) throws IOException;

	/**
	 * Creates an {@link TaxonomyWriter} instance for create or update of the index.
	 *
	 * @param recreate <code>true</code> will for recreation of the index
	 * @return a new instance of {@link IndexWriter}
	 * @throws IOException if an error occurs
	 */
	TaxonomyWriter createTaxonomyWriter(boolean recreate) throws IOException;

	/**
	 * Creates an {@link IndexReader} instance for reading the index or null if the underlying index has not changed.
	 *
	 * @param indexReader an instance of {@link IndexReader}, may be <code>null</code>
	 * @return a new instance of {@link IndexReader} or null
	 * @throws IOException if an error occurs
	 */
	DirectoryReader createIndexReader(DirectoryReader indexReader) throws IOException;

	/**
	 * Creates an {@link IndexSearcher} instance using giving {@link IndexReader} instance.
	 *
	 * @param indexReader the index reader
	 * @return a new instance of {@link IndexSearcher}
	 */
	IndexSearcher createIndexSearcher(IndexReader indexReader);

	/**
	 * Close underlying directories silently
	 */
	void closeDirectories();
}
