package com.ing.grdm.api.response;

/**
 * Represents a reference/modelreference value in the response
 */
public class ReferenceVo {

	private String value;
	private String table;

	public ReferenceVo(String value, String table) {
		this.value = value;
		this.table = table;
	}

	public String getValue() {
		return value;
	}

	public String getTable() {
		return table;
	}

}
