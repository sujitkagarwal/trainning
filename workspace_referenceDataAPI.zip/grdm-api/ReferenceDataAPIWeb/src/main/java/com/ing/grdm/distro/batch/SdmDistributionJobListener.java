package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.DistributionImportStatus;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.configuration.annotation.JobScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Job execution listener responsible for opening and closing the distribution zip file
 */
@Component
@JobScope
public class SdmDistributionJobListener implements JobExecutionListener {

	private static final Log LOG = LogFactory.getLog(SdmDistributionJobListener.class);

	private FileSystem zipFileSystem;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		final String zipFileUri = jobExecution.getJobParameters().getString("zipFileUri");
		final String fileName = Paths.get(URI.create(zipFileUri)).getFileName().toString();
		try {
			// Create a new file system for this zip (will need to close it later on!)
			LOG.info(String.format("Opening zip file %s", fileName));
			final String uriString = String.format("jar:%s", zipFileUri);
			this.zipFileSystem = FileSystems.newFileSystem(URI.create(uriString), Collections.emptyMap());
		} catch (IOException e) {
			// We don't expect this to happen, but don't fail here
			LOG.error(String.format("Could not open zip file %s", fileName), e);
		}
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		final String zipFileUri = jobExecution.getJobParameters().getString("zipFileUri");
		final int distributionSequenceNumber = jobExecution.getJobParameters().getLong("distributionSequenceNumber").intValue();

		// Find all active and imported distributions and update calculate new statuses for them
		// Also update the active distribution sequence number of the corresponding category definitions
		// This is done when job is complete so we keep a consistent set of active category definitions so the
		// caching mechanism can rely on this.
		this.categoryDefinitionDistributionRepository.getAllActiveAndImportedCategoryDefinitionDistributions()
				.stream().collect(Collectors.groupingBy(ApiCategoryDefinitionDistribution::getCategoryDefinitionId))
				.values()
				.forEach(list -> updateCategoryDefinition(list, distributionSequenceNumber));

		final Path path = Paths.get(URI.create(zipFileUri));
		try {
			if (this.zipFileSystem != null) {
				LOG.info(String.format("Closing zip file %s", path.getFileName()));
				this.zipFileSystem.close();
			}
		} catch (IOException e) {
			LOG.error(String.format("Failed to close zip file %s", path.getFileName()));
		}
	}

	private void updateCategoryDefinition(List<ApiCategoryDefinitionDistribution> distributions, int distributionSequenceNumber) {
		final ApiCategoryDefinition categoryDefinition =
				this.categoryDefinitionRepository.findOne(distributions.get(0).getCategoryDefinitionId());

		Integer activeDistributionSequenceNumber = null;
		for (ApiCategoryDefinitionDistribution distribution : distributions) {
			if (distribution.getDistributionSequenceNumber() == distributionSequenceNumber) {
				// This category definition was successfully delivered in this distribution
				// Update the category definition's active distribution sequence number
				activeDistributionSequenceNumber = distributionSequenceNumber;

				// Update status of this distribution to active
				distribution.setStatus(DistributionImportStatus.ACTIVE);
			} else {
				// Otherwise this distribution is no longer active, update status of this distribution to inactive
				distribution.setStatus(DistributionImportStatus.INACTIVE);
			}

			// Save the changes to this distribution
			distribution.setLastUpdateDate(new Date());
			this.categoryDefinitionDistributionRepository.save(distribution);
		}

		// If activeDistributionSequenceNumber is still null, this category definition was not delivered or failed while importing
		categoryDefinition.setActiveDistributionSequenceNumber(activeDistributionSequenceNumber);

		// Save the changes to this category definition
		this.categoryDefinitionRepository.save(categoryDefinition);
	}
}
