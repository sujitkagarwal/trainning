package com.ing.grdm.distro.domain;

import com.ing.grdm.distro.domain.converter.SdmColumnDefinitionConverter;
import com.ing.grdm.distro.domain.type.SdmType;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * Represents the columndefinition tag in the SDM distribution
 */
@XStreamAlias("columndefinition")
@XStreamConverter(value = SdmColumnDefinitionConverter.class)
public class SdmColumnDefinition {

	// Attributes
	private String name;
	private boolean primaryKey;
	private boolean mandatory;
	private boolean mandatoryOnLowest;
	private int orderNumber;
	private String columnDefinitionType;

	// Content
	private String description;
	private SdmType type;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(boolean primaryKey) {
		this.primaryKey = primaryKey;
	}

	public boolean isMandatory() {
		return mandatory;
	}

	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	public boolean isMandatoryOnLowest() {
		return mandatoryOnLowest;
	}

	public void setMandatoryOnLowest(boolean mandatoryOnLowest) {
		this.mandatoryOnLowest = mandatoryOnLowest;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getColumnDefinitionType() {
		return columnDefinitionType;
	}

	public void setColumnDefinitionType(String columnDefinitionType) {
		this.columnDefinitionType = columnDefinitionType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public SdmType getType() {
		return type;
	}

	public void setType(SdmType type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}
