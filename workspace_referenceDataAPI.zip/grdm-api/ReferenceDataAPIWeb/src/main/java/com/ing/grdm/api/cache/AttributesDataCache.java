package com.ing.grdm.api.cache;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimaps;
import com.ing.grdm.api.response.AttributesDataSerializer;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.Version;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.itrf.sdm.common.beans.structure.CategoryDefinition;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.util.Collections.emptyMap;

/**
 * Cache containing the required attributes data
 */
@Component
@ConditionalOnProperty("grdm.cache.enabled")
public class AttributesDataCache {

	private static final Log LOG = LogFactory.getLog(AttributesDataCache.class);

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private AttributesDataSerializer attributesDataSerializer;

	@Value("${grdm.cache.categories.exclude:}")
	private String[] excludedCategories;

	// The cached data
	private Data cachedData;

	/**
	 * Represents the cached data itself, containing:
	 * <ul>
	 * <li>The current distribution sequence number</li>
	 * <li>Map with versioned indicators per table distribution name</li>
	 * <li>Map with business keys per table distribution name, already serialized!</li>
	 * <li>Map containing all row data of active tables, indexed by business key and version</li>
	 * <li>Map containing all column names per table distribution name, used for verifying column names provided in request</li>
	 * </ul>
	 * By using a Data object we can swap in the refreshed data atomically.
	 */
	private static final class Data {
		private int distributionSequenceNumber;

		private Map<String, Boolean> versionedByDistributionName;

		private Map<String, Set<String>> columnNamesByDistributionName;

		private Map<String, String> businessKeysByDistributionName;

		private Map<String, Map<String, Map<Version, Map<String, Object>>>> columnsByDistributionName;

		private Data(int distributionSequenceNumber,
					 Map<String, Boolean> versionedByDistributionName,
					 Map<String, String> businessKeysByDistributionName,
					 Map<String, Map<String, Map<Version, Map<String, Object>>>> columnsByDistributionName) {
			this.distributionSequenceNumber = distributionSequenceNumber;
			this.versionedByDistributionName = versionedByDistributionName;
			this.columnNamesByDistributionName = cacheColumnNamesByDistributionName(columnsByDistributionName);
			this.businessKeysByDistributionName = Collections.unmodifiableMap(businessKeysByDistributionName);
			this.columnsByDistributionName = Collections.unmodifiableMap(columnsByDistributionName);
		}
	}

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		LOG.info("Loading attributes data cache on startup");
		reload();
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleAttributesDataChangedEvent(AttributesDataChangedEvent event) {
		if (event.getDistributionSequenceNumber() == null) {
			LOG.info("Reloading attributes data cache after receiving event");
			reload();
		} else if (event.getDistributionSequenceNumber() != this.cachedData.distributionSequenceNumber) {
			LOG.info(String.format("Reloading attributes data cache after receiving event, new distribution sequence number %d",
					event.getDistributionSequenceNumber()));
			reload();
		}
	}

	private void reload() {
		// Find all distributions
		LOG.info("Excluded categories in attribute cache " + Stream.of(this.excludedCategories).collect(Collectors.joining(",")));

		final Iterable<ApiCategoryDefinition> categoryDefinitions = this.categoryDefinitionRepository.findAll();

		// Cache versioned indicators by distribution name
		final Map<String, Boolean> versionedByDistributionName =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(attributesFilter())
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								ApiCategoryDefinition::isHasVersioning));

		// Load the business keys by distribution name
		final Map<String, String> businessKeysByDistributionName =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(attributesFilter())
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								this::cacheBusinessKeysByCategoryDefinitionId));

		// Load the row data
		final Map<String, Map<String, Map<Version, Map<String, Object>>>> columnsByDistributionName =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(attributesFilter())
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								this::cacheRowDataByVersionAndBusinessKey));

		// Find current distribution sequence number
		final int distributionSequenceNr = StreamSupport.stream(categoryDefinitions.spliterator(), true)
				.filter(attributesFilter())
				.mapToInt(ApiCategoryDefinition::getActiveDistributionSequenceNumber)
				.findAny().orElse(-1);

		// swap in
		this.cachedData = new Data(distributionSequenceNr, versionedByDistributionName, businessKeysByDistributionName,
				columnsByDistributionName);

		LOG.info(String.format("Attributes data cache loaded with distribution sequence number %d", distributionSequenceNr));
	}

	private Predicate<ApiCategoryDefinition> attributesFilter() {
		// Only categories applicable
		return categoryDefinition ->
				// with active distribution filter
				categoryDefinition.getActiveDistributionSequenceNumber() != null &&
						// of category type 'Attributes'
						CategoryDefinition.CATEGORY_TYPE_ATTRIBUTES.equals(categoryDefinition.getCategoryType()) &&
						// and not marked to be excluded
						Arrays.stream(this.excludedCategories)
								.noneMatch(s -> s.equalsIgnoreCase(categoryDefinition.getDistributionName()));
	}

	private String cacheBusinessKeysByCategoryDefinitionId(ApiCategoryDefinition categoryDefinition) {
		final List<ApiDataValue> tableData = this.dataValueRepository.getTableData(categoryDefinition.getTechnicalId(),
				categoryDefinition.getActiveDistributionSequenceNumber());
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try {
			// pre-serialize the list of business keys
			attributesDataSerializer.serializeBusinessKeys(outputStream, tableData, categoryDefinition.isHasVersioning());
			return new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		} catch (IOException ioe) {
			// won't happen
			return "[]";
		} finally {
			LOG.info(String.format(
					"Loaded business keys by distribution name %s with distribution sequence number %d into cache",
					categoryDefinition.getDistributionName(), categoryDefinition.getActiveDistributionSequenceNumber()));
		}
	}

	private Map<String, Map<Version, Map<String, Object>>> cacheRowDataByVersionAndBusinessKey(ApiCategoryDefinition categoryDefinition) {
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
				categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

		// Map of row data by version and business key
		return rowData.stream().collect(
				Collectors.groupingBy(
						// the key in the resulting map is the business key
						ApiDataValue::getBusinessKey,
						Collectors.groupingBy(
								// the key in the resulting map is the version
								ApiDataValue::getVersion,
								Collectors.toMap(
										// the key in the value map is the column name (always lowercase)
										dv -> dv.getColumnName().toLowerCase(),
										// the value is the object with the correct type, e.g. String, Double
										AttributesDataSerializer::getColumnNameWithAppropriateDataType))));
	}

	private static Map<String, Set<String>> cacheColumnNamesByDistributionName(
			Map<String, Map<String, Map<Version, Map<String, Object>>>> columnsByDistributionName) {
		// Sets of column names by distribution name
		return columnsByDistributionName.entrySet().stream().collect(
				Collectors.toMap(
						// the key in the resulting map is the distribution name
						Map.Entry::getKey,
						// the values in the resulting map are the cached column names
						entry -> entry.getValue()
								.values()
								.parallelStream()
								// stream the versions (values in map)
								.flatMap(versionMap -> versionMap.values()
										.parallelStream()
										// stream the column names (keys in map)
										.flatMap(columnMap -> columnMap.keySet().parallelStream()))
								.collect(Collectors.toSet())
				));
	}

	/**
	 * Check for existing table distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return true if found, false otherwise
	 */
	public boolean containsTable(String distributionName) {
		return this.cachedData.businessKeysByDistributionName.containsKey(distributionName.toUpperCase());
	}

	/**
	 * Checks if any given column name exists in given table distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @param columns          the columns from the request, case insensitive
	 * @return true if any match, false otherwise
	 */
	public boolean containsColumns(String distributionName, List<String> columns) {
		return this.cachedData.columnNamesByDistributionName
				.getOrDefault(distributionName.toUpperCase(), Collections.emptySet())
				.stream().anyMatch(s -> columns.stream().anyMatch(s::equalsIgnoreCase));
	}

	/**
	 * Returns all the business keys of the table with given distribution name
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return the pre-serialized string containing all business keys
	 */
	public String getBusinessKeysByDistributionName(String distributionName) {
		return this.cachedData.businessKeysByDistributionName.get(distributionName.toUpperCase());
	}

	/**
	 * Returns all row data from the table with given distribution name.
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return a Map of lists of versions by business key, an empty Map if none found
	 */
	public Map<String, Collection<Map<String, Object>>> getColumnsByDistributionName(String distributionName) {
		return this.cachedData.columnsByDistributionName.getOrDefault(distributionName.toUpperCase(), emptyMap())
				.entrySet().stream()
				.collect(Multimaps.flatteningToMultimap(
						Map.Entry::getKey,
						entry -> entry.getValue().values().stream(),
						ArrayListMultimap::create
				)).asMap();
	}

	/**
	 * Returns all row data from the table with given distribution name effective at given filter date.
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return a Map of lists of effective versions by business key, an empty Map if none found
	 */
	public Map<String, Collection<Map<String, Object>>> getColumnsByDistributionName(
			String distributionName, LocalDate filterDate) {
		return this.cachedData.columnsByDistributionName.getOrDefault(distributionName.toUpperCase(), emptyMap())
				.entrySet().stream()
				.collect(Multimaps.flatteningToMultimap(
						Map.Entry::getKey,
						entry -> entry.getValue().entrySet().stream()
								.filter(effectiveVersion(filterDate))
								.map(Map.Entry::getValue),
						ArrayListMultimap::create
				)).asMap();
	}

	/**
	 * Returns the row data from the table with given distribution name for given business key
	 * and, if applicable, the version effective today
	 *
	 * @param distributionName the distribution name of the table, case insensitive
	 * @param businessKey      the business key of the row, case sensitive
	 * @return the row data in a Map, an empty Map if not found
	 */
	public Map<String, Object> getColumnsByDistributionNameAndBusinessKey(String distributionName, String businessKey) {
		return this.cachedData.columnsByDistributionName
				// Get business keys of given distribution name, empty if not found
				.getOrDefault(distributionName.toUpperCase(), emptyMap())
				// Get versions of given business key, empty if not found
				.getOrDefault(businessKey, emptyMap())
				// Find the currently effective version,...
				.entrySet().stream()
				.filter(effectiveVersion(LocalDate.now()))
				.map(Map.Entry::getValue)
				.findFirst()
				// ... empty if not found
				.orElse(emptyMap());
	}

	/**
	 * @param distributionName the distribution name of the table, case insensitive
	 * @return <code>true</code> if the table is versioned, <code>false</code> otherwise
	 */
	public boolean isTableVersioned(String distributionName) {
		return this.cachedData.versionedByDistributionName.get(distributionName.toUpperCase());
	}

	private Predicate<Map.Entry<Version, Map<String, Object>>> effectiveVersion(LocalDate date) {
		return map -> map.getKey().isEffectiveAt(date);
	}

}
