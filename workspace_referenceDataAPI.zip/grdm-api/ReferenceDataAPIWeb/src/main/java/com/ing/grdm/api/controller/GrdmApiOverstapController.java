package com.ing.grdm.api.controller;

import com.ing.grdm.api.cache.OverstapCache;
import com.ing.grdm.api.domain.ForwardAccountsRequestData;
import com.ing.grdm.api.domain.ForwardAccountsResponseData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

/**
 * This is controller which expose the endpoint("/forwarding-accounts") for reference-data api.
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 28-11-2017
 */
@RestController
@ConditionalOnProperty(value = "grdm.cache.overstap.enable", matchIfMissing = true)
public class GrdmApiOverstapController {
	@Autowired
	private OverstapCache overstapCache;

	/**
	 * This method retrieves overstap data for the given accountids  with the choosen filter date
	 *
	 * @param requestData This is the request object for which forward account is fetched and option filter date.
	 * @return the forwarding account respose
	 */
	@RequestMapping(value = "/forwarding-accounts", method = RequestMethod.POST, produces = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE})
	public ForwardAccountsResponseData getForwardingAccounts(@Valid @RequestBody final ForwardAccountsRequestData requestData) {
		ForwardAccountsResponseData responseData = new ForwardAccountsResponseData();
		responseData.setFilterDate(requestData.getFilterDate());
		responseData.setForwardAccounts(overstapCache.getForwardAccountsByIbansAndDate(requestData.getAccountIds(), requestData.getFilterDate()));
		return responseData;
	}


}
