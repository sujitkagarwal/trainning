package com.ing.grdm.api.security.config;


import com.ing.grdm.api.security.authentication.provider.GrdmPeerTokenAuthenticationProvider;
import com.ing.grdm.api.security.filter.GrdmAuthenticationPeerTokenFilter;
import com.ing.grdm.api.security.handler.GrdmAuthenticationFailureHandler;
import com.ing.grdm.api.security.matcher.GrdmSkipPathRequestMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.Arrays;
import java.util.List;


/**
 * This class is used to enable peer to peer token security in grdm application .
 * {@link WebSecurityConfigurerAdapter}
 * {@link GrdmAuthenticationFailureHandler}
 * {@link GrdmPeerTokenAuthenticationProvider}
 * {@link AuthenticationManager}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 15-08-2018
 */
@ConditionalOnExpression("${grdm.api.security.enabled:true}")
@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class GrdmPeerTokenWebSecurityConfig extends WebSecurityConfigurerAdapter {
	private static final String[] SWAGGER_URL = {"/v2/api-docs", "/configuration/ui", "/swagger-resources/**", "/configuration/**", "/swagger-ui.html", "/webjars/**", "/api/token"};

	@Autowired
	private GrdmPeerTokenAuthenticationProvider grdmPeerTokenAuthenticationProvider;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private GrdmAuthenticationFailureHandler grdmAuthenticationFailureHandler;

	/**
	 * This method  is used to override the authentication provider use in grdm application.
	 * {@link GrdmPeerTokenAuthenticationProvider}
	 */
	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
		authenticationManagerBuilder.authenticationProvider(this.grdmPeerTokenAuthenticationProvider);
	}

	/**
	 * This method  is used to create object of GrdmAuthenticationPeerTokenFilter.
	 *
	 * @return this method return the filter object.
	 * @throws Exception this will throw exception if any issue to create object of filter
	 */
	public GrdmAuthenticationPeerTokenFilter authenticationPeerTokenFilterBean() throws Exception {
		List<String> pathsToSkip = Arrays.asList(SWAGGER_URL);
		GrdmSkipPathRequestMatcher matcher = new GrdmSkipPathRequestMatcher(pathsToSkip);
		GrdmAuthenticationPeerTokenFilter grdmAuthenticationPeerTokenFilter = new GrdmAuthenticationPeerTokenFilter(grdmAuthenticationFailureHandler, matcher);
		grdmAuthenticationPeerTokenFilter.setAuthenticationManager(authenticationManager);
		return grdmAuthenticationPeerTokenFilter;

	}

	/**
	 * This method  is used to override the security and authentication and integrated the spring security feature for grdm application.
	 *
	 * @param httpSecurity This is the lists of path to skip
	 * @throws Exception this will throw exception if any configuration issue
	 */
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity
				// we don't need CSRF because our token is invulnerable
				.csrf().disable()
				.exceptionHandling().and()
				// don't create session
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.addFilterBefore(authenticationPeerTokenFilterBean(), UsernamePasswordAuthenticationFilter.class)
				.headers().cacheControl();
	}


}
