package com.ing.grdm.api.constant;

/**
 * this is a constant class to be used for reference-data constants
 */
public class GrdmConstants {
	public static final String DATE_FORMAT = "yyyy-MM-dd";
	public static final String UNAUTHORIZED = "Unauthorized";


}
