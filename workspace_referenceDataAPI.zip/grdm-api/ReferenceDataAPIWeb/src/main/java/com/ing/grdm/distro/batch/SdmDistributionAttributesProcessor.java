package com.ing.grdm.distro.batch;

import com.ing.grdm.distro.domain.SdmColumn;
import com.ing.grdm.distro.domain.SdmRow;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.itrf.sdm.common.beans.data.DataRow;
import org.apache.commons.lang.StringUtils;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static org.apache.commons.lang.StringUtils.isNotBlank;

/**
 * {@link ItemProcessor} implementation responsible for converting SDM distribution rows into a list of data values.
 */
@Component
@StepScope
public class SdmDistributionAttributesProcessor implements ItemProcessor<SdmRow, List<ApiDataValue>> {

	@Value("#{stepExecutionContext['categoryDefinitionId']}")
	private long categoryDefinitionId;

	@Value("#{jobParameters['distributionSequenceNumber']}")
	private Long distributionSequenceNumber;

	@Value("#{stepExecutionContext['columnDefinitions']}")
	private Map<String, ColumnDefinition> columnDefinitions;

	@Value("#{stepExecutionContext['hasVersioning']}")
	private boolean hasVersioning;

	@Value("#{stepExecutionContext['businessKeyVersions']}")
	private ConcurrentMap<String, AtomicInteger> businessKeyVersions;

	@Override
	public List<ApiDataValue> process(SdmRow input) throws Exception {
		if (this.columnDefinitions.isEmpty()) {
			// For some reason reading the table structure failed in the step execution listener, fail here
			throw new ProcessDistributionException(String.format("No column definitions found for category definition %d", this.categoryDefinitionId));
		}
		if (DataRow.DATA_ROW_STATUS_ACTIVE_DESCRIPTION.equals(input.getStatus())) {
			return input.getColumns().stream()
					.filter(column -> isNotBlank(column.getValue()))
					.map(column -> transformColumn(column, input.getColumns()))
					.collect(Collectors.toList());
		}

		return Collections.emptyList();
	}

	private ApiDataValue transformColumn(SdmColumn currentColumn, List<SdmColumn> columns) {
		final ApiDataValue dataValue = new ApiDataValue();
		final ColumnDefinition columnDefinition = this.columnDefinitions.get(currentColumn.getName());
		dataValue.setCategoryDefinitionId(this.categoryDefinitionId);
		dataValue.setDistributionSequenceNumber(this.distributionSequenceNumber.intValue());
		dataValue.setBusinessKey(createBusinessKey(columns));
		dataValue.setColumnOrderNumber(columnDefinition.getOrderNumber());
		dataValue.setColumnName(currentColumn.getName());
		dataValue.setStorageString(currentColumn.getValue());
		dataValue.setColumnType(columnDefinition.getColumnType());
		dataValue.setReferenceTable(columnDefinition.getReferenceTable());

		// For versioned tables only
		if (this.hasVersioning) {
			// We need a 'technical' version per business key as we cannot use effective date in the id (it may be null)
			final AtomicInteger technicalVersion =
					this.businessKeyVersions.computeIfAbsent(dataValue.getBusinessKey(), key -> new AtomicInteger());

			// Only increase when processing first column
			dataValue.setTechnicalVersion(currentColumn.getName().equals(columns.get(0).getName()) ?
					technicalVersion.incrementAndGet() : technicalVersion.get());
			dataValue.setEffectiveDate(getVersionDate(columns, "EFF_DT"));
			dataValue.setEndDate(getVersionDate(columns, "END_DT"));
		}
		return dataValue;
	}

	private String createBusinessKey(List<SdmColumn> columns) {
		return columns.stream()
				.filter(column -> this.columnDefinitions.get(column.getName()).isPrimaryKey())
				.filter(column -> !this.hasVersioning || !"EFF_DT".equals(column.getName()))
				.map(SdmColumn::getValue)
				.collect(Collectors.joining("|"));
	}

	private LocalDate getVersionDate(List<SdmColumn> columns, String columnName) {
		return columns.parallelStream()
				// Find the column with given column name and make sure it has a value
				.filter(column -> column.getName().equals(columnName) && isNotBlank(column.getValue()))
				.findFirst()
				// Parse the value to a LocalDate object
				.map(column -> LocalDate.parse(column.getValue()))
				// Not found, null
				.orElse(null);
	}
}
