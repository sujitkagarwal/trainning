package com.ing.grdm.database.custom;

/**
 * Interface for custom operations on GRDM_TOPOLOGY table.
 */
public interface GrdmTopologyCustomRepository {

	/**
	 * Determines whether jobs should run in this JVM
	 *
	 * @return true if so, false otherwise
	 */
	boolean shouldJobRun();
}
