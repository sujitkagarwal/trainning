package com.ing.grdm.database;

import com.ing.grdm.database.custom.GrdmJobCustomRepository;
import com.ing.grdm.domain.GrdmJob;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Repository definition for GRDM_JOB table. This repository does not support CRUD operations.
 */
public interface GrdmJobRepository extends Repository<GrdmJob, Long>, GrdmJobCustomRepository {

	/**
	 * Updates the last_run_timestamp if applicable:
	 * <ul>
	 * <li>if given host previously ran this job, it will always update the row</li>
	 * <li>if given host did not run this job previously, it will only update if the previous run was
	 * longer ago than the given time</li>
	 * <li>if the job never ran (hostname and last_run_timestamp are null), it will always update the row</li>
	 * </ul>
	 *
	 * @param jobType         the type of the job, fqcn
	 * @param hostname        the name of the host
	 * @param failOverTimeout the time in seconds after which fail-over should apply
	 * @return the number of updated rows (typically one)
	 */
	@Query("update GrdmJob " +
			"set   hostname = ?2 " +
			",     last_run_timestamp = current_timestamp " +
			"where job_type = ?1 " +
			"and   (  hostname = ?2 " +
			"      or hostname is null and last_run_timestamp is null " +
			"      or (  extract(hour from (current_timestamp - last_run_timestamp)) * 60 * 60 + " +
			"            extract(minute from (current_timestamp - last_run_timestamp)) * 60 + " +
			"            extract(second from (current_timestamp - last_run_timestamp)) > ?3 " +
			"         )" +
			"      ) ")
	@Modifying(clearAutomatically = true)
	@Transactional
	int updateJob(String jobType, String hostname, int failOverTimeout);

}
