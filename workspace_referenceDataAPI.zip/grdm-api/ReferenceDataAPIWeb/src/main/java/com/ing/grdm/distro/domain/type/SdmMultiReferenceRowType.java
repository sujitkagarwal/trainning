package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents a multi reference row type column definition in the SDM distribution
 */
public class SdmMultiReferenceRowType implements SdmType {

	@XStreamAsAttribute
	@XStreamAlias("tablereferencecolumn")
	private String tableReferenceColumn;

	public String getTableReferenceColumn() {
		return tableReferenceColumn;
	}
}
