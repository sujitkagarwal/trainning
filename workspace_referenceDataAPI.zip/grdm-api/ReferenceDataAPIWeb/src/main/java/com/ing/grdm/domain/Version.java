package com.ing.grdm.domain;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import java.time.LocalDate;

/**
 * Represents the version of a business key, ie. combination of effective date and end date.
 */
public class Version {

	public static final Version NO_VERSION = new Version(null, null) {
		@Override
		public boolean equals(Object obj) {
			return obj != null && obj instanceof Version && ((Version) obj).effectiveDate == null;
		}

		@Override
		public int hashCode() {
			return 0;
		}
	};

	private LocalDate effectiveDate;
	private LocalDate endDate;

	private Version(LocalDate effectiveDate, LocalDate endDate) {
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
	}

	static Version fromDates(LocalDate effectiveDate, LocalDate endDate) {
		return effectiveDate == null ? NO_VERSION : new Version(effectiveDate, endDate);
	}

	/**
	 * Determines if this version is effective at given filter date.
	 * <ul>
	 * <li>Returns <code>true</code> if no filter date is given</li>
	 * <li>Returns <code>true</code> if effective date is null (no version)</li>
	 * <li>Returns <code>true</code> if given date is equal or after effective date AND before end date (or no end date)</li>
	 * </ul>
	 *
	 * @param filterDate the date at which this version should be effective
	 * @return <code>true</code> if effective, <code>false</code> otherwise
	 */
	public boolean isEffectiveAt(LocalDate filterDate) {
		return filterDate == null || this.effectiveDate == null ||
				!this.effectiveDate.isAfter(filterDate) && (this.endDate == null || this.endDate.isAfter(filterDate));
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Version)) {
			return false;
		}
		final Version version = (Version) obj;
		// effective date is always set (otherwise it would have created Version.NO_VERSION with its own logic)
		return this.effectiveDate != null && this.effectiveDate.equals(version.effectiveDate) &&
				((this.endDate == null && version.endDate == null) ||
						(this.endDate != null && this.endDate.equals(version.endDate)));

	}

	@Override
	public int hashCode() {
		// for simplicity use only effective date to generate hash code
		// effective date is always set (otherwise it would have created Version.NO_VERSION with its own logic)
		return this.effectiveDate.hashCode();
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this, ToStringStyle.SIMPLE_STYLE);
	}
}
