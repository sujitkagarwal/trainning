package com.ing.grdm.api.token;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.SSLContext;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

/**
 * This  is GrdmTokenConfiguration which used for configuration of GRDM Application
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 16-10-2017
 */
@ConditionalOnProperty(value = "grdm.api.security.type", havingValue = "accessToken")
@Configuration
public class GrdmTokenConfiguration {

	@Bean
	public RestTemplate restTemplate() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException {
		return new RestTemplate(new HttpComponentsClientHttpRequestFactory(getHttpClient()));
	}

	private CloseableHttpClient getHttpClient() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		HttpClientBuilder builder = HttpClientBuilder.create();
		// setup a Trust Strategy that allows all certificates.
		SSLContext sslContext = null;
		sslContext = new SSLContextBuilder().loadTrustMaterial(null, (s, sslSession) -> true).build();
		builder.setSSLContext(sslContext);
		// don't check Hostnames, either.
		//use SSLConnectionSocketFactory.getDefaultHostnameVerifier(), if you don't want to weaken
		// here's the special part:
		// need to create an SSL Socket Factory, to use our weakened "trust strategy";
		// and create a Registry, to register it.

		SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext);
		Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
				.register("http", PlainConnectionSocketFactory.getSocketFactory())
				.register("https", sslSocketFactory)
				.build();

		//now, we create connection-manager using our Registry.
		//allows multi-threaded use
		PoolingHttpClientConnectionManager connMgr = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
		builder.setConnectionManager(connMgr);

		return builder.build();
	}

}
