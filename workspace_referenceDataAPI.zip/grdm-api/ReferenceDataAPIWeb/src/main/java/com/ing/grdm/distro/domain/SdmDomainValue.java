package com.ing.grdm.distro.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * Represents a domain value in the SDM distribution
 */
@XStreamAlias("domainvalue")
public class SdmDomainValue {

	private String value;
	private String description;

	public String getValue() {
		return value;
	}

	public String getDescription() {
		return description;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
