package com.ing.grdm.api.metrics;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * This around aspect measures time taken by a call to a rest controller and posts it to graphite. It uses a map containing
 * aliases for all *Controller in the com.ing.grdm.api.controller package. The values are configured in application.properties.
 */
@Aspect
@Component
@ConfigurationProperties("grdm.graphite")
public class MetricsLoggerAspect {

	private Map<Class, String> aliases = new HashMap<>();

	@Value("${grdm.metrics.graphite.prefix.apps}")
	private String prefix;

	@Autowired
	private MetricRegistry metricRegistry;

	@Around("execution(* com.ing.grdm.api.controller.*Controller.*(..))")
	public Object logBefore(ProceedingJoinPoint joinPoint) throws Throwable {

		final Signature signature = joinPoint.getStaticPart().getSignature();
		final String alias = this.getAliases().get(signature.getDeclaringType());
		String methodName = signature.getName();
		if ("attributesByTableName".equals(methodName) && joinPoint.getArgs()[1] != null) {
			methodName = methodName + "WithColumns";
		} else if ("attributesByTableNameAndBusinessKey".equals(methodName) && joinPoint.getArgs()[2] != null) {
			methodName = methodName + "WithColumns";
		}
		final Timer.Context context = this.metricRegistry.timer(MetricRegistry.name(this.prefix, alias, methodName)).time();

		try {
			return joinPoint.proceed();
		} finally {
			context.stop();
		}
	}

	public Map<Class, String> getAliases() {
		return aliases;
	}
}
