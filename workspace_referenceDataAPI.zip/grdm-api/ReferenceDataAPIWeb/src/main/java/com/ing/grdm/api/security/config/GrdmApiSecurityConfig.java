package com.ing.grdm.api.security.config;

import com.ing.api.security.trust.token.access.AccessTokenParser;
import com.ing.api.security.trust.token.access.AccessTokenProperties;
import com.ing.api.security.trust.token.peer.PeerTokenParser;
import com.ing.api.security.trust.token.peer.PeerTokenProperties;
import com.ing.grdm.api.security.authentication.model.GrdmKeyStoreProperties;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

/**
 * Security configuration using access or peer tokens
 */
@Configuration
public class GrdmApiSecurityConfig {

	@Bean
	@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "accessToken")
	AccessTokenParser accessTokenParser(AccessTokenProperties properties) {
		return new AccessTokenParser(properties);
	}

	@Bean
	@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "accessToken")
	@ConfigurationProperties(prefix = "grdm.api-trust-tokens.access-tokens")
	AccessTokenProperties accessTokenProperties() {
		return new GrdmKeyStoreProperties();
	}

	@Bean
	@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
	PeerTokenParser peerTokenParser(PeerTokenProperties properties,
									@Value("${grdm.keyStoreDirectory}") String keyStoreDirectory,
									@Value("${grdm.keyStorePassword}") String keyStorePassword)
			throws IOException, GeneralSecurityException {
		return new PeerTokenParser(properties, getCertificate(keyStoreDirectory, keyStorePassword));
	}

	@Bean
	@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
	@ConfigurationProperties(prefix = "grdm.api-trust-tokens.peer-tokens")
	PeerTokenProperties peerTokenProperties() {
		return new GrdmKeyStoreProperties();
	}

	private X509Certificate getCertificate(final String keyStoreDirectory, final String keyStorePassword)
			throws IOException, GeneralSecurityException {
		final Path keyStoreFilePath = Paths.get(keyStoreDirectory, "ssl-keystore.jks");
		try (InputStream certStore = Files.newInputStream(keyStoreFilePath)) {
			KeyStore keyStore = KeyStore.getInstance("jks");
			keyStore.load(certStore, keyStorePassword.toCharArray());
			Enumeration<String> aliases = keyStore.aliases();
			while (aliases.hasMoreElements()) {
				return (X509Certificate) keyStore.getCertificate(aliases.nextElement());
			}
		}
		throw new CertificateException("Certificate not initialized properly in peer token configuration");
	}
}
