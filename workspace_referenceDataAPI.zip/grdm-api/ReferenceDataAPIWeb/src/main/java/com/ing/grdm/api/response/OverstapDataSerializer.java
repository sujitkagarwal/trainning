package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Writer;
import java.util.Map;

/**
 * Class responsible for serializing overstap data
 */
@Component
public class OverstapDataSerializer {
	private static final String OVERSTAP_STATUS = "ovt_sta";
	private static final String OVERSTAP_ACCOUNTS = "overstapAccounts";
	private static final String FILTER_DATE = "filterDate";

	@Autowired
	private JsonFactory jsonFactory;

	public void serializeOverstapData(Writer writer, Map<String, Map<String, Object>> overstapDataByOldIban, String filterDate)
			throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(writer)) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeFieldName(OVERSTAP_ACCOUNTS);
			jsonGenerator.writeStartArray();
			for (Map.Entry<String, Map<String, Object>> entry : overstapDataByOldIban.entrySet()) {
				serializeOverstapRowData(jsonGenerator, entry.getValue());
			}
			jsonGenerator.writeEndArray();
			if(filterDate == null || filterDate.isEmpty()) {
				jsonGenerator.writeEndObject();
			} else {
				jsonGenerator.writeStringField(FILTER_DATE,filterDate);
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.flush();
		}
	}

	private void serializeOverstapRowData(JsonGenerator jsonGenerator, Map<String, Object> overstapRowData)
			throws IOException {
		jsonGenerator.writeStartObject();
		for (Map.Entry<String, Object> dataValue : overstapRowData.entrySet()) {
			if(!dataValue.getKey().equals(OVERSTAP_STATUS)) {
				jsonGenerator.writeObjectField(dataValue.getKey(), dataValue.getValue());
			}
		}
		jsonGenerator.writeEndObject();
	}
}
