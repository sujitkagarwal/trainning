package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents a model reference type column definition in the SDM distribution
 */
public class SdmModelReferenceType implements SdmType {

	@XStreamAsAttribute
	@XStreamAlias("referencetable")
	private String referenceTable;

	public String getReferenceTable() {
		return referenceTable;
	}
}
