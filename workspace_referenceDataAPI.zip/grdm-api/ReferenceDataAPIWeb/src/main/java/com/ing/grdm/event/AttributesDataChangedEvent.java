package com.ing.grdm.event;

/**
 * Application event notifying listeners that attributes data has changed
 */

public class AttributesDataChangedEvent {

	private Integer distributionSequenceNumber;
	private boolean recreate;

	public AttributesDataChangedEvent() {
	}

	/**
	 * @param recreate <code>true</code> to indicate search cache index recreation is required
	 */
	public AttributesDataChangedEvent(boolean recreate) {
		this.recreate = recreate;
	}

	/**
	 * @param distributionSequenceNumber distribution sequence number initiating this event
	 * @param recreate                   <code>true</code> to indicate search cache index recreation is required
	 */
	public AttributesDataChangedEvent(Integer distributionSequenceNumber, boolean recreate) {
		this.distributionSequenceNumber = distributionSequenceNumber;
		this.recreate = recreate;
	}

	public Integer getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	public boolean isRecreate() {
		return recreate;
	}
}
