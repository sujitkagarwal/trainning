package com.ing.grdm.api.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.regex.Pattern;

/**
 * validator implementation to validate the list of accountId provided in request
 */
public class IbanValidator implements ConstraintValidator<ValidIban, List<String>> {

	private static final Pattern SAFE_IBAN_PATTERN = Pattern.compile("([a-zA-Z]{2}\\d{2}[0-9a-zA-Z]{10,30})");

	@Override
	public void initialize(ValidIban constraintAnnotation) {

	}

	@Override
	public boolean isValid(List<String> accountIds, ConstraintValidatorContext context) {
		return accountIds.parallelStream().allMatch(s -> SAFE_IBAN_PATTERN.matcher(s.trim()).matches());
	}
}
