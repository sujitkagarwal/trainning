package com.ing.grdm.api.cache;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.itrf.sdm.common.beans.structure.CategoryDefinition;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Cache containing the required mappings data
 */
@Component
public class MappingsDataCache {

	private static final Log LOG = LogFactory.getLog(AttributesDataCache.class);

	// Order number of the column containing the global code, e.g. CCRM_CODE
	private static final Integer COLUMN_ORDER_NUMBER_GLOBAL_CODE = 4;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Value("${grdm.cache.categories.exclude:}")
	private String[] excludedCategories;

	// The cached data
	private Data cachedData;

	/**
	 * Represents the cached data itself, containing:
	 * <ul>
	 * <li>The current distribution sequence number</li>
	 * <li>Map with global codes by distribution name and business key. The business key contains both system and local code, e.g. 'BSK|394'</li>
	 * <li>Map with local codes by distribution name, system code and global code</li>
	 * </ul>
	 * By using a Data object we can swap in the refreshed data atomically.
	 */
	private static final class Data {
		private int distributionSequenceNumber;

		private Map<String, Map<String, Map<String, String>>> localMappings;
		private Map<String, Map<String, Map<String, List<String>>>> globalMappings;

		private Data(int distributionSequenceNumber,
					 Map<String, Map<String, Map<String, String>>> localMappings,
					 Map<String, Map<String, Map<String, List<String>>>> globalMappings) {
			this.distributionSequenceNumber = distributionSequenceNumber;
			this.localMappings = Collections.unmodifiableMap(localMappings);
			this.globalMappings = Collections.unmodifiableMap(globalMappings);
		}
	}

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		LOG.info("Loading mappings data cache on startup");
		reload();
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleMappingsDataChangedEvent(AttributesDataChangedEvent event) {
		if (event.getDistributionSequenceNumber() == null) {
			LOG.info("Reloading mappings data cache after receiving event");
			reload();
		} else if (event.getDistributionSequenceNumber() != this.cachedData.distributionSequenceNumber) {
			LOG.info(String.format("Reloading mappings data cache after receiving event, new distribution sequence number %d",
					event.getDistributionSequenceNumber()));
			reload();
		}
	}

	private void reload() {
		// Find all distributions
		final Iterable<ApiCategoryDefinition> categoryDefinitions = this.categoryDefinitionRepository.findAll();

		// Load the local mappings to global code
		final Map<String, Map<String, Map<String, String>>> localMappings =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(mappingsFilter())
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								mapLocalCodes()));

		// Load the global mappings to local codes
		final Map<String, Map<String, Map<String, List<String>>>> globalMappings =
				StreamSupport.stream(categoryDefinitions.spliterator(), true)
						.filter(mappingsFilter())
						.collect(Collectors.toMap(
								ApiCategoryDefinition::getDistributionName,
								mapGlobalCodes()));

		// Find current distribution sequence number
		final int distributionSequenceNr = StreamSupport.stream(categoryDefinitions.spliterator(), true)
				.filter(mappingsFilter())
				.mapToInt(ApiCategoryDefinition::getActiveDistributionSequenceNumber)
				.findAny().orElse(-1);

		// swap in
		this.cachedData = new Data(distributionSequenceNr, localMappings, globalMappings);

		LOG.info(String.format("Mappings data cache loaded with distribution sequence number %d", distributionSequenceNr));
	}

	private Function<ApiCategoryDefinition, Map<String, Map<String, String>>> mapLocalCodes() {
		return categoryDefinition -> {
			final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
					categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

			return rowData.stream()
					// Column number 4 contains the global code
					.filter(dataValue -> COLUMN_ORDER_NUMBER_GLOBAL_CODE.equals(dataValue.getColumnOrderNumber()))
					// Group by system code (first part of the business key)
					.collect(Collectors.groupingBy(
							dataValue -> StringUtils.substringBefore(dataValue.getBusinessKey(), "|"),
							// Map local code (second part in the business key) to global code
							Collectors.toMap(
									dataValue -> StringUtils.substringAfter(dataValue.getBusinessKey(), "|"),
									ApiDataValue::getStorageString)));
		};
	}

	private Function<ApiCategoryDefinition, Map<String, Map<String, List<String>>>> mapGlobalCodes() {
		return categoryDefinition -> {
			final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(
					categoryDefinition.getTechnicalId(), categoryDefinition.getActiveDistributionSequenceNumber());

			return rowData.stream()
					// Column number 4 contains the global code
					.filter(dataValue -> COLUMN_ORDER_NUMBER_GLOBAL_CODE.equals(dataValue.getColumnOrderNumber()))
					// Group by system code (first part of the business key)
					.collect(Collectors.groupingBy(
							dataValue -> StringUtils.substringBefore(dataValue.getBusinessKey(), "|"),
							// Group by global code (storage string of data value with column order number 4)
							Collectors.groupingBy(
									ApiDataValue::getStorageString,
									// Map global code to local codes (second part in the business key)
									Collectors.mapping(
											dv -> StringUtils.substringAfter(dv.getBusinessKey(), "|"),
											Collectors.toList()
									))));
		};
	}

	private Predicate<ApiCategoryDefinition> mappingsFilter() {
		// Only categories applicable
		return categoryDefinition ->
				// with active distribution filter
				categoryDefinition.getActiveDistributionSequenceNumber() != null &&
						// of category type 'Mappings'
						CategoryDefinition.CATEGORY_TYPE_MAPPINGS.equals(categoryDefinition.getCategoryType()) &&
						// and not marked to be excluded
						Arrays.stream(this.excludedCategories)
								.noneMatch(s -> s.equalsIgnoreCase(categoryDefinition.getDistributionName()));
	}

	/**
	 * Returns the global code for given distribution name, system code and local code
	 *
	 * @param distributionName the distribution name of the mappings table
	 * @param systemCode       the system code
	 * @param code             the local code
	 * @return the global code or <code>null</code> if not found
	 */
	public String getGlobalByLocal(String distributionName, String systemCode, String code) {
		return getAllGlobalByLocal(distributionName, systemCode).getOrDefault(code, null);
	}

	/**
	 * Returns all global to local mappings for given distribution name and system code
	 *
	 * @param distributionName the distribution name of the mappings table, case insensitive
	 * @param systemCode       the system code
	 * @return the map of local codes by global code
	 */
	public Map<String, String> getAllGlobalByLocal(String distributionName, String systemCode) {
		return this.cachedData.localMappings
				.getOrDefault(distributionName.toUpperCase(), Collections.emptyMap())
				.getOrDefault(systemCode, Collections.emptyMap());
	}

	/**
	 * Returns the local code(s) for given distribution name, system code and global code
	 *
	 * @param distributionName the distribution name of the mappings table, case insensitive
	 * @param systemCode       the system code
	 * @param code             the global code
	 * @return the list of local codes, empty if none found
	 */
	public List<String> getLocalByGlobal(String distributionName, String systemCode, String code) {
		return getAllLocalByGlobal(distributionName, systemCode).getOrDefault(code, Collections.emptyList());
	}

	/**
	 * Returns all local to global mappings for given distribution name and system code
	 *
	 * @param distributionName the distribution name of the mappings table, case insensitive
	 * @param systemCode       the system code
	 * @return the map of global codes by local code
	 */
	public Map<String, List<String>> getAllLocalByGlobal(String distributionName, String systemCode) {
		return this.cachedData.globalMappings
				.getOrDefault(distributionName.toUpperCase(), Collections.emptyMap())
				.getOrDefault(systemCode, Collections.emptyMap());
	}

	/**
	 * Check for existing table distribution name in the local mappings
	 *
	 * @param distributionName the distribution name of the table
	 * @return <code>true</code> if found, <code>false</code> otherwise
	 */
	public boolean containsDistributionNameForLocal(String distributionName) {
		return this.cachedData.localMappings.containsKey(distributionName.toUpperCase());
	}

	/**
	 * Check for existing system code in the local mappings for given distribution name
	 *
	 * @param distributionName the distribution name of the table
	 * @param systemCode       the system code
	 * @return <code>true</code> if found, <code>false</code> otherwise
	 */
	public boolean containsSystemCodeForLocal(String distributionName, String systemCode) {
		return this.cachedData.localMappings
				.getOrDefault(distributionName.toUpperCase(), Collections.emptyMap())
				.containsKey(systemCode);
	}

	/**
	 * Check for existing table distribution name in the global mappings
	 *
	 * @param distributionName the distribution name of the table
	 * @return <code>true</code> if found, <code>false</code> otherwise
	 */
	public boolean containsDistributionNameForGlobal(String distributionName) {
		return this.cachedData.globalMappings.containsKey(distributionName.toUpperCase());
	}

	/**
	 * Check for existing system code in the global mappings for given distribution name
	 *
	 * @param distributionName the distribution name of the table
	 * @param systemCode       the system code
	 * @return <code>true</code> if found, <code>false</code> otherwise
	 */
	public boolean containsSystemCodeForGlobal(String distributionName, String systemCode) {
		return this.cachedData.globalMappings
				.getOrDefault(distributionName.toUpperCase(), Collections.emptyMap())
				.containsKey(systemCode);
	}
}
