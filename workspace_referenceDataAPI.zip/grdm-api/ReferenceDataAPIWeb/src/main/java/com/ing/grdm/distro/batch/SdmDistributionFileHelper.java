package com.ing.grdm.distro.batch;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.math.BigInteger;
import java.net.URI;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.Signature;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static com.ing.grdm.distro.batch.SdmDistributionFolder.DISTRIBUTION_FOLDER_PATTERN;

/**
 * Helper class to find distribution folders and files. Also validates the checksum of a distribution.
 */
@Component
public class SdmDistributionFileHelper {

	@Value("${grdm.distro.batch.input.folder}")
	private Path distributionRootFolder;

	@Value("${grdm.distro.checksum.algorithm:SHA-512}")
	private String algorithm;

	@Value("${grdm.distro.signature.enabled:false}")
	private boolean signature;

	@Value("${grdm.distro.signature.keystore.location:}")
	private Path keyStoreLocation;

	@Value("${grdm.distro.signature.keystore.password:}")
	private char[] keyStorePassword;

	@Value("${grdm.distro.signature.key.alias:}")
	private String keyAlias;

	static final String IMPORT_FILE_PATTERN = "[0-9]{4}_(.*)_(Attributes|Mappings).xml";

	private static final int BUFFER_SIZE = 8192 * 1024;

	/**
	 * Find a distribution folder to process based on given distribution sequence number
	 *
	 * @param lastDistributionSequenceNumber the sequence number of the last processed distribution, or null if none
	 * @return the reference to the distribution folder or null if none
	 * @throws ProcessDistributionException when distribution folder cannot be accessed
	 */
	public SdmDistributionFolder findFolderToProcess(Integer lastDistributionSequenceNumber) throws ProcessDistributionException {
		try (final DirectoryStream<Path> directoryStream = Files.newDirectoryStream(distributionRootFolder)) {
			// List will contain names of all unprocessed folders ordered by latest first
			final List<SdmDistributionFolder> list =
					StreamSupport.stream(directoryStream.spliterator(), false)
							.filter(path -> path.getFileName().toString().matches(DISTRIBUTION_FOLDER_PATTERN))
							.sorted(Comparator.reverseOrder())
							.map(path -> new SdmDistributionFolder(path, this.algorithm))
							.filter(folder -> lastDistributionSequenceNumber == null || folder.getDistributionSequenceNumber() > lastDistributionSequenceNumber)
							.collect(Collectors.toList());

			// Return the first item from the list, if any
			return list.stream().findFirst().orElse(null);
		} catch (IOException ioe) {
			throw new ProcessDistributionException(String.format("Could not open distribution root folder %s", this.distributionRootFolder.toString()));
		}
	}

	/**
	 * Returns URIs of all Attributes files contained in the zip located at given uri.<br/>
	 * It is required prior to calling this method to create the {@link java.io.FileSystem} for this zip file
	 * to be created. See {@link FileSystems#newFileSystem(URI, Map)}.
	 *
	 * @param zipFileUri the string representation of the URI to the zip file contained in the distribution folder.
	 * @return the list
	 * @throws ProcessDistributionException when the zip cannot be accessed
	 */
	List<URI> getAttributeFilesToImport(String zipFileUri) throws ProcessDistributionException {
		// Create a new file system for this zip (will need to close it later on!)
		final String uriString = String.format("jar:%s", zipFileUri);
		final FileSystem zipFileSystem = FileSystems.getFileSystem(URI.create(uriString));

		// The zip is expected to only contain one root directory, hence the iterator().next()
		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(zipFileSystem.getRootDirectories().iterator().next())) {
			// Find all files ending with 'Attributes.xml' and return them as a list of URIs
			return StreamSupport.stream(directoryStream.spliterator(), false)
					.filter(path -> path.getFileName().toString().matches(IMPORT_FILE_PATTERN))
					.sorted(Comparator.comparing(Path::getFileName))
					.map(Path::toUri)
					.collect(Collectors.toList());
		} catch (IOException e) {
			throw new ProcessDistributionException(String.format("Could not open zip file %s", Paths.get(URI.create(zipFileUri)).getFileName()), e);
		}
	}

	/**
	 * Verifies the checksum or digital signature of a zip file in given distribution folder
	 *
	 * @param folder the distribution folder
	 * @return <code>true</code> if it's valid, <code>false</code> otherwise
	 * @throws ProcessDistributionException if for some reason the necessary files are inaccessible
	 */
	public boolean verifyIntegrity(SdmDistributionFolder folder) throws ProcessDistributionException {
		return this.signature ? verifySignature(folder) : verifyChecksum(folder);
	}

	private boolean verifyChecksum(SdmDistributionFolder folder) throws ProcessDistributionException {
		try (final InputStream zipInputStream = Files.newInputStream(folder.getXmlZipFile());
			 final Reader checksumInputReader = Files.newBufferedReader(folder.getXmlChecksumFile())) {
			final MessageDigest messageDigest = DigestUtils.getDigest(this.algorithm);
			final byte[] buffer = new byte[BUFFER_SIZE];
			int length;
			while ((length = zipInputStream.read(buffer)) >= 0) {
				messageDigest.update(buffer, 0, length);
			}
			final byte[] digest = messageDigest.digest();
			final String checksum = String.format("%x", new BigInteger(1, digest));
			return IOUtils.contentEquals(new StringReader(checksum), checksumInputReader);
		} catch (IOException ioe) {
			throw new ProcessDistributionException(String.format("Checksum validation failed for distribution %s", folder.getFolderName()), ioe);
		}
	}

	private boolean verifySignature(SdmDistributionFolder folder) throws ProcessDistributionException {
		try (final InputStream zipInputStream = Files.newInputStream(folder.getXmlZipFile());
			 final InputStream keyStoreInputStream = Files.newInputStream(this.keyStoreLocation)) {
			final KeyStore keyStore = KeyStore.getInstance("JKS");
			keyStore.load(keyStoreInputStream, this.keyStorePassword);

			final Signature signature = Signature.getInstance(this.algorithm.replace("-", "") + "WithRSA");
			signature.initVerify(keyStore.getCertificate(this.keyAlias).getPublicKey());

			final byte[] buffer = new byte[BUFFER_SIZE];
			int length;
			while ((length = zipInputStream.read(buffer)) > 0) {
				signature.update(buffer, 0, length);
			}
			return signature.verify(Files.readAllBytes(folder.getXmlSignatureFile()));
		} catch (IOException | GeneralSecurityException e) {
			throw new ProcessDistributionException(String.format("Checksum validation failed for distribution %s", folder.getFolderName()), e);
		}
	}
}
