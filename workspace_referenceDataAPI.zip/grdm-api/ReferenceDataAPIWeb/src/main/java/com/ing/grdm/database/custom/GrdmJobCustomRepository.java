package com.ing.grdm.database.custom;

/**
 * Interface for custom operations on GRDM_JOB table.
 */
public interface GrdmJobCustomRepository {

	/**
	 * Returns whether given job should run on given host, decides if fail-over should apply.
	 *
	 * @param jobType         the type of the job
	 * @param hostname        the name of the host
	 * @param failoverTimeout the time in seconds after which fail-over should apply
	 * @return <code>true</code> if this host should run the job, <code>false</code> otherwise
	 */
	boolean shouldJobRun(Class<?> jobType, String hostname, int failoverTimeout);
}
