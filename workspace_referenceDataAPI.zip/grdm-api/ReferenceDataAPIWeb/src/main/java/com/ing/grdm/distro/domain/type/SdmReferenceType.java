package com.ing.grdm.distro.domain.type;

import com.ing.grdm.distro.domain.SdmDomainValue;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import java.util.List;

/**
 * Represents a reference type column definition in the SDM distribution
 */
public class SdmReferenceType implements SdmType {

	@XStreamAsAttribute
	@XStreamAlias("referencetable")
	private String referenceTable;

	@XStreamImplicit(itemFieldName = "domainvalues")
	private List<SdmDomainValue> domainValues;

	public String getReferenceTable() {
		return referenceTable;
	}

	public List<SdmDomainValue> getDomainValues() {
		return domainValues;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
