package com.ing.grdm.api.security.matcher;

import com.ing.api.security.trust.token.peer.Endpoint;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This class is used to validate the requested endpoint with the peer token endpoints .
 * This is achieved with GrdmPeerTokenPathRequestMatcher implementation of RequestMatcher.
 * {@link RequestMatcher}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
public class GrdmPeerTokenPathRequestMatcher implements RequestMatcher {
	private final OrRequestMatcher matcher;

	/**
	 * This constructor is used create GrdmPeerTokenPathRequestMatcher object
	 *
	 * @param endpoints This is the lists from peer token which is authorized to access the GRDM Application
	 * @param context 	This is application context uri.
	 */

	public GrdmPeerTokenPathRequestMatcher(List<Endpoint> endpoints, String context) {
		List<RequestMatcher> accessPath = endpoints.stream().map(end -> new AntPathRequestMatcher(end.getPathTemplate().replaceAll(context, ""), end.getMethod().stringValue())).collect(Collectors.toList());
		matcher = new OrRequestMatcher(accessPath);
	}

	@Override
	public boolean matches(HttpServletRequest request) {
		return matcher.matches(request);
	}
}