package com.ing.grdm.api.response;

import com.ing.grdm.api.cache.AttributesDataCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Implementation of {@link AttributesResponseService} using a data cache
 */
@Component
@ConditionalOnProperty("grdm.cache.enabled")
public class CachedAttributesResponseService extends AbstractResponseService implements AttributesResponseService {

	@Autowired
	private AttributesDataCache attributesDataCache;
	@Autowired
	private AttributesDataSerializer attributesDataSerializer;

	@Override
	public void respondAttributesByTableName(String distributionName,
											 List<String> columns,
											 HttpServletResponse response) throws IOException {
		if (validateInput(distributionName, null, columns, response)) {
			if (this.attributesDataCache.containsTable(distributionName)) {
				prepareResponse(response, null);
				if (columns == null || columns.isEmpty()) {
					response.getWriter().write(this.attributesDataCache.getBusinessKeysByDistributionName(distributionName));
				} else if (this.attributesDataCache.containsColumns(distributionName, columns)) {
					final Map<String, Collection<Map<String, Object>>> tableData =
							this.attributesDataCache.getColumnsByDistributionName(distributionName);
					this.attributesDataSerializer.serializeTableData(response.getOutputStream(), tableData,
							this.attributesDataCache.isTableVersioned(distributionName), columns);
				} else {
					generateColumnsNotFoundResponse(distributionName, columns, response);
				}
			} else {
				generateTableNotFoundResponse(distributionName, response);
			}
		}
	}

	@Override
	public void respondAttributesByTableNameAndBusinessKey(
			String distributionName, String businessKey, List<String> columns, HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, businessKey, columns, response)) {
			if (this.attributesDataCache.containsTable(distributionName)) {
				if (columns == null || columns.isEmpty() || this.attributesDataCache.containsColumns(distributionName, columns)) {
					final Map<String, Object> rowData =
							this.attributesDataCache.getColumnsByDistributionNameAndBusinessKey(distributionName, businessKey);
					if (rowData == null || rowData.isEmpty()) {
						generateNotFoundResponse(String.format("No record found with business key '%s' in table %s",
								businessKey, distributionName), response);
					} else {
						prepareResponse(response, null);
						this.attributesDataSerializer.serializeRowData(response.getOutputStream(), businessKey, rowData,
								this.attributesDataCache.isTableVersioned(distributionName), columns);
					}
				} else {
					generateColumnsNotFoundResponse(distributionName, columns, response);
				}
			} else {
				generateTableNotFoundResponse(distributionName, response);
			}
		}
	}
}