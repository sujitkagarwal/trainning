package com.ing.grdm.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.EventListener;

/**
 * GRDM's API Spring Boot application
 */
@SpringBootApplication
@ComponentScan(basePackages = {"com.ing.grdm.database", "com.ing.grdm.api", "com.ing.grdm.distro.batch",
		"com.ing.grdm.scheduling"})
@PropertySource(value = "classpath:/grdm.api.properties", ignoreResourceNotFound = true)
@PropertySource(value = "file:${PROPERTIES_DIR}/grdm.api.properties", ignoreResourceNotFound = true)
public class GrdmApiApplication extends SpringBootServletInitializer {

	private static final Log LOG = LogFactory.getLog(GrdmApiApplication.class);

	@Value("${grdm.app.name}")
	private String applicationName;

	@Value("${grdm.app.version}")
	private String applicationVersion;

	@Value("${hostname.fully.qualified}")
	private String hostname;

	@Value("${grdm.app.port}")
	private Integer port;

	@EventListener
	@SuppressWarnings("unused")
	public void listen(ApplicationReadyEvent event) {
		LOG.info(String.format("Application %s-%s started at address %s:%d",
				this.applicationName, this.applicationVersion, this.hostname, this.port));
	}

}
