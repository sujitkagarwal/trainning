package com.ing.grdm.api.response;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Interface for the mappings response service
 */
public interface MappingsResponseService {

	/**
	 * Responds the global code by local code request
	 *
	 * @param distributionName the distribution name of the mappings table
	 * @param systemCode       the system code
	 * @param code             the local code
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondGlobalByLocal(String distributionName, String systemCode, String code, HttpServletResponse response)
			throws IOException;

	/**
	 * Responds the all global mappings by system code request
	 *
	 * @param distributionName the distribution name of the mappings table
	 * @param systemCode       the system code
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondAllGlobalByLocal(String distributionName, String systemCode, HttpServletResponse response)
			throws IOException;

	/**
	 * Responds the local code by global code request
	 *
	 * @param distributionName the distribution name of the mappings table
	 * @param systemCode       the system code
	 * @param code             the global code
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondLocalByGlobal(String distributionName, String systemCode, String code, HttpServletResponse response)
			throws IOException;

	/**
	 * Responds the all local mappings by system code request
	 *
	 * @param distributionName the distribution name of the mappings table
	 * @param systemCode       the system code
	 * @param response         the response object
	 * @throws IOException if writing to the response fails
	 */
	void respondAllLocalByGlobal(String distributionName, String systemCode, HttpServletResponse response)
			throws IOException;
}
