package com.ing.grdm.distro.job;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.distro.batch.ProcessDistributionException;
import com.ing.grdm.distro.batch.SdmDistributionFileHelper;
import com.ing.grdm.distro.batch.SdmDistributionFolder;
import com.ing.grdm.scheduling.GrdmJobScheduler;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * This class contains everything to start the SDM distribution import spring-batch job.
 */
@Component
public class SdmDistributionImportJob {

	private static final Log LOG = LogFactory.getLog(GrdmJobScheduler.class);

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@Autowired
	@Lazy
	private JobLauncher jobLauncher;

	@Autowired
	@Lazy
	@Qualifier("xmlFileJob")
	private Job xmlFileJob;

	@Autowired
	private SdmDistributionFileHelper distributionFileHelper;

	/**
	 * Searches for a folder containing a SDM distribution to import by looking for a higher sequence number than the
	 * latest distribution sequence number. If found it will verify the checksum and start the Spring Batch job (if
	 * checksum is valid).
	 */
	public void importDistribution() {
		LOG.info("Starting import distribution job");
		final Integer lastDistributionSequenceNumber = this.categoryDefinitionDistributionRepository.getLastDistributionSequenceNumber();
		SdmDistributionFolder distributionFolder = null;
		try {
			distributionFolder = this.distributionFileHelper.findFolderToProcess(lastDistributionSequenceNumber);
			if (distributionFolder == null) {
				if (lastDistributionSequenceNumber == null) {
					LOG.info("No distributions to process found");
				} else {
					LOG.info(String.format("Latest distribution with sequence number %d already processed", lastDistributionSequenceNumber));
				}
				return;
			}

			LOG.info(String.format("Starting import job for distribution %s", distributionFolder.getFolderName()));
			if (this.distributionFileHelper.verifyIntegrity(distributionFolder)) {
				// Assemble job parameters
				final JobParameters jobParameters = new JobParametersBuilder()
						.addString("zipFileUri", distributionFolder.getXmlZipFile().toUri().toString())
						.addLong("distributionSequenceNumber", (long) distributionFolder.getDistributionSequenceNumber())
						.toJobParameters();

				LOG.info(String.format("Launching job for %s", distributionFolder.getFolderName()));
				this.jobLauncher.run(this.xmlFileJob, jobParameters);
			} else {
				LOG.info(String.format("Checksum validation failed for distribution %s", distributionFolder.getFolderName()));
			}
		} catch (ProcessDistributionException e) {
			LOG.error(e.getMessage(), e);
		} catch (JobExecutionException e) {
			LOG.error(String.format("Failed to start job for distribution %s", distributionFolder.getFolderName()), e);
		}
	}
}
