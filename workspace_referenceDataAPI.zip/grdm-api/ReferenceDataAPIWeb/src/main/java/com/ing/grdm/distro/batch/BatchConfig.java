/*
 * Copyright (c) 2017 ING Group. All rights reserved.
 * 
 * This software is the confidential and proprietary information of ING Group ("Confidential Information").
 */
package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.distro.domain.SdmColumn;
import com.ing.grdm.distro.domain.SdmRow;
import com.ing.grdm.domain.ApiDataValue;
import org.apache.commons.lang.StringUtils;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.xml.StaxEventItemReader;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.io.UrlResource;
import org.springframework.core.task.TaskExecutor;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.net.MalformedURLException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Spring Batch configuration for importing SDM distributions
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackages = "com.ing.grdm.distro")
@PropertySources(
		@PropertySource(value = "classpath:/grdm.api.properties", ignoreResourceNotFound = true)
)
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilder;

	@Autowired
	private StepBuilderFactory stepBuilder;

	@Autowired
	private SdmDistributionAttributesProcessor processor;

	/**
	 * Creates a resourceless transaction manager, required by the in-memory job repository
	 *
	 * @return a resourceless transaction manager
	 */
	@Bean
	public ResourcelessTransactionManager resourcelessTransactionManager() {
		return new ResourcelessTransactionManager();
	}

	/**
	 * Creates a thread pool task executor for the jobs
	 *
	 * @param corePoolSize  the core pool size
	 * @param maxPoolSize   the max pool size
	 * @param queueCapacity the queue capacity
	 * @return the task executor
	 */
	@Bean(name = "jobTaskExecutor")
	public TaskExecutor jobTaskExecutor(
			@Value("${grdm.distro.batch.job.core_pool_size}") int corePoolSize,
			@Value("${grdm.distro.batch.job.max_pool_size}") int maxPoolSize,
			@Value("${grdm.distro.batch.job.queue_capacity}") int queueCapacity) {
		final ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setThreadNamePrefix("job.");
		taskExecutor.setCorePoolSize(corePoolSize);
		taskExecutor.setMaxPoolSize(maxPoolSize);
		taskExecutor.setQueueCapacity(queueCapacity);
		return taskExecutor;
	}

	/**
	 * Creates a thread pool task executor for the step partitioner
	 *
	 * @param corePoolSize  the core pool size
	 * @param maxPoolSize   the max pool size
	 * @param queueCapacity the queue capacity
	 * @return the task executor
	 */
	@Bean(name = "partitionerTaskExecutor")
	public TaskExecutor partitionerTaskExecutor(
			@Value("${grdm.distro.batch.partition_step.core_pool_size}") int corePoolSize,
			@Value("${grdm.distro.batch.partition_step.max_pool_size}") int maxPoolSize,
			@Value("${grdm.distro.batch.partition_step.queue_capacity}") int queueCapacity) {
		final ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setThreadNamePrefix("partitioner.");
		taskExecutor.setCorePoolSize(corePoolSize);
		taskExecutor.setMaxPoolSize(maxPoolSize);
		taskExecutor.setQueueCapacity(queueCapacity);
		return taskExecutor;
	}

	/**
	 * Creates a thread pool task executor for the steps
	 *
	 * @param corePoolSize  the core pool size
	 * @param maxPoolSize   the max pool size
	 * @param queueCapacity the queue capacity
	 * @return the task executor
	 */
	@Bean(name = "stepTaskExecutor")
	public TaskExecutor stepTaskExecutor(
			@Value("${grdm.distro.batch.data_step.core_pool_size}") int corePoolSize,
			@Value("${grdm.distro.batch.data_step.max_pool_size}") int maxPoolSize,
			@Value("${grdm.distro.batch.data_step.queue_capacity}") int queueCapacity) {
		final ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setThreadNamePrefix("data.");
		taskExecutor.setCorePoolSize(corePoolSize);
		taskExecutor.setMaxPoolSize(maxPoolSize);
		taskExecutor.setQueueCapacity(queueCapacity);
		return taskExecutor;
	}

	/**
	 * Creates an in-memory job repository
	 *
	 * @param resourcelessTransactionManager the resourceless transaction manager
	 * @return the job repository
	 * @throws Exception if it fails to create the job repository
	 */
	@Bean
	public JobRepository jobRepository(ResourcelessTransactionManager resourcelessTransactionManager) throws Exception {
		final MapJobRepositoryFactoryBean factoryBean = new MapJobRepositoryFactoryBean(resourcelessTransactionManager());
		factoryBean.setValidateTransactionState(false);
		return factoryBean.getObject();
	}

	/**
	 * Creates a job launcher asynchronously executing jobs
	 *
	 * @param jobRepository the job repository
	 * @param taskExecutor  the task executor to use
	 * @return the job launcher
	 */
	@Bean
	public SimpleJobLauncher jobLauncher(JobRepository jobRepository, @Qualifier("jobTaskExecutor") TaskExecutor taskExecutor) {
		final SimpleJobLauncher simpleJobLauncher = new SimpleJobLauncher();
		simpleJobLauncher.setJobRepository(jobRepository);
		simpleJobLauncher.setTaskExecutor(taskExecutor);
		return simpleJobLauncher;
	}

	/**
	 * Creates an item reader which reads the data rows from the SDM distribution files
	 *
	 * @param fileUri the URI to the file to import
	 * @return the item reader
	 * @throws MalformedURLException if the URI is invalid
	 */
	@Bean(name = "sdmDataReader")
	@StepScope
	public StaxEventItemReader<SdmRow> dataItemReader(@Value("#{stepExecutionContext['fileUri']}") String fileUri) throws MalformedURLException {
		final XStreamMarshaller unmarshaller = new XStreamMarshaller();
		unmarshaller.setAnnotatedClasses(SdmRow.class, SdmColumn.class);

		final StaxEventItemReader<SdmRow> reader = new StaxEventItemReader<SdmRow>() {
			@Override
			public synchronized SdmRow read() throws Exception {
				return super.read();
			}
		};
		reader.setUnmarshaller(unmarshaller);
		reader.setResource(new UrlResource(fileUri));
		reader.setFragmentRootElementName("row");

		return reader;
	}

	/**
	 * Creates an item writer which writes the data values to the database
	 *
	 * @return the item writer
	 */
	@Bean
	@StepScope
	public ItemWriter<List<ApiDataValue>> dataItemWriter() {
		return new ItemWriter<List<ApiDataValue>>() {
			@Autowired
			private GrdmApiDataValueRepository repo;

			@Override
			public void write(List<? extends List<ApiDataValue>> items) throws Exception {
				final List<ApiDataValue> allDataValues = items.stream()
						.flatMap(List::stream)
						.filter(dataValue -> StringUtils.isNotBlank(dataValue.getStorageString()))
						.collect(Collectors.toList());
				this.repo.bulkInsert(allDataValues);
			}
		};
	}

	@Bean
	SdmDataStepListener dataStepListener() {
		return new SdmDataStepListener();
	}

	@Bean
	public Step xmlPartitionerStep(SdmDataStepPartitioner partitioner, @Qualifier("partitionerTaskExecutor") TaskExecutor taskExecutor) throws MalformedURLException {
		return stepBuilder.get("xmlPartitionerStep")
				.partitioner("xmlFileStep", partitioner)
				.taskExecutor(taskExecutor)
				.step(xmlFileStep(null))
				.build();
	}

	@Bean(name = "xmlFileStep")
	public Step xmlFileStep(@Qualifier("stepTaskExecutor") TaskExecutor taskExecutor) throws MalformedURLException {
		return stepBuilder.get("xmlFileStep")
				.<SdmRow, List<ApiDataValue>>chunk(100)
				.reader(dataItemReader(null))
				.processor(processor).writer(dataItemWriter())
				.listener(dataStepListener())
				.taskExecutor(taskExecutor)
				.build();
	}

	@Bean(name = "xmlFileJob")
	public Job xmlFileJob(SdmDistributionJobListener jobListener) throws MalformedURLException {
		return jobBuilder.get("xmlFileJob")
				.incrementer(new RunIdIncrementer())
				.start(xmlPartitionerStep(null, null))
				.listener(jobListener)
				.build();
	}
}
