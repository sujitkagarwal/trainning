package com.ing.grdm.api.metrics;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Performance analysis aspect
 */
@Aspect
@Component
@ConditionalOnProperty("grdm.performance.logging.enabled")
public class PerformanceLoggerAspect {

	private static final Log LOG = LogFactory.getLog(PerformanceLoggerAspect.class);

	private static final AtomicInteger THREAD_COUNT = new AtomicInteger(0);

	@Value("${grdm.performance.logging.min_duration:500}")
	private int minDuration;

	@Around("execution(* com.ing.grdm.api.controller.*Controller.*(..))")
	public Object logController(ProceedingJoinPoint joinPoint) throws Throwable {
		THREAD_COUNT.incrementAndGet();

		final long start = System.currentTimeMillis();

		try {
			return joinPoint.proceed();
		} finally {
			log(joinPoint, start);
			THREAD_COUNT.decrementAndGet();
		}
	}

	@Around("execution(* com.ing.grdm.api.response.*DataSerializer.*(..))")
	public Object logSerializer(ProceedingJoinPoint joinPoint) throws Throwable {
		final long start = System.currentTimeMillis();

		try {
			return joinPoint.proceed();
		} finally {
			log(joinPoint, start);
		}
	}

	@Around("execution(* com.fasterxml.jackson.core.JsonGenerator+.*(..))")
	public Object logResponse(ProceedingJoinPoint joinPoint) throws Throwable {
		final long start = System.currentTimeMillis();

		try {
			return joinPoint.proceed();
		} finally {
			log(joinPoint, start);
		}
	}

	private void log(ProceedingJoinPoint joinPoint, long start) {
		final long duration = System.currentTimeMillis() - start;
		if (duration > minDuration) {
			final Signature signature = joinPoint.getStaticPart().getSignature();
			LOG.info(String.format("Call to %s took %s ms. with thread count %d", signature.getName(), duration, THREAD_COUNT.get()));
		}
	}
}
