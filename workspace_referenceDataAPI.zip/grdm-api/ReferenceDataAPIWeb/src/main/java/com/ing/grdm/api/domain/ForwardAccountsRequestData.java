package com.ing.grdm.api.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.ing.grdm.api.validation.ValidIban;

import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.ing.grdm.api.constant.GrdmConstants.DATE_FORMAT;

/**
 * ForwardAccountsRequestData
 */

@XmlRootElement(name = "forwardAccountsRequestData")
@XmlType(propOrder = {"accountIds", "filterDate"})
@XmlAccessorType(XmlAccessType.FIELD)
public class ForwardAccountsRequestData {

	@XmlElementWrapper(name = "accountIds")
	@XmlElement(name = "accountId")
	@Size(min = 1, message = "The list of accountIds cannot be empty (at least one accountId is required)")
	@ValidIban(message = "invalid accountId provided")
	@JsonProperty("accountIds")

	private List<String> accountIds = new ArrayList<>();

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT)
	@XmlElement(name = "filterDate")
	@XmlJavaTypeAdapter(value = DateFormatAdapter.class)
	private LocalDate filterDate;

	public List<String> getAccountIds() {
		return accountIds;
	}

	public void setAccountIds(List<String> accountIds) {
		this.accountIds = accountIds;
	}

	public LocalDate getFilterDate() {
		return filterDate;
	}

	public void setFilterDate(LocalDate filterDate) {
		this.filterDate = filterDate;
	}

}
