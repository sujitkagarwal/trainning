package com.ing.grdm.api.cache.search;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.document.Document;
import org.apache.lucene.facet.FacetsConfig;
import org.apache.lucene.facet.taxonomy.TaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toMap;

/**
 * Super class for search cache implementations
 */
public abstract class AbstractCache {

	private static final Log LOG = LogFactory.getLog(AbstractCache.class);

	// Static function overriding Collectors.toMap returning a LinkedHashMap
	// It is used to give particular order on the fields in the result maps
	private static <T, K, U> Collector<T, ?, Map<K, U>> toTreeMap(Function<? super T, ? extends K> keyMapper,
																  Function<? super T, ? extends U> valueMapper) {
		return toMap(keyMapper, valueMapper, (v1, v2) -> {
			throw new RuntimeException("duplicate key");
		}, LinkedHashMap::new);
	}

	static final String TABLE_DISTRO_NAME = "table";
	static final String COLUMN_DISTRO_NAME = "column";
	static final String BUSINESS_KEY = "business_key";

	// Facets give dimensions to the index
	private FacetsConfig facetsConfig = new FacetsConfig();

	@Autowired
	private IndexFactory indexFactory;

	// For writing the index
	private IndexWriter indexWriter;
	private TaxonomyWriter taxonomyWriter;
	private boolean reloading;

	// For reading the index
	private DirectoryReader indexReader;
	private IndexSearcher indexSearcher;

	@PostConstruct
	public void init() {
		getFacets().forEach(category -> this.facetsConfig.setHierarchical(category, true));
	}

	@PreDestroy
	@SuppressWarnings("unused")
	void breakdown() {
		IOUtils.closeQuietly(this.indexWriter);
		IOUtils.closeQuietly(this.indexReader);

		this.indexFactory.closeDirectories();
	}

	/**
	 * @return the facets of the cache to be implemented
	 */
	protected abstract List<String> getFacets();

	/**
	 * Opens the index writers so the index can be created or updated
	 *
	 * @param recreate force recreate if <code>true</code>
	 * @throws IllegalStateException if reloading is in progress
	 * @throws CacheWriteException   if an error occurred while opening index
	 */
	public void openForWriting(boolean recreate) {
		if (this.reloading) {
			throw new IllegalStateException("Reload in progress");
		}
		try {
			this.reloading = true;
			this.indexWriter = this.indexFactory.createIndexWriter(recreate);
			this.taxonomyWriter = this.indexFactory.createTaxonomyWriter(recreate);
		} catch (IOException ioe) {
			closeAfterWriting();
			throw new CacheWriteException(ioe);
		}
	}

	/**
	 * Commits changes to the index and closes the index writers
	 */
	public void commitWriting() {
		if (this.reloading) {
			try {
				this.indexWriter.commit();
			} catch (IOException ioe) {
				throw new CacheWriteException(ioe);
			}
		}
	}

	/**
	 * Rolls back the changes to the index writer
	 */
	public void rollbackWriting() {
		if (this.reloading) {
			try {
				this.indexWriter.rollback();
			} catch (IOException ioe) {
				throw new CacheWriteException(ioe);
			}
		}
	}

	public void closeAfterWriting() {
		// Close
		IOUtils.closeQuietly(this.indexWriter);
		IOUtils.closeQuietly(this.taxonomyWriter);

		// Dereference
		this.indexWriter = null;
		this.taxonomyWriter = null;
		this.reloading = false;
	}

	/**
	 * (Re-)opens the index for reading
	 */
	public void openForReading() {
		if (this.reloading) {
			return;
		}
		try {
			final DirectoryReader newIndexReader = this.indexFactory.createIndexReader(this.indexReader);
			if (newIndexReader != null) {
				IOUtils.closeQuietly(this.indexReader);
				this.indexReader = newIndexReader;
				this.indexSearcher = this.indexFactory.createIndexSearcher(this.indexReader);
			}
		} catch (IOException ioe) {
			IOUtils.closeQuietly(this.indexReader);
			this.indexSearcher = null;
			this.indexReader = null;
			throw new CacheReadException(ioe);
		}
	}

	/**
	 * Adds given document to the index taking facets into account
	 *
	 * @param document the document to index
	 */
	void addDocument(Document document) {
		try {
			this.indexWriter.addDocument(this.facetsConfig.build(this.taxonomyWriter, document));
		} catch (IOException ioe) {
			throw new CacheWriteException(ioe);
		}
	}

	/**
	 * Deletes documents matching given query
	 *
	 * @param query the query
	 */
	void deleteDocument(Query query) {
		try {
			this.indexWriter.deleteDocuments(query);
		} catch (IOException ioe) {
			throw new CacheWriteException(ioe);
		}
	}

	/**
	 * Searches the index using given query. Returns the top 20 documents
	 *
	 * @param query the query
	 * @return the results as a List of Maps so it is easily serializable, or an empty list if any error occurs
	 */
	protected List<Map<String, Object>> search(Query query) {
		try {
			final TopDocs hits = this.indexSearcher.search(query, 20);

			return Arrays.stream(hits.scoreDocs).map(this::scoreDocToMap).collect(Collectors.toList());
		} catch (IOException | RuntimeException e) {
			LOG.warn("Could not execute query", e);
			return Collections.emptyList();
		}
	}

	/**
	 * Gives implementing classes the ability to include links in the returned maps
	 *
	 * @param document the current document, used to enrich links
	 * @return the links object as a map
	 */
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.emptyList();
	}

	private Map<String, Object> scoreDocToMap(ScoreDoc scoreDoc) {
		try {
			final Document doc = this.indexSearcher.doc(scoreDoc.doc);
			final Map<String, Object> result = doc.getFields()
					.stream()
					.collect(toTreeMap(IndexableField::name, this::getDocumentValue));
			final List<Map<String, Object>> links = addLinks(doc);
			if (!links.isEmpty()) {
				result.put("links", links);
			}
			return result;
		} catch (IOException ioe) {
			throw new CacheReadException(ioe);
		}
	}

	private Object getDocumentValue(IndexableField field) {
		return field.numericValue() == null ? field.stringValue() : field.numericValue();
	}

}
