package com.ing.grdm.api.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.ing.grdm.api.constant.GrdmConstants.DATE_FORMAT;

/**
 * ForwardAccountsResponseData
 */

@XmlRootElement(name = "forwardAccountsResponseData")
@XmlType(propOrder = {"forwardAccounts", "filterDate"})
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ForwardAccountsResponseData {

	@XmlElementWrapper(name = "forwardAccounts")
	@XmlElement(name = "forwardAccount")
	@JsonProperty("forwardAccounts")
	private List<ForwardAccount> forwardAccounts = new ArrayList<>();

	@JsonDeserialize(using = LocalDateDeserializer.class)
	@JsonSerialize(using = LocalDateSerializer.class)
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_FORMAT)
	@XmlElement(name = "filterDate")
	@XmlJavaTypeAdapter(value = DateFormatAdapter.class)
	private LocalDate filterDate = null;

	public List<ForwardAccount> getForwardAccounts() {
		return forwardAccounts;
	}

	public void setForwardAccounts(List<ForwardAccount> forwardAccounts) {
		this.forwardAccounts = forwardAccounts;
	}

	public LocalDate getFilterDate() {
		return filterDate;
	}

	public void setFilterDate(LocalDate filterDate) {
		this.filterDate = filterDate;
	}
}