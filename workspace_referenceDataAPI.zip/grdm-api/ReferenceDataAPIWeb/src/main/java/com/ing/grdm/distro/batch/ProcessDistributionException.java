package com.ing.grdm.distro.batch;

/**
 * Exception type for any failure occurring during importing distributions
 */
public class ProcessDistributionException extends Exception {

	public ProcessDistributionException(String message) {
		super(message);
	}

	public ProcessDistributionException(String message, Throwable cause) {
		super(message, cause);
	}
}
