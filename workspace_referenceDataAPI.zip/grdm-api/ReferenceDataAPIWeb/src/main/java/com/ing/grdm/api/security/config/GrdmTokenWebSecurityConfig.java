package com.ing.grdm.api.security.config;

import com.ing.grdm.api.security.authentication.provider.GrdmAuthenticationProvider;
import com.ing.grdm.api.security.filter.GrdmAuthenticationTokenFilter;
import com.ing.grdm.api.security.handler.GrdmAuthenticationFailureHandler;
import com.ing.grdm.api.security.matcher.GrdmSkipPathRequestMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.Arrays;
import java.util.List;


/**
 * This class is used to enable security in grdm application .This class also ensure the security of api for unauthorized access.
 * {@link WebSecurityConfigurerAdapter}
 * {@link GrdmAuthenticationProvider}
 * {@link GrdmAuthenticationFailureHandler}
 * {@link GrdmAuthenticationTokenFilter}
 * {@link AuthenticationManager}
 *
 * @author Sujit Kumar Agarwal
 * @version 1.0
 * @since 18-09-2017
 */
@ConditionalOnExpression("${grdm.api.security.enabled:true}")
@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "accessToken")
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class GrdmTokenWebSecurityConfig extends WebSecurityConfigurerAdapter {
	private static final String[] SWAGGER_URL = {"/v2/api-docs", "/configuration/ui", "/swagger-resources/**", "/configuration/**", "/swagger-ui.html", "/webjars/**", "/api/token"};

	@Autowired
	private GrdmAuthenticationProvider grdmAuthenticationProvider;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private GrdmAuthenticationFailureHandler grdmAuthenticationFailureHandler;

	/**
	 * This method  is used to override the authentication provider use in grdm application.
	 * {@link GrdmAuthenticationProvider}
	 */
	@Override
	public void configure(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception {
		authenticationManagerBuilder.authenticationProvider(this.grdmAuthenticationProvider);
	}

	/**
	 * This method  is used to create object of GrdmAuthenticationTokenFilter.
	 *
	 * @return this method return the filter object.
	 * @throws Exception this will throw exception if any issue to create object of filter
	 */
	public GrdmAuthenticationTokenFilter authenticationTokenFilterBean() throws Exception {
		List<String> pathsToSkip = Arrays.asList(SWAGGER_URL);
		GrdmSkipPathRequestMatcher matcher = new GrdmSkipPathRequestMatcher(pathsToSkip);
		GrdmAuthenticationTokenFilter grdmAuthenticationTokenFilter = new GrdmAuthenticationTokenFilter(grdmAuthenticationFailureHandler, matcher);
		grdmAuthenticationTokenFilter.setAuthenticationManager(authenticationManager);
		return grdmAuthenticationTokenFilter;

	}

	/**
	 * This method  is used to override the security and authentication and integrated the spring security feature for grdm application.
	 *
	 * @param httpSecurity This is the lists of path to skip
	 * @throws Exception this will throw exception if any configuration issue
	 */
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity
				// we don't need CSRF because our token is invulnerable
				.csrf().disable()
				.exceptionHandling().and()
				// don't create session
				.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.addFilterBefore(authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class)
				.headers().cacheControl();
	}


}
