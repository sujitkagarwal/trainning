package com.ing.grdm.database;

import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Repository definition for the GRDM_API_CAT_DEF_DISTRO table
 */
public interface GrdmApiCategoryDefinitionDistributionRepository extends CrudRepository<ApiCategoryDefinitionDistribution, ApiCategoryDefinitionDistributionId> {

	/**
	 * Finds the last processed distribution sequence number
	 *
	 * @return the distribution sequence number
	 */
	@Query("select max(distributionSequenceNumber) from ApiCategoryDefinitionDistribution ")
	Integer getLastDistributionSequenceNumber();

	/**
	 * Updates all import records older than active one to status INACTIVE for given category definition
	 *
	 * @param categoryDefinitionId             the category definition id to update records for
	 * @param activeDistributionSequenceNumber the active distribution sequence number
	 */
	@Query("update ApiCategoryDefinitionDistribution " +
			"set status = 'INACTIVE', lastUpdateDate = current_date " +
			"where categoryDefinitionId = ?1 " +
			"and distributionSequenceNumber < ?2 " +
			"and status = 'ACTIVE'")
	@Modifying(clearAutomatically = true)
	@Transactional
	void updateActiveToInactive(Long categoryDefinitionId, int activeDistributionSequenceNumber);

	/**
	 * Retrieve any category definitions containing more inactive distributions than the minimum amount
	 *
	 * @param minimumInactive minimum number of inactive distributions to retain
	 * @return the list of category definition ids
	 */
	@Query("select categoryDefinitionId from ApiCategoryDefinitionDistribution " +
			"where status = 'INACTIVE' " +
			"group by categoryDefinitionId " +
			"having count(*) > ?1")
	List<Long> getCategoryDefinitionsWithInactivesToDelete(long minimumInactive);

	/**
	 * Retrieve the distribution records to delete for given category definition
	 *
	 * @param categoryDefinitionId the id of the category definition
	 * @return the list of distributions for given category definition
	 */
	@Query("from ApiCategoryDefinitionDistribution " +
			"where categoryDefinitionId = ?1 " +
			"and status = 'INACTIVE' " +
			"and distributionSequenceNumber < (" +
			"  select max(distributionSequenceNumber) from ApiCategoryDefinitionDistribution " +
			"  where categoryDefinitionId = ?1 " +
			"  and status = 'INACTIVE'" +
			")"
	)
	List<ApiCategoryDefinitionDistribution> getCategoryDefinitionDistributionsToDelete(Long categoryDefinitionId);

	/**
	 * Return all the category definitions with status 'ACTIVE' or 'IMPORTED'
	 *
	 * @return the list of category definitions
	 */
	@Query("from ApiCategoryDefinitionDistribution where status in ('ACTIVE', 'IMPORTED')")
	List<ApiCategoryDefinitionDistribution> getAllActiveAndImportedCategoryDefinitionDistributions();

}
