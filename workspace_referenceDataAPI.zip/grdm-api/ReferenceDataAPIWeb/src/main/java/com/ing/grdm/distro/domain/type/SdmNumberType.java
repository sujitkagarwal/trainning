package com.ing.grdm.distro.domain.type;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

/**
 * Represents a number type column definition in the SDM distribution
 */
public class SdmNumberType implements SdmType {

	@XStreamAsAttribute
	private Integer size;

	@XStreamAsAttribute
	private Integer scale;

	@XStreamAsAttribute
	@XStreamAlias("allownegative")
	private boolean allowNegative;

	public Integer getSize() {
		return size;
	}

	public Integer getScale() {
		return scale;
	}

	public boolean isAllowNegative() {
		return allowNegative;
	}
}
