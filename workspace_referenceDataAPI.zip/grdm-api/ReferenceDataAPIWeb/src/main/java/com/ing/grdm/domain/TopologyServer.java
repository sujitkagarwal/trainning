package com.ing.grdm.domain;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Defines a row in the topology table, representing a server in the current environment.
 */
@Entity
@Table(name = "GRDM_TOPOLOGY")
public class TopologyServer {

	@Id
	@Column(name = "TECHNICAL_ID")
	private long technicalId;

	@Column(name = "HOSTNAME")
	private String hostname;

	@Column(name = "DATACENTER")
	private String datacenter;

	@Column(name = "DATABASE_NAME")
	private String databaseName;

	public TopologyServer() {
		// Required by JPA
	}

	public TopologyServer(long technicalId) {
		this.technicalId = technicalId;
	}

	public long getTechnicalId() {
		return technicalId;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getDatacenter() {
		return datacenter;
	}

	public void setDatacenter(String datacenter) {
		this.datacenter = datacenter;
	}

	public String getDatabaseName() {
		return databaseName;
	}

	public void setDatabaseName(String databaseName) {
		this.databaseName = databaseName;
	}

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
