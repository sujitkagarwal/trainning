package com.ing.grdm.distro.batch;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represents a specific distribution folder.
 */
public class SdmDistributionFolder {
	static final String DISTRIBUTION_FOLDER_PATTERN = "([A-Z]{3})_([0-9]{8}_[0-9]{6})_([0-9]+)";

	private String checksumExtension;
	private String systemCode;
	private Date distributionDate;
	private int distributionSequenceNumber;
	private Path folderPath;

	/**
	 * Constructs an {@link SdmDistributionFolder} instance located at given path
	 *
	 * @param folderPath the absolute path to this folder
	 * @param algorithm  the checksum algorithm used
	 */
	public SdmDistributionFolder(Path folderPath, String algorithm) {
		final Pattern pattern = Pattern.compile(DISTRIBUTION_FOLDER_PATTERN);
		final Matcher matcher = pattern.matcher(folderPath.getFileName().toString());
		if (matcher.matches()) {
			this.folderPath = folderPath;
			this.systemCode = matcher.group(1);
			try {
				this.distributionDate = new SimpleDateFormat("yyyyMMdd_HHmmss").parse(matcher.group(2));
			} catch (ParseException e) {
				// Won't happen
			}
			this.distributionSequenceNumber = Integer.parseInt(matcher.group(3));
			this.checksumExtension = algorithm.replace("-", "").toLowerCase();
		} else {
			throw new IllegalArgumentException("Not a valid distribution folder name " + folderPath.getFileName());
		}
	}

	/**
	 * @return the system code derived from the folder name
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @return the distribution date derived from the folder name
	 */
	public Date getDistributionDate() {
		return distributionDate;
	}

	/**
	 * @return the distribution sequence number derived from the folder name
	 */
	public int getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	/**
	 * @return the base folder name of this distribution
	 */
	public String getFolderName() {
		return this.folderPath.getFileName().toString();
	}

	/**
	 * @return the absolute path to the xml folder within the distribution
	 */
	public Path getXmlFolder() {
		return Paths.get(this.folderPath.toString(), "xml");
	}

	/**
	 * @return the absolute path of the XML zip file contained in the distribution
	 */
	public Path getXmlZipFile() {
		return Paths.get(getXmlFolder().toString(), this.folderPath.getFileName() + "_xml.zip");
	}

	/**
	 * @return the absolute path of the XML checksum file contained in the distribution
	 */
	public Path getXmlChecksumFile() {
		return Paths.get(getXmlFolder().toString(), this.folderPath.getFileName() + "_xml." + this.checksumExtension);
	}

	/**
	 * @return the absolute path of the XML signature file contained in the distribution
	 */
	public Path getXmlSignatureFile() {
		return Paths.get(getXmlFolder().toString(), this.folderPath.getFileName() + "_xml.rsa");
	}
}
