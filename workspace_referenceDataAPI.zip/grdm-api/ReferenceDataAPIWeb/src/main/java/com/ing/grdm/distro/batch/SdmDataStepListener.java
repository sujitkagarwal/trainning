package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.distro.domain.SdmColumnDefinition;
import com.ing.grdm.distro.domain.SdmDomainValue;
import com.ing.grdm.distro.domain.SdmStructure;
import com.ing.grdm.distro.domain.type.SdmDomainType;
import com.ing.grdm.distro.domain.type.SdmHierarchyType;
import com.ing.grdm.distro.domain.type.SdmModelReferenceType;
import com.ing.grdm.distro.domain.type.SdmMultiReferenceRowType;
import com.ing.grdm.distro.domain.type.SdmMultiReferenceTableType;
import com.ing.grdm.distro.domain.type.SdmNumberType;
import com.ing.grdm.distro.domain.type.SdmRangeType;
import com.ing.grdm.distro.domain.type.SdmReferenceType;
import com.ing.grdm.distro.domain.type.SdmSimpleType;
import com.ing.grdm.distro.domain.type.SdmStringType;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import com.ing.grdm.domain.ColumnType;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.listener.StepExecutionListenerSupport;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.xml.stax.DefaultFragmentEventReader;
import org.springframework.batch.item.xml.stax.FragmentEventReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Component;
import org.springframework.util.xml.StaxUtils;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.transform.Source;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import static com.ing.grdm.domain.DistributionImportStatus.FAILED;
import static com.ing.grdm.domain.DistributionImportStatus.IMPORTED;

/**
 * This step listener reads the structure from the distribution file before the rows are being processed.
 * It will put a map of the {@link ColumnDefinition} instances indexed by distribution name in the step execution context.
 */
@Component
public class SdmDataStepListener extends StepExecutionListenerSupport {

	private static final Log LOG = LogFactory.getLog(SdmDataStepListener.class);

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		final String fileUri = stepExecution.getExecutionContext().getString("fileUri");
		Map<String, ColumnDefinition> columnDefinitionMap;
		try {
			columnDefinitionMap = readColumnDefinitions(fileUri).stream()
					.collect(Collectors.toMap(SdmColumnDefinition::getName, SdmDataStepListener::mapColumnDefinition));
		} catch (XMLStreamException | IOException e) {
			// We don't expect this to happen, but don't fail here. Handle empty map in step itself
			LOG.error(String.format("Could not read table structure from file %s: %s", fileUri, e.getMessage()));
			columnDefinitionMap = Collections.emptyMap();
		}
		stepExecution.getExecutionContext().put("columnDefinitions", columnDefinitionMap);
		stepExecution.getExecutionContext().put("hasVersioning", hasVersioning(columnDefinitionMap));
		stepExecution.getExecutionContext().put("businessKeyVersions", new ConcurrentHashMap<String, AtomicInteger>());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		final String fileUri = stepExecution.getExecutionContext().getString("fileUri");
		final Long distributionSequenceNumber = stepExecution.getJobParameters().getLong("distributionSequenceNumber");
		final Long categoryDefinitionId = stepExecution.getExecutionContext().getLong("categoryDefinitionId");
		final boolean hasVersioning = (boolean) stepExecution.getExecutionContext().get("hasVersioning");

		// Apply if versioning is enabled for this category
		final ApiCategoryDefinition categoryDefinition = this.categoryDefinitionRepository.findOne(categoryDefinitionId);
		categoryDefinition.setHasVersioning(hasVersioning);
		this.categoryDefinitionRepository.save(categoryDefinition);

		final ApiCategoryDefinitionDistribution categoryDefinitionDistribution = this.categoryDefinitionDistributionRepository.findOne(
				new ApiCategoryDefinitionDistributionId(categoryDefinitionId, distributionSequenceNumber.intValue()));

		if (ExitStatus.COMPLETED.equals(stepExecution.getExitStatus())) {
			// Update the distribution record
			categoryDefinitionDistribution.setStatus(IMPORTED);
			categoryDefinitionDistribution.setLastUpdateDate(new Date());
			this.categoryDefinitionDistributionRepository.save(categoryDefinitionDistribution);

			LOG.info(String.format("Completed importing %s", Paths.get(URI.create(fileUri)).getFileName().toString()));
			return null;
		} else {
			// Update the distribution record
			categoryDefinitionDistribution.setStatus(FAILED);
			categoryDefinitionDistribution.setLastUpdateDate(new Date());
			this.categoryDefinitionDistributionRepository.save(categoryDefinitionDistribution);

			LOG.info(String.format("Completed importing %s with errors %s", Paths.get(URI.create(fileUri)).getFileName().toString(), stepExecution.getExitStatus()));
			return ExitStatus.FAILED;
		}
	}

	private List<SdmColumnDefinition> readColumnDefinitions(String fileUri) throws XMLStreamException, IOException {
		final Path filePath = Paths.get(URI.create(fileUri));
		LOG.info(String.format("Reading column definitions from %s", filePath.getFileName().toString()));
		final XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		final XMLEventReader eventReader = inputFactory.createXMLEventReader(Files.newInputStream(filePath));
		final FragmentEventReader fragmentEventReader = new DefaultFragmentEventReader(eventReader);

		if (moveCursorToNextFragment(fragmentEventReader)) {
			fragmentEventReader.markStartFragment();
			try {
				return unmarshalStructureFragment(fragmentEventReader);
			} finally {
				fragmentEventReader.markFragmentProcessed();
			}
		}
		return Collections.emptyList();
	}

	@SuppressWarnings("unchecked")
	private List<SdmColumnDefinition> unmarshalStructureFragment(XMLEventReader reader) throws XMLStreamException, IOException {
		final XStreamMarshaller unmarshaller = new XStreamMarshaller();
		unmarshaller.setAnnotatedClasses(SdmStructure.class, SdmColumnDefinition.class, SdmStringType.class, SdmReferenceType.class,
				SdmHierarchyType.class, SdmNumberType.class, SdmDomainType.class, SdmModelReferenceType.class,
				SdmMultiReferenceRowType.class, SdmMultiReferenceTableType.class, SdmRangeType.class, SdmSimpleType.class,
				SdmDomainValue.class);

		final Source source = StaxUtils.createStaxSource(reader);
		return ((SdmStructure) unmarshaller.unmarshal(source)).getColumnDefinitions();
	}

	private boolean moveCursorToNextFragment(XMLEventReader reader) throws NonTransientResourceException {
		try {
			while (true) {
				while (reader.peek() != null && !reader.peek().isStartElement()) {
					reader.nextEvent();
				}
				if (reader.peek() == null) {
					return false;
				}
				QName startElementName = ((StartElement) reader.peek()).getName();
				if ("structure".equals(startElementName.getLocalPart())) {
					return true;
				}
				reader.nextEvent();
			}
		} catch (XMLStreamException e) {
			throw new NonTransientResourceException("Error while reading from event reader", e);
		}
	}

	private static ColumnDefinition mapColumnDefinition(SdmColumnDefinition columnDefinition) {
		final ColumnDefinition vo = new ColumnDefinition();
		vo.setDistributionName(columnDefinition.getName());
		vo.setPrimaryKey(columnDefinition.isPrimaryKey());
		vo.setColumnType(ColumnType.byXmlName(columnDefinition.getColumnDefinitionType()));
		vo.setOrderNumber(columnDefinition.getOrderNumber());
		if (ColumnType.REFERENCE.getXmlColumnType().equals(columnDefinition.getColumnDefinitionType())) {
			vo.setReferenceTable(((SdmReferenceType) columnDefinition.getType()).getReferenceTable());
		} else if (ColumnType.MODEL_REFERENCE.getXmlColumnType().equals(columnDefinition.getColumnDefinitionType())) {
			vo.setReferenceTable(((SdmModelReferenceType) columnDefinition.getType()).getReferenceTable());
		}
		return vo;
	}

	private boolean hasVersioning(Map<String, ColumnDefinition> columnDefinitionMap) {
		// The assumption is a table is considered versioned if the 2nd and 3rd columns are effective resp. end date
		final ColumnDefinition effectiveDate = columnDefinitionMap.get("EFF_DT");
		final ColumnDefinition endDate = columnDefinitionMap.get("END_DT");
		return effectiveDate != null && effectiveDate.getOrderNumber() == 2 &&
				endDate != null && endDate.getOrderNumber() == 3;
	}

}
