package com.ing.grdm.api.domain;

import com.fasterxml.jackson.annotation.JsonRootName;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Exception Response returned as Json/xml object when exceptions are thrown
 */
@XmlRootElement
@XmlType(propOrder = {"code", "message"})
@JsonRootName(value = "error")
@XmlAccessorType(XmlAccessType.FIELD)
public class GrdmApiExceptionResponse {
	@XmlElement(name = "code")
	private int code;
	@XmlElement(name = "message")
	private String message;

	public GrdmApiExceptionResponse() {
	}

	public GrdmApiExceptionResponse(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
