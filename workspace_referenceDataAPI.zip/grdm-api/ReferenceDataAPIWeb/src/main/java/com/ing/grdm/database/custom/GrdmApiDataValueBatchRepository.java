package com.ing.grdm.database.custom;

import com.ing.grdm.domain.ApiDataValue;

import java.util.Collection;

/**
 * Extension on CRUD operations for {@link ApiDataValue}
 */
public interface GrdmApiDataValueBatchRepository {

	/**
	 * Inserts data values in bulk. Note update is not supported.
	 *
	 * @param dataValues the data values to insert
	 * @return the inserted data values
	 */
	Collection<ApiDataValue> bulkInsert(Collection<ApiDataValue> dataValues);
}
