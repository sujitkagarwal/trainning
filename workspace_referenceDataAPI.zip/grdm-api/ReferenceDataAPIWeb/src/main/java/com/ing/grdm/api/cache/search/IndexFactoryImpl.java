package com.ing.grdm.api.cache.search;

import org.apache.commons.io.IOUtils;
import org.apache.lucene.facet.taxonomy.TaxonomyWriter;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Factory bean responsible for creating Lucene kind of objects like {@link IndexReader}, {@link IndexWriter},etc.
 * It's stateful because its operations depend on the directories for the index itself and taxonomy.
 * Using this factory enables using mock objects for unit testing of {@link AbstractCache}.
 */
@Component
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class IndexFactoryImpl implements IndexFactory {

	@Autowired
	@Qualifier("cacheDirectory")
	private Directory directory;

	@Autowired
	@Qualifier("taxonomyDirectory")
	private Directory taxonomyDirectory;

	@Override
	public IndexWriter createIndexWriter(boolean recreate) throws IOException {
		final IndexWriterConfig.OpenMode openMode = recreate
				? IndexWriterConfig.OpenMode.CREATE
				: IndexWriterConfig.OpenMode.CREATE_OR_APPEND;
		return new IndexWriter(this.directory, new IndexWriterConfig().setOpenMode(openMode));
	}

	@Override
	public TaxonomyWriter createTaxonomyWriter(boolean recreate) throws IOException {
		final IndexWriterConfig.OpenMode openMode = recreate
				? IndexWriterConfig.OpenMode.CREATE
				: IndexWriterConfig.OpenMode.CREATE_OR_APPEND;
		return new DirectoryTaxonomyWriter(this.taxonomyDirectory, openMode);
	}

	@Override
	public DirectoryReader createIndexReader(DirectoryReader indexReader) throws IOException {
		final DirectoryReader newIndexReader;
		if (indexReader == null) {
			newIndexReader = DirectoryReader.open(this.directory);
		} else {
			newIndexReader = DirectoryReader.openIfChanged(indexReader);
		}
		return newIndexReader;
	}

	@Override
	public IndexSearcher createIndexSearcher(IndexReader indexReader) {
		return new IndexSearcher(indexReader);
	}

	@Override
	public void closeDirectories() {
		IOUtils.closeQuietly(this.directory);
		IOUtils.closeQuietly(this.taxonomyDirectory);
	}
}
