package com.ing.grdm.distro.domain.type;

import com.ing.grdm.distro.domain.SdmDomainValue;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

import java.util.List;

/**
 * Represents a domain type column definition in the SDM distribution
 */
public class SdmDomainType implements SdmType {

	@XStreamImplicit
	private List<SdmDomainValue> domainValues;

	public List<SdmDomainValue> getDomainValues() {
		return domainValues;
	}
}
