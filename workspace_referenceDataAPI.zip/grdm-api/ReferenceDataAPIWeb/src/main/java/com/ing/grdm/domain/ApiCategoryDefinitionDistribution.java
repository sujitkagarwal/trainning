package com.ing.grdm.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import java.util.Date;

/**
 * Represents a record in the GRDM_API_CAT_DEF_DISTRO table
 */
@Entity
@Table(name = "GRDM_API_CAT_DEF_DISTRO")
@IdClass(ApiCategoryDefinitionDistributionId.class)
public class ApiCategoryDefinitionDistribution {

	@Id
	@Column(name = "CATEGORY_DEFINITION_ID")
	private Long categoryDefinitionId;

	@Id
	@Column(name = "DISTRIBUTION_SEQ_NR")
	private Integer distributionSequenceNumber;

	@Column(name = "FILE_NAME")
	private String fileName;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "IMPORT_DATE")
	private Date importDate;

	@Column(name = "LAST_UPDATE_DATE")
	Date lastUpdateDate;

	public Long getCategoryDefinitionId() {
		return categoryDefinitionId;
	}

	public void setCategoryDefinitionId(Long categoryDefinitionId) {
		this.categoryDefinitionId = categoryDefinitionId;
	}

	public Integer getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}

	public void setDistributionSequenceNumber(Integer distributionSequenceNumber) {
		this.distributionSequenceNumber = distributionSequenceNumber;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public DistributionImportStatus getStatus() {
		return DistributionImportStatus.valueOf(this.status);
	}

	public void setStatus(DistributionImportStatus status) {
		this.status = status.name();
	}

	public Date getImportDate() {
		return importDate;
	}

	public void setImportDate(Date importDate) {
		this.importDate = importDate;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
}
