package com.ing.grdm.api.controller;

import com.ing.grdm.api.response.MappingsResponseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Reference data controller for Mappings
 */
@RestController
@RequestMapping(value = "/mappings", produces = MediaType.APPLICATION_JSON_VALUE)
public class GrdmApiMappingsDataController {

	@Autowired
	private MappingsResponseService mappingsResponseService;

	@RequestMapping(value = "/global/{tableName}/{systemCode}/{localCode}", method = RequestMethod.GET)
	public void globalCodeByLocalCode(@PathVariable("tableName") String distributionName,
									  @PathVariable("systemCode") String systemCode,
									  @PathVariable("localCode") String localCode,
									  HttpServletResponse response) throws IOException {
		this.mappingsResponseService.respondGlobalByLocal(distributionName, systemCode, localCode, response);
	}

	@RequestMapping(value = "/global/{tableName}/{systemCode}", method = RequestMethod.GET)
	public void globalCodesBySystemCode(@PathVariable("tableName") String distributionName,
										@PathVariable("systemCode") String systemCode,
										HttpServletResponse response) throws IOException {
		this.mappingsResponseService.respondAllGlobalByLocal(distributionName, systemCode, response);
	}

	@RequestMapping(value = "/local/{tableName}/{systemCode}/{globalCode}", method = RequestMethod.GET)
	public void localCodesByGlobalCode(@PathVariable("tableName") String distributionName,
									   @PathVariable("systemCode") String systemCode,
									   @PathVariable("globalCode") String globalCode,
									   HttpServletResponse response) throws IOException {
		this.mappingsResponseService.respondLocalByGlobal(distributionName, systemCode, globalCode, response);
	}

	@RequestMapping(value = "/local/{tableName}/{systemCode}", method = RequestMethod.GET)
	public void localCodesBySystemCode(@PathVariable("tableName") String distributionName,
									   @PathVariable("systemCode") String systemCode,
									   HttpServletResponse response) throws IOException {
		this.mappingsResponseService.respondAllLocalByGlobal(distributionName, systemCode, response);
	}
}
