package com.ing.grdm.event;

/**
 * Application event notifying listeners that overstap data has changed
 */

public class OverstapDataChangedEvent {

	private Integer distributionSequenceNumber;

	public OverstapDataChangedEvent() {
	}

	/**
	 * @param distributionSequenceNumber distribution sequence number initiating this event
	 */
	public OverstapDataChangedEvent(Integer distributionSequenceNumber) {
		this.distributionSequenceNumber = distributionSequenceNumber;
	}

	public Integer getDistributionSequenceNumber() {
		return distributionSequenceNumber;
	}
}
