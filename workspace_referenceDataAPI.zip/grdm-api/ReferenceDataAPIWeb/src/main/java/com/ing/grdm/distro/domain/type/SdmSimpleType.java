package com.ing.grdm.distro.domain.type;

/**
 * Represents a column definition without any attributes or children in the SDM distribution
 */
public class SdmSimpleType implements SdmType {
}
