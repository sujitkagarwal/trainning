package com.ing.grdm.api.cache.search;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.facet.FacetField;
import org.apache.lucene.facet.FacetQuery;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BoostQuery;
import org.springframework.stereotype.Component;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The business key cache
 */
@Component
public class BusinessKeyCache extends AbstractCache {
	@Override
	protected List<String> getFacets() {
		return Arrays.asList(TABLE_DISTRO_NAME, BUSINESS_KEY);
	}

	public void addDocument(String businessKey, String distributionName) {
		final Document document = new Document();

		document.add(new StringField(BUSINESS_KEY, businessKey, Field.Store.YES));
		document.add(new TextField("businessKey", businessKey, Field.Store.NO));
		document.add(new StoredField(TABLE_DISTRO_NAME, distributionName));
		document.add(new FacetField(BUSINESS_KEY, businessKey.split("\\|")));
		document.add(new FacetField(TABLE_DISTRO_NAME, distributionName));

		addDocument(document);
	}

	public void deleteDocument(String businessKey, String distributionName) {
		final BooleanQuery query = new BooleanQuery.Builder()
				.add(new FacetQuery(BUSINESS_KEY, businessKey.split("\\|")), BooleanClause.Occur.MUST)
				.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName), BooleanClause.Occur.MUST)
				.build();

		deleteDocument(query);
	}

	public List<Map<String, Object>> search(String searchString, String distributionName) {
		final FuzzyQuery fuzzyQuery = new FuzzyQuery(new Term("businessKey", searchString.toLowerCase()));
		final TermQuery termQuery = new TermQuery(new Term(BUSINESS_KEY, searchString));

		final BooleanQuery inner = new BooleanQuery.Builder()
				.add(new BoostQuery(termQuery, 2.0f), BooleanClause.Occur.SHOULD)
				.add(fuzzyQuery, BooleanClause.Occur.SHOULD)
				.build();

		if (distributionName == null) {
			return search(inner);
		}

		final BooleanQuery.Builder builder = new BooleanQuery.Builder();
		builder.add(inner, BooleanClause.Occur.MUST);
		builder.add(new FacetQuery(TABLE_DISTRO_NAME, distributionName.toLowerCase()), BooleanClause.Occur.MUST);

		return search(builder.build());
	}

	@Override
	protected List<Map<String, Object>> addLinks(Document document) {
		return Collections.singletonList(Stream.of(
				new SimpleEntry<String, Object>("rel", "self"),
				new SimpleEntry<String, Object>("href", new StringJoiner("/", "/", "")
						.add("attributes")
						.add(document.get(TABLE_DISTRO_NAME))
						.add(document.get(BUSINESS_KEY)).toString())
		).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));
	}
}
