package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.ing.grdm.domain.ApiDataValue;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * Class responsible for serializing attributes data
 */
@Component
public class AttributesDataSerializer {

	private static final String BUSINESS_KEY = "business_key";
	private static final String EFFECTIVE_DATE = "eff_dt";
	private static final String END_DATE = "end_dt";

	@Autowired
	private JsonFactory jsonFactory;

	/**
	 * Generates a response containing all business keys
	 *
	 * @param outputStream  the output stream object
	 * @param tableData     the list of versions of all business keys
	 * @param hasVersioning indicates the data to serialize is for a versioned table
	 * @throws IOException when failed to write to the output stream
	 */
	public void serializeBusinessKeys(OutputStream outputStream, List<ApiDataValue> tableData, boolean hasVersioning)
			throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(outputStream, JsonEncoding.UTF8)) {
			jsonGenerator.writeStartArray();
			for (ApiDataValue dataValue : tableData) {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField(BUSINESS_KEY, dataValue.getBusinessKey());
				if (hasVersioning) {
					jsonGenerator.writeObjectField(EFFECTIVE_DATE, dataValue.getEffectiveDate());
					jsonGenerator.writeObjectField(END_DATE, dataValue.getEndDate());
				}
				jsonGenerator.writeEndObject();
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing table data for given columns
	 *
	 * @param outputStream  the output stream object
	 * @param tableData     the table data, list of versions grouped by business key
	 * @param hasVersioning indicates the data to serialize is for a versioned table
	 * @param columns       the optional list of columns
	 * @throws IOException when failed to write to the writer
	 */
	public void serializeTableData(OutputStream outputStream, Map<String, Collection<Map<String, Object>>> tableData,
								   boolean hasVersioning, List<String> columns) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(outputStream, JsonEncoding.UTF8)) {
			jsonGenerator.writeStartArray();
			for (Map.Entry<String, Collection<Map<String, Object>>> entry : tableData.entrySet()) {
				for (Map<String, Object> value : entry.getValue()) {
					serializeRowData(jsonGenerator, entry.getKey(), value, hasVersioning, columns);
				}
			}
			jsonGenerator.writeEndArray();
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing row data for given business key and columns
	 *
	 * @param outputStream  the output stream object
	 * @param businessKey   the list of business keys
	 * @param rowData       the row data
	 * @param hasVersioning indicates the data to serialize is for a versioned table
	 * @param columns       the optional list of columns
	 * @throws IOException when failed to write to the output stream
	 */
	public void serializeRowData(OutputStream outputStream, String businessKey, Map<String, Object> rowData,
								 boolean hasVersioning, List<String> columns) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(outputStream, JsonEncoding.UTF8)) {
			serializeRowData(jsonGenerator, businessKey, rowData, hasVersioning, columns);
			jsonGenerator.flush();
		}
	}

	/**
	 * Generates a response containing row/table data for given business key and columns
	 *
	 * @param outputStream  the output stream object
	 * @param tableData     all values
	 * @param isTableData   indicates if the table data contains multiple rows
	 * @param hasVersioning indicates the data to serialize is for a versioned table
	 * @throws IOException when failed to write to the output stream
	 */
	public void serializeRowData(OutputStream outputStream, List<ApiDataValue> tableData, boolean isTableData,
								 boolean hasVersioning) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(outputStream, JsonEncoding.UTF8)) {
			if (isTableData) {
				jsonGenerator.writeStartArray();
				String currentBusinessKey = null;
				Integer currentTechnicalVersion = null;
				for (ApiDataValue apiDataValue : tableData) {
					if (!StringUtils.equals(currentBusinessKey, apiDataValue.getBusinessKey()) ||
							(currentTechnicalVersion != null && currentTechnicalVersion != apiDataValue.getTechnicalVersion())) {
						if (currentBusinessKey != null) {
							jsonGenerator.writeEndObject();
						}
						jsonGenerator.writeStartObject();
						jsonGenerator.writeStringField(BUSINESS_KEY, apiDataValue.getBusinessKey());
						if (hasVersioning) {
							jsonGenerator.writeObjectField(EFFECTIVE_DATE, apiDataValue.getEffectiveDate());
							jsonGenerator.writeObjectField(END_DATE, apiDataValue.getEndDate());
						}
						currentBusinessKey = apiDataValue.getBusinessKey();
						currentTechnicalVersion = apiDataValue.getTechnicalVersion();
					}
					if (!hasVersioning || (!apiDataValue.getColumnName().equalsIgnoreCase(EFFECTIVE_DATE) &&
							!apiDataValue.getColumnName().equalsIgnoreCase(END_DATE))) {
						jsonGenerator.writeFieldName(apiDataValue.getColumnName().toLowerCase());
						jsonGenerator.writeObject(getColumnNameWithAppropriateDataType(apiDataValue));
					}
				}
				jsonGenerator.writeEndObject();
				jsonGenerator.writeEndArray();
			} else {
				jsonGenerator.writeStartObject();
				jsonGenerator.writeStringField(BUSINESS_KEY, tableData.get(0).getBusinessKey());
				if (hasVersioning) {
					jsonGenerator.writeObjectField(EFFECTIVE_DATE, tableData.get(0).getEffectiveDate());
					jsonGenerator.writeObjectField(END_DATE, tableData.get(0).getEndDate());
				}
				for (ApiDataValue apiDataValue : tableData) {
					if (hasVersioning && (EFFECTIVE_DATE.equals(apiDataValue.getColumnName()) ||
							END_DATE.equals(apiDataValue.getColumnName()))) {
						continue;
					}
					jsonGenerator.writeFieldName(apiDataValue.getColumnName().toLowerCase());
					jsonGenerator.writeObject(getColumnNameWithAppropriateDataType(apiDataValue));
				}
				jsonGenerator.writeEndObject();
				jsonGenerator.flush();
			}
		}
	}

	/**
	 * Creates an object of the appropriate type for given data value
	 *
	 * @param apiDataValue the data value
	 * @return the object
	 */
	public static Object getColumnNameWithAppropriateDataType(ApiDataValue apiDataValue) {
		switch (apiDataValue.getColumnType()) {
			case NUMBER:
			case PERCENTAGE:
				return Double.valueOf(apiDataValue.getStorageString());
			case REFERENCE:
			case MODEL_REFERENCE:
				return new ReferenceVo(apiDataValue.getStorageString(), apiDataValue.getReferenceTable().toLowerCase());
			case DATE:
				// For date column type the storage string is already according yyyy-MM-dd
			default:
				return apiDataValue.getStorageString();
		}
	}

	private void serializeRowData(JsonGenerator jsonGenerator, String businessKey, Map<String, Object> rowData,
								  boolean hasVersioning, List<String> columns) throws IOException {
		jsonGenerator.writeStartObject();
		jsonGenerator.writeStringField(BUSINESS_KEY, businessKey);
		if (hasVersioning) {
			jsonGenerator.writeObjectField(EFFECTIVE_DATE, rowData.get(EFFECTIVE_DATE));
			jsonGenerator.writeObjectField(END_DATE, rowData.get(END_DATE));
		}
		for (Map.Entry<String, Object> dataValue : rowData.entrySet()) {
			if (hasVersioning && (EFFECTIVE_DATE.equals(dataValue.getKey()) || END_DATE.equals(dataValue.getKey()))) {
				continue;
			}
			if (columns == null || columns.isEmpty() || columns.parallelStream().anyMatch(s -> s.equalsIgnoreCase(dataValue.getKey()))) {
				jsonGenerator.writeObjectField(dataValue.getKey(), dataValue.getValue());
			}
		}
		jsonGenerator.writeEndObject();
	}
}
