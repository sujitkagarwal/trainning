package com.ing.grdm.api.response;

import com.ing.grdm.api.cache.MappingsDataCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Implementation of {@link MappingsResponseService} using cached data
 */
@Component
public class CachedMappingsResponseService extends AbstractResponseService implements MappingsResponseService {

	@Autowired
	private MappingsDataCache mappingsDataCache;
	@Autowired
	private MappingsDataSerializer mappingsDataSerializer;

	@Override
	public void respondGlobalByLocal(String distributionName,
									 String systemCode,
									 String code,
									 HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, systemCode, code, response)) {
			final String mappedCode = this.mappingsDataCache.getGlobalByLocal(distributionName, systemCode, code);
			if (mappedCode == null) {
				if (!this.mappingsDataCache.containsDistributionNameForLocal(distributionName)) {
					generateTableNotFoundResponse(distributionName, response);
				} else if (!this.mappingsDataCache.containsSystemCodeForLocal(distributionName, systemCode)) {
					generateNotFoundResponse(String.format("No mappings found for system code %s in table %s",
							systemCode, distributionName), response);
				} else {
					generateNotFoundResponse(String.format("No mapping found for code %s and system code %s in table %s",
							code, systemCode, distributionName), response);
				}
			} else {
				prepareResponse(response, null);
				this.mappingsDataSerializer.serializeGlobalCode(response.getWriter(), distributionName, mappedCode);
			}
		}
	}

	@Override
	public void respondAllGlobalByLocal(String distributionName, String systemCode, HttpServletResponse response) throws IOException {
		if (validateInput(distributionName, systemCode, response)) {
			final Map<String, String> mappings = this.mappingsDataCache.getAllGlobalByLocal(distributionName, systemCode);
			if (mappings.isEmpty()) {
				if (!this.mappingsDataCache.containsDistributionNameForLocal(distributionName)) {
					generateTableNotFoundResponse(distributionName, response);
				} else {
					generateNotFoundResponse(String.format("No mappings found for system code %s in table %s",
							systemCode, distributionName), response);
				}
			} else {
				prepareResponse(response, null);
				this.mappingsDataSerializer.serializeGlobalMappings(response.getWriter(), mappings);
			}
		}
	}

	@Override
	public void respondLocalByGlobal(String distributionName,
									 String systemCode,
									 String code,
									 HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, systemCode, code, response)) {
			final List<String> mappedCodes = this.mappingsDataCache.getLocalByGlobal(distributionName, systemCode, code);
			if (mappedCodes.isEmpty()) {
				if (!this.mappingsDataCache.containsDistributionNameForGlobal(distributionName)) {
					generateTableNotFoundResponse(distributionName, response);
				} else if (!this.mappingsDataCache.containsSystemCodeForGlobal(distributionName, systemCode)) {
					generateNotFoundResponse(String.format("No mappings found for system code %s in table %s",
							systemCode, distributionName), response);
				} else {
					generateNotFoundResponse(String.format("No mappings found for code %s and system code %s in table %s",
							code, systemCode, distributionName), response);
				}
			} else {
				prepareResponse(response, null);
				this.mappingsDataSerializer.serializeLocalCodes(response.getWriter(), mappedCodes);
			}
		}
	}

	@Override
	public void respondAllLocalByGlobal(String distributionName, String systemCode, HttpServletResponse response) throws IOException {
		if (validateInput(distributionName, systemCode, response)) {
			final Map<String, List<String>> mappings = this.mappingsDataCache.getAllLocalByGlobal(distributionName, systemCode);
			if (mappings.isEmpty()) {
				if (!this.mappingsDataCache.containsDistributionNameForGlobal(distributionName)) {
					generateTableNotFoundResponse(distributionName, response);
				} else {
					generateNotFoundResponse(String.format("No mappings found for system code %s in table %s",
							systemCode, distributionName), response);
				}
			} else {
				prepareResponse(response, null);
				this.mappingsDataSerializer.serializeLocalMappings(response.getWriter(), mappings);
			}
		}
	}

	private boolean validateInput(String distributionName, String systemCode, HttpServletResponse response) throws IOException {
		boolean result = false;
		if (!isValidTableName(distributionName)) {
			generateBadRequestResponse("Invalid table name provided", response);
		} else if (!isValidSystemCode(systemCode)) {
			generateBadRequestResponse("Invalid system code provided", response);
		} else {
			result = true;
		}
		return result;
	}

	private boolean validateInput(String distributionName, String systemCode, String code, HttpServletResponse response)
			throws IOException {
		if (validateInput(distributionName, systemCode, response) && isValidValue(code)) {
			return true;
		} else {
			generateBadRequestResponse("Invalid code provided", response);
			return false;
		}
	}

}
