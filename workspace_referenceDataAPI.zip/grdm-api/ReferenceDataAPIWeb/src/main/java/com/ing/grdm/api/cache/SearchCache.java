package com.ing.grdm.api.cache;

import com.ing.grdm.api.cache.search.AbstractCache;
import com.ing.grdm.api.cache.search.BusinessKeyCache;
import com.ing.grdm.api.cache.search.CacheReadException;
import com.ing.grdm.api.cache.search.CacheWriteException;
import com.ing.grdm.api.cache.search.ColumnNameCache;
import com.ing.grdm.api.cache.search.TableNameCache;
import com.ing.grdm.api.cache.search.ValueCache;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.itrf.sdm.common.beans.structure.CategoryDefinition;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

/**
 * The search cache
 */
@Component
public class SearchCache {

	private static final Log LOG = LogFactory.getLog(SearchCache.class);

	@Value("${grdm.cache.categories.include:}")
	private String[] includedCategories;

	@Value("${grdm.cache.categories.exclude:}")
	private String[] excludedCategories;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private TableNameCache tableNameCache;
	@Autowired
	private ColumnNameCache columnNameCache;
	@Autowired
	private BusinessKeyCache businessKeyCache;
	@Autowired
	private ValueCache valueCache;

	private List<AbstractCache> registeredCaches = new ArrayList<>();

	private Integer currentDistributionSequenceNumber = null;

	@PostConstruct
	@SuppressWarnings("unused")
	void init() {
		LOG.info("Included categories in cache " + Stream.of(this.includedCategories).collect(Collectors.joining(",")));
		LOG.info("Excluded categories in cache " + Stream.of(this.excludedCategories).collect(Collectors.joining(",")));
		this.registeredCaches.add(this.tableNameCache);
		this.registeredCaches.add(this.columnNameCache);
		this.registeredCaches.add(this.businessKeyCache);
		this.registeredCaches.add(this.valueCache);

		final Integer distributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();
		reload(distributionSequenceNumber, false);
	}

	@EventListener
	@SuppressWarnings("unused")
	void handleAttributesDataChangedEvent(AttributesDataChangedEvent event) {
		if (event.getDistributionSequenceNumber() == null) {
			LOG.info("Reloading attributes data cache after receiving event");
			final Integer distributionSequenceNumber = this.categoryDefinitionRepository.getActiveDistributionSequenceNumber();
			reload(distributionSequenceNumber, event.isRecreate());
		} else if (!event.getDistributionSequenceNumber().equals(this.currentDistributionSequenceNumber)) {
			reload(event.getDistributionSequenceNumber(), event.isRecreate());
			LOG.info(String.format("Reloading attributes data cache after receiving event, new distribution sequence number %d",
					event.getDistributionSequenceNumber()));
		}
	}

	public List<Map<String, Object>> searchDistributionName(String searchString) {
		return this.tableNameCache.search(searchString);
	}

	public List<Map<String, Object>> searchBusinessKey(String searchString, String distributionName) {
		return this.businessKeyCache.search(searchString, distributionName);
	}

	public List<Map<String, Object>> searchColumnName(String searchString, String distributionName) {
		return this.columnNameCache.search(searchString, distributionName);
	}

	public List<Map<String, Object>> searchValue(String searchString, String distributionName,
												 String columnName, String businessKey) {
		return this.valueCache.search(searchString, distributionName, columnName, businessKey);
	}

	private void reload(final Integer distributionSequenceNumber, final boolean recreate) {
		try {
			this.registeredCaches.forEach(cache -> cache.openForWriting(recreate));
		} catch (IllegalStateException ise) {
			LOG.warn("Reloading cache in progress");
			return;
		} catch (CacheWriteException cle) {
			// Resetting the current distribution number so reloading will re-attempted
			this.currentDistributionSequenceNumber = null;
			LOG.error("Failed to load cache", cle);
			return;
		}

		try {
			indexDocs(distributionSequenceNumber);

			this.registeredCaches.forEach(AbstractCache::commitWriting);

			this.currentDistributionSequenceNumber = distributionSequenceNumber;
		} catch (CacheWriteException cle) {
			// Resetting the current distribution number so reloading will re-attempted
			this.currentDistributionSequenceNumber = null;
			this.registeredCaches.forEach(AbstractCache::rollbackWriting);
			LOG.error("Failed to load cache", cle);
			return;
		} finally {
			this.registeredCaches.forEach(AbstractCache::closeAfterWriting);
		}

		try {
			this.registeredCaches.forEach(AbstractCache::openForReading);

			LOG.info(String.format(
					"Search cache loaded with distribution sequence number %d", distributionSequenceNumber));
		} catch (CacheReadException cre) {
			// Resetting the current distribution number so reloading will re-attempted
			this.currentDistributionSequenceNumber = null;
			LOG.info("Could not open directory reader", cre);
		}
	}

	private void indexDocs(final Integer distributionSequenceNumber) {
		if (distributionSequenceNumber == null) {
			LOG.info("No categories to index because active distribution sequence number is unknown");
			return;
		}

		StreamSupport.stream(this.categoryDefinitionRepository.findAll().spliterator(), true)
				.filter(cd -> CategoryDefinition.CATEGORY_TYPE_ATTRIBUTES.equals(cd.getCategoryType()))
				.filter(cd -> distributionSequenceNumber.equals(cd.getActiveDistributionSequenceNumber()))
				.filter(cd -> Arrays.stream(this.excludedCategories)
						.noneMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
				.filter(cd -> this.includedCategories.length == 0 || Arrays.stream(this.includedCategories)
						.anyMatch(s -> s.equalsIgnoreCase(cd.getDistributionName())))
				.forEach(cd -> indexCategoryDefinition(cd, distributionSequenceNumber));
	}

	private void indexCategoryDefinition(
			ApiCategoryDefinition categoryDefinition, Integer distributionSequenceNumber) {
		LOG.info("Adding category " + categoryDefinition.getDistributionName());
		final List<ApiDataValue> rowData = this.dataValueRepository.getAllRowData(categoryDefinition.getTechnicalId(),
				distributionSequenceNumber);
		final String distributionName = categoryDefinition.getDistributionName().toLowerCase();

		this.tableNameCache.addDocument(distributionName);

		rowData.parallelStream()
				.forEach(dv -> this.valueCache.addDocument(
						dv,
						distributionName));

		rowData.parallelStream()
				.collect(Collectors.groupingBy(ApiDataValue::getColumnName))
				.keySet()
				.forEach(columnName -> this.columnNameCache.addDocument(columnName.toLowerCase(), distributionName));

		rowData.parallelStream()
				.collect(Collectors.groupingBy(ApiDataValue::getBusinessKey))
				.keySet()
				.forEach(businessKey -> this.businessKeyCache.addDocument(businessKey, distributionName));
	}

}
