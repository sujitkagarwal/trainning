package com.ing.grdm.api.controller;

import com.ing.grdm.api.cache.AttributesDataCache;
import com.ing.grdm.api.cache.MappingsDataCache;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 * Health check controller
 */
@RestController
@RequestMapping("healthcheck")
@ConditionalOnProperty("grdm.cache.enabled")
public class GrdmApiHealthCheckController {

	private static final Log LOG = LogFactory.getLog(GrdmApiHealthCheckController.class);

	@Autowired
	private AttributesDataCache attributesDataCache;

	@Autowired
	private MappingsDataCache mappingsDataCache;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@ExceptionHandler(RuntimeException.class)
	@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
	void exceptionHandler(RuntimeException re) {
		LOG.error(String.format("Health check failed with message %s", re.getMessage()), re);
	}

	@RequestMapping
	ResponseEntity<Void> healthCheck() {
		// Perform some checks on cache and database
		final HttpStatus status = this.attributesDataCache.containsTable("country")
				&& this.mappingsDataCache.containsDistributionNameForGlobal("country")
				&& this.categoryDefinitionRepository.getActiveDistributionSequenceNumber() != null
				? HttpStatus.OK : HttpStatus.SERVICE_UNAVAILABLE;

		return new ResponseEntity<>(status);
	}
}
