package com.ing.grdm.api.controller;

import com.ing.grdm.api.response.SearchResponseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * The Search API controller
 */
@RestController
@RequestMapping("/attributes/search")
@SuppressWarnings("unused")
public class GrdmApiSearchController {

	@Autowired
	private SearchResponseService responseService;

	@RequestMapping(value = "/table/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchTableName(@PathVariable(name = "searchString") String searchString,
													 HttpServletResponse response, HttpServletRequest request) throws IOException {
		return this.responseService.respondSearchTableName(searchString, response);
	}

	@RequestMapping(value = "/businesskey/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchBusinessKey(@PathVariable(name = "searchString") String searchString,
													   HttpServletResponse response) throws IOException {
		return this.responseService.respondSearchBusinessKey(searchString, null, response);
	}

	@RequestMapping(value = "/businesskey/{tableName}/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchBusinessKeyInTable(@PathVariable(name = "tableName") String tableName,
															  @PathVariable(name = "searchString") String searchString,
															  HttpServletResponse response) throws IOException {
		return this.responseService.respondSearchBusinessKey(searchString, tableName, response);
	}

	@RequestMapping(value = "/column/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchColumnName(@PathVariable(name = "searchString") String searchString,
													  HttpServletResponse response) throws IOException {
		return this.responseService.respondSearchColumnName(searchString, null, response);
	}

	@RequestMapping(value = "/column/{tableName}/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchColumnName(@PathVariable(name = "tableName") String distributionName,
													  @PathVariable(name = "searchString") String searchString,
													  HttpServletResponse response) throws IOException {
		return this.responseService.respondSearchColumnName(searchString, distributionName, response);
	}

	@RequestMapping(value = "/value/{searchString}", method = RequestMethod.GET)
	public List<Map<String, Object>> searchValue(@PathVariable(name = "searchString") String searchString,
												 @RequestParam(name = "tableName", required = false) String distributionName,
												 @RequestParam(name = "column", required = false) String columnName,
												 @RequestParam(name = "businessKey", required = false) String businessKey,
												 HttpServletResponse response) throws IOException {
		return this.responseService.respondSearchValue(searchString, distributionName, columnName, businessKey, response);
	}

}
