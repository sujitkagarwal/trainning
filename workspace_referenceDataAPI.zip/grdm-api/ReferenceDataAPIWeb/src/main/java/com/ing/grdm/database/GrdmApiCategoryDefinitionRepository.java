package com.ing.grdm.database;

import com.ing.grdm.domain.ApiCategoryDefinition;
import io.swagger.annotations.Api;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * Repository definition for the GRDM_API_CATEGORY_DEFINITION table
 */
public interface GrdmApiCategoryDefinitionRepository extends CrudRepository<ApiCategoryDefinition, Long> {

	/**
	 * @param distributionName the distribution name of the category definition
	 * @param categoryType the type of the category definition
	 * @return Returns the category definition for given distribution name and category type
	 */
	ApiCategoryDefinition findByDistributionNameAndCategoryType(String distributionName, String categoryType);

	/**
	 * @param distributionName the distribution name of the category definition
	 * @return Returns the Attributes category definition for given distribution name
	 */
	@Query("from ApiCategoryDefinition where categoryType = 'Attributes' and distributionName = ?1")
	ApiCategoryDefinition findAttributesCategoryByDistributionName(String distributionName);

	/**
	 * @param distributionName the distribution name of the category definition
	 * @return Returns the Mappings category definition for given distribution name
	 */
	@Query("from ApiCategoryDefinition where categoryType = 'Mappings' and distributionName = ?1")
	ApiCategoryDefinition findMappingsCategoryByDistributionName(String distributionName);

	/**
	 * Determines the active distribution sequence number by getting the max from the database.
	 * The active distribution number is atomically updated when distribution job completes.
	 *
	 * @return the active distribution sequence number
	 */
	@Query("select max(activeDistributionSequenceNumber) from ApiCategoryDefinition")
	Integer getActiveDistributionSequenceNumber();
}
