package com.ing.grdm.distro.domain.converter;

import com.ing.grdm.distro.domain.SdmColumnDefinition;
import com.ing.grdm.distro.domain.type.SdmDomainType;
import com.ing.grdm.distro.domain.type.SdmHierarchyType;
import com.ing.grdm.distro.domain.type.SdmModelReferenceType;
import com.ing.grdm.distro.domain.type.SdmMultiReferenceRowType;
import com.ing.grdm.distro.domain.type.SdmMultiReferenceTableType;
import com.ing.grdm.distro.domain.type.SdmNumberType;
import com.ing.grdm.distro.domain.type.SdmRangeType;
import com.ing.grdm.distro.domain.type.SdmReferenceType;
import com.ing.grdm.distro.domain.type.SdmSimpleType;
import com.ing.grdm.distro.domain.type.SdmStringType;
import com.ing.grdm.distro.domain.type.SdmType;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Custom converter for columndefinition tag in the SDM distribution.
 */
public class SdmColumnDefinitionConverter implements Converter {

	private static final Log LOG = LogFactory.getLog(SdmColumnDefinitionConverter.class);

	private static final Map<String, Class<? extends SdmType>> COLUMN_DEFINITION_MAP;

	static {
		final Map<String, Class<? extends SdmType>> map = new HashMap<>();
		map.put("stringtype", SdmStringType.class);
		map.put("hierarchytype", SdmHierarchyType.class);
		map.put("referencetype", SdmReferenceType.class);
		map.put("numbertype", SdmNumberType.class);
		map.put("percentagetype", SdmNumberType.class);
		map.put("domaintype", SdmDomainType.class);
		map.put("multireferencerowtype", SdmMultiReferenceRowType.class);
		map.put("multireferencetabletype", SdmMultiReferenceTableType.class);
		map.put("modelreferencetype", SdmModelReferenceType.class);
		map.put("rangefromtype", SdmRangeType.class);
		map.put("rangeuntiltype", SdmRangeType.class);
		// Known types datetype, parametertype, modelparametertype, cdsusertype and uamusertype are SdmSimpleType
		COLUMN_DEFINITION_MAP = Collections.unmodifiableMap(map);
	}

	@Override
	public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext context) {
		// We only unmarshal
		throw new UnsupportedOperationException();
	}

	@Override
	public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext context) {
		final SdmColumnDefinition result = new SdmColumnDefinition();
		applyAttributes(reader, result);

		while (reader.hasMoreChildren()) {
			reader.moveDown();
			applyChild(reader, context, result);
			reader.moveUp();
		}

		return result;
	}

	@Override
	public boolean canConvert(Class type) {
		return SdmColumnDefinition.class.isAssignableFrom(type);
	}

	@SuppressWarnings("unchecked")
	private void applyAttributes(HierarchicalStreamReader reader, SdmColumnDefinition result) {
		for (Iterator<String> iterator = reader.getAttributeNames(); iterator.hasNext(); ) {
			final String attributeName = iterator.next();
			switch (attributeName) {
				case "name":
					result.setName(reader.getAttribute("name"));
					break;
				case "primarykey":
					result.setPrimaryKey(Boolean.valueOf(reader.getAttribute("primarykey")));
					break;
				case "mandatory":
					result.setMandatory(Boolean.valueOf(reader.getAttribute("mandatory")));
					break;
				case "mandatoryonlowest":
					result.setMandatoryOnLowest(Boolean.valueOf(reader.getAttribute("mandatoryonlowest")));
					break;
				case "ordernumber":
					result.setOrderNumber(Integer.parseInt(reader.getAttribute("ordernumber")));
					break;
				case "type":
					result.setColumnDefinitionType(reader.getAttribute("type"));
					break;
				default:
					LOG.warn(String.format("Unhandled attribute found: %s", attributeName));
			}
		}
	}

	private void applyChild(HierarchicalStreamReader reader, UnmarshallingContext context, SdmColumnDefinition result) {
		final String nodeName = reader.getNodeName();
		if ("description".equals(nodeName)) {
			result.setDescription(reader.getValue());
		} else {
			final Class<? extends SdmType> typeClass = COLUMN_DEFINITION_MAP.getOrDefault(nodeName, SdmSimpleType.class);
			result.setType((SdmType) context.convertAnother(result, typeClass));
		}
	}
}
