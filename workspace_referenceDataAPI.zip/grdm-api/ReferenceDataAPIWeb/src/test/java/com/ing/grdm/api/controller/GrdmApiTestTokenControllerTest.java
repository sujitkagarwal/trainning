package com.ing.grdm.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.api.security.trust.token.access.AccessTokenParser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit tests for {@link GrdmApiTestTokenController}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class GrdmApiTestTokenControllerTest {

	@Mock
	private ResourceLoader resourceLoader;

	@Spy
	private ObjectMapper objectMapper;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private AccessTokenParser accessTokenParser;

	@InjectMocks
	private GrdmApiTestTokenController controller;

	@Test
	@SuppressWarnings("unchecked")
	public void test() throws Exception {
		ReflectionTestUtils.setField(controller, "tokenServerUrl", "url");

		doReturn(new ClassPathResource("/token.json")).when(this.resourceLoader).getResource(anyString());
		doReturn(new ResponseEntity<>("[{" +
				"\"token_identifier\": \"string\"," +
				"\"unencrypted_access_token\": \"the_token\"" +
				"}]", HttpStatus.OK))
				.when(this.restTemplate).exchange(anyString(), any(), any(), any(Class.class));

		final MockMvc mockMvc = MockMvcBuilders.standaloneSetup(this.controller).build();

		mockMvc.perform(MockMvcRequestBuilders.get("/api/token"))
				.andExpect(status().isOk())
				.andExpect(content().string("Bearer the_token"));
	}

}
