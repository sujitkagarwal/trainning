package com.ing.grdm.database;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link GrdmJobRepository}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {GrdmDatabaseConfig.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
@Sql(executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD,
		statements = "insert into grdm_job (technical_id, job_type) values (1000, 'com.ing.grdm.database.GrdmJobRepositoryRWTest')")
public class GrdmJobRepositoryRWTest {

	@Autowired
	private GrdmJobRepository repository;

	@Test
	public void testShouldJobRun() throws InterruptedException {

		// First update should always run because hostname and last run date are null
		boolean result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_A", 2);
		assertThat(result, is(true));

		// A different host should not run the job right away
		result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_B", 2);
		assertThat(result, is(false));

		TimeUnit.SECONDS.sleep(1);

		// ... also not within one second, if timeout is two seconds
		result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_B", 2);
		assertThat(result, is(false));

		TimeUnit.SECONDS.sleep(1);

		// After two seconds it should run the job
		result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_B", 2);
		assertThat(result, is(true));

		// ... and subsequently
		result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_B", 2);
		assertThat(result, is(true));

		// The initial host should no longer run the job
		result = this.repository.shouldJobRun(GrdmJobRepositoryRWTest.class, "HOST_A", 2);
		assertThat(result, is(false));
	}

}
