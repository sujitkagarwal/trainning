package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.database.GrdmDatabaseConfig;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.domain.DistributionImportStatus;
import com.ing.grdm.scheduling.GrdmJobScheduler;
import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.URISyntaxException;
import java.time.LocalDate;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for the batch job importing SDM distributions
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {BatchConfig.class, GrdmDatabaseConfig.class, GrdmJobScheduler.class})
@DataJpaTest
@Commit
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class BatchTest {

	public static class TestConfig {
		@Bean
		JobLauncherTestUtils jobLauncherTestUtils() {
			return new JobLauncherTestUtils();
		}
	}

	@Autowired
	private JobLauncherTestUtils jobLauncher;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@After
	public void after() {
		// The job tested commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to verify the data inserted in the database by the jobs/steps
		this.categoryDefinitionRepository.deleteAll();
		this.categoryDefinitionDistributionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	@Test
	@Ignore // Worksn't because JobLauncherTestUtils cannot invoke a individual step launched by a partitioner
	public void testDataStep() throws InterruptedException, URISyntaxException {
		final String uri = Thread.currentThread().getContextClassLoader().getResource("0002_COUNTRY_Attributes.xml").toURI().toString();
		final JobParameters parameters = new JobParametersBuilder()
				.addLong("categoryDefinitionId", 2L)
				.addLong("distributionSequenceNumber", 1L)
				.addString("zipFileUri", uri)
				.toJobParameters();
		final JobExecution jobExecution = this.jobLauncher.launchStep("xmlFileStep", parameters);

		int count = 0;
		do {
			TimeUnit.SECONDS.sleep(2L);
		} while (jobExecution.isRunning() && count++ < 10);

		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());

		final List<ApiDataValue> rowData = this.dataValueRepository.getRowData(2L, 1, "NL");
		assertNotNull(rowData);
		assertFalse(rowData.isEmpty());
	}

	@Test
	public void testJob() throws Exception {
		final String uri = Thread.currentThread().getContextClassLoader().getResource("SDM_20170925_120000_1_xml.zip").toURI().toString();
		final JobParameters parameters = new JobParametersBuilder()
				.addString("zipFileUri", uri)
				.addLong("distributionSequenceNumber", 1L)
				.toJobParameters();
		final JobExecution jobExecution = this.jobLauncher.launchJob(parameters);

		int count = 0;
		do {
			TimeUnit.SECONDS.sleep(2L);
		} while (jobExecution.isRunning() && count++ < 10);

		assertEquals(BatchStatus.COMPLETED, jobExecution.getStatus());
		final ApiCategoryDefinition attributesCategoryDefinition =
				this.categoryDefinitionRepository.findAttributesCategoryByDistributionName("COUNTRY");
		assertNotNull(attributesCategoryDefinition);
		assertEquals(Integer.valueOf(1), attributesCategoryDefinition.getActiveDistributionSequenceNumber());
		assertThat(attributesCategoryDefinition.isHasVersioning(), is(false));

		final ApiCategoryDefinitionDistribution attributesCategoryDefinitionDistribution =
				this.categoryDefinitionDistributionRepository.findOne(
						new ApiCategoryDefinitionDistributionId(attributesCategoryDefinition.getTechnicalId(), 1));
		assertNotNull(attributesCategoryDefinitionDistribution);
		assertEquals(DistributionImportStatus.ACTIVE, attributesCategoryDefinitionDistribution.getStatus());

		final List<ApiDataValue> attributesTableData =
				this.dataValueRepository.getTableData(attributesCategoryDefinition.getTechnicalId(), 1);
		assertFalse(attributesTableData.isEmpty());

		final List<ApiDataValue> attributesDataValues =
				this.dataValueRepository.getRowData(attributesCategoryDefinition.getTechnicalId(), 1, "NL");
		assertNotNull(attributesDataValues);
		assertFalse(attributesDataValues.isEmpty());

		final ApiDataValue attributesDataValue = attributesDataValues.stream()
				.filter(dv -> "DOMESTIC_MACRO_RATING".equals(dv.getColumnName()))
				.findFirst()
				.orElse(null);
		assertNotNull(attributesDataValue);
		assertEquals("NL", attributesDataValue.getBusinessKey());
		assertEquals(4, attributesDataValue.getColumnOrderNumber());
		assertEquals(ColumnType.REFERENCE, attributesDataValue.getColumnType());
		assertEquals("RISK_RATING", attributesDataValue.getReferenceTable());

		final ApiCategoryDefinition mappingsCategoryDefinition =
				this.categoryDefinitionRepository.findMappingsCategoryByDistributionName("COUNTRY");
		assertThat(mappingsCategoryDefinition, is(notNullValue()));
		assertThat(mappingsCategoryDefinition.getActiveDistributionSequenceNumber(), is(1));

		final ApiCategoryDefinitionDistribution mappingsCategoryDefinitionDistribution =
				this.categoryDefinitionDistributionRepository.findOne(
						new ApiCategoryDefinitionDistributionId(mappingsCategoryDefinition.getTechnicalId(), 1));
		assertThat(mappingsCategoryDefinitionDistribution, is(notNullValue()));
		assertThat(mappingsCategoryDefinitionDistribution.getStatus(), is(DistributionImportStatus.ACTIVE));

		final List<ApiDataValue> mappingsTableData =
				this.dataValueRepository.getTableData(mappingsCategoryDefinition.getTechnicalId(), 1);
		assertThat(mappingsTableData.isEmpty(), is(false));

		final List<ApiDataValue> mappingsDataValues =
				this.dataValueRepository.getRowData(mappingsCategoryDefinition.getTechnicalId(), 1, "BSK|216");
		assertThat(mappingsDataValues, is(notNullValue()));
		assertThat(mappingsDataValues.isEmpty(), is(false));

		final ApiDataValue mappingsDataValue = mappingsDataValues.stream()
				.filter(dv -> "LOCAL_CODE".equals(dv.getColumnName()))
				.findFirst()
				.orElse(null);
		assertThat(mappingsDataValue, is(notNullValue()));
		assertThat(mappingsDataValue.getBusinessKey(), is("BSK|216"));
		assertThat(mappingsDataValue.getColumnOrderNumber(), is(2));
		assertThat(mappingsDataValue.getColumnType(), is(ColumnType.STRING));
		assertThat(mappingsDataValue.getStorageString(), is("216"));

		final ApiCategoryDefinition versionedCategoryDefinition =
				this.categoryDefinitionRepository.findAttributesCategoryByDistributionName("TEST_API_VERSION");
		assertThat(versionedCategoryDefinition, notNullValue());
		assertThat(versionedCategoryDefinition.getActiveDistributionSequenceNumber(), is(1));
		assertThat(versionedCategoryDefinition.isHasVersioning(), is(true));

		final ApiCategoryDefinitionDistribution versionedCategoryDefinitionDistribution =
				this.categoryDefinitionDistributionRepository.findOne(
						new ApiCategoryDefinitionDistributionId(versionedCategoryDefinition.getTechnicalId(), 1));
		assertThat(versionedCategoryDefinitionDistribution, is(notNullValue()));
		assertThat(versionedCategoryDefinitionDistribution.getStatus(), is(DistributionImportStatus.ACTIVE));

		final List<ApiDataValue> versionedTableData =
				this.dataValueRepository.getTableData(versionedCategoryDefinition.getTechnicalId(), 1);
		assertThat(versionedTableData, not(empty()));

		final List<ApiDataValue> versionedDataValues =
				this.dataValueRepository.getRowData(versionedCategoryDefinition.getTechnicalId(), 1, "B");
		assertThat(versionedDataValues, notNullValue());
		assertThat(versionedDataValues, not(empty()));

		final List<ApiDataValue> filteredDataValues = versionedDataValues.stream()
				.filter(dv -> "B".equals(dv.getBusinessKey()))
				.filter(dv -> "CODE".equals(dv.getColumnName()))
				.collect(Collectors.toList());
		assertThat(filteredDataValues, hasSize(3));

		ApiDataValue versionedDataValue = filteredDataValues.get(0);
		assertThat(versionedDataValue, notNullValue());
		assertThat(versionedDataValue.getBusinessKey(), is("B"));
		assertThat(versionedDataValue.getColumnOrderNumber(), is(1));
		assertThat(versionedDataValue.getColumnType(), is(ColumnType.STRING));
		assertThat(versionedDataValue.getStorageString(), is("B"));
		assertThat(versionedDataValue.getEffectiveDate(), is(LocalDate.parse("2012-05-30")));
		assertThat(versionedDataValue.getEndDate(), is(LocalDate.parse("2014-05-30")));

		versionedDataValue = filteredDataValues.get(1);
		assertThat(versionedDataValue, notNullValue());
		assertThat(versionedDataValue.getBusinessKey(), is("B"));
		assertThat(versionedDataValue.getColumnOrderNumber(), is(1));
		assertThat(versionedDataValue.getColumnType(), is(ColumnType.STRING));
		assertThat(versionedDataValue.getStorageString(), is("B"));
		assertThat(versionedDataValue.getEffectiveDate(), is(LocalDate.parse("2014-05-30")));
		assertThat(versionedDataValue.getEndDate(), is(LocalDate.parse("2016-05-30")));

		versionedDataValue = filteredDataValues.get(2);
		assertThat(versionedDataValue, notNullValue());
		assertThat(versionedDataValue.getBusinessKey(), is("B"));
		assertThat(versionedDataValue.getColumnOrderNumber(), is(1));
		assertThat(versionedDataValue.getColumnType(), is(ColumnType.STRING));
		assertThat(versionedDataValue.getStorageString(), is("B"));
		assertThat(versionedDataValue.getEffectiveDate(), is(LocalDate.parse("2016-05-30")));
		assertThat(versionedDataValue.getEndDate(), nullValue());
	}
}
