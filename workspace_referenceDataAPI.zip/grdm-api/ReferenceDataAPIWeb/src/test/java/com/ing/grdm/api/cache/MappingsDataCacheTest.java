package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link MappingsDataCache}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = {"grdm.cache.enabled=true",
		"grdm.cache.categories.exclude=gender"})
@RunWith(SpringRunner.class)
public class MappingsDataCacheTest {


	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private MappingsDataCache cache;

	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Test
	public void testReloadAndCaseSensitivity() {
		this.eventPublisher.publishEvent(new AttributesDataChangedEvent());

		// Existing local-to-global mappings
		final Map<String, String> allGlobalByLocal = this.cache.getAllGlobalByLocal("COUNTRY", "BSK");
		assertThat(allGlobalByLocal, notNullValue());
		assertThat(allGlobalByLocal.entrySet(), not(empty()));
		assertThat(allGlobalByLocal.entrySet(), hasSize(4));
		assertThat(allGlobalByLocal, hasEntry("394", "NL"));
		assertThat(allGlobalByLocal, hasEntry("NL", "NL"));
		assertThat(allGlobalByLocal, hasEntry("393", "FR"));
		assertThat(allGlobalByLocal, hasEntry("FR", "FR"));

		final String globalByLocal = this.cache.getGlobalByLocal("COUNTRY", "BSK", "394");
		assertThat(globalByLocal, is("NL"));

		// Non-existing
		assertThat(this.cache.getAllGlobalByLocal("COUNTRY", "BSL"), notNullValue());
		assertThat(this.cache.getAllGlobalByLocal("COUNTRY", "BSL").entrySet(), empty());
		assertThat(this.cache.getGlobalByLocal("COUNTRY2", "BSK", "394"), is(nullValue()));
		assertThat(this.cache.getGlobalByLocal("COUNTRY", "BSL", "394"), is(nullValue()));
		assertThat(this.cache.getGlobalByLocal("COUNTRY", "BSK", "390"), is(nullValue()));

		// Distribution name is case insensitive, system code and code are case sensitive
		assertThat(this.cache.getGlobalByLocal("country", "BSK", "NL"), is(notNullValue()));
		assertThat(this.cache.getGlobalByLocal("CouNTRy", "BSK", "NL"), is(notNullValue()));
		assertThat(this.cache.getGlobalByLocal("COUNTRY", "bsk", "NL"), is(nullValue()));
		assertThat(this.cache.getGlobalByLocal("COUNTRY", "BSK", "Nl"), is(nullValue()));

		// Existing global-to-local mappings
		final Map<String, List<String>> allLocalByGlobal = this.cache.getAllLocalByGlobal("COUNTRY", "BSK");
		assertThat(allLocalByGlobal, notNullValue());
		assertThat(allLocalByGlobal.entrySet(), not(empty()));
		assertThat(allLocalByGlobal.entrySet(), hasSize(2));
		assertThat(allLocalByGlobal, hasKey("NL"));
		assertThat(allLocalByGlobal, hasKey("FR"));
		assertThat(allLocalByGlobal.get("NL"), contains("394", "NL"));
		assertThat(allLocalByGlobal.get("FR"), contains("393", "FR"));

		final List<String> localByGlobal = this.cache.getLocalByGlobal("COUNTRY", "BSK", "NL");
		assertThat(localByGlobal, is(notNullValue()));
		assertThat(localByGlobal, not(empty()));
		assertThat(localByGlobal, contains("394", "NL"));

		// Non-existing
		assertThat(this.cache.getAllGlobalByLocal("COUNTRY", "BSL"), notNullValue());
		assertThat(this.cache.getAllGlobalByLocal("COUNTRY", "BSL").entrySet(), empty());
		assertThat(this.cache.getLocalByGlobal("COUNTRY2", "BSK", "NL"), empty());
		assertThat(this.cache.getLocalByGlobal("COUNTRY", "BSL", "NL"), empty());
		assertThat(this.cache.getLocalByGlobal("COUNTRY", "BSK", "UK"), empty());

		// Distribution name is case insensitive, system code and code are case sensitive
		assertThat(this.cache.getLocalByGlobal("country", "BSK", "NL"), not(empty()));
		assertThat(this.cache.getLocalByGlobal("CouNTRy", "BSK", "NL"), not(empty()));
		assertThat(this.cache.getLocalByGlobal("COUNTRY", "bsk", "NL"), empty());
		assertThat(this.cache.getLocalByGlobal("COUNTRY", "BSK", "Nl"), empty());

		// Gender table is excluded
		assertThat(this.cache.getGlobalByLocal("GENDER", "PDS", "1"), is(nullValue()));
		assertThat(this.cache.getLocalByGlobal("GENDER", "PDS", "M"), empty());

		// Contains methods
		assertThat(this.cache.containsDistributionNameForLocal("COUNTRY"), is(true));
		assertThat(this.cache.containsDistributionNameForLocal("GENDER"), is(false));
		assertThat(this.cache.containsSystemCodeForLocal("COUNTRY", "BSK"), is(true));
		assertThat(this.cache.containsSystemCodeForLocal("COUNTRY", "PDS"), is(false));

		assertThat(this.cache.containsDistributionNameForGlobal("COUNTRY"), is(true));
		assertThat(this.cache.containsDistributionNameForGlobal("GENDER"), is(false));
		assertThat(this.cache.containsSystemCodeForGlobal("COUNTRY", "BSK"), is(true));
		assertThat(this.cache.containsSystemCodeForGlobal("COUNTRY", "BSL"), is(false));
	}

	@Before
	public void loadApiCategoryDefinition() {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "DESCRIPTION", "Netherlands", "NL");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Mappings");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "CCRM_CODE", "NL", "BSK|394");
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "CCRM_CODE", "NL", "BSK|NL");
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "CCRM_CODE", "FR", "BSK|393");
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "CCRM_CODE", "FR", "BSK|FR");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("GENDER");
		apiCategoryDefinition.setCategoryType("Mappings");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "CCRM_CODE", "M", "PDS|1");
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String columnName, String storageString, String businessKey) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(4);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}