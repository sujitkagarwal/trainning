package com.ing.grdm.api.cache.search;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link BusinessKeyCache}
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 13-12-2017
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = SearchCacheConfig.class)
@ActiveProfiles({"businessKeyCache"})
public class BusinessKeyCacheTest {

	@Autowired
	private BusinessKeyCache businessKeyCache;

	@Test
	public void testAddAndDelete() {

		addDocument("NL", "country");
		addDocument("EUROPE", "language");
		this.businessKeyCache.openForReading();

		List<Map<String, Object>> result = this.businessKeyCache.search("NL", null);
		assertThat(result.size(), is(1));
		result = this.businessKeyCache.search("EUROPE", null);
		assertThat(result.size(), is(1));

		addDocument("NL", "language");
		this.businessKeyCache.openForReading();

		result = this.businessKeyCache.search("NL", null);
		assertThat(result.size(), is(2));
		result = this.businessKeyCache.search("NL", "language");
		assertThat(result.size(), is(1));

		deleteDocument("NL", "country");
		this.businessKeyCache.openForReading();

		result = this.businessKeyCache.search("NL", null);
		assertThat(result.size(), is(1));
	}

	private void addDocument(String businessKey, String distributionName) {
		try {
			this.businessKeyCache.openForWriting(false);
			this.businessKeyCache.addDocument(businessKey, distributionName);
			this.businessKeyCache.commitWriting();
		} finally {
			this.businessKeyCache.closeAfterWriting();
		}
	}

	private void deleteDocument(String businessKey, String distributionName) {
		try {
			this.businessKeyCache.openForWriting(false);
			this.businessKeyCache.deleteDocument(businessKey, distributionName);
			this.businessKeyCache.commitWriting();
		} finally {
			this.businessKeyCache.closeAfterWriting();
		}
	}
}
