package com.ing.grdm.api;

import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Spring Boot test application starter
 */
public class GrdmApiTestApplication extends GrdmApiApplication {

	public static void main(String[] args) {
		new SpringApplicationBuilder(GrdmApiApplication.class)
				.profiles("integration")
				.run(args);
	}
}
