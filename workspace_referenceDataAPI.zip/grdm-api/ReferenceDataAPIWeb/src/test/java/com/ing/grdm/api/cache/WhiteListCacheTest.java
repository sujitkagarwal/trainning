package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.security.config.GrdmTestConfig;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.transaction.Transactional;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * /**
 * Unit tests for {@link WhiteListCache}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = {GrdmApiTestApplication.class, GrdmTestConfig.class},
		properties = {"grdm.api.security.type=peerToken", "grdm.environment=DEV"})
@RunWith(SpringRunner.class)
@Transactional
public class WhiteListCacheTest {
	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	private String hostName[] = {"localhost-DEV-1", "localhost-DEV-2", "localhost-TST-1", "localhost-TST-2", "localhost-ACC-1", "localhost-ACC-2"};
	private String env[] = {"DEV", "TST", "ACC", "PRD"};


	@Autowired
	private WhiteListCache cache;

	@Test
	public void testWhiteListCache() {
		this.cache.init();
		assertThat(this.cache.contains(hostName[0]), is(true));
		assertThat(this.cache.contains(hostName[1]), is(true));
		assertThat(this.cache.contains(hostName[2]), is(false));
		assertThat(this.cache.contains(hostName[2]), is(false));
		assertThat(this.cache.contains(hostName[3]), is(false));
	}


	@Before
	public void loadApiCategoryDefinition() {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("GRDM_API_WL");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);

		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "DevTesting-1", hostName[0], 0);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "DevTesting-2", hostName[1], 0);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "TSTTesting-1", hostName[2], 1);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "TSTTesting-2", hostName[2], 1);

	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String businessKey, String hostname, int counter) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(businessKey);
		apiDataValue.setColumnName("CODE");
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);

		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(businessKey);
		apiDataValue.setColumnName("DSC");
		apiDataValue.setColumnOrderNumber(2);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(hostname);
		apiDataValue.setColumnName("HOSTNAME");
		apiDataValue.setColumnOrderNumber(3);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.DOMAIN);
		apiDataValue.setStorageString(env[counter]);
		apiDataValue.setColumnName("ENV");
		apiDataValue.setColumnOrderNumber(18);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);

	}
}
