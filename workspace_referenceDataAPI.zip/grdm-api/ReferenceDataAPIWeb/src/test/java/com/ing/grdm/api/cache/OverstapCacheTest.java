package com.ing.grdm.api.cache;


import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.UUID;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link OverstapCache}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.cache.overstap.enable=true")
@RunWith(SpringRunner.class)
@Transactional
public class OverstapCacheTest {

	private final String oldIban = "NL19INGB0000458973";
	private final String oldIban1 = "NL19INGB0000458975";
	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;
	@Autowired
	private OverstapCache cache;

	@Test
	public void testOverStapCache() {

		this.cache.init();
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban), LocalDate.of(2017, Month.JANUARY, 1)).size(), is(1));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban.toLowerCase()), LocalDate.of(2017, Month.JANUARY, 1)).size(), is(1));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban), LocalDate.of(2017, Month.AUGUST, 22)).size(), is(0));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban), LocalDate.of(2017, Month.AUGUST, 21)).size(), is(1));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban), LocalDate.of(2016, Month.AUGUST, 21)).size(), is(1));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban), LocalDate.of(2016, Month.AUGUST, 20)).size(), is(0));
		assertThat(this.cache.getForwardAccountsByIbansAndDate(Arrays.asList(oldIban1), LocalDate.of(2017, Month.JULY, 10)).size(), is(0));
	}

	@Before
	public void loadApiCategoryDefinition() {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("OVERSTAP_TABLE");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);

		createApiDataValue(apiCategoryDefinition.getTechnicalId(), UUID.randomUUID().toString(), "06", oldIban);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), UUID.randomUUID().toString(), "03", oldIban1);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String businessKey, String status, String oldIban) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString("P000458973");
		apiDataValue.setColumnName("BBAN_OLD");
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);

		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString("0310612306");
		apiDataValue.setColumnName("BBAN_NEW");
		apiDataValue.setColumnOrderNumber(2);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.DOMAIN);
		apiDataValue.setStorageString(status);
		apiDataValue.setColumnName("OVT_STA");
		apiDataValue.setColumnOrderNumber(3);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(oldIban);
		apiDataValue.setColumnName("IBAN_OLD");
		apiDataValue.setColumnOrderNumber(18);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString("NL80RABO0310612306");
		apiDataValue.setColumnName("IBAN_NEW");
		apiDataValue.setColumnOrderNumber(19);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);

		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString("RABONL2U");
		apiDataValue.setColumnName("BIC_NEW");
		apiDataValue.setColumnOrderNumber(6);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);


		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.DATE);
		apiDataValue.setStorageString("2016-08-21");
		apiDataValue.setColumnName("STRT_DT_EFF");
		apiDataValue.setColumnOrderNumber(16);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);

		apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString("2017-08-21");
		apiDataValue.setColumnName("EXP_DT");
		apiDataValue.setColumnOrderNumber(11);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}
