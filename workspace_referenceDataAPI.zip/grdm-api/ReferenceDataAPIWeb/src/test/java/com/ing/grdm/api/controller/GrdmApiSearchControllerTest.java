package com.ing.grdm.api.controller;

import com.google.common.collect.Maps;
import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.cache.SearchCache;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit test for {@link GrdmApiSearchController}
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 12-12-2017
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class)
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class GrdmApiSearchControllerTest {

	@Autowired
	private GrdmApiSearchController searchController;
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private SearchCache searchCache;

	@Test
	public void controllerInitializedCorrectly() {
		assertThat(searchController).isNotNull();
	}

	@Test
	public void testSearchDistributionName() throws Exception {
		when(searchCache.searchDistributionName(Mockito.anyString())).thenReturn(createDistributionNameSearchResponse());
		mockMvc.perform(get("/attributes/search/table/country"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links", is(notNullValue())))
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country")));
		verify(searchCache, times(1)).searchDistributionName(Mockito.anyString());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchDistributionName_InvalidSearchString() throws Exception {
		mockMvc.perform(get("/attributes/search/table/countr%"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid search string provided")));
		verify(searchCache, never()).searchDistributionName(Mockito.anyString());
	}

	@Test
	public void testSearchValue() throws Exception {
		when(searchCache.searchValue(anyString(), any(), any(), any())).thenReturn(createValueSearchResponse());
		mockMvc.perform(get("/attributes/search/value/eUrOpE"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].column", is("parent")))
				.andExpect(jsonPath("$[0].business_key", is("CEEUR")))
				.andExpect(jsonPath("$[0].value", is("EUROPE")))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country/CEEUR")))
				.andExpect(jsonPath("$[1].column", is("ccrm_code")))
				.andExpect(jsonPath("$[1].business_key", is("EUROPE")))
				.andExpect(jsonPath("$[1].value", is("EUROPE")))
				.andExpect(jsonPath("$[1].table", is("country")))
				.andExpect(jsonPath("$[1].links").isNotEmpty())
				.andExpect(jsonPath("$[1].links[0].rel", is("self")))
				.andExpect(jsonPath("$[1].links[0].href", is("/attributes/country/EUROPE")));
		verify(searchCache, times(1)).searchValue(anyString(), any(), any(), any());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchValue_WithAllParams() throws Exception {
		when(searchCache.searchValue(anyString(), anyString(), anyString(), anyString())).thenReturn(
				createValueSearchResponse("ccrm_code", "EUROPE", "EUROPE", "country"));
		mockMvc.perform(get("/attributes/search/value/eUrOpE?tableName=country&column=ccrm_code&businessKey=europe"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].column", is("ccrm_code")))
				.andExpect(jsonPath("$[0].business_key", is("EUROPE")))
				.andExpect(jsonPath("$[0].value", is("EUROPE")))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country/EUROPE")));
		verify(searchCache, times(1)).searchValue(anyString(), anyString(), anyString(), anyString());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchValue_InvalidSearchString() throws Exception {
		mockMvc.perform(get("/attributes/search/value/cou|ntry"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid search string provided")));
		verify(searchCache, never()).searchValue(anyString(), any(), any(), any());
	}

	@Test
	public void testSearchValue_InvalidDistributionName() throws Exception {
		mockMvc.perform(get("/attributes/search/value/eUrOpE?tableName=country$&column=ccrm_code&businessKey=europe"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid table name provided")));
		verify(searchCache, never()).searchValue(anyString(), anyString(), anyString(), anyString());
	}

	@Test
	public void testSearchValue_InvalidColumnNames() throws Exception {
		mockMvc.perform(get("/attributes/search/value/eUrOpE?tableName=country&column=de$cription&businessKey=europe"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid column name(s) provided")));
		verify(searchCache, never()).searchValue(anyString(), anyString(), anyString(), anyString());
	}

	@Test
	public void testSearchValue_InvalidBusinessKey() throws Exception {
		mockMvc.perform(get("/attributes/search/value/eUrOpE?tableName=country&column=ccrm_code&businessKey=europe@"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid business key provided")));
		verify(searchCache, never()).searchValue(anyString(), anyString(), anyString(), anyString());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchBusinessKey() throws Exception {
		when(searchCache.searchBusinessKey(anyString(), any())).thenReturn(createBusinessKeySearchResponse());
		mockMvc.perform(get("/attributes/search/businesskey/NL"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].business_key", is("NL")))
				.andExpect(jsonPath("$[0].table", is("language")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/language/NL")))
				.andExpect(jsonPath("$[1].business_key", is("NL")))
				.andExpect(jsonPath("$[1].table", is("country")))
				.andExpect(jsonPath("$[1].links").isNotEmpty())
				.andExpect(jsonPath("$[1].links[0].rel", is("self")))
				.andExpect(jsonPath("$[1].links[0].href", is("/attributes/country/NL")));
		verify(searchCache, times(1)).searchBusinessKey(anyString(), any());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchBusinessKeyInTable() throws Exception {
		when(searchCache.searchBusinessKey(anyString(), anyString())).thenReturn(createBusinessKeySearchResponse("NL", "country"));
		mockMvc.perform(get("/attributes/search/businesskey/country/nL"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].business_key", is("NL")))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country/NL")));
		verify(searchCache, times(1)).searchBusinessKey(anyString(), anyString());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchColumnName() throws Exception {
		when(searchCache.searchColumnName(anyString(), any())).thenReturn(createColumnNameSearchResponse());
		mockMvc.perform(get("/attributes/search/column/descrIpTiOn"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(2)))
				.andExpect(jsonPath("$[0].column", is("description")))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country?column=description")))
				.andExpect(jsonPath("$[1].column", is("description")))
				.andExpect(jsonPath("$[1].table", is("language")))
				.andExpect(jsonPath("$[1].links").isNotEmpty())
				.andExpect(jsonPath("$[1].links[0].rel", is("self")))
				.andExpect(jsonPath("$[1].links[0].href", is("/attributes/language?column=description")));
		verify(searchCache, times(1)).searchColumnName(anyString(), any());
		verifyNoMoreInteractions(searchCache);
	}

	@Test
	public void testSearchColumnNameInTable() throws Exception {
		when(searchCache.searchColumnName(anyString(), anyString())).thenReturn(createColumnNameSearchResponse("description", "country"));
		mockMvc.perform(get("/attributes/search/column/country/DEscrIptIon"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$").isArray())
				.andExpect(jsonPath("$").isNotEmpty())
				.andExpect(jsonPath("$", hasSize(1)))
				.andExpect(jsonPath("$[0].column", is("description")))
				.andExpect(jsonPath("$[0].table", is("country")))
				.andExpect(jsonPath("$[0].links").isNotEmpty())
				.andExpect(jsonPath("$[0].links[0].rel", is("self")))
				.andExpect(jsonPath("$[0].links[0].href", is("/attributes/country?column=description")));
		verify(searchCache, times(1)).searchColumnName(anyString(), anyString());
		verifyNoMoreInteractions(searchCache);
	}

	private List<Map<String, Object>> createDistributionNameSearchResponse() {
		final Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/country");
		final Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("table", "country");
		objectMap.put("links", Lists.newArrayList(linkMap));
		return Lists.newArrayList(objectMap);
	}

	private List<Map<String, Object>> createValueSearchResponse() {
		final List<Map<String, Object>> responseObject = Lists.newArrayList();
		Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/country/CEEUR");
		Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("column", "parent");
		objectMap.put("business_key", "CEEUR");
		objectMap.put("value", "EUROPE");
		objectMap.put("table", "country");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/country/EUROPE");
		objectMap = Maps.newHashMap();
		objectMap.put("column", "ccrm_code");
		objectMap.put("business_key", "EUROPE");
		objectMap.put("value", "EUROPE");
		objectMap.put("table", "country");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		return responseObject;
	}

	private List<Map<String, Object>> createValueSearchResponse(String columnName, String businessKey, String value, String tableName) {
		final List<Map<String, Object>> responseObject = Lists.newArrayList();
		final Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/" + tableName + "/" + businessKey);
		final Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("column", columnName);
		objectMap.put("business_key", businessKey);
		objectMap.put("value", value);
		objectMap.put("table", tableName);
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		return responseObject;
	}

	private List<Map<String, Object>> createBusinessKeySearchResponse() {
		final List<Map<String, Object>> responseObject = Lists.newArrayList();
		Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/language/NL");
		Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("business_key", "NL");
		objectMap.put("table", "language");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/country/NL");
		objectMap = Maps.newHashMap();
		objectMap.put("business_key", "NL");
		objectMap.put("table", "country");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		return responseObject;
	}

	private List<Map<String, Object>> createBusinessKeySearchResponse(String businessKey, String tableName) {
		final Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/" + tableName + "/" + businessKey);
		final Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("business_key", businessKey);
		objectMap.put("table", tableName);
		objectMap.put("links", Lists.newArrayList(linkMap));
		return Lists.newArrayList(objectMap);
	}

	private List<Map<String, Object>> createColumnNameSearchResponse() {
		final List<Map<String, Object>> responseObject = Lists.newArrayList();
		Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/country?column=description");
		Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("column", "description");
		objectMap.put("table", "country");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/language?column=description");
		objectMap = Maps.newHashMap();
		objectMap.put("column", "description");
		objectMap.put("table", "language");
		objectMap.put("links", Lists.newArrayList(linkMap));
		responseObject.add(objectMap);
		return responseObject;
	}

	private List<Map<String, Object>> createColumnNameSearchResponse(String columnName, String tableName) {
		final Map<String, String> linkMap = Maps.newHashMap();
		linkMap.put("rel", "self");
		linkMap.put("href", "/attributes/" + tableName + "?column=" + columnName);
		final Map<String, Object> objectMap = Maps.newHashMap();
		objectMap.put("column", columnName);
		objectMap.put("table", tableName);
		objectMap.put("links", Lists.newArrayList(linkMap));
		return Lists.newArrayList(objectMap);
	}
}