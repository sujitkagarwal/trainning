package com.ing.grdm.api.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ing.grdm.api.cache.MappingsDataCache;
import com.ing.grdm.api.response.CachedMappingsResponseService;
import com.ing.grdm.api.response.MappingsDataSerializer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit tests for {@link GrdmApiMappingsDataController}
 */
@SpringBootTest(classes = {GrdmApiMappingsDataController.class, CachedMappingsResponseService.class,
		MappingsDataSerializer.class, ObjectMapper.class, JsonFactory.class})
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class GrdmApiMappingsDataControllerTest {

	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private MappingsDataCache cache;

	@Test
	public void testGlobalCodeByLocaLCode() throws Exception {
		doReturn("NL").when(this.cache).getGlobalByLocal(anyString(), anyString(), anyString());

		this.mockMvc.perform(get("/mappings/global/country/BSK/394"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("code", is("NL")))
				.andExpect(jsonPath("links[0].rel", is("attributes")))
				.andExpect(jsonPath("links[0].href", is("/attributes/country/NL")));
	}

	@Test
	public void testGlobalCodeByLocalCodeIllegalDistributionName() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country%*/BSK/394"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid table name provided")));
	}

	@Test
	public void testGlobalCodeByLocalCodeIllegalSystemCode() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country/INVALID/394"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid system code provided")));
	}

	@Test
	public void testGlobalCodeByLocalCodeIllegalCode() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country/BSK/code|invalid"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid code provided")));
	}

	@Test
	public void testGlobalCodeByLocalCodeDistributionNameNotFound() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country/BSK/394"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No table found with distribution name 'country'")));
	}

	@Test
	public void testGlobalCodeByLocalCodeSystemCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForLocal("country");

		this.mockMvc.perform(get("/mappings/global/country/BSK/394"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mappings found for system code BSK in table country")));
	}

	@Test
	public void testGlobalCodeByLocalCodeCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForLocal("country");
		doReturn(true).when(this.cache).containsSystemCodeForLocal("country", "BSK");

		this.mockMvc.perform(get("/mappings/global/country/BSK/394"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mapping found for code 394 and system code BSK in table country")));
	}

	@Test
	public void testGlobalCodesBySystemCode() throws Exception {
		doReturn(ImmutableMap.of("394", "NL", "393", "FR")).when(this.cache).getAllGlobalByLocal("country", "BSK");

		this.mockMvc.perform(get("/mappings/global/country/BSK"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("data[0].local", is("394")))
				.andExpect(jsonPath("data[0].global", is("NL")))
				.andExpect(jsonPath("data[1].local", is("393")))
				.andExpect(jsonPath("data[1].global", is("FR")));
	}

	@Test
	public void testGlobalCodesBySystemCodeIllegalDistributionName() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country%*/BSK"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid table name provided")));
	}

	@Test
	public void testGlobalCodesBySystemCodeIllegalSystemCode() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country/INVALID"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid system code provided")));
	}

	@Test
	public void testGlobalCodesBySystemCodeDistributionNameNotFound() throws Exception {
		this.mockMvc.perform(get("/mappings/global/country/BSK"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No table found with distribution name 'country'")));
	}

	@Test
	public void testGlobalCodesBySystemCodeSystemCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForLocal("country");

		this.mockMvc.perform(get("/mappings/global/country/BSK"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mappings found for system code BSK in table country")));
	}

	@Test
	public void testLocalCodesByGlobalCode() throws Exception {
		doReturn(ImmutableList.of("NL", "394")).when(this.cache).getLocalByGlobal("country", "BSK", "NL");

		this.mockMvc.perform(get("/mappings/local/country/BSK/NL"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("data[0]", is("NL")))
				.andExpect(jsonPath("data[1]", is("394")));
	}

	@Test
	public void testLocalCodesByGlobalCodeInvalidDistributionName() throws Exception {
		this.mockMvc.perform(get("/mappings/local/country!*/BSK/NL"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid table name provided")));
	}

	@Test
	public void testLocalCodesByGlobalCodeInvalidSystemCode() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");

		this.mockMvc.perform(get("/mappings/local/country/INVALID/NL"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid system code provided")));
	}

	@Test
	public void testLocalCodesByGlobalCodeInvalidCode() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");
		doReturn(true).when(this.cache).containsSystemCodeForGlobal("country", "BSK");

		this.mockMvc.perform(get("/mappings/local/country/BSK/code|invalid"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid code provided")));
	}

	@Test
	public void testLocalCodesByGlobalCodeDistributionNameNotFound() throws Exception {
		this.mockMvc.perform(get("/mappings/local/country/BSK/NL"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No table found with distribution name 'country'")));
	}

	@Test
	public void testLocalCodesByGlobalCodeSystemCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");

		this.mockMvc.perform(get("/mappings/local/country/BSK/NL"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mappings found for system code BSK in table country")));
	}

	@Test
	public void testLocalCodesByGlobalCodeCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");
		doReturn(true).when(this.cache).containsSystemCodeForGlobal("country", "BSK");

		this.mockMvc.perform(get("/mappings/local/country/BSK/NL"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mappings found for code NL and system code BSK in table country")));
	}

	@Test
	public void testLocalCodesBySystemCode() throws Exception {
		doReturn(ImmutableMap.of(
				"NL", ImmutableList.of("NL", "394"),
				"FR", ImmutableList.of("FR", "393")))
				.when(this.cache).getAllLocalByGlobal("country", "BSK");

		this.mockMvc.perform(get("/mappings/local/country/BSK"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("data[0].global", is("NL")))
				.andExpect(jsonPath("data[0].local[0]", is("NL")))
				.andExpect(jsonPath("data[0].local[1]", is("394")))
				.andExpect(jsonPath("data[1].global", is("FR")))
				.andExpect(jsonPath("data[1].local[0]", is("FR")))
				.andExpect(jsonPath("data[1].local[1]", is("393")));
	}

	@Test
	public void testLocalCodesBySystemCodeInvalidDistributionName() throws Exception {
		this.mockMvc.perform(get("/mappings/local/country!*/BSK"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid table name provided")));
	}

	@Test
	public void testLocalCodesBySystemCodeInvalidSystemCode() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");

		this.mockMvc.perform(get("/mappings/local/country/INVALID"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("code", is(400)))
				.andExpect(jsonPath("message", is("Invalid system code provided")));
	}

	@Test
	public void testLocalCodesBySystemCodeDistributionNameNotFound() throws Exception {
		this.mockMvc.perform(get("/mappings/local/country/BSK"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No table found with distribution name 'country'")));
	}

	@Test
	public void testLocalCodesBySystemCodeSystemCodeNotFound() throws Exception {
		doReturn(true).when(this.cache).containsDistributionNameForGlobal("country");

		this.mockMvc.perform(get("/mappings/local/country/BSK"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("code", is(404)))
				.andExpect(jsonPath("message", is("No mappings found for system code BSK in table country")));
	}
}
