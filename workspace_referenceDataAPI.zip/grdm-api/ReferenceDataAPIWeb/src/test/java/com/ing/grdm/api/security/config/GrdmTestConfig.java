package com.ing.grdm.api.security.config;

import com.ing.api.security.trust.token.peer.PeerTokenParser;
import com.ing.api.security.trust.token.peer.PeerTokenProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Enumeration;

/**
 * Some additional configuration for testing the application.
 */
public class GrdmTestConfig {

	@Bean
	@ConditionalOnProperty(name = "grdm.api.security.type", havingValue = "peerToken")
	PeerTokenParser peerTokenParser(PeerTokenProperties properties)
			throws CertificateException, NoSuchAlgorithmException, KeyStoreException, IOException, URISyntaxException {
		return new PeerTokenParser(properties, getCertificate());
	}

	private X509Certificate getCertificate() throws KeyStoreException, IOException, CertificateException, NoSuchAlgorithmException, URISyntaxException {
		final Path keyStoreFilePath = Paths.get(ClassLoader.getSystemResource("grdm-test.jks").toURI());
		try (InputStream certStore = Files.newInputStream(keyStoreFilePath)) {
			KeyStore keyStore = KeyStore.getInstance("jks");
			keyStore.load(certStore, "grdm01".toCharArray());
			Enumeration<String> aliases = keyStore.aliases();
			return (X509Certificate) keyStore.getCertificate(aliases.nextElement());
		}
	}

}
