package com.ing.grdm.distro;

import com.ing.grdm.distro.domain.SdmCategory;
import com.ing.grdm.distro.domain.SdmColumn;
import com.ing.grdm.distro.domain.SdmColumnDefinition;
import com.ing.grdm.distro.domain.SdmRow;
import com.ing.grdm.distro.domain.SdmStructure;
import com.ing.grdm.distro.domain.SdmTable;
import com.ing.grdm.distro.domain.type.SdmDomainType;
import com.ing.grdm.distro.domain.SdmDomainValue;
import com.ing.grdm.distro.domain.type.SdmHierarchyType;
import com.ing.grdm.distro.domain.type.SdmNumberType;
import com.ing.grdm.distro.domain.type.SdmReferenceType;
import com.ing.grdm.distro.domain.type.SdmStringType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.util.xml.StaxUtils;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.transform.Source;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.isA;
import static org.junit.Assert.assertThat;

/**
 * Unit test for XStream annotated classes for SDM distribution files
 */
public class UnmarshallerTest {

	private XStreamMarshaller marshaller;

	@Rule
	public ExpectedException exceptionRule = ExpectedException.none();

	@Before
	public void createMarshaller() {
		this.marshaller = new XStreamMarshaller();
		this.marshaller.setAnnotatedClasses(
				SdmTable.class, SdmCategory.class, SdmStructure.class, SdmColumnDefinition.class,
				SdmStringType.class, SdmReferenceType.class, SdmHierarchyType.class, SdmNumberType.class, SdmDomainType.class, SdmDomainValue.class,
				SdmRow.class, SdmColumn.class);
	}

	@Test
	public void testUnmarshal() throws IOException, XMLStreamException {
		// Setup
		final XMLInputFactory inputFactory = XMLInputFactory.newInstance();
		final XMLStreamReader streamReader = inputFactory.createXMLStreamReader(
				Thread.currentThread().getContextClassLoader().getResourceAsStream("0043_OIL_SRC_SYS_CONFIGN_Attributes.xml"));
		final Source source = StaxUtils.createStaxSource(streamReader);

		// Unmarshal to SdmTable object
		final SdmTable sdmTable = (SdmTable) marshaller.unmarshal(source);
		Assert.assertEquals("OIL_SRC_SYS_CONFIGN", sdmTable.getName());
		Assert.assertEquals(38, sdmTable.getDistributionSequenceNumber());

		// Verify Category
		final SdmCategory category = sdmTable.getCategory();
		Assert.assertEquals("Attributes", category.getType());

		// Verify Structure
		final SdmStructure structure = category.getStructure();
		final List<SdmColumnDefinition> columnDefinitions = structure.getColumnDefinitions();
		Assert.assertFalse(columnDefinitions.isEmpty());

		// Verify column definitions
		// Reference type
		SdmColumnDefinition columnDefinition = columnDefinitions.get(0);
		Assert.assertEquals("SRCE_SYS", columnDefinition.getName());
		Assert.assertTrue(columnDefinition.isPrimaryKey());
		Assert.assertTrue(columnDefinition.isMandatory());
		Assert.assertEquals(1, columnDefinition.getOrderNumber());
		Assert.assertEquals("reference", columnDefinition.getColumnDefinitionType());
		Assert.assertEquals("Source System", columnDefinition.getDescription());
		Assert.assertEquals(SdmReferenceType.class, columnDefinition.getType().getClass());

		SdmReferenceType referenceType = (SdmReferenceType) columnDefinition.getType();
		Assert.assertEquals("DATA_SOURCE", referenceType.getReferenceTable());

		// Domain type
		columnDefinition = columnDefinitions.get(1);
		Assert.assertEquals("FILE_TYP", columnDefinition.getName());
		Assert.assertTrue(columnDefinition.isPrimaryKey());
		Assert.assertTrue(columnDefinition.isMandatory());
		Assert.assertTrue(columnDefinition.isMandatoryOnLowest());
		Assert.assertEquals(2, columnDefinition.getOrderNumber());
		Assert.assertEquals("domain", columnDefinition.getColumnDefinitionType());
		Assert.assertEquals("File Type", columnDefinition.getDescription());
		Assert.assertEquals(SdmDomainType.class, columnDefinition.getType().getClass());

		SdmDomainType domainType = (SdmDomainType) columnDefinition.getType();
		final List<SdmDomainValue> domainValues = domainType.getDomainValues();
		Assert.assertFalse(domainValues.isEmpty());
		Assert.assertEquals("CSV", domainValues.get(0).getValue());
		Assert.assertEquals("Comma Seperated", domainValues.get(0).getDescription());

		// String type
		columnDefinition = columnDefinitions.get(5);
		Assert.assertEquals("FILE_NM", columnDefinition.getName());
		Assert.assertFalse(columnDefinition.isPrimaryKey());
		Assert.assertFalse(columnDefinition.isMandatory());
		Assert.assertEquals(6, columnDefinition.getOrderNumber());
		Assert.assertEquals("string", columnDefinition.getColumnDefinitionType());
		Assert.assertEquals("File Name", columnDefinition.getDescription());
		Assert.assertEquals(SdmStringType.class, columnDefinition.getType().getClass());

		SdmStringType stringType = (SdmStringType) columnDefinition.getType();
		Assert.assertEquals(Integer.valueOf(255), stringType.getSize());

		// Number type
		columnDefinition = columnDefinitions.get(6);
		Assert.assertEquals("PROCNG_ORD", columnDefinition.getName());
		Assert.assertFalse(columnDefinition.isPrimaryKey());
		Assert.assertFalse(columnDefinition.isMandatory());
		Assert.assertEquals(7, columnDefinition.getOrderNumber());
		Assert.assertEquals("number", columnDefinition.getColumnDefinitionType());
		Assert.assertEquals("Processing Order", columnDefinition.getDescription());
		Assert.assertEquals(SdmNumberType.class, columnDefinition.getType().getClass());

		SdmNumberType numberType = (SdmNumberType) columnDefinition.getType();
		Assert.assertEquals(Integer.valueOf(1), numberType.getSize());
		Assert.assertEquals(Integer.valueOf(0), numberType.getScale());
		Assert.assertTrue(numberType.isAllowNegative());

		// Hierarchy type
		columnDefinition = columnDefinitions.get(9);
		Assert.assertEquals("PARENT", columnDefinition.getName());
		Assert.assertFalse(columnDefinition.isPrimaryKey());
		Assert.assertTrue(columnDefinition.isMandatory());
		Assert.assertEquals(10, columnDefinition.getOrderNumber());
		Assert.assertEquals("hierarchy", columnDefinition.getColumnDefinitionType());
		Assert.assertEquals("Parent", columnDefinition.getDescription());
		Assert.assertEquals(SdmHierarchyType.class, columnDefinition.getType().getClass());

		SdmHierarchyType hierarchyType = (SdmHierarchyType) columnDefinition.getType();
		Assert.assertEquals(4, hierarchyType.getMaxLevel());

		// Row
		final List<SdmRow> rows = category.getRows();
		Assert.assertFalse(rows.isEmpty());

		SdmRow row = rows.get(0);
		List<SdmColumn> columns = row.getColumns();
		Assert.assertEquals("Inactive", row.getStatus());
		Assert.assertFalse(columns.isEmpty());
		assertThat(row.getLevel(), is(3));

		SdmColumn column = columns.get(0);
		Assert.assertEquals("SRCE_SYS", column.getName());
		Assert.assertEquals("CSI_BE", column.getValue());

		row = rows.get(5);
		columns = row.getColumns();
		Assert.assertEquals("Active", row.getStatus());
		Assert.assertFalse(columns.isEmpty());

		column = columns.get(0);
		Assert.assertEquals("SRCE_SYS", column.getName());
		Assert.assertEquals("CSI_BE", column.getValue());
	}

	@Test
	public void testMarshal() throws IOException {
		exceptionRule.expectCause(isA(UnsupportedOperationException.class));
		SdmColumnDefinition columnDefinition = new SdmColumnDefinition();
		this.marshaller.marshalWriter(columnDefinition, new StringWriter());
	}
}
