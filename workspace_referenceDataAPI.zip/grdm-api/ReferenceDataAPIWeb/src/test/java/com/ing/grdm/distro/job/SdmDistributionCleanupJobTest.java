package com.ing.grdm.distro.job;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link SdmDistributionCleanupJob}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class SdmDistributionCleanupJobTest {

	@Mock
	private GrdmApiCategoryDefinitionDistributionRepository distributionRepository;

	@Mock
	private GrdmApiDataValueRepository dataValueRepository;

	@InjectMocks
	private SdmDistributionCleanupJob job = new SdmDistributionCleanupJob();

	@Test
	public void testCleanupDistributions() {
		doReturn(Arrays.asList(1L, 2L)).when(this.distributionRepository)
				.getCategoryDefinitionsWithInactivesToDelete(anyLong());
		doAnswer(invocation -> {
			final ApiCategoryDefinitionDistribution distribution1 = new ApiCategoryDefinitionDistribution();
			distribution1.setCategoryDefinitionId(invocation.getArgument(0));
			distribution1.setDistributionSequenceNumber(1);
			final ApiCategoryDefinitionDistribution distribution2 = new ApiCategoryDefinitionDistribution();
			distribution2.setCategoryDefinitionId(invocation.getArgument(0));
			distribution2.setDistributionSequenceNumber(2);
			return Arrays.asList(distribution1, distribution2);
		}).when(this.distributionRepository).getCategoryDefinitionDistributionsToDelete(anyLong());

		this.job.cleanupDistributions();

		verify(this.distributionRepository, times(2))
				.getCategoryDefinitionDistributionsToDelete(anyLong());
		verify(this.dataValueRepository, times(4))
				.deleteCategoryDefinitionDistributionSequenceNumber(anyLong(), anyInt());
		verify(this.distributionRepository, times(4))
				.save((ApiCategoryDefinitionDistribution) any());
	}
}
