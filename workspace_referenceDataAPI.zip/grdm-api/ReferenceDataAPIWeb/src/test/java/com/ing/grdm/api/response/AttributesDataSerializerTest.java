package com.ing.grdm.api.response;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.ing.grdm.api.constant.GrdmConstants;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ing.grdm.domain.ColumnType.DATE;
import static com.ing.grdm.domain.ColumnType.NUMBER;
import static com.ing.grdm.domain.ColumnType.STRING;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link AttributesDataSerializer}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class AttributesDataSerializerTest {

	@Spy
	private JsonFactory jsonFactory = new JsonFactory(
			new ObjectMapper()
					.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
					.registerModule(new JavaTimeModule()));

	@InjectMocks
	private AttributesDataSerializer serializer = new AttributesDataSerializer();

	@Test
	public void testSerializeBusinessKeys() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		final List<ApiDataValue> tableData = createApiTableData().stream()
				.filter(dv -> dv.getColumnName().equals("code"))
				.collect(Collectors.toList());
		this.serializer.serializeBusinessKeys(outputStream, tableData, false);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].eff_dt").doesNotExist(content);
		verify(this.jsonFactory, Mockito.times(1)).createGenerator(outputStream, JsonEncoding.UTF8);
	}

	@Test
	public void testSerializeVersionedBusinessKeys() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		final List<ApiDataValue> tableData = createVersionedApiTableData().stream()
				.filter(dv -> dv.getColumnName().equals("code"))
				.collect(Collectors.toList());
		this.serializer.serializeBusinessKeys(outputStream, tableData, true);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[0].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[1].eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[1].end_dt").assertValue(content, nullValue());
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[2].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[3].business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[3].eff_dt").assertValue(content, nullValue());
		new JsonPathExpectationsHelper("$[3].end_dt").assertValue(content, nullValue());
		verify(this.jsonFactory, Mockito.times(1)).createGenerator(outputStream, JsonEncoding.UTF8);
	}

	@Test
	public void testSerializeTableData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeTableData(outputStream, createTableData(), false, Collections.emptyList());
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "All description");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 82);
		new JsonPathExpectationsHelper("$[0].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
		new JsonPathExpectationsHelper("$[1].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[2].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[2].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[2].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[2].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[2].end_dt").doesNotExist(content);
	}

	@Test
	public void testSerializeVersionedTableData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeTableData(outputStream, createVersionedTableData(), true, Collections.emptyList());
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[0].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "All description");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 82);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[1].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[2].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[2].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[2].people").assertValue(content, 66);
		new JsonPathExpectationsHelper("$[3].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[3].eff_dt").assertValue(content, "2016-06-01");
		new JsonPathExpectationsHelper("$[3].end_dt").assertValue(content, "2019-06-01");
		new JsonPathExpectationsHelper("$[3].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[3].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[3].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[3].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[4].eff_dt").assertValue(content, "2019-06-01");
		new JsonPathExpectationsHelper("$[4].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[4].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[4].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[4].people").assertValue(content, 18);
	}

	@Test
	public void testSerializeTableDataWithColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeTableData(outputStream, createTableData(), false, Arrays.asList("code", "people"));
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 82);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[2].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[2].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[2].people").assertValue(content, 17);
	}

	@Test
	public void testSerializeVersionedTableDataWithColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeTableData(outputStream, createVersionedTableData(), true, Arrays.asList("code", "people"));
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[0].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$[0].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 82);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[1].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[2].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[2].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[2].people").assertValue(content, 66);
		new JsonPathExpectationsHelper("$[3].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[3].eff_dt").assertValue(content, "2016-06-01");
		new JsonPathExpectationsHelper("$[3].end_dt").assertValue(content, "2019-06-01");
		new JsonPathExpectationsHelper("$[3].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[3].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[3].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[3].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[4].eff_dt").assertValue(content, "2019-06-01");
		new JsonPathExpectationsHelper("$[4].end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$[4].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[4].description").doesNotExist(content);
		new JsonPathExpectationsHelper("$[4].people").assertValue(content, 18);
	}

	@Test
	public void testSerializeRowData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, "All", createTableData().get("All").iterator().next(), false, Collections.emptyList());
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$.eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "All description");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 82);
	}

	@Test
	public void testSerializeVersionedRowData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, "All", createVersionedTableData().get("All").iterator().next(), true, Collections.emptyList());
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "All");
		new JsonPathExpectationsHelper("$.eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$.end_dt").assertValue(content, "2030-06-01");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "All");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "All description");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 82);
	}

	@Test
	public void testSerializeRowDataWithColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, "NL", createTableData().get("NL").iterator().next(), false, Arrays.asList("code", "people"));
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").doesNotExist(content);
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeRowDataWithDateColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, "NL", createVersionedTableData().get("NL").iterator().next(), false, Arrays.asList("code", "people", "eff_dt", "end_dt"));
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").doesNotExist(content);
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$.eff_dt").assertValue(content, "2016-06-01");
		new JsonPathExpectationsHelper("$.end_dt").assertValue(content, "2019-06-01");
	}

	@Test
	public void testSerializeVersionedRowDataWithColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, "NL", createVersionedTableData().get("NL").iterator().next(), true, Arrays.asList("code", "people"));
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.eff_dt").assertValue(content, "2016-06-01");
		new JsonPathExpectationsHelper("$.end_dt").assertValue(content, "2019-06-01");
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").doesNotExist(content);
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeRowDataTableData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, createApiTableData(), true, false);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 65);
	}

	@Test
	public void testSerializeRowDataVersionedTableData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, createVersionedApiTableData(), true, true);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		System.out.println(content);
		new JsonPathExpectationsHelper("$").assertValueIsArray(content);
		new JsonPathExpectationsHelper("$[0].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[0].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[0].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[0].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[0].people").assertValue(content, 17);
		new JsonPathExpectationsHelper("$[1].business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[1].eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[1].end_dt").assertValue(content, nullValue());
		new JsonPathExpectationsHelper("$[1].code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$[1].description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$[1].people").assertValue(content, 18);
		new JsonPathExpectationsHelper("$[2].business_key").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].eff_dt").assertValue(content, "2015-06-01");
		new JsonPathExpectationsHelper("$[2].end_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$[2].code").assertValue(content, "UK");
		new JsonPathExpectationsHelper("$[2].description").assertValue(content, "United Kingdom");
		new JsonPathExpectationsHelper("$[2].people").assertValue(content, 65);
	}

	@Test
	public void testSerializeRowDataRowData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, createApiRowData(), false, false);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.eff_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.end_dt").doesNotExist(content);
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeRowDataRowDataWithDateColumns() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, createVersionedApiRowData(), false, false);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$.end_dt").assertValue(content, nullValue());
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test
	public void testSerializeVersionedRowDataRowData() throws IOException {
		final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		this.serializer.serializeRowData(outputStream, createVersionedApiRowData(), false, true);
		final String content = new String(outputStream.toByteArray(), StandardCharsets.UTF_8);
		new JsonPathExpectationsHelper("$").assertValueIsMap(content);
		new JsonPathExpectationsHelper("$.business_key").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.eff_dt").assertValue(content, "2018-06-01");
		new JsonPathExpectationsHelper("$.end_dt").assertValue(content, nullValue());
		new JsonPathExpectationsHelper("$.code").assertValue(content, "NL");
		new JsonPathExpectationsHelper("$.description").assertValue(content, "Netherlands");
		new JsonPathExpectationsHelper("$.people").assertValue(content, 17);
	}

	@Test(expected = IOException.class)
	public void testSerializeTableDataIOException() throws IOException {
		final OutputStream outputStream = Mockito.mock(OutputStream.class);
		doThrow(IOException.class).when(outputStream).flush();
		this.serializer.serializeTableData(outputStream, createTableData(), false, Collections.emptyList());
	}

	private Map<String, Collection<Map<String, Object>>> createTableData() {
		final ListMultimap<String, Map<String, Object>> table = ArrayListMultimap.create();
		table.put("All", ImmutableMap.of("code", "All", "description", "All description", "people", 82));
		table.put("UK", ImmutableMap.of("code", "UK", "description", "United Kingdom", "people", 65));
		table.put("NL", ImmutableMap.of("code", "NL", "description", "Netherlands", "people", 17));
		return table.asMap();
	}

	private Map<String, Collection<Map<String, Object>>> createVersionedTableData() {
		final ListMultimap<String, Map<String, Object>> table = ArrayListMultimap.create();
		table.put("All", ImmutableMap.of("code", "All", "eff_dt", "2015-06-01", "end_dt", "2030-06-01", "description", "All description", "people", 82));
		table.put("UK", ImmutableMap.of("code", "UK", "eff_dt", "2015-06-01", "end_dt", "2018-06-01", "description", "United Kingdom", "people", 65));
		table.put("UK", ImmutableMap.of("code", "UK", "eff_dt", "2018-06-01", "end_dt", "2030-06-01", "description", "United Kingdom", "people", 66));
		table.put("NL", ImmutableMap.of("code", "NL", "eff_dt", "2016-06-01", "end_dt", "2019-06-01", "description", "Netherlands", "people", 17));
		table.put("NL", ImmutableMap.of("code", "NL", "eff_dt", "2019-06-01", "end_dt", "2030-06-01", "description", "Netherlands", "people", 18));
		return table.asMap();
	}

	private List<ApiDataValue> createApiTableData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "code", STRING, "NL"),
				createApiDataValue("NL", "description", STRING, "Netherlands"),
				createApiDataValue("NL", "people", NUMBER, "17"),
				createApiDataValue("UK", "code", STRING, "UK"),
				createApiDataValue("UK", "description", STRING, "United Kingdom"),
				createApiDataValue("UK", "people", NUMBER, "65"),
				createApiDataValue("All", "code", STRING, "All"),
				createApiDataValue("All", "description", STRING, "All description"),
				createApiDataValue("All", "people", NUMBER, "82")
		);
	}

	private List<ApiDataValue> createVersionedApiTableData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "2015-06-01", "2018-06-01", "code", STRING, "NL", 1),
				createApiDataValue("NL", "2015-06-01", "2018-06-01", "eff_dt", DATE, "2015-06-01", 1),
				createApiDataValue("NL", "2015-06-01", "2018-06-01", "end_dt", DATE, "2018-06-01", 1),
				createApiDataValue("NL", "2015-06-01", "2018-06-01", "description", STRING, "Netherlands", 1),
				createApiDataValue("NL", "2015-06-01", "2018-06-01", "people", NUMBER, "17", 1),
				createApiDataValue("NL", "2018-06-01", null, "code", STRING, "NL", 2),
				createApiDataValue("NL", "2018-06-01", null, "eff_dt", DATE, "2018-06-01", 2),
				createApiDataValue("NL", "2018-06-01", null, "end_dt", DATE, null, 2),
				createApiDataValue("NL", "2018-06-01", null, "description", STRING, "Netherlands", 2),
				createApiDataValue("NL", "2018-06-01", null, "people", NUMBER, "18", 2),
				createApiDataValue("UK", "2015-06-01", "2018-06-01", "code", STRING, "UK", 1),
				createApiDataValue("UK", "2015-06-01", "2018-06-01", "eff_dt", DATE, "2015-06-01", 1),
				createApiDataValue("UK", "2015-06-01", "2018-06-01", "end_dt", DATE, "2018-06-01", 1),
				createApiDataValue("UK", "2015-06-01", "2018-06-01", "description", STRING, "United Kingdom", 1),
				createApiDataValue("UK", "2015-06-01", "2018-06-01", "people", NUMBER, "65", 1),
				createApiDataValue("All", null, null, "code", STRING, "All", 1),
				createApiDataValue("All", null, null, "eff_dt", DATE, null, 1),
				createApiDataValue("All", null, null, "end_dt", DATE, null, 1),
				createApiDataValue("All", null, null, "description", STRING, "All description", 1),
				createApiDataValue("All", null, null, "people", NUMBER, "82", 1)
		);
	}

	private List<ApiDataValue> createApiRowData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "code", STRING, "NL"),
				createApiDataValue("NL", "description", STRING, "Netherlands"),
				createApiDataValue("NL", "people", NUMBER, "17")
		);
	}

	private List<ApiDataValue> createVersionedApiRowData() {
		return Lists.newArrayList(
				createApiDataValue("NL", "2018-06-01", null, "code", STRING, "NL", 1),
				createApiDataValue("NL", "2018-06-01", null, "eff_dt", DATE, "2018-06-01", 1),
				createApiDataValue("NL", "2018-06-01", null, "end_dt", DATE, null, 1),
				createApiDataValue("NL", "2018-06-01", null, "description", STRING, "Netherlands", 1),
				createApiDataValue("NL", "2018-06-01", null, "people", NUMBER, "17", 1)
		);
	}

	private ApiDataValue createApiDataValue(String businessKey, String columnName, ColumnType columnType, String storageString) {
		return createApiDataValue(businessKey, null, null, columnName, columnType, storageString, 0);
	}

	private ApiDataValue createApiDataValue(String businessKey, String effectiveDate, String endDate, String columnName,
											ColumnType columnType, String storageString, int technicalVersion) {
		final ApiDataValue dataValue = new ApiDataValue();
		dataValue.setBusinessKey(businessKey);
		dataValue.setColumnName(columnName);
		dataValue.setColumnType(columnType);
		dataValue.setStorageString(storageString);
		dataValue.setTechnicalVersion(technicalVersion);
		if (effectiveDate != null) {
			dataValue.setEffectiveDate(LocalDate.parse(effectiveDate));
		}
		if (endDate != null) {
			dataValue.setEndDate(LocalDate.parse(endDate));
		}

		return dataValue;
	}
}
