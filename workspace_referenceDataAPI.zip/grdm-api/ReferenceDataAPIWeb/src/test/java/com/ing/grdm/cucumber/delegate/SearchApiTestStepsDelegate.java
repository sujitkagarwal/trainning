package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual search test steps. Needs to be wired in the cucumber glue class.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
@Component
@Scope("cucumber-glue")
public class SearchApiTestStepsDelegate extends GrdmApiTestStepsDelegate {
	private static final Log LOG = LogFactory.getLog(SearchApiTestStepsDelegate.class);

	// The deserialized json response of the search request
	private List<Map<String, Object>> searchResponse;

	/**
	 * Perform search request for table
	 *
	 * @param distributionName tableName
	 * @throws IOException communication error with the server
	 */
	public void searchTable(String distributionName) throws IOException {
		LOG.info(String.format("the client makes an search request for table %s", distributionName));
		performSearchRequest(null, "table", distributionName);
	}

	/**
	 * Perform search request for a value
	 *
	 * @param searchString searchString entered for the value search request
	 * @throws IOException communication error with the server
	 */
	public void searchValue(String searchString) throws IOException {
		searchValueParameterized(null, null, null, searchString);
	}

	/**
	 * Perform search request for a value
	 *
	 * @param distributionName table name
	 * @param columnName       column name
	 * @param businessKey      business key
	 * @param searchString     searchString entered for the value search request
	 * @throws IOException communication error with the server
	 */
	public void searchValueParameterized(String distributionName, String columnName, String businessKey, String searchString)
			throws IOException {
		final List<NameValuePair> nvps = Lists.newArrayList();
		final StringBuilder logMessage = new StringBuilder("the client makes an search request for value '")
				.append(searchString).append('\'');
		if (distributionName != null) {
			logMessage.append(String.format(" distributionName '%s'", distributionName));
			nvps.add(new BasicNameValuePair("tableName", distributionName));
		}
		if (businessKey != null) {
			logMessage.append(String.format(" businessKey '%s'", businessKey));
			nvps.add(new BasicNameValuePair("businessKey", businessKey));
		}
		if (columnName != null) {
			logMessage.append(String.format(" columnName '%s'", columnName));
			nvps.add(new BasicNameValuePair("column", columnName));
		}
		LOG.info(logMessage);
		performSearchRequest(nvps, "value", searchString);
	}

	/**
	 * Perform search request for a column
	 *
	 * @param columnName search string entered for column search
	 * @throws IOException communication error with the server
	 */
	public void searchColumn(String columnName) throws IOException {
		searchColumnParameterized(null, columnName);
	}

	/**
	 * Perform search request for a column
	 *
	 * @param columnName       search string entered for column search
	 * @param distributionName table name
	 * @throws IOException communication error with the server
	 */
	public void searchColumnParameterized(String distributionName, String columnName) throws IOException {
		final StringBuilder logMessage = new StringBuilder("the client makes an search request for column '")
				.append(columnName).append('\'');
		if (distributionName != null) {
			logMessage.append(String.format(" with distributionName %s", distributionName));
		}

		LOG.info(logMessage);
		performSearchRequest(null, "column", distributionName, columnName);
	}

	/**
	 * Perform search request for a business key
	 *
	 * @param businessKey search string entered for business key search
	 * @throws IOException communication error with the server
	 */
	public void searchBusinessKey(String businessKey) throws IOException {
		searchBusinessKeyParameterized(null, businessKey);
	}

	/**
	 * Perform search request for a business key
	 *
	 * @param distributionName table name
	 * @param businessKey      search string entered for business key search
	 * @throws IOException communication error with the server
	 */
	public void searchBusinessKeyParameterized(String distributionName, String businessKey) throws IOException {
		StringBuilder logMessage = new StringBuilder("the client makes an search request for the business key '")
				.append(businessKey).append('\'');
		if (distributionName != null) {
			logMessage.append(String.format(" with distributionName %s", distributionName));
		}
		LOG.info(logMessage);
		performSearchRequest(null, "businesskey", distributionName, businessKey);
	}

	/**
	 * Verify non empty results of table search
	 *
	 * @param distributionName tableName
	 * @throws IOException communication error with the server
	 */
	@SuppressWarnings("unchecked")
	public void verifyTableSearchResponse(String distributionName) throws IOException {
		LOG.info(String.format("the client receives search results for table %s", distributionName));

		assertThat(searchResponse, not(empty()));
		assertThat(searchResponse, hasSize(1));
		assertThat(searchResponse.get(0), hasEntry("table", distributionName));
		assertThat(searchResponse.get(0), hasKey("links"));

		final List<Map<String, String>> links = (List<Map<String, String>>) searchResponse.get(0).get("links");
		assertThat(links, hasSize(1));
		assertThat(links.get(0), hasEntry("rel", "self"));
		assertThat(links.get(0), hasEntry("href", "/attributes/" + distributionName));
	}

	/**
	 * Verify non empty results of value search
	 *
	 * @param value input searchString for value search request
	 * @throws IOException communication error with the server
	 */
	public void verifyNonEmptySearchResponse(String value) throws IOException {
		LOG.info(String.format("the client receives search results for value %s", value));

		assertThat(searchResponse, not(empty()));
		assertThat(searchResponse, hasSize(20));
		assertThat(searchResponse.get(0), hasEntry("value", value));
	}

	/**
	 * Verify non empty results of value search with params
	 *
	 * @param value            searchString
	 * @param distributionName table Name
	 * @param column           column name
	 * @param businessKey      business key
	 */
	public void verifyValueSearchResponse(String value, String distributionName, String column, String businessKey) {
		LOG.info(String.format("the client receives search results for value %s with distribution name %s , column %s and business key %s",
				value, distributionName, column, businessKey));

		assertThat(searchResponse, not(empty()));
		assertThat(searchResponse, hasSize(1));
		assertThat(searchResponse.get(0), hasEntry("column", column));
		assertThat(searchResponse.get(0), hasEntry("business_key", businessKey));
		assertThat(searchResponse.get(0), hasEntry("value", value));
		assertThat(searchResponse.get(0), hasEntry("table", distributionName));
	}

	/**
	 * Verify non empty results of business key search with params
	 *
	 * @param businessKey      business key
	 * @param distributionName table Name
	 */
	public void verifyBusinessKeySearchResponse(String businessKey, String distributionName) {
		LOG.info(String.format("And the client receives search results for the business key '%s' with distribution name '%s'",
				businessKey, distributionName));

		assertThat(searchResponse, not(empty()));
		assertThat(searchResponse, hasSize(1));
		assertThat(searchResponse.get(0), hasEntry("business_key", businessKey));
		assertThat(searchResponse.get(0), hasEntry("table", distributionName));
	}

	/**
	 * Verify empty results of value search
	 *
	 * @throws IOException communication error with the server
	 */
	public void verifyEmptySearchResponse() throws IOException {
		LOG.info("the client receives empty response for the search request");

		assertThat(searchResponse, empty());
	}

	private void performSearchRequest(List<NameValuePair> nvps, String... pathElements) throws IOException {
		final StringJoiner pathJoiner = new StringJoiner("/", "", "")
				.add("/reference-data/attributes/search");
		Arrays.stream(pathElements).filter(Objects::nonNull).forEach(pathJoiner::add);
		final String content = performGetRequest(pathJoiner.toString(), nvps);
		final TypeReference<List<Map<String, Object>>> typeReference = new TypeReference<List<Map<String, Object>>>() {
		};
		if (content != null) {
			this.searchResponse = new ObjectMapper().readValue(content, typeReference);
		}
	}
}
