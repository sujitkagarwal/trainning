package com.ing.grdm.api.controller;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.cache.MappingsDataCache;
import com.ing.grdm.api.cache.SearchCache;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Unit test for {@link GrdmApiAttributesDataController}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class)
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class GrdmApiAttributesDataControllerTest {

	@Autowired
	private GrdmApiAttributesDataController attributesDataController;
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	private GrdmApiCategoryDefinitionRepository apiCategoryDefinitionRepository;
	@MockBean
	private GrdmApiDataValueRepository apiDataValueRepository;
	@MockBean // Need to mock to prevent unwanted interactions
	private SearchCache searchCache;
	@MockBean // Need to mock to prevent unwanted interactions
	private MappingsDataCache mappingsDataCache;

	@Test
	public void controllerInitializedCorrectly() {
		assertThat(attributesDataController, notNullValue());
	}

	@Test
	public void testAttributesByTableName() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		final List<ApiDataValue> apiDataValues = Arrays.asList(
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1)
		);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableData(anyLong(), anyInt())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[1].business_key", is("AD")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getTableData(anyLong(), anyInt());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testVersionedAttributesByTableName() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(true);
		final List<ApiDataValue> apiDataValues = Arrays.asList(
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 2, "2015-06-01", "2018-06-01"),
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 3, "2018-06-01", null),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1, null, 1, "2015-06-01", "2018-06-01"),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1, null, 2, "2015-06-01", "2018-06-01"),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1, null, 3, "2018-06-01", null)
		);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableData(anyLong(), anyInt())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[0].eff_dt", is("2012-06-01")))
				.andExpect(jsonPath("$[0].end_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[1].business_key", is("NEAS")))
				.andExpect(jsonPath("$[1].eff_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[1].end_dt", is("2018-06-01")))
				.andExpect(jsonPath("$[2].business_key", is("NEAS")))
				.andExpect(jsonPath("$[2].eff_dt", is("2018-06-01")))
				.andExpect(jsonPath("$[2].end_dt", nullValue()))
				.andExpect(jsonPath("$[3].business_key", is("AD")))
				.andExpect(jsonPath("$[4].business_key", is("AD")))
				.andExpect(jsonPath("$[5].business_key", is("AD")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getTableData(anyLong(), anyInt());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
						createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2),
						createApiDataValue("NEAS", "CRS_COMMITTED", "N", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR"),
						createApiDataValue("NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26),
						createApiDataValue("NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14),
						createApiDataValue("NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20),
						createApiDataValue("NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22),
						createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1),
						createApiDataValue("AD", "DESCRIPTION", "Andorra", ColumnType.STRING, 2),
						createApiDataValue("AD", "CRS_COMMITTED", "Y", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR"));
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableDataByColumns(anyLong(), anyInt(), any())).thenReturn(
				apiDataValues);
		mockMvc.perform(get("/attributes/country?column=CCRM_CODE&column=DESCRIPTION&column=CRS_COMMITTED&column=KMV_BUCKET_NUMBER&column=ASSETS_BIGGEST_BANK&column=REFERENCE_DATE&column=PERCENTAGE"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[0].ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$[0].description", is("Northeast Asia")))
				.andExpect(jsonPath("$[0].crs_committed.value", is("N")))
				.andExpect(jsonPath("$[0].crs_committed.table", is("yes_no_indicator")))
				.andExpect(jsonPath("$[0].kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$[0].assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$[0].reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$[0].percentage", is(30.00000000)))
				.andExpect(jsonPath("$[1].business_key", is("AD")))
				.andExpect(jsonPath("$[1].ccrm_code", is("AD")))
				.andExpect(jsonPath("$[1].description", is("Andorra")))
				.andExpect(jsonPath("$[1].crs_committed.value", is("Y")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getTableDataByColumns(anyLong(), anyInt(), any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testVersionedAttributesByTableNameWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(true);
		final List<ApiDataValue> apiDataValues = Arrays.asList(
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "EFF_DT", "2012-06-01", ColumnType.DATE, 2, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "END_DT", "2015-06-01", ColumnType.DATE, 3, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 4, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "CRS_COMMITTED", "N", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR", 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "EFF_DT", "2015-06-01", ColumnType.DATE, 2, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "END_DT", null, ColumnType.DATE, 3, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "CRS_COMMITTED", "N", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR", 2, "2015-06-01", null),
				createApiDataValue("NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20, null, 2, "2015-06-01", null),
				createApiDataValue("NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22, null, 2, "2015-06-01", null),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("AD", "EFF_DT", "2012-06-01", ColumnType.DATE, 2, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("AD", "END_DT", "2015-06-01", ColumnType.DATE, 3, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("AD", "DESCRIPTION", "Andorra", ColumnType.STRING, 2, null, 1, "2012-06-01", "2015-06-01"),
				createApiDataValue("AD", "CRS_COMMITTED", "Y", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR", 1, "2015-06-01", null),
				createApiDataValue("AD", "CCRM_CODE", "AD", ColumnType.STRING, 1, null, 2, "2015-06-01", null),
				createApiDataValue("AD", "EFF_DT", "2015-06-01", ColumnType.DATE, 2, null, 2, "2015-06-01", null),
				createApiDataValue("AD", "END_DT", null, ColumnType.DATE, 3, null, 2, "2015-06-01", null),
				createApiDataValue("AD", "DESCRIPTION", "Andorra", ColumnType.STRING, 2, null, 2, "2015-06-01", null),
				createApiDataValue("AD", "CRS_COMMITTED", "Y", ColumnType.REFERENCE, 63, "YES_NO_INDICATOR", 2, "2015-06-01", null)
		);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableDataByColumns(anyLong(), anyInt(), any())).thenReturn(
				apiDataValues);
		mockMvc.perform(get("/attributes/country?column=CCRM_CODE&column=DESCRIPTION&column=CRS_COMMITTED&column=KMV_BUCKET_NUMBER&column=ASSETS_BIGGEST_BANK&column=REFERENCE_DATE&column=PERCENTAGE"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].business_key", is("NEAS")))
				.andExpect(jsonPath("$[0].eff_dt", is("2012-06-01")))
				.andExpect(jsonPath("$[0].end_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[0].ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$[0].description", is("Northeast Asia")))
				.andExpect(jsonPath("$[0].crs_committed.value", is("N")))
				.andExpect(jsonPath("$[0].crs_committed.table", is("yes_no_indicator")))
				.andExpect(jsonPath("$[0].kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$[0].assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$[0].reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$[0].percentage", is(30.00000000)))
				.andExpect(jsonPath("$[1].business_key", is("NEAS")))
				.andExpect(jsonPath("$[1].eff_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[1].end_dt", nullValue()))
				.andExpect(jsonPath("$[2].business_key", is("AD")))
				.andExpect(jsonPath("$[2].eff_dt", is("2012-06-01")))
				.andExpect(jsonPath("$[2].end_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[2].ccrm_code", is("AD")))
				.andExpect(jsonPath("$[2].description", is("Andorra")))
				.andExpect(jsonPath("$[2].crs_committed.value", is("Y")))
				.andExpect(jsonPath("$[3].business_key", is("AD")))
				.andExpect(jsonPath("$[3].eff_dt", is("2015-06-01")))
				.andExpect(jsonPath("$[3].end_dt", nullValue()))
				.andExpect(jsonPath("$[3].ccrm_code", is("AD")))
				.andExpect(jsonPath("$[3].description", is("Andorra")))
				.andExpect(jsonPath("$[3].crs_committed.value", is("Y")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getTableDataByColumns(anyLong(), anyInt(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableName_DistributionNameNotFound() throws Exception {
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(null);
		mockMvc.perform(get("/attributes/country"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No table found with distribution name 'country'")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(0)).getTableData(anyLong(), anyInt());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableName_ColumnNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getTableDataByColumns(anyLong(), anyInt(), any())).thenReturn(
				Collections.emptyList());
		mockMvc.perform(get("/attributes/country?column=description"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No columns found in table country with name(s) 'description'")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getTableDataByColumns(anyLong(), anyInt(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableName_InvalidDistributionName() throws Exception {
		mockMvc.perform(get("/attributes/country$"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid table name provided")));
		verify(apiCategoryDefinitionRepository, never()).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableName_InvalidColumnNames() throws Exception {
		mockMvc.perform(get("/attributes/country?column=de$cription"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid column name(s) provided")));
		verify(apiCategoryDefinitionRepository, never()).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
						createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2),
						createApiDataValue("NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26),
						createApiDataValue("NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14),
						createApiDataValue("NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20),
						createApiDataValue("NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22));

		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(anyLong(), anyInt(), anyString(), any())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.description", is("Northeast Asia")))
				.andExpect(jsonPath("$.kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$.assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$.reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$.percentage", is(30.00000000)));

		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowData(anyLong(), anyInt(), anyString(), any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testVersionedAttributesByTableNameAndBusinessKey() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(true);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(
						createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "EFF_DT", "2015-06-01", ColumnType.DATE, 2, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "END_DT", null, ColumnType.DATE, 3, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 4, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "KMV_BUCKET_NUMBER", "2", ColumnType.NUMBER, 26, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "ASSETS_BIGGEST_BANK", "12524.35601000", ColumnType.NUMBER, 14, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "REFERENCE_DATE", "2017-06-22", ColumnType.DATE, 20, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "PERCENTAGE", "30", ColumnType.PERCENTAGE, 22, null, 2, "2015-06-01", null)
				);

		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(anyLong(), anyInt(), anyString(), any())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.eff_dt", is("2015-06-01")))
				.andExpect(jsonPath("$.end_dt", nullValue()))
				.andExpect(jsonPath("$.description", is("Northeast Asia")))
				.andExpect(jsonPath("$.kmv_bucket_number", is(2.0)))
				.andExpect(jsonPath("$.assets_biggest_bank", is(12524.35601000)))
				.andExpect(jsonPath("$.reference_date", is("2017-06-22")))
				.andExpect(jsonPath("$.percentage", is(30.00000000)));

		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowData(anyLong(), anyInt(), anyString(), any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKeyWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		List<ApiDataValue> apiDataValues = Arrays.asList(
				createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1),
				createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 2));
		List<String> columns = Arrays.asList("CCRM_CODE", "DESCRIPTION");
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName("COUNTRY")).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList())).thenReturn(
				apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS?column=CCRM_CODE&column=DESCRIPTION"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.description", is("Northeast Asia")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testVersionedAttributesByTableNameAndBusinessKeyWithColumns() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(true);
		List<ApiDataValue> apiDataValues =
				Arrays.asList(
						createApiDataValue("NEAS", "CCRM_CODE", "NEAS", ColumnType.STRING, 1, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "EFF_DT", "2015-06-01", ColumnType.DATE, 2, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "END_DT", null, ColumnType.DATE, 3, null, 2, "2015-06-01", null),
						createApiDataValue("NEAS", "DESCRIPTION", "Northeast Asia", ColumnType.STRING, 4, null, 2, "2015-06-01", null)
				);

		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList())).thenReturn(apiDataValues);
		mockMvc.perform(get("/attributes/country/NEAS?column=DESCRIPTION&column=REFERENCE_DATE"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.business_key", is("NEAS")))
				.andExpect(jsonPath("$.ccrm_code", is("NEAS")))
				.andExpect(jsonPath("$.eff_dt", is("2015-06-01")))
				.andExpect(jsonPath("$.end_dt", nullValue()))
				.andExpect(jsonPath("$.description", is("Northeast Asia")));

		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_DistributionNameNotFound() throws Exception {
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(null);
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No table found with distribution name 'country'")));

		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowData(anyLong(), anyInt(), anyString(), any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_BusinessKeyNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(anyLong(), anyInt(), anyString(), any())).thenReturn(
				new ArrayList<>());
		mockMvc.perform(get("/attributes/country/NEAS"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No record found with business key 'NEAS' in table country")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowData(anyLong(), anyInt(), anyString(), any());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_ColumnNotFound() throws Exception {
		ApiCategoryDefinition apiCategoryDefinition = createApiCategoryDefinition(false);
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenReturn(apiCategoryDefinition);
		when(apiDataValueRepository.getRowData(anyLong(), anyInt(), anyString(), any())).thenReturn(
				new ArrayList<>());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isNotFound())
				.andExpect(jsonPath("$.code", is(404)))
				.andExpect(jsonPath("$.message", is("No record found with business key 'NEAS' or columns with name(s) 'description' in table country")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, times(1)).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_IllegalArgumentException() throws Exception {
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenThrow(new IllegalArgumentException());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Bad Request")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_RuntimeException() throws Exception {
		when(apiCategoryDefinitionRepository.findAttributesCategoryByDistributionName(anyString())).thenThrow(new RuntimeException());
		mockMvc.perform(get("/attributes/country/NEAS?column=description"))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.code", is(500)))
				.andExpect(jsonPath("$.message", is("Internal Server Error")));
		verify(apiCategoryDefinitionRepository, times(1)).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidDistributionName() throws Exception {
		mockMvc.perform(get("/attributes/country$/NEAS"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid table name provided")));
		verify(apiCategoryDefinitionRepository, never()).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidBusinessKey() throws Exception {
		mockMvc.perform(get("/attributes/country/NEAS$"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid business key provided")));
		verify(apiCategoryDefinitionRepository, never()).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	@Test
	public void testAttributesByTableNameAndBusinessKey_InvalidColumnNames() throws Exception {
		mockMvc.perform(get("/attributes/country/NEAS?column=de$cription"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Invalid column name(s) provided")));
		verify(apiCategoryDefinitionRepository, never()).findAttributesCategoryByDistributionName(anyString());
		verify(apiDataValueRepository, never()).getRowDataByColumns(anyLong(), anyInt(), anyString(), any(), anyList());
		verifyNoMoreInteractions(apiCategoryDefinitionRepository);
		verifyNoMoreInteractions(apiDataValueRepository);
	}

	private ApiCategoryDefinition createApiCategoryDefinition(boolean hasVersioning) {
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(134);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("ATTRIBUTES");
		apiCategoryDefinition.setTechnicalId(1604L);
		apiCategoryDefinition.setHasVersioning(hasVersioning);
		return apiCategoryDefinition;
	}

	private ApiDataValue createApiDataValue(String businessKey, String columnName, String storageString,
											ColumnType columnType, int columnOrderNumber) {
		return createApiDataValue(businessKey, columnName, storageString, columnType, columnOrderNumber, null);
	}

	private ApiDataValue createApiDataValue(String businessKey, String columnName, String storageString,
											ColumnType columnType, int columnOrderNumber, String referenceTable) {
		return createApiDataValue(businessKey, columnName, storageString, columnType, columnOrderNumber, referenceTable,
				0, null, null);
	}

	private ApiDataValue createApiDataValue(String businessKey, String columnName, String storageString,
											ColumnType columnType, int columnOrderNumber, String referenceTable,
											int technicalVersion, String effectiveDate, String endDate) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(1001L);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(columnType);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(columnOrderNumber);
		apiDataValue.setBusinessKey(businessKey);
		apiDataValue.setReferenceTable(referenceTable);
		apiDataValue.setTechnicalVersion(technicalVersion);
		if (effectiveDate != null) {
			apiDataValue.setEffectiveDate(LocalDate.parse(effectiveDate));
		}
		if (endDate != null) {
			apiDataValue.setEndDate(LocalDate.parse(endDate));
		}
		return apiDataValue;
	}
}