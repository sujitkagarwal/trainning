package com.ing.grdm.api.security;


import com.ing.api.security.trust.token.access.AccessToken;
import com.ing.api.security.trust.token.access.AccessTokenBuilder;
import com.ing.api.security.trust.token.access.AccessTokenClaimsSet;
import com.ing.api.security.trust.token.access.AccessTokenClaimsSetBuilder;
import com.ing.api.security.trust.token.access.AccessTokenProperties;
import com.ing.api.security.trust.token.access.Executor;
import com.ing.api.security.trust.token.access.ExecutorBuilder;
import com.ing.api.security.trust.token.access.Means;
import com.ing.api.security.trust.token.access.MeansBuilder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Unit tests for access tokens
 */
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
public abstract class ApiSecurityTest {

	@Autowired
	private AccessTokenProperties accessTokenProperties;

	String CreateToken() {
		AccessTokenBuilder accessTokenBuilder = new AccessTokenBuilder(this.accessTokenProperties);
		List<Means> means = new ArrayList<>();
		means.add(new MeansBuilder().setType("means1").build());
		means.add(new MeansBuilder().setType("means2").setId("id2").build());
		Executor executor = new ExecutorBuilder().setProfile("profile")
				.setPerson("person")
				.setMeans(means)
				.setGrant("grant")
				.setLevelOfAssurance(1)
				.setType("customer")
				.build();
		AccessTokenClaimsSet claimsSet = new AccessTokenClaimsSetBuilder().setIssuer("issuer")
				.setTimeToLive(60000)
				.setScopes("scope1", "scope2")
				.setClientId("clientId")
				.setPinningType("Cookie")
				.setPinningValue(UUID.randomUUID().toString())
				.setSetId("setID")
				.setExecutor(executor)
				.build();

		AccessToken accessToken = accessTokenBuilder.createAccessToken(claimsSet);
		return accessToken.serialize();
	}
}
