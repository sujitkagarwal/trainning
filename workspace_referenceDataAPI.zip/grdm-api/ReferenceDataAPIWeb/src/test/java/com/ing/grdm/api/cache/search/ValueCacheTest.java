package com.ing.grdm.api.cache.search;

import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link ValueCache}
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { SearchCacheConfig.class })
@ActiveProfiles("valueCache")
public class ValueCacheTest {

	@Autowired
	private ValueCache valueCache;

	@Test
	public void testAddAndDelete() {
		addStringDocument("country", "code", "NL", "NL");
		addStringDocument("country", "description", "NL", "Netherlands");
		addNumberDocument("country", "assets", "NL", "1.0");
		this.valueCache.openForReading();

		List<Map<String, Object>> result = this.valueCache.search("NL", null, null, null);
		assertThat(result.size(), is(1));
		assertThat(result.get(0).get("value"), is("NL"));
		assertThat(result.get(0).get("table"), is("country"));
		assertThat(result.get(0).get("column"), is("code"));
		assertThat(result.get(0).get("business_key"), is("NL"));

		result = this.valueCache.search("Netherlands", null, null, null);
		assertThat(result.size(), is(1));
		assertThat(result.get(0).get("value"), is("Netherlands"));
		assertThat(result.get(0).get("table"), is("country"));
		assertThat(result.get(0).get("column"), is("description"));
		assertThat(result.get(0).get("business_key"), is("NL"));

		addStringDocument("language", "code", "nl", "nl");
		addStringDocument("language", "description", "nl", "Dutch");
		this.valueCache.openForReading();

		result = this.valueCache.search("nl", null, null, null);
		assertThat(result.size(), is(2));

		result = this.valueCache.search("nl", "language", null, null);
		assertThat(result.size(), is(1));

		result = this.valueCache.search("nl", null, "code", null);
		assertThat(result.size(), is(2));

		deleteDocument("country", "code", "NL");
		deleteDocument("country", "description", "NL");
		this.valueCache.openForReading();

		result = this.valueCache.search("NL", "country", null, null);
		assertThat(result.size(), is(0));

		result = this.valueCache.search("Netherlands", "country", null, null);
		assertThat(result.size(), is(0));
	}

	private void addStringDocument(String tableName, String columnName, String businessKey, String storageString) {
		addDocument(tableName, columnName, ColumnType.STRING, businessKey, storageString);
	}

	private void addNumberDocument(String tableName, String columnName, String businessKey, String storageString) {
		addDocument(tableName, columnName, ColumnType.NUMBER, businessKey, storageString);
	}

	private void addDocument(String tableName, String columnName, ColumnType columnType, String businessKey, String storageString) {
		try {
			this.valueCache.openForWriting(false);
			final ApiDataValue dataValue = createApiDataValue(columnName, columnType, businessKey, storageString);
			this.valueCache.addDocument(dataValue, tableName);
			this.valueCache.commitWriting();
		} finally {
			this.valueCache.closeAfterWriting();
		}
	}

	private void deleteDocument(String tableName, String columnName, String businessKey) {
		try {
			this.valueCache.openForWriting(false);
			this.valueCache.deleteDocument(tableName, columnName, businessKey);
			this.valueCache.commitWriting();
		} finally {
			this.valueCache.closeAfterWriting();
		}
	}

	private ApiDataValue createApiDataValue(String columnName, ColumnType columnType, String businessKey, String storageString) {
		final ApiDataValue dataValue = new ApiDataValue();
		dataValue.setColumnName(columnName);
		dataValue.setBusinessKey(businessKey);
		dataValue.setStorageString(storageString);
		dataValue.setColumnType(columnType);
		return dataValue;
	}

}
