package com.ing.grdm.api.response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.ing.grdm.api.cache.SearchCache;
import org.assertj.core.util.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doAnswer;

/**
 * Unit tests for {@link CachedSearchResponseService}
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 12-12-2017
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class CachedSearchResponseServiceTest {

	@Mock
	private SearchCache cache;

	@Spy
	private ObjectMapper objectMapper;

	@InjectMocks
	private SearchResponseService responseService = new CachedSearchResponseService();

	@Before
	public void init() throws IOException {
		doAnswer(invocation -> {
			final Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country");
			final Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			return Lists.newArrayList(objectMap);
		}).when(this.cache).searchDistributionName("country");
		doAnswer(invocation -> {
			final Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country/CEEUR");
			Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("column", "parent");
			objectMap.put("business_key", "CEEUR");
			objectMap.put("value", "EUROPE");
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			return Lists.newArrayList(objectMap);
		}).when(this.cache).searchValue("euRopE", "country", "parent", "CEEUR");
		doAnswer(invocation -> {
			final Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country/EUROPE");
			Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("column", "ccrm_code");
			objectMap.put("business_key", "EUROPE");
			objectMap.put("value", "EUROPE");
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			return Lists.newArrayList(objectMap);
		}).when(this.cache).searchValue("euRopE", null, null, null);
		doAnswer(invocation -> {
			final List<Map<String, Object>> responseObject = Lists.newArrayList();
			Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/language/NL");
			Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("business_key", "NL");
			objectMap.put("table", "language");
			objectMap.put("links", Lists.newArrayList(linkMap));
			responseObject.add(objectMap);
			linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country/NL");
			objectMap = Maps.newHashMap();
			objectMap.put("business_key", "NL");
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			responseObject.add(objectMap);
			return responseObject;
		}).when(this.cache).searchBusinessKey("nL", null);
		doAnswer(invocation -> {
			final Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/language/NL");
			final Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("business_key", "NL");
			objectMap.put("table", "language");
			objectMap.put("links", Lists.newArrayList(linkMap));
			return Lists.newArrayList(objectMap);
		}).when(this.cache).searchBusinessKey("nL", "language");
		doAnswer(invocation -> {
			final List<Map<String, Object>> responseObject = Lists.newArrayList();
			Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country?column=description");
			Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("column", "description");
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			responseObject.add(objectMap);
			linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/language?column=description");
			objectMap = Maps.newHashMap();
			objectMap.put("column", "description");
			objectMap.put("table", "language");
			objectMap.put("links", Lists.newArrayList(linkMap));
			responseObject.add(objectMap);
			return responseObject;
		}).when(this.cache).searchColumnName("descRiPTiOn", null);
		doAnswer(invocation -> {
			final Map<String, String> linkMap = Maps.newHashMap();
			linkMap.put("rel", "self");
			linkMap.put("href", "/attributes/country?column=description");
			final Map<String, Object> objectMap = Maps.newHashMap();
			objectMap.put("column", "description");
			objectMap.put("table", "country");
			objectMap.put("links", Lists.newArrayList(linkMap));
			return Lists.newArrayList(objectMap);
		}).when(this.cache).searchColumnName("descRiPTiOn", "coUNtRy");
	}

	@Test
	public void testSearchTableName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> result = this.responseService.respondSearchTableName("country", response);
		assertThat(response.getStatus(), is(200));
		assertThat(result.isEmpty(), is(false));
		assertThat(result.get(0).get("table"), is("country"));
		assertThat(result.get(0).containsKey("links"), is(true));
		final List<Map<String, String>> linksList = (List<Map<String, String>>) result.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country"));
	}

	@Test
	public void testSearchTableName_InvalidSearchString() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondSearchTableName("country$", response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid search string provided");
	}

	@Test
	public void testSearchValue() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchValue("euRopE", null, null, null, response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(1));
		assertThat(searchValueResult.get(0).get("column"), is("ccrm_code"));
		assertThat(searchValueResult.get(0).get("business_key"), is("EUROPE"));
		assertThat(searchValueResult.get(0).get("value"), is("EUROPE"));
		assertThat(searchValueResult.get(0).get("table"), is("country"));
	}

	@Test
	public void testSearchValue_WithAllParams() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchValue("euRopE", "country", "parent", "CEEUR", response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(1));
		assertThat(searchValueResult.get(0).get("column"), is("parent"));
		assertThat(searchValueResult.get(0).get("business_key"), is("CEEUR"));
		assertThat(searchValueResult.get(0).get("value"), is("EUROPE"));
		assertThat(searchValueResult.get(0).get("table"), is("country"));
	}

	@Test
	public void testSearchValue_InvalidDistributionName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondSearchValue("nl", "country$", "ccrm_code", "ccrm_code", response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid table name provided");
	}

	@Test
	public void testSearchValue_InvalidColumnName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondSearchValue("eUrOpE", "country", "de$cription", "EUROPE", response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid column name(s) provided");
	}

	@Test
	public void testSearchValue_InvalidBusinessKey() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondSearchValue("eUrOpE", "country", "description", "Europe@", response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid business key provided");
	}

	@Test
	public void testSearchValue_InvalidSearchString() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		this.responseService.respondSearchValue("eUr|OpE", "country", "description", "Europe", response);
		assertThat(response.getStatus(), is(400));
		verifyErrorJson(response.getContentAsString(), 400, "Invalid search string provided");
	}

	@Test
	public void testSearchBusinessKey() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchBusinessKey("nL", null, response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(2));
		assertThat(searchValueResult.get(1).get("business_key"), is("NL"));
		assertThat(searchValueResult.get(1).get("table"), is("country"));
		assertThat(searchValueResult.get(1).containsKey("links"), is(true));
		List<Map<String, String>> linksList = (List<Map<String, String>>) searchValueResult.get(1).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/NL"));
		assertThat(searchValueResult.get(0).get("business_key"), is("NL"));
		assertThat(searchValueResult.get(0).get("table"), is("language"));
		assertThat(searchValueResult.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchValueResult.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/language/NL"));
	}

	@Test
	public void testSearchBusinessKeyWithTableName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchBusinessKey("nL", "language", response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(1));
		assertThat(searchValueResult.get(0).get("business_key"), is("NL"));
		assertThat(searchValueResult.get(0).get("table"), is("language"));
		assertThat(searchValueResult.get(0).containsKey("links"), is(true));
		final List<Map<String, String>> linksList = (List<Map<String, String>>) searchValueResult.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/language/NL"));
	}

	@Test
	public void testSearchColumnName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchColumnName("descRiPTiOn", null, response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(2));
		assertThat(searchValueResult.get(0).get("column"), is("description"));
		assertThat(searchValueResult.get(0).get("table"), is("country"));
		assertThat(searchValueResult.get(0).containsKey("links"), is(true));
		List<Map<String, String>> linksList = (List<Map<String, String>>) searchValueResult.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=description"));
		assertThat(searchValueResult.get(1).get("column"), is("description"));
		assertThat(searchValueResult.get(1).get("table"), is("language"));
		assertThat(searchValueResult.get(1).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchValueResult.get(1).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/language?column=description"));
	}

	@Test
	public void testSearchColumnNameWithTableName() throws IOException {
		final MockHttpServletResponse response = new MockHttpServletResponse();
		final List<Map<String, Object>> searchValueResult =
				this.responseService.respondSearchColumnName("descRiPTiOn", "coUNtRy", response);
		assertThat(response.getStatus(), is(200));
		assertThat(searchValueResult.isEmpty(), is(false));
		assertThat(searchValueResult.size(), is(1));
		assertThat(searchValueResult.get(0).get("column"), is("description"));
		assertThat(searchValueResult.get(0).get("table"), is("country"));
		assertThat(searchValueResult.get(0).containsKey("links"), is(true));
		final List<Map<String, String>> linksList = (List<Map<String, String>>) searchValueResult.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=description"));
	}

	private void verifyErrorJson(String content, int code, String messageContains) {
		new JsonPathExpectationsHelper("$.code").assertValue(content, code);
		new JsonPathExpectationsHelper("$.message")
				.assertValue(content, containsString(messageContains), String.class);
	}
}
