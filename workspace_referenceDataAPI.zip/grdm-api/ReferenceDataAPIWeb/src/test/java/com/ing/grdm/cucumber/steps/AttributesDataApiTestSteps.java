package com.ing.grdm.cucumber.steps;

import com.ing.grdm.cucumber.delegate.AttributesDataApiTestStepsDelegate;
import cucumber.api.java8.En;
import org.springframework.beans.factory.annotation.Autowired;


/**
 * Test steps for the Attributes data API test.
 */
@SuppressWarnings("unused")
public class AttributesDataApiTestSteps implements En {

	@Autowired
	public AttributesDataApiTestSteps(AttributesDataApiTestStepsDelegate delegate) {

		When("^the client requests (\\w+) for table '(\\w+)'$", delegate::requestTable);

		When("^the client requests (\\w+) for table '(\\w+)' and columns '(\\w+)'$",
				delegate::requestTableWithColumns);

		And("^the client receives (\\d+) business keys for table '(.+)'$", delegate::verifyNumberOfBusinessKeys);

		And("^the client receives value for business key '(\\w+)'$", delegate::verifyBusinessKey);

		And("^the client receives no value for business key '(.+)'$", delegate::verifyNoBusinessKey);

		And("^the client receives version for business key '(.+)' with effective date '(.+)' and end date '(.*)'$",
				delegate::verifyBusinessKeyVersion);

		And("^the client receives no version for business key '(.+)' with effective date '(.+)'$",
				delegate::verifyNoBusinessKeyVersion);

		And("^the client receives value for business key '(.+)' and column '(.+)' is '(.+)'$",
				delegate::verifyColumnValue);

		And("^the client receives version for business key '(.+)' with effective date '(.+)' and column '(.+)' is '(.+)'$",
				delegate::verifyVersionedColumnValue);

		When("^the client requests (\\w+) for table '(\\w+)' and business key '(\\w+)'$",
				delegate::requestTableWithBusinessKey);

		When("^the client requests (\\w+) for table '(\\w+)' and business key '(\\w+)' and columns are '(.+)'$",
				delegate::requestTableWithBusinessKeyWithColumns);

	}

}