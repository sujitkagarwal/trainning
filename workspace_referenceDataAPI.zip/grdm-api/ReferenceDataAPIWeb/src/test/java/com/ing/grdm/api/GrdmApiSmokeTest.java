package com.ing.grdm.api;

import com.ing.grdm.api.controller.GrdmApiOverstapController;
import com.ing.grdm.api.controller.GrdmApiAttributesDataController;
import com.ing.grdm.api.controller.GrdmApiTestTokenController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * A simple smoke test
 */
@SpringBootTest(classes = GrdmApiApplication.class, properties = {"grdm.cache.overstap.enable=true"})
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
public class GrdmApiSmokeTest {

	@Autowired
	private GrdmApiTestTokenController grdmApiTestTokenController;

	@Autowired
	private GrdmApiAttributesDataController grdmApiAttributesDataController;

	@Autowired
	private GrdmApiOverstapController grdmApiOverstapController;

	@Test
	public void testGrdmApiTestController() {
		assertThat(grdmApiTestTokenController).isNotNull();
	}

	@Test
	public void testGrdmApiReferenceDataController() {
		assertThat(grdmApiAttributesDataController).isNotNull();
	}

	@Test
	public void testGrdmApiOverstapController() {
		assertThat(grdmApiOverstapController).isNotNull();
	}


}
