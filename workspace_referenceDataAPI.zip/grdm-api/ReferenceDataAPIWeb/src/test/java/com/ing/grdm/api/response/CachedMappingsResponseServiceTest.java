package com.ing.grdm.api.response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.ing.grdm.api.cache.MappingsDataCache;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.JsonPathExpectationsHelper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Collections;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;

/**
 * Unit tests for {@link CachedMappingsResponseService}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class CachedMappingsResponseServiceTest {

	@Mock
	private MappingsDataCache cache;
	@Mock
	private MappingsDataSerializer serializer;
	@Spy
	@SuppressWarnings("unused")
	private ObjectMapper objectMapper;
	@Spy
	private MockHttpServletResponse response;

	@InjectMocks
	private CachedMappingsResponseService responseService;

	@Before
	public void init() throws IOException {
		doReturn(null).when(this.cache).getGlobalByLocal(anyString(), anyString(), anyString());
		doReturn("NL").when(this.cache).getGlobalByLocal("country", "BSK", "394");
		doReturn(Collections.emptyMap()).when(this.cache).getAllGlobalByLocal(anyString(), anyString());
		doReturn(ImmutableMap.of("NL", "394")).when(this.cache).getAllGlobalByLocal("country", "BSK");
		doReturn(Boolean.FALSE).when(this.cache).containsDistributionNameForLocal(anyString());
		doReturn(Boolean.TRUE).when(this.cache).containsDistributionNameForLocal("country");
		doReturn(Boolean.FALSE).when(this.cache).containsSystemCodeForLocal(anyString(), anyString());
		doReturn(Boolean.TRUE).when(this.cache).containsSystemCodeForLocal("country", "BSK");

		doReturn(Collections.emptyList()).when(this.cache).getLocalByGlobal(anyString(), anyString(), anyString());
		doReturn(ImmutableList.of("NL", "394")).when(this.cache).getLocalByGlobal("country", "BSK", "NL");
		doReturn(Collections.emptyMap()).when(this.cache).getAllLocalByGlobal(anyString(), anyString());
		doReturn(ImmutableMap.of("NL", ImmutableList.of("394", "NL"))).when(this.cache).getAllLocalByGlobal("country", "BSK");
		doReturn(Boolean.FALSE).when(this.cache).containsDistributionNameForGlobal(anyString());
		doReturn(Boolean.TRUE).when(this.cache).containsDistributionNameForGlobal("country");
		doReturn(Boolean.FALSE).when(this.cache).containsSystemCodeForGlobal(anyString(), anyString());
		doReturn(Boolean.TRUE).when(this.cache).containsSystemCodeForGlobal("country", "BSK");

		doAnswer(invocation -> {
			((Writer) invocation.getArgument(0)).write("global_code");
			return null;
		}).when(this.serializer).serializeGlobalCode(any(), anyString(), anyString());

		doAnswer(invocation -> {
			((Writer) invocation.getArgument(0)).write("[global_codes]");
			return null;
		}).when(this.serializer).serializeGlobalMappings(any(), anyMap());

		doAnswer(invocation -> {
			((Writer) invocation.getArgument(0)).write("local_codes");
			return null;
		}).when(this.serializer).serializeLocalCodes(any(), anyList());

		doAnswer(invocation -> {
			((Writer) invocation.getArgument(0)).write("[local_codes]");
			return null;
		}).when(this.serializer).serializeLocalMappings(any(), anyMap());
	}

	@Test
	public void testRespondGlobalByLocal() throws IOException {
		this.responseService.respondGlobalByLocal("country", "BSK", "394", this.response);

		assertThat(this.response.getStatus(), is(200));
		assertThat(this.response.getContentAsString(), is("global_code"));
	}

	@Test
	public void testRespondGlobalByLocalIllegalDistributionName() throws IOException {
		this.responseService.respondGlobalByLocal("coun|&*", "BSK", "394", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid table name provided");
	}

	@Test
	public void testRespondGlobalByLocalIllegalSystemCode() throws IOException {
		this.responseService.respondGlobalByLocal("country", "INVALID", "394", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid system code provided");
	}

	@Test
	public void testRespondGlobalByLocalIllegalCode() throws IOException {
		this.responseService.respondGlobalByLocal("country", "BSK", "code|invalid", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid code provided");
	}

	@Test
	public void testRespondGlobalByLocalDistributionNameNotFound() throws IOException {
		this.responseService.respondGlobalByLocal("currency", "BSK", "394", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No table found with distribution name");
	}

	@Test
	public void testRespondGlobalByLocalSystemCodeNotFound() throws IOException {
		this.responseService.respondGlobalByLocal("country", "PDS", "394", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mappings found for system code");
	}

	@Test
	public void testRespondGlobalByLocalCodeNotFound() throws IOException {
		this.responseService.respondGlobalByLocal("country", "BSK", "001", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mapping found for code");
	}

	@Test
	public void testRespondAllGlobalByLocal() throws IOException {
		this.responseService.respondAllGlobalByLocal("country", "BSK", this.response);

		assertThat(this.response.getStatus(), is(200));
		assertThat(this.response.getContentAsString(), is("[global_codes]"));
	}

	@Test
	public void testRespondAllGlobalByLocalIllegalDistributionName() throws IOException {
		this.responseService.respondAllGlobalByLocal("coun|&*", "BSK", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid table name provided");
	}

	@Test
	public void testRespondAllGlobalByLocalIllegalSystemCode() throws IOException {
		this.responseService.respondAllGlobalByLocal("country", "INVALID", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid system code provided");
	}

	@Test
	public void testRespondAllGlobalByLocalDistributionNameNotFound() throws IOException {
		this.responseService.respondAllGlobalByLocal("currency", "BSK", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No table found with distribution name");
	}

	@Test
	public void testRespondAllGlobalByLocalSystemCodeNotFound() throws IOException {
		this.responseService.respondAllGlobalByLocal("country", "PDS", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mappings found for system code");
	}

	@Test
	public void testRespondLocalByGlobal() throws IOException {
		this.responseService.respondLocalByGlobal("country", "BSK", "NL", this.response);

		assertThat(this.response.getStatus(), is(200));
		assertThat(this.response.getContentAsString(), is("local_codes"));
	}

	@Test
	public void testRespondLocalByGlobalIllegalDistributionName() throws IOException {
		this.responseService.respondLocalByGlobal("coun|&*", "BSK", "NL", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid table name provided");
	}

	@Test
	public void testRespondLocalByGlobalIllegalSystemCode() throws IOException {
		this.responseService.respondLocalByGlobal("country", "INVALID", "NL", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid system code provided");
	}

	@Test
	public void testRespondLocalByGlobalIllegalCode() throws IOException {
		this.responseService.respondLocalByGlobal("country", "BSK", "code|invalid", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid code provided");
	}

	@Test
	public void testRespondLocalByGlobalDistributionNameNotFound() throws IOException {
		this.responseService.respondLocalByGlobal("currency", "BSK", "NL", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No table found with distribution name");
	}

	@Test
	public void testRespondLocalByGlobalSystemCodeNotFound() throws IOException {
		this.responseService.respondLocalByGlobal("country", "PDS", "394", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mappings found for system code");
	}

	@Test
	public void testRespondLocalByGlobalCodeNotFound() throws IOException {
		this.responseService.respondLocalByGlobal("country", "BSK", "001", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mappings found for code");
	}

	@Test
	public void testRespondAllLocalByGlobal() throws IOException {
		this.responseService.respondAllLocalByGlobal("country", "BSK", this.response);

		assertThat(this.response.getStatus(), is(200));
		assertThat(this.response.getContentAsString(), is("[local_codes]"));
	}

	@Test
	public void testRespondAllLocalByGlobalIllegalDistributionName() throws IOException {
		this.responseService.respondAllLocalByGlobal("coun|&*", "BSK", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid table name provided");
	}

	@Test
	public void testRespondAllLocalByGlobalIllegalSystemCode() throws IOException {
		this.responseService.respondAllLocalByGlobal("country", "INVALID", this.response);

		assertThat(this.response.getStatus(), is(400));
		verifyErrorJson(this.response, 400, "Invalid system code provided");
	}

	@Test
	public void testRespondAllLocalByGlobalDistributionNameNotFound() throws IOException {
		this.responseService.respondAllLocalByGlobal("currency", "BSK", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No table found with distribution name");
	}

	@Test
	public void testRespondAllLocalByGlobalSystemCodeNotFound() throws IOException {
		this.responseService.respondAllLocalByGlobal("country", "PDS", this.response);

		assertThat(this.response.getStatus(), is(404));
		verifyErrorJson(this.response, 404, "No mappings found for system code");
	}

	private void verifyErrorJson(MockHttpServletResponse response, int code, String messageContains)
			throws UnsupportedEncodingException {
		new JsonPathExpectationsHelper("$.code").assertValue(response.getContentAsString(), code);
		new JsonPathExpectationsHelper("$.message")
				.assertValue(response.getContentAsString(), containsString(messageContains), String.class);
	}
}
