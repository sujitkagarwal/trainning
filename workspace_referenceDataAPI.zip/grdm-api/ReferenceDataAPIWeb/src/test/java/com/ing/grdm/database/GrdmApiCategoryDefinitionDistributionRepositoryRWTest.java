package com.ing.grdm.database;

import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import com.ing.grdm.domain.DistributionImportStatus;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Unit tests for {@link GrdmApiCategoryDefinitionDistributionRepository}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {GrdmDatabaseConfig.class})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class GrdmApiCategoryDefinitionDistributionRepositoryRWTest {

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository repository;

	@Test
	public void testInsert() throws ParseException {
		final Date importDate = new SimpleDateFormat("yyyyMMdd").parse("20171001");
		final Date lastUpdateDate = new SimpleDateFormat("yyyyMMdd").parse("20171003");
		final ApiCategoryDefinitionDistribution categoryDefinitionImport = insertApiCategoryDefinitionDistribution(
				1L, 10, "filename", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);
		this.repository.save(categoryDefinitionImport);

		final ApiCategoryDefinitionDistribution result = this.repository.findOne(new ApiCategoryDefinitionDistributionId(1L, 10));

		Assert.assertEquals(Long.valueOf(1L), result.getCategoryDefinitionId());
		Assert.assertEquals(Integer.valueOf(10), result.getDistributionSequenceNumber());
		Assert.assertEquals("filename", result.getFileName());
		Assert.assertEquals(DistributionImportStatus.ACTIVE, result.getStatus());
		Assert.assertEquals(importDate, result.getImportDate());
		Assert.assertEquals(lastUpdateDate, result.getLastUpdateDate());
	}

	@Test
	public void testLastDistributionSequenceNumber() {
		insertApiCategoryDefinitionDistribution(1L, 1, "some file", DistributionImportStatus.ACTIVE, new Date(), new Date());
		insertApiCategoryDefinitionDistribution(2L, 2, "some file", DistributionImportStatus.ACTIVE, new Date(), new Date());
		insertApiCategoryDefinitionDistribution(3L, 2, "some file", DistributionImportStatus.ACTIVE, new Date(), new Date());
		insertApiCategoryDefinitionDistribution(4L, 3, "some file", DistributionImportStatus.ACTIVE, new Date(), new Date());
		insertApiCategoryDefinitionDistribution(5L, 3, "some file", DistributionImportStatus.ACTIVE, new Date(), new Date());

		Assert.assertEquals(Integer.valueOf(3), this.repository.getLastDistributionSequenceNumber());
	}

	@Test
	public void testGetCategoryDefinitionsWithInactivesToDelete() throws ParseException {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		final Date importDate = dateFormat.parse("20171001");
		final Date lastUpdateDate = dateFormat.parse("20171002");
		insertApiCategoryDefinitionDistribution(1L, 1, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(1L, 2, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(1L, 3, "some file", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(2L, 1, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(2L, 2, "some file", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);

		final List<Long> inactivesToDelete = this.repository.getCategoryDefinitionsWithInactivesToDelete(1L);

		Assert.assertEquals(1, inactivesToDelete.size());
		Assert.assertEquals(Long.valueOf(1), inactivesToDelete.get(0));
	}

	@Test
	public void testGetCategoryDefinitionDistributionsToDelete() throws ParseException {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		final Date importDate = dateFormat.parse("20171001");
		final Date lastUpdateDate = dateFormat.parse("20171002");
		insertApiCategoryDefinitionDistribution(1L, 1, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(1L, 2, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(1L, 3, "some file", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);

		final List<ApiCategoryDefinitionDistribution> inactivesToDelete = this.repository.getCategoryDefinitionDistributionsToDelete(1L);

		Assert.assertEquals(1, inactivesToDelete.size());
		Assert.assertEquals(Long.valueOf(1), inactivesToDelete.get(0).getCategoryDefinitionId());
		Assert.assertEquals(Integer.valueOf(1), inactivesToDelete.get(0).getDistributionSequenceNumber());
	}

	@Test
	public void testGetAllActiveAndImportedCategoryDefinitionDistributions() throws ParseException {
		final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		final Date importDate = dateFormat.parse("20171001");
		final Date lastUpdateDate = dateFormat.parse("20171002");
		insertApiCategoryDefinitionDistribution(1L, 1, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(1L, 2, "some file", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(2L, 1, "some file", DistributionImportStatus.INACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(2L, 2, "some file", DistributionImportStatus.ACTIVE, importDate, lastUpdateDate);
		insertApiCategoryDefinitionDistribution(2L, 3, "some file", DistributionImportStatus.IMPORTED, importDate, lastUpdateDate);

		final List<ApiCategoryDefinitionDistribution> categoryDefinitionsToInactivate = this.repository.getAllActiveAndImportedCategoryDefinitionDistributions();

		Assert.assertFalse(categoryDefinitionsToInactivate.isEmpty());
		Assert.assertEquals(3, categoryDefinitionsToInactivate.size());
		Assert.assertEquals(1L, categoryDefinitionsToInactivate.get(0).getCategoryDefinitionId().longValue());
		Assert.assertEquals(2, categoryDefinitionsToInactivate.get(0).getDistributionSequenceNumber().intValue());
		Assert.assertEquals(2L, categoryDefinitionsToInactivate.get(1).getCategoryDefinitionId().longValue());
		Assert.assertEquals(2, categoryDefinitionsToInactivate.get(1).getDistributionSequenceNumber().intValue());
		Assert.assertEquals(2L, categoryDefinitionsToInactivate.get(2).getCategoryDefinitionId().longValue());
		Assert.assertEquals(3, categoryDefinitionsToInactivate.get(2).getDistributionSequenceNumber().intValue());
	}

	private ApiCategoryDefinitionDistribution insertApiCategoryDefinitionDistribution(
			Long categoryDefinitionId, Integer distributionSequenceNumber, String fileName, DistributionImportStatus status, Date importDate, Date lastUpdateDate) {
		final ApiCategoryDefinitionDistribution categoryDefinitionImport = new ApiCategoryDefinitionDistribution();
		categoryDefinitionImport.setCategoryDefinitionId(categoryDefinitionId);
		categoryDefinitionImport.setDistributionSequenceNumber(distributionSequenceNumber);
		categoryDefinitionImport.setFileName(fileName);
		categoryDefinitionImport.setStatus(status);
		categoryDefinitionImport.setImportDate(importDate);
		categoryDefinitionImport.setLastUpdateDate(lastUpdateDate);
		return this.repository.save(categoryDefinitionImport);
	}
}
