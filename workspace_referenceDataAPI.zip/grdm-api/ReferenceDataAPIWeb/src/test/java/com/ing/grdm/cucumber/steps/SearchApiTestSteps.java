package com.ing.grdm.cucumber.steps;

import com.ing.grdm.cucumber.delegate.SearchApiTestStepsDelegate;
import cucumber.api.java8.En;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Test steps for the search API test.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
@SuppressWarnings("unused")
public class SearchApiTestSteps implements En {
	@Autowired
	public SearchApiTestSteps(SearchApiTestStepsDelegate delegate) {

		When("^the client makes a search request for the table '(.*)'$", delegate::searchTable);

		When("^the client makes a search request for the value '(.*)'$", delegate::searchValue);

		When("^the client makes a search request for the column '(.*)'$", delegate::searchColumn);

		When("^the client makes a search request for the business key '(.*)'$", delegate::searchBusinessKey);

		When("^the client makes a search request with table name '(.*)', column '(.*)' and business key '(.*)' for the value '(.*)'$",
				delegate::searchValueParameterized);

		When("^the client makes a search request with table name '(.*)' for the column '(.*)'$",
				delegate::searchColumnParameterized);

		When("^the client makes a search request with table name '(.*)' for the business key '(.*)'$",
				delegate::searchBusinessKeyParameterized);

		And("^the client receives search results for table '(\\w+)'$", delegate::verifyTableSearchResponse);

		And("^the client receives search results for the value '(\\w+)' with distribution name '(\\w+)' , column '(\\w+)' and business key '(\\w+)'$",
				delegate::verifyValueSearchResponse);

		And("^the client receives search results for the business key '(\\w+)' with distribution name '(\\w+)'$",
				delegate::verifyBusinessKeySearchResponse);

		And("^the client receives search results with best matches for the value '(\\w+)'$",
				delegate::verifyNonEmptySearchResponse);

		And("^the client receives empty response for the search request$",
				delegate::verifyEmptySearchResponse);
	}
}
