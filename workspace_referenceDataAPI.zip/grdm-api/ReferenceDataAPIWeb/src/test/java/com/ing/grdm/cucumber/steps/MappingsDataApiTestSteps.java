package com.ing.grdm.cucumber.steps;

import com.ing.grdm.cucumber.delegate.MappingsDataApiTestStepsDelegate;
import cucumber.api.java8.En;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Test steps for the Mappings data API test.
 */
@SuppressWarnings("unused")
public class MappingsDataApiTestSteps implements En {

	@Autowired
	public MappingsDataApiTestSteps(MappingsDataApiTestStepsDelegate delegate) {

		When("^the client requests global mappings for table '(.+)' and system '(\\w+)'$",
				delegate::requestGlobalMappingsBySystemCode);

		When("^the client requests mappings for table '(.+)' and system '(\\w+)' and local code '(.+)'$",
				delegate::requestGlobalCodeByLocalCode);

		When("^the client requests local mappings for table '(.+)' and system '(\\w+)'$",
				delegate::requestLocalMappingsBySystemCode);

		When("^the client requests mappings for table '(.+)' and system '(\\w+)' and global code '(.+)'$",
				delegate::requestLocalCodesByGlobalCode);

		Then("^the client receives global mappings for '(\\w+)': '(\\w+)'$", delegate::verifyGlobalMappings);

		Then("^the client receives global code '(\\w+)'$", delegate::verifyGlobalCode);

		Then("^the client receives local mappings for '(\\w+)': (.+)$", delegate::verifyLocalMappings);

		Then("^the client receives local codes (.+)$", delegate::verifyLocalCodes);
	}
}
