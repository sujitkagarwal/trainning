package com.ing.grdm.api.cache;

import com.ing.grdm.api.cache.search.CacheReadException;
import com.ing.grdm.api.cache.search.CacheWriteException;
import com.ing.grdm.api.cache.search.TableNameCache;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.springframework.test.util.ReflectionTestUtils.getField;
import static org.springframework.test.util.ReflectionTestUtils.setField;

/**
 * Unit tests for {@link SearchCache}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class SearchCacheTest {

	@Mock
	private TableNameCache tableNameCache;
	@Mock
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Mock
	private GrdmApiDataValueRepository dataValueRepository;

	@InjectMocks
	private SearchCache searchCache;

	@Before
	public void init() throws IOException {
		setField(this.searchCache, "registeredCaches", Collections.singletonList(this.tableNameCache));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_IncludedCategories() {
		setField(this.searchCache, "excludedCategories", new String[0]);
		setField(this.searchCache, "includedCategories", new String[]{"country", "language"});
		doReturn(1).when(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		doAnswer(invocation -> {
					// included
					final ApiCategoryDefinition categoryDefinition1 = new ApiCategoryDefinition();
					categoryDefinition1.setTechnicalId(1001L);
					categoryDefinition1.setActiveDistributionSequenceNumber(1);
					categoryDefinition1.setDistributionName("country");
					categoryDefinition1.setCategoryType("Attributes");

					// included but ignored because of no active distribution sequence number
					final ApiCategoryDefinition categoryDefinition2 = new ApiCategoryDefinition();
					categoryDefinition2.setTechnicalId(1002L);
					categoryDefinition2.setActiveDistributionSequenceNumber(null);
					categoryDefinition2.setDistributionName("language");
					categoryDefinition2.setCategoryType("Attributes");

					// not included
					final ApiCategoryDefinition categoryDefinition3 = new ApiCategoryDefinition();
					categoryDefinition3.setTechnicalId(1003L);
					categoryDefinition3.setActiveDistributionSequenceNumber(1);
					categoryDefinition3.setDistributionName("product_type");
					categoryDefinition3.setCategoryType("Attributes");

					// not included, mappings category
					final ApiCategoryDefinition categoryDefinition4 = new ApiCategoryDefinition();
					categoryDefinition4.setTechnicalId(1043L);
					categoryDefinition4.setActiveDistributionSequenceNumber(1);
					categoryDefinition4.setDistributionName("country");
					categoryDefinition4.setCategoryType("Mappings");

					return Arrays.asList(categoryDefinition1, categoryDefinition2, categoryDefinition3, categoryDefinition4);
				}
		).when(this.categoryDefinitionRepository).findAll();
		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).openForReading();
		verify(this.tableNameCache).addDocument("country");
		verify(this.tableNameCache, never()).addDocument("language");
		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.dataValueRepository).getAllRowData(1001L, 1);
		verify(this.dataValueRepository, never()).getAllRowData(1002L, 1);
		verify(this.dataValueRepository, never()).getAllRowData(1003L, 1);

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(1));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_ExcludedCategories() {
		setField(this.searchCache, "excludedCategories", new String[]{"product_type"});
		setField(this.searchCache, "includedCategories", new String[0]);
		doReturn(1).when(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		doAnswer(invocation -> {
					final ApiCategoryDefinition categoryDefinition1 = new ApiCategoryDefinition();
					categoryDefinition1.setTechnicalId(1001L);
					categoryDefinition1.setActiveDistributionSequenceNumber(1);
					categoryDefinition1.setDistributionName("country");
					categoryDefinition1.setCategoryType("Attributes");

					final ApiCategoryDefinition categoryDefinition2 = new ApiCategoryDefinition();
					categoryDefinition2.setTechnicalId(1002L);
					categoryDefinition2.setActiveDistributionSequenceNumber(null);
					categoryDefinition2.setDistributionName("language");
					categoryDefinition2.setCategoryType("Attributes");

					final ApiCategoryDefinition categoryDefinition3 = new ApiCategoryDefinition();
					categoryDefinition3.setTechnicalId(1003L);
					categoryDefinition3.setActiveDistributionSequenceNumber(1);
					categoryDefinition3.setDistributionName("product_type");
					categoryDefinition3.setCategoryType("Attributes");

					return Arrays.asList(categoryDefinition1, categoryDefinition3);
				}
		).when(this.categoryDefinitionRepository).findAll();
		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).openForReading();
		verify(this.tableNameCache).addDocument("country");
		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.dataValueRepository).getAllRowData(1001L, 1);
		verify(this.dataValueRepository, never()).getAllRowData(1002L, 1);
		verify(this.dataValueRepository, never()).getAllRowData(1003L, 1);

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(1));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_ExistingDistributionNumber() {
		setField(this.searchCache, "currentDistributionSequenceNumber", 1);

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent(1, false));

		verify(this.tableNameCache, never()).openForWriting(anyBoolean());
		verify(this.tableNameCache, never()).commitWriting();
		verify(this.tableNameCache, never()).rollbackWriting();
		verify(this.categoryDefinitionRepository, never()).getActiveDistributionSequenceNumber();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(1));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_NoCurrentDistributionSequenceNumber() {
		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent(1, false));

		verify(this.categoryDefinitionRepository, never()).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).openForReading();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(1));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_NewDistributionNumber() {
		setField(this.searchCache, "currentDistributionSequenceNumber", 1);
		doReturn(2).when(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache, never()).rollbackWriting();
		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(2));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_ReloadInProgress() {
		setField(this.searchCache, "currentDistributionSequenceNumber", 1);
		doThrow(new IllegalStateException()).when(this.tableNameCache).openForWriting(anyBoolean());

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache, never()).commitWriting();
		verify(this.tableNameCache, never()).rollbackWriting();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(1));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_CacheWriteExceptionOnWrite() {
		setField(this.searchCache, "currentDistributionSequenceNumber", 1);
		doThrow(new CacheWriteException(null)).when(this.tableNameCache).openForWriting(anyBoolean());

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache, never()).commitWriting();
		verify(this.tableNameCache, never()).rollbackWriting();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(nullValue()));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_CacheWriteExceptionOnCommit() {
		setField(this.searchCache, "currentDistributionSequenceNumber", 1);
		doThrow(new CacheWriteException(null)).when(this.tableNameCache).commitWriting();

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache).openForWriting(anyBoolean());
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).rollbackWriting();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(nullValue()));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_CacheReadException() {
		doThrow(new CacheReadException(null)).when(this.tableNameCache).openForReading();

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).openForReading();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(nullValue()));
	}

	@Test
	public void testHandleAttributesDataChangedEvent_NoCategoryDefinition() {
		doReturn(null).when(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();

		this.searchCache.handleAttributesDataChangedEvent(new AttributesDataChangedEvent());

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.tableNameCache).commitWriting();
		verify(this.tableNameCache).openForReading();

		final Object number = getField(this.searchCache, "currentDistributionSequenceNumber");
		assertThat(number, is(nullValue()));
	}

}
