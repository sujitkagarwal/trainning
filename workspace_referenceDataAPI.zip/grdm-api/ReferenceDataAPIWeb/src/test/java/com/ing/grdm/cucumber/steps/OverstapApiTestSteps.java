package com.ing.grdm.cucumber.steps;

import com.ing.grdm.cucumber.delegate.OverstapApiTestStepsDelegate;
import cucumber.api.java8.En;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Test steps for the overstap test.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
public class OverstapApiTestSteps implements En {
	@Autowired
	public OverstapApiTestSteps(OverstapApiTestStepsDelegate delegate) {

		When("^the client requests forward accounts for ibans '(.*)'$", delegate::requestForwardAccounts);

		When("^the client requests forward accounts for filter date '(.*)' and ibans '(.+)'$",
				delegate::requestForwardAccountsWithFilterDate);

		When("^the client makes an invalid request$", delegate::placeInvalidRequest);

		And("^the client receives forward accounts for ibans '(.+)'$", delegate::verifyForwardAccountsByIbans);

		And("^the client receives empty array of forward accounts$", delegate::verifyEmptyForwardAccountsByIbans);

		And("^the client receives filter date as '(.*)'$", delegate::verifyFilterDate);
	}
}
