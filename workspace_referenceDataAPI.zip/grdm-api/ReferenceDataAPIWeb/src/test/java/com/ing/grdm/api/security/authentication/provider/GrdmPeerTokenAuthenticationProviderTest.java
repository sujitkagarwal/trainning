package com.ing.grdm.api.security.authentication.provider;


import com.ing.api.security.trust.TrustException;
import com.ing.api.security.trust.http.HttpMethod;
import com.ing.api.security.trust.token.peer.Endpoint;
import com.ing.api.security.trust.token.peer.EndpointBuilder;
import com.ing.api.security.trust.token.peer.PeerToken;
import com.ing.api.security.trust.token.peer.PeerTokenClaimsSet;
import com.ing.api.security.trust.token.peer.PeerTokenParser;
import com.ing.grdm.api.cache.WhiteListCache;
import com.ing.grdm.api.security.authentication.exception.GrdmAuthenticationException;
import com.ing.grdm.api.security.authentication.model.JWTToken;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.Authentication;

import javax.security.auth.x500.X500Principal;
import java.security.cert.X509Certificate;
import java.util.Arrays;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

/**
 * Unit tests for {@link GrdmPeerTokenAuthenticationProvider}
 */

@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class GrdmPeerTokenAuthenticationProviderTest {
	@Mock
	WhiteListCache whiteListCache;
	@Mock
	private PeerTokenParser peerTokenParser;

	@InjectMocks
	private GrdmPeerTokenAuthenticationProvider grdmPeerTokenAuthenticationProvider;

	private final String TEST_PEER_TOKEN = "Test_Peer_Token";
	private X509Certificate cert;
	private PeerToken peerToken;

	@Test
	public void testAuthenticationWithPeerToken() throws TrustException {
		setUpMockData();
		given(peerTokenParser.parsePeerToken(TEST_PEER_TOKEN, cert)).willReturn(peerToken);
		JWTToken authentication = (JWTToken) grdmPeerTokenAuthenticationProvider.authenticate(new JWTToken("Test_Peer_Token", cert));
		assertThat(authentication.getToken(), is("Test_Peer_Token"));
	}

	@Test
	public void testAuthenticationWithoutPeerToken() throws TrustException {
		setUpMockData();
		given(this.whiteListCache.contains(anyString())).willReturn(true);
		Authentication authenticate = grdmPeerTokenAuthenticationProvider.authenticate(new JWTToken(null, cert));
		assertTrue(authenticate.isAuthenticated());
	}


	@Test(expected = GrdmAuthenticationException.class)
	public void testAuthenticationExceptionWithoutPeerToke() {
		setUpMockData();
		given(this.whiteListCache.contains(anyString())).willThrow(GrdmAuthenticationException.class);
		given(this.whiteListCache.contains(anyString())).willReturn(true);
		grdmPeerTokenAuthenticationProvider.authenticate(new JWTToken(null, cert));
	}


	@Test(expected = GrdmAuthenticationException.class)
	public void testAuthenticationExceptionWithPeerToken() throws TrustException {
		setUpMockData();
		given(peerTokenParser.parsePeerToken(TEST_PEER_TOKEN, cert)).willThrow(GrdmAuthenticationException.class);
		grdmPeerTokenAuthenticationProvider.authenticate(new JWTToken("Test_Peer_Token", cert));
	}

	private void setUpMockData() {
		this.cert = mock(X509Certificate.class);
		X500Principal principal = new X500Principal("CN=lrv1714f.europe.intranet, OU=ReferenceDataAPI, OU=TST, OU=PKI, OU=Services, O=ING");
		given(cert.getSubjectDN()).willReturn(principal);
		this.peerToken = mock(PeerToken.class);
		PeerTokenClaimsSet peerTokenClaimsSet = mock(PeerTokenClaimsSet.class);
		given(peerToken.getClaimsSet()).willReturn(peerTokenClaimsSet);
		Endpoint endpoint1 = new EndpointBuilder().setMethod(HttpMethod.GET).setHost("api.ing.com").setPathTemplate("/reference-data/attributes/country").setVersion("1.0.0").build();
		given(peerTokenClaimsSet.getEndpoints()).willReturn(Arrays.asList(endpoint1));
	}

}
