package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.domain.ForwardAccount;
import com.ing.grdm.api.domain.ForwardAccountsResponseData;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual overstap test steps. Needs to be wired in the cucumber glue class.
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 30-11-2017
 */
@Component
@Scope("cucumber-glue")
public class OverstapApiTestStepsDelegate extends GrdmApiTestStepsDelegate {

	private static final Log LOG = LogFactory.getLog(OverstapApiTestStepsDelegate.class);

	private static final String OVERSTAP_API_PATH = "/reference-data/forwarding-accounts";

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private JsonFactory jsonFactory;

	// The deserialized json response of the forward accounts request
	private ForwardAccountsResponseData forwardAccountsResponseData;

	// The serialized object for the overstap request
	private final Writer overstapRequestObject = new StringWriter();

	/**
	 * Perform overstap request for the list of old ibans
	 *
	 * @param ibans List of old ibans
	 * @throws IOException communication error with the server
	 */
	public void requestForwardAccounts(String ibans) throws IOException {
		LOG.info(String.format("the client requests forward accounts for ibans %s", ibans));
		final List<String> nvps = Arrays.stream(StringUtils.split(ibans, ',')).collect(Collectors.toList());
		performForwardAccountsRequest(nvps, null);
	}

	/**
	 * Perform overstap request for the list of old ibans and a valid filter date
	 *
	 * @param ibans      list of old ibans
	 * @param filterDate a valid filter date
	 * @throws IOException communication error with the server
	 */
	public void requestForwardAccountsWithFilterDate(String filterDate, String ibans) throws IOException {
		LOG.info(String.format("the client requests forward accounts for ibans %s and filterdate %s", ibans, filterDate));
		final List<String> nvps = Arrays.stream(StringUtils.split(ibans, ',')).collect(Collectors.toList());
		performForwardAccountsRequest(nvps, filterDate);
	}

	/**
	 * Verify forward accounts received in response by passing list of old ibans
	 *
	 * @param oldIbans list of old ibans
	 */
	public void verifyForwardAccountsByIbans(String oldIbans) {
		LOG.info(String.format("the client receives forward accounts for ibans %s", oldIbans));
		final List<String> oldIbansList = Arrays.stream(StringUtils.split(oldIbans, ','))
				.collect(Collectors.toList());
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final List<ForwardAccount> forwardAccounts = this.forwardAccountsResponseData.getForwardAccounts();
		assertThat(forwardAccounts, notNullValue());
		assertThat(forwardAccounts, hasSize(oldIbansList.size()));
		assertThat((forwardAccounts.get(0).getAccountId()), is(oldIbansList.get(0)));
		assertThat((forwardAccounts.get(1).getAccountId()), is(oldIbansList.get(1)));
	}

	/**
	 * Verify that forward accounts received in response is empty
	 */
	public void verifyEmptyForwardAccountsByIbans() {
		LOG.info("the client receives empty array of forward accounts");
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final List<ForwardAccount> forwardAccounts = this.forwardAccountsResponseData.getForwardAccounts();
		assertThat(forwardAccounts, notNullValue());
		assertThat(forwardAccounts, empty());
	}

	/**
	 * Verify filter date received in response
	 */
	public void verifyFilterDate(String filterDate) {
		LOG.info(String.format("the client receives filter date as %s", filterDate));
		if (this.forwardAccountsResponseData == null) {
			return;
		}
		final DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE;
		final LocalDate receivedFilterDate = this.forwardAccountsResponseData.getFilterDate();
		assertThat(receivedFilterDate, notNullValue());
		assertThat(receivedFilterDate, is(LocalDate.parse(filterDate, formatter)));
	}

	/**
	 * Making an invalid request to forward accounts API
	 */
	public void placeInvalidRequest() throws IOException {
		LOG.info("the client makes an invalid request");

		performPostRequest(OVERSTAP_API_PATH, "Some bogus request");
	}

	private void performForwardAccountsRequest(List<String> oldIbans, String filterDate) throws IOException {
		final String requestData = createForwardAccountsRequestData(oldIbans, filterDate);
		final String content = performPostRequest(OVERSTAP_API_PATH, requestData);
		if (content != null) {
			this.forwardAccountsResponseData = objectMapper.readValue(content, ForwardAccountsResponseData.class);
		}
	}

	private String createForwardAccountsRequestData(List<String> oldIbans, String filterDate) throws IOException {
		try (JsonGenerator jsonGenerator = this.jsonFactory.createGenerator(this.overstapRequestObject)) {
			jsonGenerator.writeStartObject();
			jsonGenerator.writeFieldName("accountIds");
			jsonGenerator.writeStartArray();
			for (String accountId : oldIbans) {
				jsonGenerator.writeString(accountId);
			}
			jsonGenerator.writeEndArray();
			if (filterDate != null) {
				jsonGenerator.writeFieldName("filterDate");
				jsonGenerator.writeString(filterDate);
			}
			jsonGenerator.writeEndObject();
			jsonGenerator.flush();
		}
		return this.overstapRequestObject.toString();
	}
}
