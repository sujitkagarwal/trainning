package com.ing.grdm.distro.batch;

import com.ing.grdm.database.GrdmApiCategoryDefinitionDistributionRepository;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmDatabaseConfig;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiCategoryDefinitionDistribution;
import com.ing.grdm.domain.ApiCategoryDefinitionDistributionId;
import com.ing.grdm.domain.DistributionImportStatus;
import org.junit.After;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.test.JobScopeTestExecutionListener;
import org.springframework.batch.test.MetaDataInstanceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemNotFoundException;
import java.nio.file.FileSystems;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;

import static org.springframework.batch.test.MetaDataInstanceFactory.DEFAULT_JOB_EXECUTION_ID;
import static org.springframework.batch.test.MetaDataInstanceFactory.DEFAULT_JOB_INSTANCE_ID;
import static org.springframework.batch.test.MetaDataInstanceFactory.DEFAULT_JOB_NAME;

/**
 * Unit tests for {@link SdmDistributionJobListener}
 */
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {BatchConfig.class, GrdmDatabaseConfig.class})
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class, JobScopeTestExecutionListener.class
})
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
public class SdmDistributionJobListenerTest {

	@Autowired
	private SdmDistributionJobListener jobListener;

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiCategoryDefinitionDistributionRepository categoryDefinitionDistributionRepository;

	@After
	public void after() {
		// The job tested commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to verify the data inserted in the database by the jobs/steps
		this.categoryDefinitionRepository.deleteAll();
		this.categoryDefinitionDistributionRepository.deleteAll();
	}

	@Test
	public void testBeforeJob() throws URISyntaxException, IOException {
		Assert.assertNull(ReflectionTestUtils.getField(this.jobListener, "zipFileSystem"));
		this.jobListener.beforeJob(getJobExecution());

		final FileSystem zipFileSystem = (FileSystem) ReflectionTestUtils.getField(this.jobListener, "zipFileSystem");
		Assert.assertNotNull(zipFileSystem);
		Assert.assertTrue(zipFileSystem.isOpen());
		zipFileSystem.close();
	}

	@Test(expected = FileSystemNotFoundException.class)
	public void testBeforeJobNonExistingZip() throws URISyntaxException {
		Assert.assertNull(ReflectionTestUtils.getField(this.jobListener, "zipFileSystem"));
		try {
			this.jobListener.beforeJob(getJobExecution("file:///non-existing.zip"));
		} finally {
			Assert.assertNull(ReflectionTestUtils.getField(this.jobListener, "zipFileSystem"));
		}
	}

	@Test
	public void testAfterJob() throws URISyntaxException, IOException {
		Assert.assertNull(ReflectionTestUtils.getField(this.jobListener, "zipFileSystem"));
		ReflectionTestUtils.setField(this.jobListener, "zipFileSystem",
				FileSystems.newFileSystem(URI.create("jar:" + getZipFileUri()), Collections.emptyMap()));

		this.jobListener.afterJob(getJobExecution());

		Assert.assertFalse(((FileSystem) ReflectionTestUtils.getField(this.jobListener, "zipFileSystem")).isOpen());
	}

	@Test
	public void testAfterJobInactivateCategoryDefinition() throws URISyntaxException, IOException {
		final Long categoryDefinitionId = insertApiCategoryDefinitionAndDistribution();

		this.jobListener.afterJob(getJobExecution());

		final ApiCategoryDefinitionDistribution distribution = this.categoryDefinitionDistributionRepository
				.findOne(new ApiCategoryDefinitionDistributionId(categoryDefinitionId, 1));
		final DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Assert.assertNotNull(distribution);
		Assert.assertEquals(DistributionImportStatus.INACTIVE, distribution.getStatus());
		Assert.assertEquals(dateFormat.format(new Date()), dateFormat.format(distribution.getLastUpdateDate()));
	}

	private String getZipFileUri() throws URISyntaxException {
		return Thread.currentThread().getContextClassLoader().getResource("SDM_20170925_120000_1_xml.zip").toURI().toString();
	}

	private JobExecution getJobExecution() throws URISyntaxException {
		return getJobExecution(getZipFileUri());
	}

	private JobExecution getJobExecution(String fileUri) {
		final JobParameters jobParameters = new JobParametersBuilder()
				.addString("zipFileUri", fileUri)
				.addLong("distributionSequenceNumber", 2L)
				.toJobParameters();
		return MetaDataInstanceFactory.createJobExecution(
				DEFAULT_JOB_NAME, DEFAULT_JOB_INSTANCE_ID, DEFAULT_JOB_EXECUTION_ID, jobParameters);
	}

	private Long insertApiCategoryDefinitionAndDistribution() {
		ApiCategoryDefinition categoryDefinition = new ApiCategoryDefinition();
		categoryDefinition.setDistributionName("COUNTRY");
		categoryDefinition.setCategoryType("Attributes");
		categoryDefinition.setActiveDistributionSequenceNumber(1);
		categoryDefinition = this.categoryDefinitionRepository.save(categoryDefinition);

		final ApiCategoryDefinitionDistribution categoryDefinitionDistribution = new ApiCategoryDefinitionDistribution();
		categoryDefinitionDistribution.setCategoryDefinitionId(categoryDefinition.getTechnicalId());
		categoryDefinitionDistribution.setDistributionSequenceNumber(1);
		categoryDefinitionDistribution.setFileName("some file");
		categoryDefinitionDistribution.setStatus(DistributionImportStatus.ACTIVE);
		categoryDefinitionDistribution.setImportDate(new Date());
		categoryDefinitionDistribution.setLastUpdateDate(new Date(1506722400000L)); // some date before today
		this.categoryDefinitionDistributionRepository.save(categoryDefinitionDistribution);

		return categoryDefinition.getTechnicalId();
	}
}
