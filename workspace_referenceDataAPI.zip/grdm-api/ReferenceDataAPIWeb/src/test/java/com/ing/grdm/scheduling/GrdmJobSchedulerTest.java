package com.ing.grdm.scheduling;

import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmJobRepository;
import com.ing.grdm.distro.job.SdmDistributionCleanupJob;
import com.ing.grdm.distro.job.SdmDistributionImportJob;
import com.ing.grdm.event.AttributesDataChangedEvent;
import com.ing.grdm.event.OverstapDataChangedEvent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.UnknownHostException;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Unit tests for {@link GrdmJobScheduler}
 */
@RunWith(MockitoJUnitRunner.StrictStubs.class)
public class GrdmJobSchedulerTest {

	@Mock
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Mock
	private GrdmJobRepository jobRepository;
	@Mock
	private SdmDistributionImportJob importJob;
	@Mock
	private SdmDistributionCleanupJob cleanupJob;
	@Mock
	private ApplicationEventPublisher eventPublisher;

	@InjectMocks
	private GrdmJobScheduler jobScheduler;

	@Before
	public void init() {
		ReflectionTestUtils.setField(this.jobScheduler, "hostname", "HOST_A");
	}

	@Test
	public void testRunBatch() throws UnknownHostException {
		doReturn(true).when(this.jobRepository).shouldJobRun(SdmDistributionImportJob.class, "HOST_A", 0);
		this.jobScheduler.runBatch();

		verify(this.jobRepository).shouldJobRun(SdmDistributionImportJob.class, "HOST_A", 0);
		verify(this.importJob).importDistribution();
	}

	@Test
	public void testDontRunBatch() throws UnknownHostException {
		doReturn(false).when(this.jobRepository).shouldJobRun(SdmDistributionImportJob.class, "HOST_A", 0);
		this.jobScheduler.runBatch();

		verify(this.jobRepository).shouldJobRun(SdmDistributionImportJob.class, "HOST_A", 0);
		verify(this.importJob, never()).importDistribution();
	}

	@Test
	public void testRunCleanupJob() throws UnknownHostException {
		doReturn(true).when(this.jobRepository).shouldJobRun(SdmDistributionCleanupJob.class, "HOST_A", 0);
		this.jobScheduler.runCleanupJob();

		verify(this.jobRepository).shouldJobRun(SdmDistributionCleanupJob.class, "HOST_A", 0);
		verify(this.cleanupJob).cleanupDistributions();
	}

	@Test
	public void testDontRunCleanupJob() throws UnknownHostException {
		doReturn(false).when(this.jobRepository).shouldJobRun(SdmDistributionCleanupJob.class, "HOST_A", 0);
		this.jobScheduler.runCleanupJob();

		verify(this.jobRepository).shouldJobRun(SdmDistributionCleanupJob.class, "HOST_A", 0);
		verify(this.cleanupJob, never()).cleanupDistributions();
	}

	@Test
	public void testMonitorAttributesDataChanges() {
		this.jobScheduler.monitorAttributesDataChanges();

		verify(this.categoryDefinitionRepository).getActiveDistributionSequenceNumber();
		verify(this.eventPublisher, times(1)).publishEvent(any(AttributesDataChangedEvent.class));
		verify(this.eventPublisher, times(1)).publishEvent(any(OverstapDataChangedEvent.class));
	}
}
