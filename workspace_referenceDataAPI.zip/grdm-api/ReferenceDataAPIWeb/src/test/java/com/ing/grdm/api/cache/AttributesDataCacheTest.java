package com.ing.grdm.api.cache;

import com.google.common.collect.ImmutableMap;
import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link AttributesDataCache}
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = {"grdm.cache.enabled=true",
		"grdm.cache.categories.exclude=gender"})
@RunWith(SpringRunner.class)
public class AttributesDataCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;

	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;

	@Autowired
	private AttributesDataCache cache;

	@Autowired
	private ApplicationEventPublisher eventPublisher;

	@Test
	public void testReloadAndCaseSensitivity() {

		// containsTable is case insensitive
		assertThat(this.cache.containsTable("COUNTRY"), is(false));
		assertThat(this.cache.containsTable("CoUnTry"), is(false));
		assertThat(this.cache.containsTable("country"), is(false));

		// containsBusinessKey is case insensitive, columns are case insensitive
		assertThat(this.cache.containsColumns("CoUnTry", Collections.singletonList("DESCRIPTION")), is(false));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("DeScRiPtIoN")), is(false));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("description")), is(false));

		// distributionName is case insensitive
		assertThat(this.cache.getColumnsByDistributionName("COUNTRY"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("CoUnTrY"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("country"), is(Collections.emptyMap()));

		// businessKey is case sensitive
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "NL"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "Nl"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("COUNTRY", "nl"), is(Collections.emptyMap()));

		// Signal cache to reload
		this.eventPublisher.publishEvent(new AttributesDataChangedEvent());

		// containsTable is case insensitive
		assertThat(this.cache.containsTable("COUNTRY"), is(true));
		assertThat(this.cache.containsTable("CoUnTry"), is(true));
		assertThat(this.cache.containsTable("country"), is(true));

		// containsBusinessKey is case insensitive, columns are case insensitive
		assertThat(this.cache.containsColumns("CoUnTry", Collections.singletonList("DESCRIPTION")), is(true));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("DeScRiPtIoN")), is(true));
		assertThat(this.cache.containsColumns("CoUnTrY", Collections.singletonList("description")), is(true));

		// verify containsTable is case insensitive and table excluded in cache
		assertThat(this.cache.containsTable("GENDER"), is(false));
		assertThat(this.cache.containsTable("GenDer"), is(false));
		assertThat(this.cache.containsTable("gender"), is(false));

		// verify containsBusinessKey is case insensitive, columns are case insensitive and table excluded in cache
		assertThat(this.cache.containsColumns("GENDER", Collections.singletonList("DESCRIPTION")), is(false));
		assertThat(this.cache.containsColumns("GenDer", Collections.singletonList("DeScRiPtIoN")), is(false));
		assertThat(this.cache.containsColumns("gender", Collections.singletonList("description")), is(false));

		// verify distributionName is case insensitive and table excluded in cache
		assertThat(this.cache.getColumnsByDistributionName("GENDER"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("GenDer"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionName("gender"), is(Collections.emptyMap()));

		// verify businessKey is case sensitive and table excluded in cache
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("GENDER", "F"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("GENDER", "f"), is(Collections.emptyMap()));

		// verify Mappings table is not in cache
		assertThat(this.cache.containsTable("CURRENCY"), is(false));
		assertThat(this.cache.containsColumns("CURRENCY", Collections.singletonList("LOCAL_CODE")), is(false));
		assertThat(this.cache.getColumnsByDistributionName("CURRENCY"), is(Collections.emptyMap()));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("CURRENCY", "DNB|EUR"), is(Collections.emptyMap()));

		// getColumnsByDistributionName, distributionName is case insensitive
		final Map<String, Collection<Map<String, Object>>> tableData = this.cache.getColumnsByDistributionName("CoUnTrY");

		// businessKey is case sensitive
		assertThat(tableData, hasKey("NL"));
		assertThat(tableData, not(hasKey("nl")));

		// returned columnName is uppercase, storage string is case sensitive
		assertThat(tableData.get("NL").iterator().next(), hasKey("description"));
		assertThat(tableData.get("NL").iterator().next(), not(hasKey("DESCRIPTION")));
		assertThat(tableData.get("NL").iterator().next(), hasEntry("description", "Netherlands"));

		// getColumnsByDistributionNameAndBusinessKey, distributionName is case sensitive, businessKey is case sensitive
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("CoUnTrY", "Nl"), is(Collections.emptyMap()));

		final Map<String, Object> columnData = this.cache.getColumnsByDistributionNameAndBusinessKey("CoUnTrY", "NL");
		assertThat(columnData, notNullValue());

		// returned columnNames are in uppercase
		assertThat(columnData, hasKey("description"));
		assertThat(columnData, not(hasKey("DESCRIPTION")));
		assertThat(columnData, hasEntry("description", "Netherlands"));

		// versioned table
		assertThat(this.cache.containsTable("versioned"), is(true));
		assertThat(this.cache.containsColumns("versioned", Collections.singletonList("code")), is(true));

		// only effective values are returned for versions
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("versioned", "A"), hasEntry("code", "A2"));
		assertThat(this.cache.getColumnsByDistributionNameAndBusinessKey("versioned", "B"), is(Collections.emptyMap()));

		final Map<String, Collection<Map<String, Object>>> versionedDataAll =
				this.cache.getColumnsByDistributionName("VERSIONED");
		assertThat(versionedDataAll, hasKey("A"));
		assertThat(versionedDataAll, hasKey("B"));
		assertThat(versionedDataAll, hasKey("C"));
		assertThat(versionedDataAll, hasKey("D"));
		assertThat(versionedDataAll.get("A"), containsInAnyOrder(Arrays.asList(
				is(ImmutableMap.of("code", "A1")),
				is(ImmutableMap.of("code", "A2")),
				is(ImmutableMap.of("code", "A3")))));

		final Map<String, Collection<Map<String, Object>>> versionedDataYesterday =
				this.cache.getColumnsByDistributionName("VERSIONED", LocalDate.now().minusDays(1));
		assertThat(versionedDataYesterday, hasKey("A"));
		assertThat(versionedDataYesterday, hasKey("B"));
		assertThat(versionedDataYesterday, not(hasKey("C")));
		assertThat(versionedDataYesterday, not(hasKey("D")));
		assertThat(versionedDataYesterday.get("A"), contains(
				is(ImmutableMap.of("code", "A1"))
		));

		final Map<String, Collection<Map<String, Object>>> versionedDataToday =
				this.cache.getColumnsByDistributionName("VERSIONED", LocalDate.now());
		assertThat(versionedDataToday, hasKey("A"));
		assertThat(versionedDataToday, not(hasKey("B")));
		assertThat(versionedDataToday, not(hasKey("C")));
		assertThat(versionedDataToday, not(hasKey("D")));
		assertThat(versionedDataToday.get("A"), contains(
				is(ImmutableMap.of("code", "A2"))
		));

		final Map<String, Collection<Map<String, Object>>> versionedDataTomorrow =
				this.cache.getColumnsByDistributionName("VERSIONED", LocalDate.now().plusDays(1));
		assertThat(versionedDataTomorrow, hasKey("A"));
		assertThat(versionedDataTomorrow, not(hasKey("B")));
		assertThat(versionedDataTomorrow, hasKey("C"));
		assertThat(versionedDataTomorrow, not(hasKey("D")));
		assertThat(versionedDataTomorrow.get("A"), contains(
				is(ImmutableMap.of("code", "A3"))
		));
	}

	@Before
	public void loadApiCategoryDefinition() {
		// Assuming previous test cleaned-up data, make sure cache is empty as well
		this.eventPublisher.publishEvent(new AttributesDataChangedEvent());

		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "DESCRIPTION", "Netherlands", "NL");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("GENDER");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "DESCRIPTION", "Female", "F");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("CURRENCY");
		apiCategoryDefinition.setCategoryType("Mappings");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "LOCAL_CODE", "NLG", "DNB|EUR");

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("VERSIONED");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		final LocalDate today = LocalDate.now();
		final LocalDate tomorrow = today.plusDays(1);
		// business key A has three versions, the one with code A2 is the effective one
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "A1", "A", 1, today.minusYears(1), today);
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "A2", "A", 2, today, tomorrow);
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "A3", "A", 3, tomorrow, null);
		// business key B is a past version
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "B1", "B", 1, today.minusYears(1), today);
		// business key C is a future version effective as of tomorrow
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "C1", "C", 1, tomorrow, null);
		// business key D is a closed version (normally would not be present in data values table)
		createVersionedApiDataValue(apiCategoryDefinition.getTechnicalId(), "CODE", "D1", "D", 1, today, today);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String columnName, String storageString, String businessKey) {
		createVersionedApiDataValue(categoryDefinitionId, columnName, storageString, businessKey, 0, null, null);
	}

	private void createVersionedApiDataValue(long categoryDefinitionId, String columnName, String storageString, String businessKey, Integer technicalVersion, LocalDate effectiveDate, LocalDate endDate) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(ColumnType.STRING);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		apiDataValue.setTechnicalVersion(technicalVersion);
		apiDataValue.setEffectiveDate(effectiveDate);
		apiDataValue.setEndDate(endDate);
		this.dataValueRepository.save(apiDataValue);
	}
}
