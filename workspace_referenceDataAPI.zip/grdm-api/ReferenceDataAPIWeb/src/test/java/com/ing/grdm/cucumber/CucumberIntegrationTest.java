package com.ing.grdm.cucumber;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

/**
 * Cucumber runner for the integration test, invoked during build test phase.
 */
@RunWith(Cucumber.class)
@CucumberOptions(
		glue = {"com.ing.grdm.cucumber.integration", "com.ing.grdm.cucumber.steps"},
		features = {"classpath:features"}
)
public class CucumberIntegrationTest {
}
