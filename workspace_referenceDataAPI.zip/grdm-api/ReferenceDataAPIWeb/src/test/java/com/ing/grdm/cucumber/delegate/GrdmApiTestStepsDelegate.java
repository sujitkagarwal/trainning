package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.domain.GrdmApiExceptionResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.RequestBuilder;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

/**
 * Base class for GRDM API's test steps delegates
 */
@Component
public class GrdmApiTestStepsDelegate {

	@Autowired
	private HttpClient httpClient;

	@Autowired
	private URIBuilder uriBuilder;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private GrdmApiResponse response;

	String performGetRequest(String path, List<NameValuePair> nvps) throws IOException {
		return performRequest(HttpGet.METHOD_NAME, path, null, nvps);
	}

	String performPostRequest(String path, String requestData) throws IOException {
		return performRequest(HttpPost.METHOD_NAME, path, requestData, null);
	}

	private String performRequest(String methodName, String path, String requestData, List<NameValuePair> nvps)
			throws IOException {
		final URI uri = createUri(path, nvps);
		final RequestBuilder builder = RequestBuilder.create(methodName).setUri(uri);
		if (requestData != null) {
			builder.setEntity(new StringEntity(requestData, ContentType.APPLICATION_JSON));
		}
		final HttpUriRequest request = builder.build();
		final HttpResponse response = this.httpClient.execute(request);
		final HttpEntity entity = response.getEntity();
		final StringWriter writer = new StringWriter();
		IOUtils.copy(entity.getContent(), writer);
		this.response.setResponseStatus(response.getStatusLine().getStatusCode());
		final String content = writer.toString();
		if (this.response.getResponseStatus() != HttpServletResponse.SC_OK && StringUtils.isNotEmpty(content)) {
			GrdmApiExceptionResponse p = objectMapper.readValue(content, GrdmApiExceptionResponse.class);
			this.response.setResponseMessage(p.getMessage());
		}
		return this.response.getResponseStatus() == HttpServletResponse.SC_OK ? content : null;
	}

	private URI createUri(String path, List<NameValuePair> nvps) {
		try {
			final URIBuilder builder = this.uriBuilder.setPath(path);
			if (nvps != null) {
				builder.setParameters(nvps).build();
			}
			return builder.build();
		} catch (URISyntaxException use) {
			// Won't happen, so let the framework handle it
			throw new RuntimeException(use);
		}
	}
}
