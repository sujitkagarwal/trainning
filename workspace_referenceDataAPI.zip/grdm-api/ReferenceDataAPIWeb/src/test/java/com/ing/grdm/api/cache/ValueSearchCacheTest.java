package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link SearchCache} pertaining to Value search
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 13-12-2017
 */
@ActiveProfiles({"test", "searchCache"})
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.cache.categories.exclude=language")
@RunWith(SpringRunner.class)
public class ValueSearchCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;
	@Autowired
	private SearchCache searchCache;
	@Autowired
	private ApplicationEventPublisher publisher;

	@Test
	public void testSearch() throws IOException {
		List<Map<String, Object>> searchResults;
		assertThat(this.searchCache.searchValue("nl", null, null, null).size(), is(0));

		// signal search cache to reload
		publisher.publishEvent(new AttributesDataChangedEvent());

		// search for a value which is present in both included and excluded categories , verify value is case insensitive and
		// verify the search results are placed in descending order of their matches
		searchResults = this.searchCache.searchValue("nl", null, null, null);
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(4));
		assertThat(searchResults.get(0).get("column"), is("country_cluster"));
		assertThat(searchResults.get(0).get("business_key"), is("WS4"));
		assertThat(searchResults.get(0).get("value"), is("nl"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(1).get("column"), is("country_cluster_correl"));
		assertThat(searchResults.get(1).get("business_key"), is("ES3"));
		assertThat(searchResults.get(1).get("value"), is("NL"));
		assertThat(searchResults.get(1).get("table"), is("country"));
		assertThat(searchResults.get(2).get("column"), is("test_3"));
		assertThat(searchResults.get(2).get("business_key"), is("All"));
		assertThat(searchResults.get(2).get("value"), is("Nl3"));
		assertThat(searchResults.get(2).get("table"), is("api_test_tbl"));

		// search for a value with distributionName and verify distribution name is case insensitive
		searchResults = this.searchCache.searchValue("nl", "CoUnTry", null, null);
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(3));
		assertThat(searchResults.get(0).get("column"), is("country_cluster"));
		assertThat(searchResults.get(0).get("business_key"), is("WS4"));
		assertThat(searchResults.get(0).get("value"), is("nl"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(1).get("column"), is("country_cluster_correl"));
		assertThat(searchResults.get(1).get("business_key"), is("ES3"));
		assertThat(searchResults.get(1).get("value"), is("NL"));
		assertThat(searchResults.get(1).get("table"), is("country"));
		assertThat(searchResults.get(2).get("column"), is("country_cluster_r_squared"));
		assertThat(searchResults.get(2).get("business_key"), is("FR"));
		assertThat(searchResults.get(2).get("value"), is(11.0));
		assertThat(searchResults.get(2).get("table"), is("country"));

		// search for a value with columnName and verify columnName is case insensitive
		searchResults = this.searchCache.searchValue("nL", null, "country_ClUsTer_correl", null);
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("country_cluster_correl"));
		assertThat(searchResults.get(0).get("business_key"), is("ES3"));
		assertThat(searchResults.get(0).get("value"), is("NL"));
		assertThat(searchResults.get(0).get("table"), is("country"));

		// search for a value with businessKey and verify businessKey is case insensitive
		searchResults = this.searchCache.searchValue("nL", null, null, "Es3");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("country_cluster_correl"));
		assertThat(searchResults.get(0).get("business_key"), is("ES3"));
		assertThat(searchResults.get(0).get("value"), is("NL"));
		assertThat(searchResults.get(0).get("table"), is("country"));

		// search for a value with distributionName, columnName and businessKey , verify case sensitivity , verify by interchanging letters
		// of search string
		searchResults = this.searchCache.searchValue("Ln", "counTrY", "country_cluStEr", "ws4");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("country_cluster"));
		assertThat(searchResults.get(0).get("business_key"), is("WS4"));
		assertThat(searchResults.get(0).get("value"), is("nl"));
		assertThat(searchResults.get(0).get("table"), is("country"));

	}

	@Before
	public void loadApiCategoryDefinition() {
		// Signal cache to reload just to be doubly sure that fresh indexes are created
		publisher.publishEvent(new AttributesDataChangedEvent(true));

		// Loading data into in-memory database
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "NL", "ES3", "COUNTRY_CLUSTER_CORREL", ColumnType.STRING);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "11", "FR", "COUNTRY_CLUSTER_R_SQUARED", ColumnType.NUMBER);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "nl", "WS4", "COUNTRY_CLUSTER", ColumnType.STRING);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("LANGUAGE");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "nl", "NL", "LANGUAGE_ISO", ColumnType.STRING);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("API_TEST_TBL");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Nl3", "All", "TEST_3", ColumnType.STRING);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String storageString, String businessKey, String columnName,
									ColumnType columnType) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(columnType);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}
