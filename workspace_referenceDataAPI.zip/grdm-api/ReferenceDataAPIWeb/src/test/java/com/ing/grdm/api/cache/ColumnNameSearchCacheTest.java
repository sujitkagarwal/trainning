package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link SearchCache} pertaining to column search
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 13-12-2017
 */
@ActiveProfiles({"test", "searchCache"})
@SpringBootTest(classes = GrdmApiTestApplication.class)
@RunWith(SpringRunner.class)
public class ColumnNameSearchCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;
	@Autowired
	private SearchCache searchCache;
	@Autowired
	private ApplicationEventPublisher publisher;

	@Test
	public void testSearch() throws IOException {
		List<Map<String, Object>> searchResults;
		List<Map<String, String>> linksList;
		assertThat(this.searchCache.searchColumnName("desCrIpTion", null).isEmpty(), is(true));
		assertThat(this.searchCache.searchColumnName("desCrIpTion", "country").isEmpty(), is(true));

		// signal search cache to reload
		publisher.publishEvent(new AttributesDataChangedEvent());

		// search for a column for a category that is loaded into cache , verify column is case insensitive and
		// verify the search results are placed in descending order of their matches
		searchResults = this.searchCache.searchColumnName("desCRIpTIon", null);
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(3));
		assertThat(searchResults.get(0).get("column"), is("description"));
		assertThat(searchResults.get(0).get("table").toString(), Matchers.either(Matchers.is("country")).or(Matchers.is("language")));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), Matchers.either(Matchers.is("/attributes/language?column=description")).or(
				Matchers.is("/attributes/country?column=description")));
		assertThat(searchResults.get(2).get("column"), is("descption"));
		assertThat(searchResults.get(2).get("table"), is("product_type"));
		assertThat(searchResults.get(2).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(2).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/product_type?column=descption"));

		// search for a column with distributionName and verify distribution name is case insensitive
		searchResults = this.searchCache.searchColumnName("desCriPtion", "CoUnTry");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("description"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=description"));

		// search for a column with distributionName and by interchanging letters for column name
		searchResults = this.searchCache.searchColumnName("desirCPtion", "CoUnTry");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("description"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=description"));

		// search for a column with distributionName and verify exact match works for column name
		searchResults = this.searchCache.searchColumnName("GOV_RATING_FOREIGN_CCY", "country");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("gov_rating_foreign_ccy"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=gov_rating_foreign_ccy"));

		// search for a column with distributionName and verify partial match i.e fuzzy search works for column name
		searchResults = this.searchCache.searchColumnName("GOV_RATING_FOIGN_CCY", "country");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("column"), is("gov_rating_foreign_ccy"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country?column=gov_rating_foreign_ccy"));
	}

	@Before
	public void loadApiCategoryDefinition() {
		// Signal cache to reload just to be doubly sure that fresh indexes are created
		publisher.publishEvent(new AttributesDataChangedEvent(true));

		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Asia", "ASIAXX", "DESCRIPTION", ColumnType.STRING);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "YC02", "LI", "GOV_RATING_FOREIGN_CCY", ColumnType.REFERENCE);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("LANGUAGE");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "English", "EN", "DESCRIPTION", ColumnType.STRING);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("PRODUCT_TYPE");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Lending", "WS", "DESCPTION", ColumnType.STRING);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String storageString, String businessKey, String columnName,
									ColumnType columnType) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(columnType);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}
