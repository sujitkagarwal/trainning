package com.ing.grdm.cucumber.regression;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Iterables;
import cucumber.api.java8.En;
import org.apache.http.client.HttpClient;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.Iterator;
import java.util.List;

/**
 * Configuration for the regression test. The regression test is performed against application deployed on Tomcat server.
 */
@ContextConfiguration(classes = GrdmApiRegressionTestConfiguration.Config.class)
@SuppressWarnings("unused")
class GrdmApiRegressionTestConfiguration implements En {

	GrdmApiRegressionTestConfiguration() {
		When("^setup$", () -> {
		});

		And("^cleaning$", () -> {
		});
	}

	@Configuration
	@ComponentScan(basePackages = "com.ing.grdm.cucumber.delegate")
	@PropertySource("classpath:grdm.api.properties")
	@ImportResource("classpath:/cucumber-context.xml")
	static class Config {

		@Bean
		HttpClient httpClient() throws GeneralSecurityException, IOException {
			final KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			keyStore.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("grdm-test.jks"),
					"grdm01".toCharArray());

			final SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
					new SSLContextBuilder()
							.loadTrustMaterial(null, new TrustSelfSignedStrategy())
							.loadKeyMaterial(keyStore, "grdm01".toCharArray()).build(), (s, sslSession) -> true);

			return HttpClients.custom().setSSLSocketFactory(socketFactory).build();
		}

		@Bean
		URIBuilder uriBuilder(@Value("#{'${grdm.hostnames.${test.environment}}'.split(',')}") List<String> hostnames) {
			return new URIBuilder() {
				private Iterator<String> hostnameIterator = Iterables.cycle(hostnames).iterator();

				@Override
				public URI build() throws URISyntaxException {
					setHost(hostnameIterator.next());
					return super.build();
				}
			}.setScheme("https").setPort(8443);
		}

		@Bean
		JsonFactory jsonFactory() {
			final JsonFactory jsonFactory = new JsonFactory();
			jsonFactory.disable(JsonGenerator.Feature.AUTO_CLOSE_TARGET);
			jsonFactory.setCodec(new ObjectMapper());
			return jsonFactory;
		}

		@Bean
		ObjectMapper objectMapper(JsonFactory jsonFactory) {
			return new ObjectMapper(jsonFactory);
		}
	}
}
