package com.ing.grdm.api.cache.search;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link ColumnNameCache}
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 21-12-2017
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = SearchCacheConfig.class)
@ActiveProfiles({ "columnNameCache" })
public class ColumnNameCacheTest {

	@Autowired
	private ColumnNameCache columnNameCache;

	@Test
	public void testAddAndDelete() {

		addDocument("cdd_risk_level", "country");
		addDocument("language_iso", "language");
		this.columnNameCache.openForReading();

		List<Map<String, Object>> result = this.columnNameCache.search("cdd_risk_level", null);
		assertThat(result.size(), is(1));
		result = this.columnNameCache.search("LANGUAGE_ISO", null);
		assertThat(result.size(), is(1));

		addDocument("description", "language");
		addDocument("description", "country");
		this.columnNameCache.openForReading();

		result = this.columnNameCache.search("desCRiPTion", null);
		assertThat(result.size(), is(2));
		result = this.columnNameCache.search("desCRiPTion", "language");
		assertThat(result.size(), is(1));

		deleteDocument("description", "country");
		this.columnNameCache.openForReading();

		result = this.columnNameCache.search("description", null);
		assertThat(result.size(), is(1));
	}

	private void addDocument(String columnName, String distributionName) {
		try {
			this.columnNameCache.openForWriting(false);
			this.columnNameCache.addDocument(columnName, distributionName);
			this.columnNameCache.commitWriting();
		} finally {
			this.columnNameCache.closeAfterWriting();
		}
	}

	private void deleteDocument(String columnName, String distributionName) {
		try {
			this.columnNameCache.openForWriting(false);
			this.columnNameCache.deleteDocument(columnName, distributionName);
			this.columnNameCache.commitWriting();
		} finally {
			this.columnNameCache.closeAfterWriting();
		}
	}
}
