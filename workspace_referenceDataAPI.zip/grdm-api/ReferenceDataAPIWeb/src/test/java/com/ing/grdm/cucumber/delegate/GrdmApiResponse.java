package com.ing.grdm.cucumber.delegate;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * Stateful response object to be shared between test steps classes
 */
@Component
@Scope(value = "cucumber-glue")
public class GrdmApiResponse {

	// The status code of the server's response
	private int responseStatus;

	// The status message of the server's response
	private String responseMessage;

	public int getResponseStatus() {
		return responseStatus;
	}

	void setResponseStatus(int responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
}
