package com.ing.grdm.api.security;

import com.ing.api.security.trust.token.peer.PeerToken;
import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.security.config.GrdmTestConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit integration tests for peer token authentication with whitelisting
 */
@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = GrdmTestConfig.class)
@SpringBootTest(classes = GrdmApiTestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {"grdm.api.security.enabled=true", "grdm.api.security.type=peerToken", "grdm.environment=local"})
public class GrdmSecurityPeerTokenIntegrationTest {


	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	@Test
	public void testInvalidAuthentication() {
		HttpEntity<String> entity = new HttpEntity<String>(null, null);
		ResponseEntity<String> response = restTemplate.exchange("/api/config/get/85",
				HttpMethod.GET, entity, String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
	}

	@Test
	public void testValidAuthentication() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(PeerToken.HEADER_NAME, "eyJhbGciOiJSUzI1NiIsIng1dCI6IjVGOkFGOjQwOjlDOkQyOkQ5OjVGOjM5OjVFOkI5OkNCOjkzOjYxOkJFOjNCOkExOjVFOjA1OjMzOkQwIn0.eyJzdWIiOiJSZWZlcmVuY2VEYXRhQVBJIiwiZW5kcG9pbnRzIjpbeyJtZXRob2QiOiJHRVQiLCJob3N0IjoiYXBpLnJlZmVyZW5jZWRhdGEuaW5nLm5ldCIsInBhdGhUZW1wbGF0ZSI6Ii9yZWZlcmVuY2UtZGF0YS9hdHRyaWJ1dGVzL3t0YWJsZURpc3RyaWJ1dGlvbk5hbWV9IiwidmVyc2lvbiI6IjEuMC4yIn1dLCJ2ZXIiOiIxLjAiLCJqdGkiOiIwYmIyNmY2MS1iN2M2LTRjMWQtOTg3Zi1lODY5OTFjNDA0YzQiLCJ0eXAiOiJwZWVyIiwiZXhwIjoxNTQ5ODgyOTc1LCJuYmYiOjE1MzQzMzA5NzUsImlhdCI6MTUzNDMzMDk3NSwiaXNzIjoiQVBJUmVnaXN0cnlBUEkifQ.CRLCr4wYHaLn5X-XgDMXP2wrin9Bx5fDOglxTNQupHcb937_EWAO4WzpQEE4AvPob3SlRgGS2FIz8fHz-aPBlNwq_wf4ryYrLyI-NIMJyWeZ6z7p13AA1GDxvxk2Gqscnmg5sOw_A7VxUfROMElp8MbTc9e0C4r1t5e98UW22uxI8K1T405w6Klt1mtLyLc02TUoPre8NH97uusuwns_XKInX5p9GrsiQhZW0iZ3XZKy7ANCs7cAdvS5f7zl1D-AXTCVTxiIwRHuT2LovNp-fruid5Fkq6_pELRmugQ1SYXEZJvkBXITw8ZPD-SwV32x3sSqR_Bdm6-ObN1JEaSaR7vbPtpfyy_Jol0KNQiIKG0GVDX6kPj-6aOR5XR5S3AQWffnDg5_97t34miUc87e-rrMRrxPPLQbb9T2vGmWPJjgu0y-xptt6GVVd8Zowg9jtHv-qbu1x6F3bDmk2QmgoWo48CyziG2220AETO3B0qBALJvlRpwqzn7RFoRUGn2rXiOnzSB0JQzEk48XCwZYjpdAWPqwpjx-0LSpuX5wEKvkwEmh_r5wVwppLI0t66iB02oWeUmGcwTOuJAfmpXRBGyicPszkFx6LOwYsTuobkU1wwTR4Uin1WiK29E_YYQPAHp7lAmBlPk9gE2pawZVd5JjIAp_A76d5_M8p9o5-t0");
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange("/api/config/get/85",
				HttpMethod.GET, entity, String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);

	}
}
