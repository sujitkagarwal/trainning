package com.ing.grdm.api.cache.search;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link TableNameCache}
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = { SearchCacheConfig.class })
@ActiveProfiles("tableNameCache")
public class TableNameCacheTest {

	@Autowired
	private TableNameCache tableNameCache;

	@Test
	public void testAddAndDelete() {

		addDocument("country");
		this.tableNameCache.openForReading();

		List<Map<String, Object>> country = this.tableNameCache.search("country");
		List<Map<String, Object>> language = this.tableNameCache.search("language");

		assertThat(country.size(), is(1));
		assertThat(language.size(), is(0));

		addDocument("language");
		this.tableNameCache.openForReading();

		country = this.tableNameCache.search("country");
		language = this.tableNameCache.search("language");

		assertThat(country.size(), is(1));
		assertThat(language.size(), is(1));

		deleteDocument("country");
		this.tableNameCache.openForReading();

		country = this.tableNameCache.search("country");
		language = this.tableNameCache.search("language");

		assertThat(country.size(), is(0));
		assertThat(language.size(), is(1));
	}

	private void addDocument(String tableName) {
		try {
			this.tableNameCache.openForWriting(false);
			this.tableNameCache.addDocument(tableName);
			this.tableNameCache.commitWriting();
		} finally {
			this.tableNameCache.closeAfterWriting();
		}
	}

	private void deleteDocument(String tableName) {
		try {
			this.tableNameCache.openForWriting(false);
			this.tableNameCache.deleteDocument(tableName);
			this.tableNameCache.commitWriting();
		} finally {
			this.tableNameCache.closeAfterWriting();
		}
	}

}
