package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.database.GrdmApiDataValueRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.domain.ApiDataValue;
import com.ing.grdm.domain.ColumnType;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.hamcrest.Matchers;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link SearchCache} pertaining to business key search
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 13-12-2017
 */
@ActiveProfiles({"test", "searchCache"})
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.cache.categories.exclude=language")
@RunWith(SpringRunner.class)
public class BusinessKeySearchCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private GrdmApiDataValueRepository dataValueRepository;
	@Autowired
	private SearchCache searchCache;
	@Autowired
	private ApplicationEventPublisher publisher;

	@Test
	public void testSearch() throws IOException {
		List<Map<String, Object>> searchResults;
		List<Map<String, String>> linksList;
		assertThat(this.searchCache.searchBusinessKey("nl", null).isEmpty(), is(true));
		assertThat(this.searchCache.searchBusinessKey("NL", "country").isEmpty(), is(true));

		// signal search cache to reload
		publisher.publishEvent(new AttributesDataChangedEvent(true));

		// search for a business key for a category that is loaded into cache and for the one not loaded , verify business key is case insensitive and
		// verify the search results are placed in descending order of their matches
		searchResults = this.searchCache.searchBusinessKey("nl", null);
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(4));
		assertThat(searchResults.get(0).get("business_key"), is("nl"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/nl"));

		assertThat(searchResults.get(1).get("business_key"), is("NL"));
		assertThat(searchResults.get(1).get("table").toString(), Matchers.either(Matchers.is("country")).or(Matchers.is("api_test_tbl")));
		assertThat(searchResults.get(1).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(1).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), Matchers.either(Matchers.is("/attributes/country/NL")).or(
				Matchers.is("/attributes/api_test_tbl/NL")));

		assertThat(searchResults.get(3).get("business_key"), is("11"));
		assertThat(searchResults.get(3).get("table"), is("country"));
		assertThat(searchResults.get(3).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(3).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/11"));

		// search for a business key with distributionName and verify distribution name is case insensitive
		searchResults = this.searchCache.searchBusinessKey("NL", "CoUnTry");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(3));
		assertThat(searchResults.get(0).get("business_key"), is("NL"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/NL"));

		// search for a business key with distributionName and by interchanging letters for search string
		searchResults = this.searchCache.searchBusinessKey("AfracI", "CoUnTry");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("business_key"), is("AFRICA"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/AFRICA"));

		// search for a business key with distributionName and verify exact match works for business key
		searchResults = this.searchCache.searchBusinessKey("Africa", "country");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("business_key"), is("AFRICA"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/AFRICA"));

		// search for a business key with distributionName and verify partial match i.e fuzzy search works for business key
		searchResults = this.searchCache.searchBusinessKey("Afri", "country");
		assertThat(searchResults.isEmpty(), is(false));
		assertThat(searchResults.size(), is(1));
		assertThat(searchResults.get(0).get("business_key"), is("AFRICA"));
		assertThat(searchResults.get(0).get("table"), is("country"));
		assertThat(searchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) searchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).get("href"), is("/attributes/country/AFRICA"));
	}

	@Before
	public void loadApiCategoryDefinition() {
		// Signal cache to reload just to be doubly sure that fresh indexes are created
		publisher.publishEvent(new AttributesDataChangedEvent(true));

		// Load data into in-memory database
		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "NL", "NL", "country_cluster_correl", ColumnType.STRING);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "11", "11", "country_cluster_r_squared", ColumnType.NUMBER);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "nl", "nl", "country_cluster", ColumnType.STRING);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "Africa", "AFRICA", "country_cluster", ColumnType.STRING);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("LANGUAGE");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "nl", "NL", "language_iso", ColumnType.STRING);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("API_TEST_TBL");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
		createApiDataValue(apiCategoryDefinition.getTechnicalId(), "NL", "NL", "test_3", ColumnType.STRING);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
		this.dataValueRepository.deleteAll();
	}

	private void createApiDataValue(long categoryDefinitionId, String storageString, String businessKey, String columnName,
									ColumnType columnType) {
		ApiDataValue apiDataValue = new ApiDataValue();
		apiDataValue.setCategoryDefinitionId(categoryDefinitionId);
		apiDataValue.setDistributionSequenceNumber(1);
		apiDataValue.setColumnType(columnType);
		apiDataValue.setStorageString(storageString);
		apiDataValue.setColumnName(columnName);
		apiDataValue.setColumnOrderNumber(1);
		apiDataValue.setBusinessKey(businessKey);
		this.dataValueRepository.save(apiDataValue);
	}
}
