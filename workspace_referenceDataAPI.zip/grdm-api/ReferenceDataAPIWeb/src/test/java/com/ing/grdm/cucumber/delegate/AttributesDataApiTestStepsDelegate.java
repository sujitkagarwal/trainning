package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual test steps for Reference Data API. Needs to be wired in the cucumber glue class.
 */
@Component
@Scope("cucumber-glue")
public class AttributesDataApiTestStepsDelegate extends GrdmApiTestStepsDelegate {

	private static final Log LOG = LogFactory.getLog(AttributesDataApiTestStepsDelegate.class);

	// The deserialized json response of the request by table name
	private List<Map<String, Object>> byTableNameResponse;

	// The deserialized json response of the request by table name and business key
	private Map<String, Object> byTableNameAndBusinessKeyResponse;

	/**
	 * Perform a by table name request
	 *
	 * @param type  type of SDM table, e.g. Attributes
	 * @param table distribution name of the table
	 * @throws IOException communication error with the server
	 */
	public void requestTable(String type, String table) throws IOException {
		LOG.info(String.format("the client requests %s for table %s", type, table));

		performByTableNameRequest(String.format("/reference-data/%s/%s", type, table), Collections.emptyList());
	}

	/**
	 * @param type    type of SDM table, e.g. Attributes
	 * @param table   distribution name of the table
	 * @param columns any specific columns to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithColumns(String type, String table, String columns) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and columns %s", type, table, columns));

		final List<NameValuePair> nvps = Arrays.stream(StringUtils.split(columns, ','))
				.map(s -> new BasicNameValuePair("column", s))
				.collect(Collectors.toList());

		performByTableNameRequest(String.format("/reference-data/%s/%s", type, table), nvps);
	}

	/**
	 * @param type        type of SDM table, e.g. Attributes
	 * @param table       distribution name of the table
	 * @param businessKey any businessKey to retrieve
	 * @param columns     any specific columns to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithBusinessKeyWithColumns(String type, String table, String businessKey, String columns) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and business key %s and columns %s", type, table, businessKey, columns));
		final List<NameValuePair> nvps = Arrays.stream(StringUtils.split(columns, ','))
				.map(s -> new BasicNameValuePair("column", s))
				.collect(Collectors.toList());
		performByTableNameAndBusinessKeyRequest(String.format("/reference-data/%s/%s/%s", type, table, businessKey), nvps);
	}

	/**
	 * @param type        type of SDM table, e.g. Attributes
	 * @param table       distribution name of the table
	 * @param businessKey any businessKey to retrieve
	 * @throws IOException communication error with the server
	 */
	public void requestTableWithBusinessKey(String type, String table, String businessKey) throws IOException {
		LOG.info(String.format("the client requests %s for table %s and business key %s ", type, table, businessKey));
		performByTableNameAndBusinessKeyRequest(String.format("/reference-data/%s/%s/%s", type, table, businessKey),
				Collections.emptyList());
	}

	/**
	 * Verify the number of returned business keys
	 *
	 * @param size  the size
	 * @param table the distribution name of the table
	 */
	public void verifyNumberOfBusinessKeys(int size, String table) {
		LOG.info(String.format("the client receives %d business keys for table %s", size, table));

		assertThat(this.byTableNameResponse.size(), is(size));
	}

	/**
	 * Verify a business key
	 *
	 * @param businessKey the business key
	 */
	public void verifyBusinessKey(String businessKey) {
		LOG.info(String.format("the client receives value for business key %s", businessKey));

		assertThat(this.byTableNameResponse, notNullValue());
		assertThat(this.byTableNameResponse, not(empty()));

		final Map<String, Object> valueMap = this.byTableNameResponse.parallelStream()
				.filter(map -> map.get("business_key").equals(businessKey))
				.findAny()
				.orElse(null);

		assertThat(valueMap, notNullValue());
		assertThat(valueMap, hasEntry("business_key", businessKey));
	}

	/**
	 * Verify business key not in response
	 *
	 * @param businessKey the business key
	 */
	public void verifyNoBusinessKey(String businessKey) {
		LOG.info(String.format("the client receives no value for business key %s", businessKey));

		assertThat(this.byTableNameResponse, notNullValue());
		assertThat(this.byTableNameResponse, not(empty()));

		final Map<String, Object> valueMap = this.byTableNameResponse.parallelStream()
				.filter(map -> map.get("business_key").equals(businessKey))
				.findAny()
				.orElse(null);

		assertThat(valueMap, nullValue());
	}

	/**
	 * Verify a version of a business key
	 *
	 * @param businessKey   the business key
	 * @param effectiveDate the effective date of the business key
	 * @param endDate       the end date of the business key (provide empty string for open end date)
	 */
	public void verifyBusinessKeyVersion(String businessKey, String effectiveDate, String endDate) {
		LOG.info(String.format("the client receives version for business key %s with effective date %s and end date %s",
				businessKey, effectiveDate, endDate));

		assertThat(this.byTableNameResponse, notNullValue());
		assertThat(this.byTableNameResponse, not(empty()));

		final Map<String, Object> valueMap = this.byTableNameResponse.parallelStream()
				.filter(map -> map.get("business_key").equals(businessKey) && map.get("eff_dt").equals(effectiveDate))
				.findAny()
				.orElse(null);

		assertThat(valueMap, notNullValue());
		assertThat(valueMap, hasEntry("business_key", businessKey));
		assertThat(valueMap, hasEntry("eff_dt", effectiveDate));
		assertThat(valueMap, hasEntry(is("end_dt"), is(StringUtils.trimToNull(endDate))));
	}

	/**
	 * Verify a version of a business key not in response
	 *
	 * @param businessKey   the business key
	 * @param effectiveDate the effective date of the business key
	 */
	public void verifyNoBusinessKeyVersion(String businessKey, String effectiveDate) {
		LOG.info(String.format("the client receives no version for business key %s with effective date %s",
				businessKey, effectiveDate));

		assertThat(this.byTableNameResponse, notNullValue());
		assertThat(this.byTableNameResponse, not(empty()));

		final Map<String, Object> valueMap = this.byTableNameResponse.parallelStream()
				.filter(map -> map.get("business_key").equals(businessKey) && map.get("eff_dt").equals(effectiveDate))
				.findAny()
				.orElse(null);

		assertThat(valueMap, nullValue());
	}

	/**
	 * Verify a particular column's value
	 *
	 * @param businessKey the business key of the row
	 * @param column      the column
	 * @param value       the value
	 */
	public void verifyColumnValue(String businessKey, String column, String value) {
		LOG.info(String.format("the client receives value for business key %s and column %s is %s", businessKey, column, value));

		final Map<String, Object> valueMap;

		if (this.byTableNameResponse != null) {
			valueMap = this.byTableNameResponse.parallelStream()
					.filter(map -> map.get("business_key").equals(businessKey))
					.findAny()
					.orElse(null);
		} else if (this.byTableNameAndBusinessKeyResponse != null) {
			valueMap = this.byTableNameAndBusinessKeyResponse;
		} else {
			return;
		}

		assertThat(valueMap, notNullValue());
		assertThat(valueMap, hasEntry("business_key", businessKey));
		assertThat(valueMap, hasEntry(column, value));
	}

	/**
	 * Verify a particular column's value of a version
	 *
	 * @param businessKey   the business key of the row
	 * @param effectiveDate the effective date of the business key
	 * @param column        the column
	 * @param value         the value
	 */
	public void verifyVersionedColumnValue(String businessKey, String effectiveDate, String column, String value) {
		LOG.info(String.format("the client receives version for business key %s with effective date %s and column %s is %s",
				businessKey, effectiveDate, column, value));

		final Map<String, Object> valueMap;

		if (this.byTableNameResponse != null) {
			valueMap = this.byTableNameResponse.parallelStream()
					.filter(map -> map.get("business_key").equals(businessKey) && map.get("eff_dt").equals(effectiveDate))
					.findAny()
					.orElse(null);
		} else if (this.byTableNameAndBusinessKeyResponse != null) {
			valueMap = this.byTableNameAndBusinessKeyResponse;
		} else {
			return;
		}

		assertThat(valueMap, notNullValue());
		assertThat(valueMap, hasEntry("business_key", businessKey));
		assertThat(valueMap, hasEntry("eff_dt", effectiveDate));
		assertThat(valueMap, hasEntry(column, value));
	}

	private void performByTableNameRequest(String path, List<NameValuePair> nvps) throws IOException {
		final String content = performGetRequest(path, nvps);
		final TypeReference<List<Map<String, Object>>> typeReference = new TypeReference<List<Map<String, Object>>>() {
		};
		if (content != null) {
			this.byTableNameResponse = new ObjectMapper().readValue(content, typeReference);
		}
	}

	private void performByTableNameAndBusinessKeyRequest(String path, List<NameValuePair> nvps) throws IOException {
		final String content = performGetRequest(path, nvps);
		final TypeReference<Map<String, Object>> typeReference = new TypeReference<Map<String, Object>>() {
		};
		if (content != null) {
			this.byTableNameAndBusinessKeyResponse = new ObjectMapper().readValue(content, typeReference);
		}
	}
}
