package com.ing.grdm.api.cache;

import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.database.GrdmApiCategoryDefinitionRepository;
import com.ing.grdm.domain.ApiCategoryDefinition;
import com.ing.grdm.event.AttributesDataChangedEvent;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Unit tests for {@link SearchCache} pertaining to table search
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 13-12-2017
 */
@ActiveProfiles({"test", "searchCache"})
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.cache.categories.exclude=gender")
@RunWith(SpringRunner.class)
public class TableNameSearchCacheTest {

	@Autowired
	private GrdmApiCategoryDefinitionRepository categoryDefinitionRepository;
	@Autowired
	private SearchCache searchCache;
	@Autowired
	private ApplicationEventPublisher publisher;

	@Test
	public void testSearch() throws IOException {
		List<Map<String, Object>> tableSearchResults;
		List<Map<String, String>> linksList;
		assertThat(this.searchCache.searchDistributionName("cOuNtry").isEmpty(), is(true));

		// signal search cache to reload
		publisher.publishEvent(new AttributesDataChangedEvent());

		// search a table loaded in cache and verify table name is case insensitive
		tableSearchResults = this.searchCache.searchDistributionName("coUnTrY");
		assertThat(tableSearchResults.isEmpty(), is(false));
		assertThat(tableSearchResults.size(), is(1));
		assertThat(tableSearchResults.get(0).containsKey("table"), is(true));
		assertThat(tableSearchResults.get(0).get("table"), is("country"));
		assertThat(tableSearchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) tableSearchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).containsKey("rel"), is(true));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).containsKey("href"), is(true));
		assertThat(linksList.get(0).get("href"), is("/attributes/country"));

		// search table loaded in cache by interchanging letters and verify table name is case insensitive
		tableSearchResults = this.searchCache.searchDistributionName("coNuTyR");
		assertThat(tableSearchResults.isEmpty(), is(false));
		assertThat(tableSearchResults.size(), is(1));
		assertThat(tableSearchResults.get(0).containsKey("table"), is(true));
		assertThat(tableSearchResults.get(0).get("table"), is("country"));
		assertThat(tableSearchResults.get(0).containsKey("links"), is(true));
		linksList = (List<Map<String, String>>) tableSearchResults.get(0).get("links");
		assertThat(linksList.size(), is(1));
		assertThat(linksList.get(0).containsKey("rel"), is(true));
		assertThat(linksList.get(0).get("rel"), is("self"));
		assertThat(linksList.get(0).containsKey("href"), is(true));
		assertThat(linksList.get(0).get("href"), is("/attributes/country"));

		// search a table loaded in cache with less than minimum letters required for fuzzy search
		tableSearchResults = this.searchCache.searchDistributionName("coun");
		assertThat(tableSearchResults.isEmpty(), is(true));

		// search a table that is excluded in cache
		tableSearchResults = this.searchCache.searchDistributionName("genDer");
		assertThat(tableSearchResults.isEmpty(), is(true));
	}

	@Before
	public void loadApiCategoryDefinition() {
		// Signal cache to reload just to be doubly sure that fresh indexes are created
		publisher.publishEvent(new AttributesDataChangedEvent(true));

		ApiCategoryDefinition apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("COUNTRY");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);

		apiCategoryDefinition = new ApiCategoryDefinition();
		apiCategoryDefinition.setActiveDistributionSequenceNumber(1);
		apiCategoryDefinition.setDistributionName("GENDER");
		apiCategoryDefinition.setCategoryType("Attributes");
		this.categoryDefinitionRepository.save(apiCategoryDefinition);
	}

	@After
	public void after() {
		// This test commits data to in-memory database, make sure it's deleted afterwards
		// Committing is required to so the data inserted in the database can be loaded by the caching mechanism
		this.categoryDefinitionRepository.deleteAll();
	}
}
