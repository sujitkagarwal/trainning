package com.ing.grdm.cucumber.steps;

import com.ing.grdm.cucumber.delegate.GrdmApiResponse;
import cucumber.api.java8.En;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

/**
 * Test steps used in different features.
 */
@SuppressWarnings("unused")
public class GrdmApiSharedTestSteps implements En {

	private static final Log LOG = LogFactory.getLog(GrdmApiSharedTestSteps.class);

	@Autowired
	public GrdmApiSharedTestSteps(GrdmApiResponse response) {

		Then("^the client receives status code (\\d+)$", (Integer statusCode) -> {
			LOG.info(String.format("the client receives status code of %d", statusCode));

			assertThat(response.getResponseStatus(), is(statusCode));
		});

		And("^the client receives status message '(.*)'$", (String statusMessage) -> {
			LOG.info(String.format("the client receives status message as %s", statusMessage));

			assertThat(response.getResponseMessage(), is(statusMessage));
		});

	}
}
