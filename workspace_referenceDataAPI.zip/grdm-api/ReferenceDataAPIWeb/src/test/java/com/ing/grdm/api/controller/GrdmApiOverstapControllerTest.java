package com.ing.grdm.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ing.grdm.api.GrdmApiTestApplication;
import com.ing.grdm.api.cache.OverstapCache;
import com.ing.grdm.api.domain.ForwardAccount;
import com.ing.grdm.api.domain.ForwardAccountsRequestData;
import org.assertj.core.util.Lists;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

/**
 * Unit test for {@link GrdmApiOverstapController}
 *
 * @author Purushottam Selvan Yadav
 * @version 1.0
 * @since 28-11-2017
 */
@ActiveProfiles("test")
@SpringBootTest(classes = GrdmApiTestApplication.class, properties = "grdm.cache.overstap.enable=true")
@AutoConfigureMockMvc
@RunWith(SpringRunner.class)
public class GrdmApiOverstapControllerTest {
	private static final List<String> oldIbans = Arrays.asList("NL03INGB0000461686", "NL19INGB0000458973");
	private static final LocalDate filterDate = LocalDate.of(2017, 02, 03);
	private static final ForwardAccountsRequestData requestData = createForwardAccountsRequestData(oldIbans, null);
	private static final ForwardAccountsRequestData requestDataWithFilterDate = createForwardAccountsRequestData(oldIbans, filterDate);

	@Autowired
	private GrdmApiOverstapController overstapController;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@MockBean
	private OverstapCache overstapCache;

	@Test
	public void controllerInitializedCorrectly() {
		assertThat(overstapController).isNotNull();
	}

	@Test
	public void testForwardAccounts() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, null)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(objectMapper.writeValueAsString(requestData)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(notNullValue())))
				.andExpect(jsonPath("$.forwardAccounts[0].accountId", is("NL19INGB0000458973")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountId", is("NL80RABO0310612306")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountBIC", is("RABONL2U")))
				.andExpect(jsonPath("$.forwardAccounts[0].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[0].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].accountId", is("NL03INGB0000461686")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountId", is("NL91SNSB0856282219")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountBIC", is("SNSBNL2A")))
				.andExpect(jsonPath("$.forwardAccounts[1].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.filterDate").doesNotExist());
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_RequestBodyInXMLFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, null)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, null)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(notNullValue())))
				.andExpect(jsonPath("$.forwardAccounts[0].accountId", is("NL19INGB0000458973")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountId", is("NL80RABO0310612306")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountBIC", is("RABONL2U")))
				.andExpect(jsonPath("$.forwardAccounts[0].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[0].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].accountId", is("NL03INGB0000461686")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountId", is("NL91SNSB0856282219")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountBIC", is("SNSBNL2A")))
				.andExpect(jsonPath("$.forwardAccounts[1].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.filterDate").doesNotExist());
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_ResponseInXMLFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, null)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, null))
				.accept(MediaType.APPLICATION_XML))
				.andExpect(status().isOk())
				.andExpect(content().xml(createForwardAccountsResponseInXml(false, null)));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccountsWithFilterDate() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, filterDate)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(objectMapper.writeValueAsString(requestDataWithFilterDate)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(notNullValue())))
				.andExpect(jsonPath("$.forwardAccounts[0].accountId", is("NL19INGB0000458973")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountId", is("NL80RABO0310612306")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountBIC", is("RABONL2U")))
				.andExpect(jsonPath("$.forwardAccounts[0].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[0].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].accountId", is("NL03INGB0000461686")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountId", is("NL91SNSB0856282219")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountBIC", is("SNSBNL2A")))
				.andExpect(jsonPath("$.forwardAccounts[1].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.filterDate", is("2017-02-03")));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, filterDate);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccountsWithFilterDate_RequestBodyInXMLFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, filterDate)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, filterDate)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(notNullValue())))
				.andExpect(jsonPath("$.forwardAccounts[0].accountId", is("NL19INGB0000458973")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountId", is("NL80RABO0310612306")))
				.andExpect(jsonPath("$.forwardAccounts[0].forwardAccountBIC", is("RABONL2U")))
				.andExpect(jsonPath("$.forwardAccounts[0].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[0].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].accountId", is("NL03INGB0000461686")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountId", is("NL91SNSB0856282219")))
				.andExpect(jsonPath("$.forwardAccounts[1].forwardAccountBIC", is("SNSBNL2A")))
				.andExpect(jsonPath("$.forwardAccounts[1].startDate", is("2016-07-21")))
				.andExpect(jsonPath("$.forwardAccounts[1].expirationDate", is("2017-08-21")))
				.andExpect(jsonPath("$.filterDate", is("2017-02-03")));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, filterDate);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccountsWithFilterDate_ResponseInXmlFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, filterDate)).thenReturn(createForwardAccounts());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, filterDate))
				.accept(MediaType.APPLICATION_XML))
				.andExpect(status().isOk())
				.andExpect(content().xml(createForwardAccountsResponseInXml(false, filterDate)));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, filterDate);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_EmptyResponse() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, null)).thenReturn(Lists.newArrayList());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(objectMapper.writeValueAsString(requestData)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(empty())))
				.andExpect(jsonPath("$.filterDate").doesNotExist());
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_EmptyResponseInXmlFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, null)).thenReturn(Lists.newArrayList());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, null))
				.accept(MediaType.APPLICATION_XML))
				.andExpect(status().isOk())
				.andExpect(content().xml(createForwardAccountsResponseInXml(true, null)));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccountsWithFilterDate_EmptyResponse() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, filterDate)).thenReturn(Lists.newArrayList());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(objectMapper.writeValueAsString(requestDataWithFilterDate)))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.forwardAccounts", is(empty())))
				.andExpect(jsonPath("$.filterDate", is("2017-02-03")));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, filterDate);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccountsWithFilterDate_EmptyResponseInXmlFormat() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(oldIbans, filterDate)).thenReturn(Lists.newArrayList());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_XML)
				.content(createForwardAccountsRequestDataInXml(oldIbans, filterDate))
				.accept(MediaType.APPLICATION_XML))
				.andExpect(status().isOk())
				.andExpect(content().xml(createForwardAccountsResponseInXml(true, filterDate)));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(oldIbans, filterDate);
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_InvalidAccountId() throws Exception {
		final ForwardAccountsRequestData requestData =
				createForwardAccountsRequestData(Arrays.asList("NLW03INGB0000461686", "NL19INGB0000458973"), null);
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(objectMapper.writeValueAsString(requestData)))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("invalid accountId provided")));
		verify(overstapCache, never()).getForwardAccountsByIbansAndDate(Mockito.any(), Mockito.any());
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_RuntimeException() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(Mockito.any(), Mockito.any())).thenThrow(new RuntimeException());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(requestData)))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.code", is(500)))
				.andExpect(jsonPath("$.message", is("Internal Server Error")));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(Mockito.any(), Mockito.any());
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_IllegalArgumentException() throws Exception {
		when(this.overstapCache.getForwardAccountsByIbansAndDate(Mockito.any(), Mockito.any())).thenThrow(new IllegalArgumentException());
		mockMvc.perform(post("/forwarding-accounts")
				.contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(objectMapper.writeValueAsString(requestData)))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.code", is(400)))
				.andExpect(jsonPath("$.message", is("Bad Request")));
		verify(overstapCache, times(1)).getForwardAccountsByIbansAndDate(Mockito.any(), Mockito.any());
		verifyNoMoreInteractions(overstapCache);
	}

	@Test
	public void testForwardAccounts_MethodNotSupportedException() throws Exception {
		mockMvc.perform(get("/forwarding-accounts?accountIds=NL03INGB0000461686&accountIds=NL19INGB0000458973"))
				.andExpect(status().isMethodNotAllowed());
		verify(overstapCache, never()).getForwardAccountsByIbansAndDate(oldIbans, null);
		verifyNoMoreInteractions(overstapCache);
	}

	private List<ForwardAccount> createForwardAccounts() {
		final List<ForwardAccount> forwardAccountsList = Lists.newArrayList();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		ForwardAccount forwardAccount =
				new ForwardAccount("NL19INGB0000458973", LocalDate.parse("2016-07-21", formatter), "NL80RABO0310612306", "RABONL2U",
						LocalDate.parse("2017-08-21", formatter));
		forwardAccountsList.add(forwardAccount);
		forwardAccount =
				new ForwardAccount("NL03INGB0000461686", LocalDate.parse("2016-07-21", formatter), "NL91SNSB0856282219", "SNSBNL2A",
						LocalDate.parse("2017-08-21", formatter));
		forwardAccountsList.add(forwardAccount);
		return forwardAccountsList;
	}

	private static ForwardAccountsRequestData createForwardAccountsRequestData(final List<String> oldIbans, final LocalDate filterDate) {
		final ForwardAccountsRequestData forwardAccountsRequestData = new ForwardAccountsRequestData();
		forwardAccountsRequestData.setAccountIds(oldIbans);
		forwardAccountsRequestData.setFilterDate(filterDate);
		return forwardAccountsRequestData;
	}

	private String createForwardAccountsRequestDataInXml(final List<String> oldIbans, final LocalDate filterDate) {
		final StringBuilder requestDataInXml = new StringBuilder("<forwardAccountsRequestData><accountIds>");
		for (String accountId : oldIbans) {
			requestDataInXml.append("<accountId>").append(accountId).append("</accountId>");
		}
		requestDataInXml.append("</accountIds>");
		if (filterDate != null) {
			requestDataInXml.append("<filterDate>").append(filterDate).append("</filterDate>");
		}
		return requestDataInXml.append("</forwardAccountsRequestData>").toString();
	}

	private String createForwardAccountsResponseInXml(boolean emptyResponse , LocalDate filterDate) {
		final StringBuilder responseInXml = new StringBuilder("<forwardAccountsResponseData>");
		if (emptyResponse) {
			responseInXml.append("<forwardAccounts/>");
			if (filterDate != null) {
				responseInXml.append("<filterDate>").append(filterDate).append("</filterDate>");
			}
		} else {
			responseInXml.append("<forwardAccounts><forwardAccount><accountId>NL19INGB0000458973</accountId><forwardAccountId>")
					.append("NL80RABO0310612306</forwardAccountId><forwardAccountBIC>RABONL2U</forwardAccountBIC><startDate>2016-07-21")
					.append("</startDate><expirationDate>2017-08-21</expirationDate></forwardAccount><forwardAccount>")
					.append("<accountId>NL03INGB0000461686</accountId><forwardAccountId>NL91SNSB0856282219</forwardAccountId>")
					.append("<forwardAccountBIC>SNSBNL2A</forwardAccountBIC><startDate>2016-07-21</startDate><expirationDate>2017-08-21")
					.append("</expirationDate></forwardAccount></forwardAccounts>");
			if (filterDate != null) {
				responseInXml.append("<filterDate>").append(filterDate).append("</filterDate>");
			}
		}
		return responseInXml.append("</forwardAccountsResponseData>").toString();
	}
}