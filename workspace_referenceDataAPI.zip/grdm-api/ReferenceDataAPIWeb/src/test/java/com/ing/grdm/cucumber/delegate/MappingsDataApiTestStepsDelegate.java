package com.ing.grdm.cucumber.delegate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertThat;

/**
 * Delegate class executing the actual test steps for Mappings Data API. Needs to be wired in the cucumber glue class.
 */
@Component
@Scope("cucumber-glue")
public class MappingsDataApiTestStepsDelegate extends GrdmApiTestStepsDelegate {

	private static final Log LOG = LogFactory.getLog(MappingsDataApiTestStepsDelegate.class);

	@Autowired
	private ObjectMapper objectMapper;

	private Map<String, List<Map<String, String>>> globalMappingsResponse;
	private Map<String, Object> globalCodeResponse;
	private Map<String, List<Map<String, Object>>> localMappingsResponse;
	private Map<String, List<String>> localCodesResponse;

	public void requestGlobalMappingsBySystemCode(String distributionName, String systemCode) throws IOException {
		LOG.info(String.format("requestGlobalMappingsBySystemCode %s %s", distributionName, systemCode));
		performRequestGlobalMappingsBySystemCode(distributionName, systemCode);
	}

	public void requestGlobalCodeByLocalCode(String distributionName, String systemCode, String localCode) throws IOException {
		LOG.info(String.format("requestGlobalCodeByLocalCode %s %s %s", distributionName, systemCode, localCode));
		performRequestGlobalCodeByLocalCode(distributionName, systemCode, localCode);
	}

	public void requestLocalMappingsBySystemCode(String distributionName, String systemCode) throws IOException {
		LOG.info(String.format("requestLocalMappingsBySystemCode %s %s", distributionName, systemCode));
		performRequestLocalMappingsBySystemCode(distributionName, systemCode);
	}

	public void requestLocalCodesByGlobalCode(String distributionName, String systemCode, String globalCode) throws IOException {
		LOG.info(String.format("requestLocalCodeByGlobalCode %s %s %s", distributionName, systemCode, globalCode));
		performRequestLocalCodesByGlobalCode(distributionName, systemCode, globalCode);
	}

	public void verifyGlobalMappings(String localCode, String globalCode) {
		LOG.info(String.format("verifyGlobalMappings %s %s", localCode, globalCode));

		assertThat(this.globalMappingsResponse, notNullValue());
		assertThat(this.globalMappingsResponse.entrySet(), not(empty()));
		assertThat(this.globalMappingsResponse.get("data"), not(empty()));
		assertThat(this.globalMappingsResponse.get("data"), hasItem(
				ImmutableMap.of("local", localCode, "global", globalCode)));
	}

	@SuppressWarnings("unchecked")
	public void verifyGlobalCode(String globalCode) {
		LOG.info(String.format("verifyGlobalCode %s", globalCode));

		assertThat(this.globalCodeResponse, notNullValue());
		assertThat(this.globalCodeResponse.entrySet(), not(empty()));
		assertThat(this.globalCodeResponse, hasEntry("code", globalCode));
		assertThat(this.globalCodeResponse, hasKey("links"));

		final List<Map<String, String>> links = (List<Map<String, String>>) this.globalCodeResponse.get("links");
		assertThat(links, hasSize(1));
		assertThat(links.get(0), hasEntry("rel", "attributes"));
		assertThat(links.get(0), hasEntry("href", "/attributes/country/" + globalCode));
	}

	@SuppressWarnings("unchecked")
	public void verifyLocalMappings(String globalCode, String localMappings) {
		LOG.info(String.format("verifyLocalMappings %s [%s]", globalCode, localMappings));

		assertThat(this.localMappingsResponse, notNullValue());
		assertThat(this.localMappingsResponse, hasKey("data"));
		assertThat(this.localMappingsResponse.get("data"), not(empty()));

		final Map<String, List<String>> data = this.localMappingsResponse.get("data").stream().collect(Collectors.toMap(
				item -> (String) item.get("global"),
				item -> (List<String>) item.get("local")));

		final Pattern pattern = Pattern.compile("'([^']*)'");
		final Matcher matcher = pattern.matcher(localMappings);
		while (matcher.find()) {
			assertThat(data, hasKey(globalCode));
			assertThat(data.get(globalCode), hasItem(matcher.group(1)));
		}
	}

	public void verifyLocalCodes(String localCodes) {
		LOG.info(String.format("verifyLocalCodes [%s]", localCodes));

		assertThat(this.localCodesResponse, notNullValue());
		assertThat(this.localCodesResponse, hasKey("data"));
		assertThat(this.localCodesResponse.get("data"), hasSize(2));

		final Pattern pattern = Pattern.compile("'([^']*)'");
		final Matcher matcher = pattern.matcher(localCodes);
		while (matcher.find()) {
			assertThat(this.localCodesResponse.get("data"), hasItem(matcher.group(1)));
		}
	}

	private void performRequestGlobalMappingsBySystemCode(String distributionName, String systemCode)
			throws IOException {
		final String content = performRequest("global", distributionName, systemCode);

		if (content != null) {
			this.globalMappingsResponse =
					this.objectMapper.readValue(content, new TypeReference<Map<String, List<Map<String, String>>>>() {
					});
		}
	}

	private void performRequestGlobalCodeByLocalCode(String distributionName, String systemCode, String localCode)
			throws IOException {
		final String content = performRequest("global", distributionName, systemCode, localCode);

		if (content != null) {
			this.globalCodeResponse = this.objectMapper.readValue(content, new TypeReference<Map<String, Object>>() {
			});
		}
	}

	private void performRequestLocalMappingsBySystemCode(String distributionName, String systemCode) throws IOException {
		final String content = performRequest("local", distributionName, systemCode);

		if (content != null) {
			this.localMappingsResponse =
					this.objectMapper.readValue(content, new TypeReference<Map<String, List<Map<String, Object>>>>() {
					});
		}
	}

	private void performRequestLocalCodesByGlobalCode(String distributionName, String systemCode, String globalCode)
			throws IOException {
		final String content = performRequest("local", distributionName, systemCode, globalCode);
		if (content != null) {
			this.localCodesResponse = this.objectMapper
					.readValue(content, new TypeReference<Map<String, List<String>>>() {
					});
		}
	}

	private String performRequest(String... pathElements) throws IOException {
		final StringJoiner pathJoiner = new StringJoiner("/", "/", "")
				.add("reference-data").add("mappings");
		Arrays.stream(pathElements).filter(Objects::nonNull).forEach(pathJoiner::add);
		return performGetRequest(pathJoiner.toString(), null);
	}
}
