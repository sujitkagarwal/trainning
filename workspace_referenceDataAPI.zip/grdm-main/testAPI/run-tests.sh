apath="/apache-jmeter/bin/"
spath="/testscripts/"
rpath="/testresults/"

tests=$(ls "$spath")

echo 'hello from run-tests'